
package com.scb
import org.apache.spark.{SparkConf,SparkContext}
import org.apache.spark.sql.hive.HiveContext


class MSCKTest{
}
object MSCKTest{
  def main(args:Array [String])
  {
    val sparkConf = new SparkConf().setAppName("process").setMaster("local")
    val sc = new SparkContext(sparkConf)
    println("connecting to Spark");
    val hiveContext = new HiveContext(sc)
    println("connecting to hive context");

    val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)
    println("connecting to sql contect");

    println("sql context created"+sqlContext)
    //CTRLFW/EBBS/HAAS/$env/processing/get_partitions/$cnty/$source$env_$cnty_$env_landing_TABLES.txt")

    val database = "oat_landing"
    val name     = "ebbsoat_cn"

    val df1 = sqlContext.sql("use $database")
    df1.collect.foreach(println)
    val df2 = sqlContext.sql("show tables like '$name'")
    //val df1 = sc.textFile("/CTRLFW/EBBS/HAAS/$env/processing/get_partitions/$cnty/$source$env_$cnty_$env_landing_TABLES.txt")

    var df3 = df2.collect().foreach(println)
    val tab = Set(df3)
    tab.foreach{
      x=>println(x)
        sqlContext.sql("MSCK REPAIR TABLE "+ x)
        println("Executed successfully:pass")
    }

  }
}

