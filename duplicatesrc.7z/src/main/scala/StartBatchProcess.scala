
import java.io.{File, FileInputStream}
import java.nio.file.{Files, Paths, StandardCopyOption}
import java.security.PrivilegedAction
import java.text.SimpleDateFormat
import java.util.{Calendar, Properties}

import org.apache.commons.io.FileUtils
import org.apache.hadoop.security.UserGroupInformation
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SQLContext}
import org.apache.spark.sql.functions.lit
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.sql.hive.HiveContext

import scala.collection.parallel.immutable.ParSeq
import scala.io.Source
import scala.util.Try
import scala.util.control.Breaks.breakable

object StartBatchProcess {

  val now = Calendar.getInstance().getTime()
  val formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val currentTime = formatter.format(now)


  def main(args: Array[String]): Unit = {

    if (args.length <= 3) {
      sys.error("Usage : StartBatchProcess <source> <country> <NAS base directory> <partitiondate> <hdfsuser> ")
      System.exit(1)
    } else {

      implicit val conf = new SparkConf().setAppName("Migration").setMaster("local")
      implicit val sc = new SparkContext(conf)
      implicit val sqlContext = new HiveContext(sc)

      startExtraction(sc, sqlContext, args)
    }
  }

  def startExtraction(sc: SparkContext, sqlContext: SQLContext, args: Array[String]): Unit = {

    val source = args(0) //sourceSystem
    val country = args(1) //country
    val baseDir = args(2) //base dir
    val DELTA_DATE = args(3)

    val tableProperties = getProperties(baseDir)(source)

    val sourceParam = SourceParam(source, country, DELTA_DATE)

    val destDir = s"$baseDir/$source/downstream/"
    val sriOpenSchema = tableProperties.schemaProp.get(s"${source.toUpperCase}_SRI_OPEN").toString
    val auditTableSchema = tableProperties.schemaProp.get("AUDIT_DB").toString
    val eodTableName = tableProperties.schemaProp.getOrDefault(s"${source.toUpperCase}_EOD_TABLE", "").toString
    import sqlContext.implicits._
    val deltaTablePartition = getPartitionForMaster(sqlContext)(sriOpenSchema)(eodTableName)(DELTA_DATE)

    val inputHqlFiles = getListOfFiles(s"$baseDir/$source/hqlfiles/")
    import util.control.Breaks._

    inputHqlFiles.foreach(queryFilter(sriOpenSchema)(tableProperties)(DELTA_DATE)(deltaTablePartition)(_).foreach((data: (String, String)) => {

      breakable {
        val recordDataFrame = Try(sqlContext.sql(data._1)).getOrElse(null)
        if (null == recordDataFrame) {
          sc.parallelize(Seq(data._2)).toDF().write.format("com.databricks.spark.csv").mode("append").save(s"file:///$baseDir/$source/reject/")
          break
        }
        val rowCount = recordDataFrame.count()
        val tableName = data._2

        val outputDataFrame = formattedRecord(sc)(sqlContext)(sourceParam)(tableProperties)(recordDataFrame)(tableName)(rowCount)
        deleteFile(s"$destDir/${source.toUpperCase}_${country.toUpperCase}_${tableName.toUpperCase}_${DELTA_DATE.replace("-", "")}.dat")
        outputDataFrame.write.format("com.databricks.spark.csv").mode("overwrite").save(s"file:///$destDir/${tableName}_tmp/")

        populateRowCount(sc)(sqlContext)(sourceParam)(auditTableSchema)(tableName)(rowCount)
        formatDirectory(sourceParam)(destDir)(tableName)
      }
    }))
  }


  val getPartitionForMaster: SQLContext => String => String => String => String = sqlContext => eodSchema => {
    case eodTableName if eodTableName.isEmpty => businessDate => businessDate
    case eodTableName => businessDate => {
      val df = sqlContext.sql(s"select eds from $eodSchema.$eodTableName where batch_date='$businessDate'")
      if (df.take(1).length != 0) {
        df.collect()(0).get(0).toString
      }
      else {
        throw new Exception("Partition date is not available in EOD TABLE for the business date" + businessDate)
      }
    }
  }

  val queryFilter: String => TableProperties => String => String => File => ParSeq[(String, String)] = sriOpenSchema => tableProperties => businessDate => deltaPartitionDate => file => {
    Source.fromFile(file).getLines.toList.flatMap(_.split(";")).par.filter(_.toLowerCase.startsWith("select "))
      .par.map(data => {
      val sourceDetails = data.split("\\.")(1).split(" ")(0).split("_")
      val tableName = getTableName(sourceDetails)
      val tableType = tableProperties.tableTypeProp.getOrDefault(tableName, "").toString
      val partitionDate = if (tableType.toLowerCase == "txn") businessDate else deltaPartitionDate
      val finalQuery = data.replace("SRI_OPEN", sriOpenSchema).replace("DELTA_DATE", partitionDate)
      (finalQuery, tableName)
    }).par
  }

  case class SourceParam(source: String, country: String, businessDate: String)

  case class TableProperties(primaryKeyProp: Properties, schemaProp: Properties, tableTypeProp: Properties)

  val formattedRecord: SparkContext => SQLContext => SourceParam => TableProperties => DataFrame => String => Long => DataFrame = sc =>
    sqlContext => sourceParam =>
      tableProperties => recordDataFrame =>
        tableName => rowCount => {
          val dataRdd = recordDataFrame.rdd.map {
            _.mkString("\u0001")
          }
          val tableSchema = `parallelize Rdd`(sc)(recordDataFrame.columns.mkString("\u0001"))
          val header: RDD[String] = `parallelize Rdd`(sc)(s"H\u0001${tableName}\u0001${tableProperties.tableTypeProp.get(tableName)}\u0001${tableProperties.primaryKeyProp.get(tableName)}")
          val trailer: RDD[String] = `parallelize Rdd`(sc)(s"T\u0001${sourceParam.country}\u0001${sourceParam.source}\u0001${sourceParam.businessDate.replace("-", "")}\u0001$rowCount")

          import sqlContext.implicits._

          val headerRdd = header.union(tableSchema).toDF().withColumn("order", lit(1))
          val outDf = dataRdd.union(trailer).toDF().withColumn("order", lit(2))
          headerRdd.union(outDf).orderBy("order").coalesce(1).drop("order")
        }


  val populateRowCount: SparkContext => SQLContext => SourceParam => String => String => Long => Unit = sc => sqlContext => sourceParam =>
    auditTableSchema =>
      tableName => count => {
        import sqlContext.implicits._
        val rowCount: RDD[String] = `parallelize Rdd`(sc)(s"NULL\u0001NULL\u0001${sourceParam.source}\u0001${tableName}\u0001${count}\u0001FOUND\u0001NULL\u0001NULL\u0001${currentTime}")

        rowCount.toDF().write.format("com.databricks.spark.csv").mode("overwrite")
          .save(s"/dev/cndl/hdata/$auditTableSchema/rowcounts_audit/workflowname=${sourceParam.source}/bday=${sourceParam.businessDate.replace("-", "")}/")
      }

  val getTableName: Array[String] => String = {
    case sourceDetails if sourceDetails.length >= 3 => sourceDetails.drop(2).mkString("_")
    case sourceDetails if sourceDetails.length >= 2 => sourceDetails(1)
    case sourceDetails => sourceDetails(0)
  }

  val `parallelize Rdd`: SparkContext => String => RDD[String] = sc => input => {
    sc.parallelize(Seq(input))
  }

  val formatDirectory: SourceParam => String => String => Unit = sourceParam => destDir => {
    tableName =>
      Files.move(Paths.get(getListOfFiles(s"$destDir/${tableName}_tmp/").filter(_.getName.startsWith("part"))(0).getAbsolutePath),
        Paths.get(s"$destDir/${sourceParam.source.toUpperCase}_${sourceParam.country.toUpperCase}_${tableName.toUpperCase}_${sourceParam.businessDate.replace("-", "")}.dat"),
        StandardCopyOption.ATOMIC_MOVE)
      FileUtils.cleanDirectory(new File(s"$destDir/${tableName}_tmp/"));
      deleteFile(s"$destDir/${tableName}_tmp/")
  }

  val deleteFile: String => Unit = dir => {
    Files.deleteIfExists(Paths.get(dir))
  }


  val getProperties: String => String => TableProperties = baseDir => source => {
    val primaryKeyProp = populateProperty(s"$baseDir/$source/config/Table_type_config")
    val tableTypeProp = populateProperty(s"$baseDir/$source/config/primary_keys")
    val schemaProp = populateProperty(s"$baseDir/$source/config/CNDL_downstream_info.txt")
    TableProperties(primaryKeyProp, schemaProp, tableTypeProp)
  }


  val populateProperty: String => Properties = dir => {
    val props = new Properties()
    props.load(new FileInputStream(dir))
    props
  }


  def moveFile(oldName: String, newName: String): Boolean =
    Try(new File(oldName).renameTo(new File(newName))).getOrElse(false)

  val getListOfFiles: String => List[File] = dir => {
    val d = new File(dir)
    if (d.exists && d.isDirectory) {
      d.listFiles.filter(_.isFile).toList
    } else {
      List[File]()
    }
  }


}

