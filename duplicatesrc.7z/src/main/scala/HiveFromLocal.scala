import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.{SparkConf, SparkContext}

object HiveFromLocal {
  def main(args: Array[String]): Unit = {

  val sparkConf=new SparkConf().setAppName("test1").setMaster("local[*]")
  val sc=new SparkContext(sparkConf)
  val sqlContext=new HiveContext(sc)
  val df=sqlContext.sql("select count(*) from icdd_snapshot.icdd_ae_vcddprfctryrelatnall ")
  df.show()
  println("hi")


}


}
