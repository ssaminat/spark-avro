import java.util.*;

import org.omg.CORBA.BAD_CONTEXT;

import java.sql.*;

public class BankDao {

	public static Connection getConnection(){
		Connection con=null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","oracle");
		}catch(Exception e){System.out.println(e);}
		return con;
	}
	public static int save(BankDetails e){
		int status=0;
		try{
			Connection con=BankDao.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into BankDetails(account_no,customer_name,ifsc_code,ifsc_code,account_type) values (?,?,?,?,?)");
			ps.setInt(1,e.getAccount_no());
			ps.setString(2,e.getCustomer_name());
			ps.setString(3,e.getIfsc_code());
			ps.setString(4,e.getBranch_name());
			ps.setString(5,e.getAccount_type());	
			
			status=ps.executeUpdate();
			
			con.close();
		}catch(Exception ex){ex.printStackTrace();}
		
		return status;
	}
	public static int update(BankDetails e){
		int status=0;
		try{
			Connection con=BankDao.getConnection();
			PreparedStatement ps=con.prepareStatement("update BankDetails set customer_name=?,ifsc_code=?,ifsc_code=?,account_type=? where account_no=?");
			ps.setInt(5,e.getAccount_no());
			ps.setString(1,e.getCustomer_name());
			ps.setString(2,e.getIfsc_code());
			ps.setString(3,e.getBranch_name());
			ps.setString(4,e.getAccount_type());	
			
			status=ps.executeUpdate();
			
			con.close();
		}catch(Exception ex){ex.printStackTrace();}
		
		return status;
	}
	public static int delete(int account_no){
		int status=0;
		try{
			Connection con=BankDao.getConnection();
			PreparedStatement ps=con.prepareStatement("delete from BankDetails where account_no=?");
			ps.setInt(1,account_no);
			status=ps.executeUpdate();
			
			con.close();
		}catch(Exception e){e.printStackTrace();}
		
		return status;
	}
	public static BankDetails getCustomereByAccno(int account_no){
		BankDetails e=new BankDetails();
		
		try{
			Connection con=BankDao.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from BankDetails where account_no=?");
			ps.setInt(1,account_no);
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				e.setAccount_no(rs.getInt(1));
				e.setCustomer_name(rs.getString(2));
				e.setIfsc_code(rs.getString(3));
				e.setBranch_name(rs.getString(4));
				e.setAccount_type(rs.getString(5));
			}
			con.close();
		}catch(Exception ex){ex.printStackTrace();}
		
		return e;
	}
	public static List<BankDetails> getAllCustomers(){
		List<BankDetails> list=new ArrayList<BankDetails>();
		
		try{
			Connection con=BankDao.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from BankDetails");
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				BankDetails e=new BankDetails();
				e.setAccount_no(rs.getInt(1));
				e.setCustomer_name(rs.getString(2));
				e.setIfsc_code(rs.getString(3));
				e.setBranch_name(rs.getString(4));
				e.setAccount_type(rs.getString(5));
				list.add(e);
			}
			con.close();
		}catch(Exception e){e.printStackTrace();}
		
		return list;
	}
}
