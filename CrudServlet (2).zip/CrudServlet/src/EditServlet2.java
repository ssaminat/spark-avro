

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/EditServlet2")
public class EditServlet2 extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String accno=request.getParameter("account_no");
		int account_no=Integer.parseInt(accno);
		String customer_name=request.getParameter("customer_name");
		String ifsc_code=request.getParameter("ifsc_code");
		String branch_name=request.getParameter("branch_name");
		String account_type=request.getParameter("account_type");
		
		BankDetails e=new BankDetails();
		e.setAccount_no(account_no);
		e.setCustomer_name(customer_name);
		e.setIfsc_code(ifsc_code);
		e.setBranch_name(branch_name);
		e.setAccount_type(account_type);		
		int status=BankDao.update(e);
		if(status>0){
			response.sendRedirect("ViewServlet");
		}else{
			out.println("Sorry! unable to update record");
		}
		
		out.close();
	}

}
