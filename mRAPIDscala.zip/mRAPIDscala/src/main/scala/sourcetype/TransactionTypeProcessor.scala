package sourcetype

import processor.SourceTypeProcessor

class TransactionTypeProcessor extends SourceTypeProcessor{
  def process
}