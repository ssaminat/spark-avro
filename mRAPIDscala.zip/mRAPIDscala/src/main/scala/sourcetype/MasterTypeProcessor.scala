package sourcetype

import processor.SourceTypeProcessor

class MasterTypeProcessor extends SourceTypeProcessor{
  
  def process
}