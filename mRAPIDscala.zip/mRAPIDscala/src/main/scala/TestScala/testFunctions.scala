package TestScala

import org.apache.spark.sql.SQLContext
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext


object testFunctions {
  def main(args: Array[String]): Unit = {
    println("12")
        val conf = new SparkConf().setAppName("mRAPID").setMaster("local")
    val sc = new SparkContext(conf)
    val hc = new SQLContext(sc)  

    val readFile = sc.textFile("C:/Users/1556151.CG-SCB-VISA/Desktop/Important/Scalaword/TL_THRESHOLD_ROLLUP.D2017051.T221737601.R000006")
    val dd=readFile.map(x=>checkNull(x.split('\u0001')))
//dd.collect.foreach((println))  
  }
  def checkNull(line:Array[String])={
    
val z=line.filter(x=>(x.split('\u0001')(1).equals("") ))
println("z is : " +z)
z.foreach(println)
}

}