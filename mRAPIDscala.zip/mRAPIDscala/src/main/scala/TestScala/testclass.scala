package TestScala


object testclass extends App{
  println("Welcome to the Scala worksheet")
  var lines="""hi,this,is,siva
|JOI 
|jjio 
"""
    var list=List("2","34","5","is","100")          //> list  : List[Int] = List(1, 2, 34, 5, 6, 67, 78, 8, 89, 9)
  //list.map(x=>(x==(1)))                           //> res0: List[Boolean] = List(true, false, false, false, false, false, false, f

  list.map(x=>checkis(x))
  def checkis(str: String) : Option[Int] =
  {
    try{
      println(str)
       Some(str.toInt)
  
    }
    catch
    {
            case e: Exception => None         

    }
  
  }
}