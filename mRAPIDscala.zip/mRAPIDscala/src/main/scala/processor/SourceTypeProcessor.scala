package processor

trait SourceTypeProcessor {
  
  def process
}