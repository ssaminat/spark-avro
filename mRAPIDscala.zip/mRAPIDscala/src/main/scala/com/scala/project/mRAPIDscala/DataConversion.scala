package com.scala.parctice

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.hive.HiveContext
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.functions._
import org.apache.spark.sql.hive.HiveContext
import org.apache.log4j.Logger
import org.apache.log4j.{Level, Logger}
import org.apache.hadoop.io.NullWritable
import org.apache.hadoop.io.Text
import org.apache.hadoop.io.NullWritable
import org.apache.hadoop.io.Text
import org.apache.spark.annotation.Experimental

object DataConversion extends Serializable {
    val logger: Logger = Logger.getLogger("My.Example.Code.Rules")
    Logger.getLogger("org.apache.spark").setLevel(Level.WARN)
    Logger.getLogger("org.apache.spark.storage.BlockManager").setLevel(Level.ERROR)
    logger.setLevel(Level.INFO)
    
   
    val conf = new SparkConf().setAppName("DataConversion").setMaster("local")
    val sc = new SparkContext(conf)
    val hc = new HiveContext(sc)
    val sqlContext = new org.apache.spark.sql.SQLContext(sc)
    import sqlContext.implicits._
    
  def main(args: Array[String]) {
      val sourceName =  args(0)
      val cntry = args(1)
      val tableName = args(2)
      val dataBase = args(3)      
      
      datamigration(sourceName,cntry,tableName,dataBase)
  }
  
  def datamigration(sourceName : String, cntry : String,tableName : String ,dataBase : String){
    if(dataBase.equalsIgnoreCase("snapshot")){
      snapShotMigration(sourceName,cntry,tableName);
    }else{
      stagingMigration(sourceName,cntry,tableName);
    }
  }
  
  def snapShotMigration(sourceName : String , cntry : String, tableName : String){
    val paritionQuery = "show partitions dev_sri_open."+sourceName+"_"+cntry+"_"+tableName
    val partitions = sqlContext.sql(paritionQuery)
    val paritionsList = partitions.collect()
    val date = paritionsList.foreach(f=> f.toString().split("=")(1).replaceAll("_", "-"))
    val query = "select rowid,s_startdt,s_starttime,s_enddt,s_endtime,c_journaltime,c_transactionid,c_operationtype,c_userid,bank_code,country_code,city_code,bank_location,bank_name,clr_code,address1,address2,address3,bank_name_cms,address1_cms,address2_cms,address3_cms,cast(modi_date as STRING) ,action_flag,bank_type,ach_enable,rtgs_enable,regional_bank,reg_clr_schema,ods from dev_sri_open."+sourceName+"_"+cntry+"_"+tableName+" where ods='"+date+"'"
    val sriDF = hc.sql("query")
    sriDF.write.orc("/dev/scudee/sts/hdata/sts_snapshot/bh/sts_bh_tl_bank/edmp_partitiondate="+date)
    
  }
  
  def stagingMigration(sourceName : String , cntry : String, tableName : String){
    val file = sc.sequenceFile("hdfs://nnscbhaasdev/dev/edm/hadoop/sts/hdata/dev_storage/stsdev_bh_verifytypes/vds=2017_02_21/stsdev_bh_tlthresholdrollup-r-00000", classOf[NullWritable],classOf[Text]).map(x=>x._2.toString().split("(\001)|(\002)")).map(f => (f(1), f(2), f(3), f(4), f(5), f(6), f(7), f(8), f(9), f(10), f(11),f(12), f(13), f(14), f(15), f(16), f(17), f(18), f(19), f(20)))
    
  }
}