package com.scala.project.mRAPIDscala

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.SQLContext
import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Column;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.hive.HiveContext;
import scala.tools.nsc.io.Lexer.StringLit
import scala.collection.immutable.List
import org.apache.spark.sql.functions._
import factory.factorytypeprocessor

object TestSpark {

  def main(args: Array[String]): Unit = {
    val conf = new SparkConf().setAppName("mRAPID").setMaster("local")
    val sc = new SparkContext(conf)
    val hc = new SQLContext(sc)
    println("hiii23332i")
    val dfAvro = hc.read.format("com.databricks.spark.avro").load("C:/Users/1556151.CG-SCB-VISA/Desktop/Important/Project/AVROTEST/LPMCMASTER/*.avro")
    //C:/Users/1556151.CG-SCB-VISA/Desktop/Important/Project/AVROTEST/LPMCMASTER
    dfAvro.columns
    //msgtype|prdcd
    //val dfORC = hc.read.orc("")
   // val result = dfAvro.unionAll(dfORC)
    val primaryKeysList = List("msgtype", "prdcd").toSeq
   // dfAvro.groupBy(primaryKeysList.head,primaryKeysList.tail:_*).agg(max("c_journaltime")).agg(max("rowid")).show()
    
    val dfwithoutdup=dfAvro.groupBy(primaryKeysList.head,primaryKeysList.tail:_*).agg(max("c_journaltime"),max("rowid"))
    val df1=dfwithoutdup.withColumnRenamed("max(rowid)", "rowid").withColumnRenamed("max(c_journaltime)", "c_journaltime")
    val pkjoin=primaryKeysList:+("rowid"):+("c_journaltime")
    dfAvro.join(df1, pkjoin).show
    val pc= new factorytypeprocessor()
    pc.apply("master")
    sc.stop()

  }
}