package com.scala.project.mRAPIDscala


import org.apache.spark.SparkConf
import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.SparkContext

object start {
  def main(args: Array[String]): Unit = {
    val conf = new SparkConf().setAppName("mRAPID")
   val sc = new SparkContext(conf)
    val hc=new HiveContext(sc)
    val dfAvro=hc.read.format("com.databricks.spark.avro").load("C:/Users/1556151.CG-SCB-VISA/Desktop/Important/Project/AVROTEST/LPMCMASTER/*.avro")
    //C:/Users/1556151.CG-SCB-VISA/Desktop/Important/Project/AVROTEST/LPMCMASTER
    dfAvro.show()
    val dfORC=hc.read.orc("")
    val result = dfAvro.unionAll(dfORC)
    val primaryKeysList = List("","")
    
    
    
  }
}