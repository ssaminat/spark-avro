package fileprocessor
import metadataExtraction.MetaExtraction
import org.apache.spark.sql.Column
import factory.factorytypeprocessor

class CDCFileProcessor {
  val metaextraction = new MetaExtraction
  def process
  {
  val tablenamewithsourcetype = metaextraction.getTableList
  //val g=tablenamewithsourcetype.rdd
  //val df=tablenamewithsourcetype.collect()
//  /.map(r=>Map(tablenamewithsourcetype.select("TableName").zip(tablenamewithsourcetype.select("TableName")))
  //df.map(r=>Map(df.("TableName").zip(df.select("TableName"))))
  val tableList = tablenamewithsourcetype.select("TableName").collectAsList()
  var table=tableList.iterator()
while(table.hasNext())
{
 var tableType=tablenamewithsourcetype.where(tablenamewithsourcetype.col("TableName").equalTo(table.next)).collect().toString()
 val dd=factorytypeprocessor(tableType)
}
}
}

//dataFrame
 // .map { case Row(name, age) => Map("name" -> name, "age" -> age) }
// df.collect.map(x=>Map(df.columns.zip(x.toSeq):_*).take(1))