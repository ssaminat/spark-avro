package factory

import sourcetype.MasterTypeProcessor
import sourcetype.TransactionTypeProcessor

object factorytypeprocessor {
  
  def apply(protype : String) = protype.toUpperCase() match
  {
  case "MASTER" => new MasterTypeProcessor()
  case "TRANSACTION" => new TransactionTypeProcessor()
  case _ =>
    //the inputs that r needed for processing, 1. form avro and orc file path 2. primarykeycolumnslist
}
}