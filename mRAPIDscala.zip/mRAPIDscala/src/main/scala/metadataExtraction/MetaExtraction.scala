package metadataExtraction

import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Column;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.hive.HiveContext;
import scala.tools.nsc.io.Lexer.StringLit
import scala.collection.immutable.List
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.DataFrame

case class tablewithsourcetype(TableName: String, SourceType: String, Version: Int)
case class tablewithcolumns(TableName: String, Columns: String, Version: Int, primaryKeyIndicator :String)
class MetaExtraction extends config.config{
   def getTableList : DataFrame =
  {
    import sqlContext.implicits._
    val inputRDD = sc.textFile("C:/Users/1556151.CG-SCB-VISA/Documents/bh_all_tables_V1")
    val ipDF = inputRDD.map(x => (x.split("\002"))).filter(x => x(0).equalsIgnoreCase("BH")).map(f => (tablewithsourcetype(f(1), f(3), f(10).toInt))).toDF()
    val tablenamewithsourcetype = ipDF.groupBy("TableName", "SourceType").agg(max("Version"))
   return tablenamewithsourcetype 
  }
}

/* def main(args: Array[String]): Unit = {

    import sqlContext.implicits._
    val inputRDD = sc.textFile("C:/Users/1556151.CG-SCB-VISA/Documents/bh_all_tables_V1")
    val ipDF = inputRDD.map(x => (x.split("\002"))).filter(x => x(0).equalsIgnoreCase("BH")).map(f => (tablewithsourcetype(f(1), f(3), f(10).toInt))).toDF()
    val tablenamewithsourcetype = ipDF.groupBy("TableName", "SourceType").agg(max("Version"))
      tablenamewithsourcetype.show
    //        val input2RDD = sc.wholeTextFiles("C:/Users/1556151.CG-SCB-VISA/Desktop/Important/Scalaworld/ScalaInputs/gps_all_tl_eod_marker/#/#")
    //    input2RDD.map(f => (f._1.contains("2017-02-04") || f._1.contains("2017-02-05"),  f._2.split("\001"))).filter(f => f._1.equals(true)).mapValues(f => f(0).split(" ")(0)).collect().foreach(println)
   
     val eodMarkerDF = sqlContext.sql("select * from scudee_dev_ops_ptest.gps_all_tl_eod_marker")
    
    eodMarkerDF.cache()
    val eodandNexteoddate = eodMarkerDF.where("edmp_partitiondate='2017-02-05'").select("eod_date", "next_eod_date")
    val latestpartitions = eodMarkerDF.orderBy(desc("edmp_partitiondate")).select("edmp_partitiondate").distinct.take(2)
    //val latestpartitions = eodMarkerDF.sort(df.col("edmp_partitiondate").desc).select("edmp_partitiondate").distinct().take(2);
    var eod1 = latestpartitions(0).toString.replace("[", "").replace("]", "")
    var eod2 = latestpartitions(1).toString.replace("[", "").replace("]", "")
    if (latestpartitions.length == 1) {
      val df3 = eodMarkerDF.groupBy("edmp_partitiondate").agg(max("c_journaltime").as("c_journaltime")).orderBy("c_journaltime")
      val df4 = df3.where(col("edmp_partitiondate").equalTo(eod1))
    } else {
      val df3 = eodMarkerDF.groupBy("edmp_partitiondate").agg(max("c_journaltime").as("c_journaltime")).orderBy("c_journaltime")
      val df4 = df3.where(col("edmp_partitiondate").equalTo(eod1) || col("edmp_partitiondate").equalTo(eod2))
    }
    val rdd= sc.textFile("hdfs://nnscbhaasdev/dev/scudee/gps/hdata/gps_dev_ops/gps_all_tab_columns/#");
    var versionindex :Int=11
    val rdd1=rdd.map(x=>x.split("\u0002")).map(f=>tablewithcolumns(f(0),f(1),f(11).toInt,f(7)))

    sc.stop()
  } */
 
 
   