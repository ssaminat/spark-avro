/*
 * Delta vs transaction and only apply rules on delta
 * CDC vs Batch
 * Get primary key from scb_all_columns
 * 
 * */

package com.CG.Scalaprogram
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.hive.HiveContext

object myapp {
  def main(args: Array[String]) {
    val conf = new SparkConf()
      .setAppName("processing_filterdata")
      .setMaster("local")
    val sparkContext = new SparkContext(conf)
    val hiveContext = new HiveContext(sparkContext)
    val df = hiveContext.sql("select max(batch_date) from cgfspoc5.input_eod2")
    df.describe()
    df.collect().foreach { x => ??? }
    //df.write.mode("overwrite").saveAsTable()
    //df.li
    var maxdate = df.head.get(0).toString()
    println("as MaxDate: " + maxdate)
    val df1 = hiveContext.sql("select * from cgfspoc5.meta_table")
    val df2 = df1.columns
    val avtablenames = df1.select(df2(0))
    val orctablenames = df1.select(df2(1))
    val pk1 = df1.select(df2(2))
    val pk2 = df1.select(df2(3))
    val maxdatecolumn = df1.select(df2(4))

    val avtablenameslist = avtablenames.collectAsList()
    val orctablenameslist = orctablenames.collectAsList()
    val pk1list = pk1.collectAsList()
    val pk2list = pk2.collectAsList()
    val maxdatecolumnlist = maxdatecolumn.collectAsList()
    for (a <- 0 to (avtablenameslist.size() - 1)) {
      var t1 = hiveContext.sql("select " + pk1list.get(a).toString.replace("[", "").replace("]", "") + "," + pk2list.get(a).toString.replace("[", "").replace("]", "") + "," + "max(" + maxdatecolumnlist.get(a).toString.replace("[", "").replace("]", "") + ") as c_transactionid from " + avtablenameslist.get(a).toString.replace("[", "").replace("]", "") + " GROUP BY " + pk1list.get(a).toString.replace("[", "").replace("]", "") + "," + pk2list.get(a).toString.replace("[", "").replace("]", ""))
      println(t1)
      t1.registerTempTable("processtable1")
      var t2 = hiveContext.sql("select * from " + avtablenameslist.get(a).toString.replace("[", "").replace("]", ""))
      println(t2)
      t2.registerTempTable("processtable2")
      var t3 = hiveContext.sql("select a.* from processtable2 a join processtable1 b on   a." + pk1list.get(a).toString.replace("[", "").replace("]", "") + "=b." + pk1list.get(a).toString.replace("[", "").replace("]", "") + " and a." + pk2list.get(a).toString.replace("[", "").replace("]", "") + "=b." + pk2list.get(a).toString.replace("[", "").replace("]", "") + "  and   a." + maxdatecolumnlist.get(a).toString.replace("[", "").replace("]", "") + "= b." + maxdatecolumnlist.get(a).toString.replace("[", "").replace("]", "") + " and a.c_operationtype <>'D' ")
      println(t3)
      t3.registerTempTable("processtable3")
      hiveContext.sql("insert into table " + orctablenameslist.get(a).toString.replace("[", "").replace("]", "") + " select * from processtable3")

    }
    sparkContext.stop

  }

}