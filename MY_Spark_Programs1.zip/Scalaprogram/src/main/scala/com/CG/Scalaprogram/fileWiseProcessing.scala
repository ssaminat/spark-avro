package com.CG.Scalaprogram
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD.rddToPairRDDFunctions
import org.apache.spark.sql.hive.HiveContext
import java.util.List
import java.io.File
import java.io._
import java.util.HashMap
import java.lang.Iterable;
import java.util.Arrays.ArrayList
import java.util.Arrays.ArrayList
import java.util.ArrayList
import scala.collection.mutable.ArrayBuffer
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.DataFrameReader
import com.databricks.spark.avro._
import org.apache.spark.sql.SQLContext

object fileWiseProcessing {
   def main(args: Array[String]) {
         println("xx")

     val conf = new SparkConf()
      .setAppName("processing_filterdata")
      .setMaster("local")
    val sparkContext = new SparkContext(conf)
     val sqlContext=new SQLContext(sparkContext)
    val hiveContext = new HiveContext(sparkContext );
/*    val df = hiveContext.sql("select max(batch_date) from cgfspoc5.stg_eod_av")
    var maxdate = df.head.get(0).toString()
    println("as MaxDate: " + maxdate)
    hiveContext.sql("insert into table cgfspoc5.stg_oninfo_orc_cp select * from cgfspoc5.stg_oninfo_av_cp where c_operationtype = 'I' and updateddate = '" + maxdate + "'")
    var t1 = hiveContext.sql("select relationshipno,countrycode,c_operationtype , MAX(c_transactionid)  AS c_transactionid from cgfspoc5.stg_oninfo_av_cp where c_operationtype = 'A'  and updateddate = '" + maxdate + "'" + " GROUP BY relationshipno,countrycode,c_operationtype")
    t1.registerTempTable("processtable1")
    var t2 = hiveContext.sql("select * from cgfspoc5.stg_oninfo_av_cp where c_operationtype = 'A'  and updateddate = '2015-11-11'")
    t2.registerTempTable("processtable2")
    var t3 = hiveContext.sql("select a.* from processtable2 a join processtable1 b on  a.c_transactionid = b.c_transactionid and a.relationshipno=b.relationshipno and a.countrycode=b.countrycode")
    t3.registerTempTable("processtable3")
    hiveContext.sql("insert into table cgfspoc5.stg_oninfo_orc_cp select * from processtable3")*/
    val path = new File("D:/Users/ssaminat/Desktop/Inputavrofiles/stg_oninfo_av_cp/staging/test22");
    val path1="D:/Users/ssaminat/Desktop/Inputavrofiles/stg_oninfo_av_cp/staging/test22"
    val rdd=sparkContext.textFile(path1)
    rdd.collect.foreach { println }
/*    var files = path.listFiles();
    println("path is: "+path)
    for(file <- files)
    {
      if(file.isFile())
      {
        println("systems are: "+file.getName)
        val ff =file.toPath()
        
        //val df = sqlContext.read.json(path)
        //val df = hiveContext.read.format("com.databricks.spark.avro").load("ff")
//df.printSchema

      // val peopleDS = spark.avro.read(file)

      }
    }
*/
   }
}