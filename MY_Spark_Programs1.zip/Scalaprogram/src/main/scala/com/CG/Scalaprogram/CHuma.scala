package com.CG.Scalaprogram
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD.rddToPairRDDFunctions
import org.apache.spark.sql.hive.HiveContext;
import org.apache.spark.api.java.JavaRDD
import org.apache.spark.sql.Row

object CHuma {
  
  def main(args: Array[String]){
    println("Hiii");
     println("Hwwwi");
        val conf = new SparkConf()
      .setAppName("CHuma")
      .setMaster("local")    
      val sc = new SparkContext(conf)
	val hc = new HiveContext(sc);

//val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)
   val sqlContext = new org.apache.spark.sql.SQLContext(sc)
val result = hc.sql("select * from cgfspoc5.stg_eod_av")
val d=result.map(x => x(7))
val result1 = hc.sql("select max(batch_date) from cgfspoc5.stg_eod_av")
var maxdate = result1.head.get(0).toString()

val df= hc.sql("select * from cgfspoc5.stg_oninfo_av where updateddate ='"+ maxdate +"'")
val dfrdd= hc.sql("select * from cgfspoc5.stg_oninfo_av where updateddate = '"+ maxdate+"'").rdd
//df.filter(x => x.)
val Irdd=dfrdd.filter { x => x(1).equals('I') }
//val Idf=df.filter(c_operationtype)

//val Ardd=dfrdd.filter { x => x(1).equals('A') }.map { x => ((x(3),x(4)),x(0),x(1),x(2),x(5),x(6)) }
   val Ardd=dfrdd.filter { x => x(1).equals('A') } .map { x => ((x(3),x(4)),x) }
   /*JavaRDD<Row = Ardd.toJavaRDD();
   JavaRDD<Row> = Ardd.ma*/
   
 //  val Ardd1=Ardd.reduceByKey((x,y)=>(x,func(y)))
      
//List<> Arddlist = new ArrayList<>()
var list = new java.util.ArrayList[String]()


//result2.filter()
var sqll="select * from cgfspoc5.stg_oninfo_av_cp where c_operationtype = 'I' and updateddate = '"+maxdate +"'"
//result2.filter("c_operationtype" =='I').show()
val files=df.filter(df("c_operationtype").equalTo("D") )
for(ff<-files)
{
  
}

/*files.map { x=>x.s }
*/for(file <- files)
{
  val ff =file(1)
  println(ff)
  //|| ff.equals("A")
/*    var list = new List()
  if(ff.equals("I") ){
    println("the I&A record is: "+file)
    val correctrec=file
    list.add(ff)
  }
*/    
  
/*  else
  {
    println("the D&B record is: "+file)
  }
*/}
    sc.stop
  }
   
  
}