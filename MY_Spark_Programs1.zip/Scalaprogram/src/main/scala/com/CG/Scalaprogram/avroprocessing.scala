package com.CG.Scalaprogram
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD.rddToPairRDDFunctions
import java.io.File
import java.io._
import java.util.HashMap
import java.lang.Iterable;
import java.util.Arrays.ArrayList
import java.util.Arrays.ArrayList
import java.util.ArrayList
import scala.collection.mutable.ArrayBuffer
//import com.databricks.spark.avro


object avroprocessing {
  def main(args: Array[String]) = {
      val conf = new SparkConf()
      .setAppName("ParallelProcessing")
      .setMaster("local")    
      val sc = new SparkContext(conf)
var sql1=("insert into table cgfspoc5.stg_oninfo_orc_cp select * from cgfspoc5.stg_oninfo_av_cp where c_operationtype = 'I' and updateddate ="+"'maxdate'")
      println(sql1)      
    }
}