package com.CG.spark
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD.rddToPairRDDFunctions
class inputfile {
  def ii()
  {
        println("222")

  val conf = new SparkConf().setAppName("inputfiles").setMaster("local")
    val sc =new SparkContext(conf)
    val ip=sc.textFile("D:/Users/ssaminat/Downloads/inputdir/input1.txt")
    
    for(a <- 0 until 1)
    {
      val ip1 =ip.map { x => x+"\n"+x }
      ip1.saveAsTextFile("D:/Users/ssaminat/Downloads/inputdir/output1")    
       
    }
         
    
  } 
}
object inputfiles
{
  def main(args : Array[String])=
  {
    println("4555")
    var obj:inputfile  =new inputfile()
    obj.ii()
  }
}