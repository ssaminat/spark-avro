/*package com.CG.spark

import scala.io.Source
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.hadoop.io.{LongWritable,Text}
import org.apache.spark.SparkContext._
import org.apache.hadoop.mapreduce.lib.input.{FileSplit,TextInputFormat}
import org.apache.spark.rdd.RDD.rddToPairRDDFunctions
import java.io
import java.util
import java.util.Calendar
import java.lang
import sun.util.calendar.JulianCalendar.Date
import sun.util.calendar.JulianCalendar.Date
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
//import java.awt.TexturePaintContext.Int
//import scala.collection.generic.BitOperations.Int

object filecheck {
	def main(args: Array[String])=
	{
println("xxxxxxxxxxxxxxxxxxxxxxxx")
		val conf = new SparkConf()
		.setAppName("filecheck")
		.setMaster("local")

		val sc = new SparkContext(conf)
		val lastfile = sc.wholeTextFiles("D:/Users/ssaminat/Downloads/Recon_hourly")
		val files = lastfile.map { case (filename, content) => (filename, content)}
	  

		var z=0
				for (filename <- files.keys){ 	
					//println(filename)
					val result: Array[String] = filename.split(Array(':', '/', '_'))
							//println(result(11))
							var x:Int = Integer.parseInt(result(11))
						
							if (x>z){
								z=x
								println("x inside: "+x)
								println("z inside: "+z)
							}
							
					println("z outside: "+z)

				}  	
println("z outside11: "+z)
		
		var latestfilename = new String
		var datee= new String
				for (filename <- files.keys){ 	
					//println(filename)
					val result: Array[String] = filename.split(Array(':', '/', '_'))
							var xx:Int = Integer.parseInt(result(11))
							var date2 = result(10)
        val format = new java.text.SimpleDateFormat("yyyyDDD")
        val format1 = new java.text.SimpleDateFormat("dd-MM-yyyy")
        var dt = format.parse(date2)
					var actualdate =format1.format(dt)
					datee=actualdate
        System.out.println("Julian: " + date2 + " in date format :" + format1.format(dt));
							if(xx.equals(z))
							{
								  latestfilename =filename
								
								  
							}
				}
		
		println("latestfilename2: "+latestfilename)
		println("2: "+z)
		var julianDt = "2014076";
        val format = new java.text.SimpleDateFormat("yyyyDDD")
        val format1 = new java.text.SimpleDateFormat("dd-MM-yyyy")
        var dt = format.parse(julianDt);
        System.out.println("Julian: " + julianDt + " in date format :" + format1.format(dt));
		//var datee = "2016-09-24"
		println("datee: "+datee)
		val contents = lastfile.map { case (filename, content) => (filename,content.split("\\r?\\n"))}
		var  count=0
		for(line <- contents.values) 
		{
		  var len=line.length		  
		  println("length: " + len)
		 
		  for(a <- 0 until len)
		  {
		    println("count: " + count)
		    		 // println(line(a))
		    		  if(line(a).split(" ")(0).contains(datee))
		        {
		      println(line(a))
		        }
		    		  //line(a).split(" ")
count=count+1
		  
		  }
		  
		}
		

		.filter { x => x.contains(datee) }
		//contents.saveAsTextFile("D:/Users/ssaminat/Downloads/Recon_hourly/out1")
		for(line <- latestfilename.getLines())
        println(line)
				//val contents2 =contents.map { y=>y }
		
				var count=0
		    for(cc <- contents2.collect)
		    {
		      println("for loop")
		      		      println(cc+count)
		      val result: Array[String] = cc.split("\n")
		      for(ccc <- result)
		      {
		      println(ccc+count)

		      if(cc.toString().contains("2016-09-22"))
		      {
		        println("if loop"+count)
		      //val contents3 =contents2.filter { x => x.contains(datee)}
		      println(ccc+count)
		    }
		      count=count+1
		    }
		    }

								

				
				//val contents4 = contents3.collect()
				//println(contents4)
				//filter { x => x.contains(datee) }
				//myFunction(contents.contains("2016-09-22"))
		//val contents2 =contents.map { x => x.split(" ") } //.filter { x => x.contains(datee) }
		//println(contents2.collect)
				//contents2.saveAsTextFile("D:/Users/rjittuka/Documents/Recon_hourly/out1")

		//contents3.saveAsTextFile("D:/Users/rjittuka/Documents/Recon_hourly/out")
//val filename = "fileopen.scala"
//for (line <- Source.fromFile(filename).getLines) {
//    println(line)
//}
		
	}
def findlatest(z : Int,x :Int) : Int ={
 if(x>z){
								z=x
								println("x inside: "+x)
								println("z inside: "+z)
							}
 
  zif (x > z)
  else x}
  


}

*/