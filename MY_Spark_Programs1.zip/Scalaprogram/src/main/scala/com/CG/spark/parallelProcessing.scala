package com.CG.spark
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD.rddToPairRDDFunctions
import java.io.File
import java.io._
import java.util
import scala.collection.JavaConversions._


object Parallelprocessing {
  def main(args: Array[String]) = {
println("zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz")
    val conf = new SparkConf()
      .setAppName("ParallelProcessing")
      .setMaster("local")    
      val sc = new SparkContext(conf)
    //val fc = sc.wholeTextFiles("file:///opt/cgfspoc5/poc/pp/inputdir")
    val fc = sc.wholeTextFiles("D:/Users/ssaminat/Downloads/inputdir")
    val files = fc.map { case (filename, content) => filename}
    val contents1 = fc.map{case (filename,content) => (content.split("\\r?\\n"))}
    val contents = fc.map{case (filename,content) => content.toUpperCase()}
    var list = new java.util.ArrayList[Int]()
		//val contents = lastfile.map { case (filename, content) => (filename,content.split("\\r?\\n"))}
for(line <- contents1.collect) 
		{
		  var len=line.length	
		  
		  list.add(len)

		}
    		  println("length: " + list(0))
		    println("length: " + list(1))
		      println("length: " + list(2))
        var count1 =0
       

  for (s <- files.collect) {       
     if(s.contains("inputdir"))
     {
val file = new File("/"+s.substring(6,34)+"/output/"+"output-"+count1)
val bww = new BufferedWriter(new FileWriter(file))
val con = contents.collect
  bww.write(con(count1))
bww.close()
   }
     count1 =count1+1
     }
        var count =0
        
   for (ss <- files.collect) {       
     if(ss.contains("inputdir"))
     {
val file = new File("/"+ss.substring(6,34)+"/output/"+"outputCount-"+count)
val bw = new BufferedWriter(new FileWriter(file))
//list.foreach { i => bw.write(i) }
var count2=count+1
  bw.write("No. of lines in file "+ count2 +": "+list(count))
bw.close()
   }
     count =count+1
     }
    sc.stop
  }
}