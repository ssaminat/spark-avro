/*///*package com.CG.spark;
// SimpleApp.scala 
//import org.apache.spark.SparkContext
//import org.apache.spark.SparkContext._
//import org.apache.spark.SparkConf
// hadoop 
//
//import org.apache.hadoop.conf.Configuration;
//import org.apache.hadoop.fs.FileSystem;
//import org.apache.hadoop.fs.Path;
//import org.apache.hadoop.io.NullWritable
//import org.apache.hadoop.mapred.lib.MultipleTextOutputFormat
// java 
//import java.io.Serializable;
//
//import org.apache.log4j.Logger
//import org.apache.log4j.Level
// Custom TextOutput Format 
//class RDDMultipleTextOutputFormat extends MultipleTextOutputFormat[Any, Any] {
//override def generateActualKey(key: Any, value: Any): Any =
//NullWritable.get()
//
//override def generateFileNameForKeyValue(key: Any, value: Any, name: String): String =
//return key.asInstanceOf[String] +”-“+ name;   // for output hdfs://Ouptut_dir/inputFilename-part-****
////return key.asInstanceOf[String] +”/”+ name;   // for output hdfs://Ouptut_dir/inputFilename/part-**** [inputFilename – as directory of its partFiles ]
//}
//
// Spark Context 
//object Spark {
//val sc = new SparkContext(new SparkConf().setAppName(“test”).setMaster(“local[*]”))
//}
//
// WordCount Processing 
//
//object Process extends Serializable{
//def apply(filename: String): org.apache.spark.rdd.RDD[(String, String)]= {
//println(“i am called…..”)
//val simple_path = filename.split(‘/’).last;
//val lines = Spark.sc.textFile(filename);
//val counts     = lines.flatMap(line => line.split(” “)).map(word => (word, 1)).reduceByKey(_ + _); //(word,count)
//val fname_word_counts = counts.map( x => (simple_path,x._1+”\t”+ x._2));   // (filename,word\tcount)
//fname_word_counts
//}
//}
//
//object SimpleApp  {
//
//def main(args: Array[String]) {
//
////Logger.getLogger(“org”).setLevel(Level.OFF)
////Logger.getLogger(“akka”).setLevel(Level.OFF)
//
//// input ans output paths
//val INPUT_PATH = “hdfs://master:8020/vijay/mywordcount/”
//val OUTPUT_PATH = “hdfs://master:8020/vijay/mywordcount/output/”
//
//// context
//val context = Spark.sc
//val data = context.wholeTextFiles(INPUT_PATH)
//
//// final output RDD
//var output : org.apache.spark.rdd.RDD[(String, String)] = context.emptyRDD
//
//// files to process
//val files = data.map { case (filename, content) => filename}
//
//// Apply wordcount Processing on each File received in wholeTextFiles.
//files.collect.foreach( filename => {
//output = output.union(Process(filename));
//})
//
////output.saveAsTextFile(OUTPUT_PATH);   // this will save output as (filename,word\tcount)
//output.saveAsHadoopFile(OUTPUT_PATH, classOf[String], classOf[String],classOf[RDDMultipleTextOutputFormat])  // custom output Format.
//
////close context
//context.stop();
//
//}
//}*/*/