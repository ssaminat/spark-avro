package avro
import com.databricks.spark.avro._
import org.apache.spark.sql
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.hive.HiveContext
import java.io.File
import java.io._
import org.apache.spark.sql.SQLContext

class avroPractice {
  //val spark = SparkSession.builder().master("local").getOrCreate()
    def main(args: Array[String]) {
      val conf = new SparkConf()
      .setAppName("processing_filterdata")
      .setMaster("local")
    val sparkContext = new SparkContext(conf)
val sqlContext = new SQLContext(sparkContext)
      sqlContext.read.avro
      val df = sqlContext.read.avro("D:/Users/ssaminat/Desktop/Avroexperiment/twitter.avsc")
}
}