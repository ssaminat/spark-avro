package com.CG.Scalaprogram
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD.rddToPairRDDFunctions
import org.apache.spark.sql.hive.HiveContext;
import org.apache.spark.sql.DataFrame
import com.sun.org.apache.xalan.internal.xsltc.compiler.ForEach

//import df.implicits_
object sivasworksheet {;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(409); 


 
 		 var primarykeylist = "[aaaaaaaaaaa,bbbbbbbbbbbbbbb]";System.out.println("""primarykeylist  : String = """ + $show(primarykeylist ));$skip(73); 
     var PKeys=primarykeylist.toString.replace("[", "").replace("]", "");System.out.println("""PKeys  : String = """ + $show(PKeys ));$skip(30); 
		 var Pkey =PKeys.split(",");System.out.println("""Pkey  : Array[String] = """ + $show(Pkey ));$skip(38); 
     var len =PKeys.split(",").length;System.out.println("""len  : Int = """ + $show(len ));$skip(34); 
     var l: List[String] = List();System.out.println("""l  : List[String] = """ + $show(l ));$skip(25); 
     var ggg =new String;System.out.println("""ggg  : String = """ + $show(ggg ));$skip(26); 
     var gggg =new String;System.out.println("""gggg  : String = """ + $show(gggg ));$skip(44); 
     val builder = StringBuilder.newBuilder;System.out.println("""builder  : StringBuilder = """ + $show(builder ));$skip(14); 
     ggg="ff";$skip(422); 
     for(pk <- Pkey)
     {
    // println(Pkey(len-1))
    // println(pk)
     if(Pkey(len-1)==pk)
     {
    /// println("inside if "+pk)
    // println("1")
     ggg = "a." +pk + "=b." +pk
     }
     else
     {
     //println("inside else "+pk)
          //println("2")
     
     ggg= "a." +pk + "=b." +pk +" and "
     
     }
     builder.append(ggg)
     l = ggg :: l
     // l =List() ::: List(ggg)
     
    
};$skip(26); 
println("gggg: "+builder);$skip(20); 

 var lll=l.reverse;System.out.println("""lll  : List[String] = """ + $show(lll ))}
// for( j <- 0 to  len-1)
// {
 //var fi = lll(j).append(
// }
     
}
