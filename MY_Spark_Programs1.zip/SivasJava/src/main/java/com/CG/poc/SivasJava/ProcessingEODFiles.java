/**
 * @author ikumarav
 * Date 14-10-2016
 */
package com.CG.poc.SivasJava;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.LocatedFileStatus;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.RemoteIterator;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.DataFrameWriter;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.hive.HiveContext;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

import scala.Tuple2;


/*
 * ProcessingEODFiles process the files(IABD) from staging in AVRO format and store the processed files in ORC format.<br>
 * I - Insert
 * A - After Update
 * B - Before Update
 * D - Delete
 * 1.Get the EOD from  stg_eod_av table.<br>
 * 2. Get all the table name from the staging directory.<br>
 * 3. Using EOD date, get all the files from the list of tables under staging directory.<br>
 * 4. Remove the B and D from the files. Get the latest updated journal_time A files based on relationshipno and countrycode. <br>
 * 5. Combine both updated A and I files and store that all files in ORC table.
 */

public class ProcessingEODFiles 
{
    public static void main( String[] args )
    {
    	final long serialVersionUID = 1L;
    	
    	try {
    	JavaSparkContext javaSparkContext = new JavaSparkContext(new SparkConf()
        .setAppName("ProcessingEODFiles").setMaster("local"));
    	
    	HiveContext  hiveContext= new HiveContext(javaSparkContext.sc());
    	
    	FileSystem hdfs =FileSystem.get(new Configuration());
    	
    	ProcessingQuery processingQuery = new ProcessingQuery();
    	
    	String query = "select max(batch_date) from cgfspoc5.stg_eod_av";
    	JavaRDD<Row> eodDateMap = hiveContext.sql(query).javaRDD();
    	String eodDate = eodDateMap.first().toString().replace("[", "").replace("]", "");
    	
    	Path path = new Path("hdfs://horton-nn-1.aws.sho.com:8020/apps/hive/warehouse/staging");
    	List<String> fileNameList = new ArrayList<String>();
    	FileStatus[] fileStatus = hdfs.listStatus(path);
    	for(FileStatus fileStat:fileStatus){
    		String fileName = fileStat.getPath().toString();
    		fileNameList.add(fileName);
    	}
    	
    	System.out.println("fileNameList"+fileNameList);
    	
    	for(int i=0;i<fileNameList.size();i++){
    		
    		JavaRDD<Row> files = processingQuery.processQuery(fileNameList.get(i),eodDate);
    		
    		long beforeProccessCount = files.count();
        	System.out.println("beforeProccessCount"+beforeProccessCount);
        	
        	JavaRDD<Row> filesMapWithI = files.filter(new Function<Row,Boolean>(){
        		public Boolean call(Row s){
        			return s.get(1).equals("I");
        			
        		}
        	});
        	
        	
        	JavaRDD<Row> filesMapWithA = files.filter(new Function<Row,Boolean>(){
        		public Boolean call(Row s){
        			return s.get(1).equals("A");
        			
        		}
        	});
        	
        	
        	JavaRDD<Row> filesMapWithUpdatedA = filesMapWithA.mapToPair(new PairFunction<Row, String, Row>() {
        			public Tuple2<String, Row> call(Row row) {
        	            String key = String.valueOf(row.getAs("relationshipno"))+String.valueOf(row.getAs("countrycode"));
        	            return new Tuple2<String, Row>(key, row);
        	        }
    		}).reduceByKey(new Function2<Row, Row, Row>(){
        		public Row call(Row row1, Row row2) throws Exception {
        			DateFormat format = new SimpleDateFormat("YYYY-MM-DD");
                    Date rs1 = format.parse(String.valueOf(row1.getAs("c_journaltime")));
                    Date rs2 = format.parse(String.valueOf(row2.getAs("c_journaltime")));
                   
                    if (rs1.after(rs2)) {
                        return row1;
                    } else {
                        return row2;
                    }
                }
        	}).map(new Function<Tuple2<String, Row>, Row>() {
        		public Row call(Tuple2<String, Row> tuple) {
                    return tuple._2;
                }
        	});
        	
        	
        	JavaRDD<Row> finalFiles	= filesMapWithUpdatedA.union(filesMapWithI);
        	
        	// Initialize StructField list
        	List<StructField> structFields = new ArrayList<StructField>();

        	// Create StructFields for name & age
        	StructField structField1 = DataTypes.createStructField("c_journaltime", DataTypes.StringType, true);
        	StructField structField2 = DataTypes.createStructField("c_operationtype", DataTypes.StringType, true);
        	StructField structField3 = DataTypes.createStructField("c_transactionid", DataTypes.StringType, true);
        	StructField structField4 = DataTypes.createStructField("relationshipno", DataTypes.StringType, true);
        	StructField structField5 = DataTypes.createStructField("countrycode", DataTypes.StringType, true);
        	StructField structField6 = DataTypes.createStructField("nationality", DataTypes.StringType, true);
        	StructField structField7 = DataTypes.createStructField("updateddate", DataTypes.StringType, true);

        	// Add StructFields name & age into list
        	structFields.add(structField1);
        	structFields.add(structField2);
        	structFields.add(structField3);
        	structFields.add(structField4);
        	structFields.add(structField5);
        	structFields.add(structField6);
        	structFields.add(structField7);

        	// Create StructType from StructFields. This will be used to create DataFrame
        	StructType schema = DataTypes.createStructType(structFields);
        	
        	DataFrame finalFileDataFrame = hiveContext.createDataFrame(finalFiles, schema);
        	
        	
    			
    			
    			Path path1 = new Path("hdfs://horton-nn-1.aws.sho.com:8020/apps/hive/warehouse/cgfspoc5.db/orc");
    			if(hdfs.exists(path1)){
    				hdfs.delete(path1, true);
    			}
    		
        	
        	DataFrameWriter finalFileDataFrameWriter = finalFileDataFrame.write();
        	finalFileDataFrameWriter.format("orc").save("hdfs://horton-nn-1.aws.sho.com:8020/apps/hive/warehouse/cgfspoc5.db/orc");
        	query = "CREATE TABLE IF NOT EXISTS"+fileNameList.get(i)+"_orc"+"(`c_journaltime` string,`c_operationtype` string,`c_transactionid` string,`relationshipno` string,`countrycode` string,`nationality` string,`updateddate` string)"+
        	"ROW FORMAT SERDE"+
      "'org.apache.hadoop.hive.ql.io.orc.OrcSerde'"+
    "STORED AS INPUTFORMAT"+
      "'org.apache.hadoop.hive.ql.io.orc.OrcInputFormat'"+
    "OUTPUTFORMAT"+
      "'org.apache.hadoop.hive.ql.io.orc.OrcOutputFormat'"+
    "LOCATION"+
      "'hdfs://horton-nn-1.aws.sho.com:8020/apps/hive/warehouse/staging/orc/'"+"fileNameList.get(i)"+
    "TBLPROPERTIES ("+
      "'COLUMN_STATS_ACCURATE'='false',"+
      "'numFiles'='6',"+
      "'numRows'='-1',"+
      "'rawDataSize'='-1',"+
      "'totalSize'='4690',"+
      "'transient_lastDdlTime'='1476336799')";
        	hiveContext.sql(query);
        	//hiveContext.createExternalTable("stg_oninfo_orc_sample2", "hdfs://horton-nn-1.aws.sho.com:8020/apps/hive/warehouse/cgfspoc5.db/stg_oninfo_orc_sample2");
        	//finalFileDataFrameWriter.format("orc").saveAsTable("stg_oninfo_orc_sample2");
        	
        	
        	List<Row> ex = finalFileDataFrame.collectAsList();
        	System.out.println("exddddddddddddddddddddddddddd"+ex);
    	}
    	
    	
    	
    	
    	
    	
    	} catch (IOException e) {
			e.printStackTrace();
		}
    	
    }// close for public static void main
}
