package org.capgemini.mrapid.processing.sparksql

import scala.collection.Map

import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.sql._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.hive.HiveContext
import org.capgemini.mrapid.processing.exception.ProcessException
import org.capgemini.mrapid.processing.exception.QueryException
import org.capgemini.mrapid.processing.util.Constants._

import com.typesafe.config.ConfigFactory
import org.apache.spark.SparkContext
import scala.collection.mutable.ListBuffer
import scala.collection.mutable
import java.io.IOException
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.FSDataOutputStream
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.Path
import java.sql.Timestamp



case class QueryExecutor(val systemName: String, val countryName: String, val partitionName: String) {

  val logger = Logger.getLogger(getClass.getName)

  /**
   * This method is used to get the tables with columns.
   *
   * @param columns
   *            : one or more columns with comma separated
   * @return List<Row> List of tables.
   * @throws QueryException
   */

  //case class TableWithSourceType(table_name: String, source_type: String)

  @throws(classOf[QueryException])
  def executeQueryForTableList(columns: String, countryName: String,
    sqlContext: HiveContext, conf: SparkConf, partitionDate: String, sc: SparkContext)  = {

    logger.info("inside the executeQueryForTableList() method")

    val commonDatabase = conf.get("spark.commonDatabase")
    val filePath = conf.get("spark.filePath")
    var query = ""
    var tableNameWithSourceType:  Array[(String, String)] = null
   
     try {
       
      var listBuffer = new ListBuffer[String]()

      listBuffer += filePath
      listBuffer += commonDatabase
      listBuffer += systemName + UNDERSCORE + SCB_ALL_TAB
      listBuffer += countryName + UNDERSCORE + SCB_ALL_TAB + UNDERSCORE + STAR

      var allTablesPath = listBuffer.mkString("/")

     import sqlContext.implicits._

     var tableWithSourceRDD = sc.textFile(allTablesPath).filter { cols => cols.split(DELIMITER)(0).equalsIgnoreCase(countryName) }
                                 .map{row => (row.split(DELIMITER)(1),row.split(DELIMITER)(3))}
        
      var tableWithSourceRDDDF = tableWithSourceRDD.toDF().cache()
      
      tableNameWithSourceType = tableWithSourceRDDDF.map { row => (row(0).toString(),row(1).toString())}.collect()
      
     } catch {
      case runTimeException: RuntimeException => {
        logger.error(runTimeException.getMessage())
        System.exit(0)
      }
      case e: Exception => throw new QueryException(e.getMessage())
    }

    
     tableNameWithSourceType
  }

  /*@throws(classOf[QueryException])
  def executeQueryForTableList(columns: String, countryName: String,
    hiveContext: HiveContext, prop: SparkConf, partitionDate: String) :Array[(String, String)] = {

    logger.info("inside the executeQueryForTableList() method")

    val commonDatabase = prop.get("spark.commonDatabase")
    var query = ""
    //var tableNameWithSourceType: scala.collection.Map[String, String] = null

     var ctryNamUpper = countryName.toUpperCase();

      if (columns.length() == 0) {

        query = ("select " + TABLE_NAME + " from "
          + commonDatabase + DOT + systemName + UNDERSCORE
          + SCB_ALL_TAB + " where " + COUNTRY_NAME + EQUAL_SIGN + "'" + ctryNamUpper + "'")

      } else {

        query = ("select " + TABLE_NAME + COMMA + columns + COMMA + VERSION + " from " +
          commonDatabase + DOT + systemName + UNDERSCORE + SCB_ALL_TAB + " where "
          + COUNTRY_NAME + EQUAL_SIGN + "'" + ctryNamUpper + "'" + " order by " + VERSION + " asc")
        
             
     }

      logger.info("Executing Query for getting table list:->" + query);
      val resultSetDF = hiveContext.sql(query).map { row => (row(0).toString(),row(1).toString())}
      var tableNameWithSourceType = resultSetDF.collect
     
     logger.info("tableNameWithSourceTypeAAA:->" + tableNameWithSourceType)

      var resultSetDF = hiveContext.sql(query).cache()
      
      var tableNameWithSourceType = resultSetDF.map { row => (row(0).toString(),row(1).toString())}.collect()
      
      tableNameWithSourceType

      }
  */
  
  /**
   * This method is used to get the next eod date.
   *
   * @param countryCode
   *            : Cannot be null
   * @param partitionDate
   *            : Cannot be null
   * @return List of EodDate
   * @throws QueryException
   */

  @throws(classOf[QueryException])
  @throws(classOf[ProcessException])
  def getNextEodDate(countryCode: String, partitionDate: String,
    sqlContext: HiveContext, conf: SparkConf, sc: SparkContext):Array[String] = {

    logger.info("inside the getNextEodDate() method")
  
    var query = ""
    var nextEodDate:Array[String] = null
    try {

      var commonDatabase = conf.get("spark.commonDatabase")
      var cdc_eod_Marker = conf.get("spark.cdc_eod_marker")
      var filePath = conf.get("spark.filePath")
      
      import sqlContext.implicits._
      var listBuffer = new ListBuffer[String]()

      listBuffer += filePath
      listBuffer += commonDatabase
      listBuffer += countryName
      listBuffer += systemName + UNDERSCORE + countryName + UNDERSCORE + cdc_eod_Marker.toLowerCase()
      listBuffer += PART_ODS + EQUAL_SIGN + partitionDate

      var nextEodPath = listBuffer.mkString("/")
      var nextEodDateRDD = sc.textFile(nextEodPath).map { cols => cols.split(EODDELIMITER)(5) }.toDF()
            
       nextEodDate = nextEodDateRDD.map {x => x(0).toString}.collect()
      
      if (nextEodDate(0) == null || nextEodDate(0).size == 0) {
        logger.error("Next_Eod_Date is null")
        throw new ProcessException("Next_Eod_Date is null")

      }
      
     
    } catch {
      case runTimeException: RuntimeException => { logger.error(runTimeException.getMessage())
        
        System.exit(0)}
      case exception: Exception => {
        logger.error(exception)

        if (exception.isInstanceOf[ProcessException]) {
          throw new ProcessException(exception.getMessage())
        }

        throw new QueryException(exception.getMessage())
      }
    }
    
    nextEodDate

     
  }

  /**
   * This method is used to get the list of latest EodDates.
   *
   * @param countryCode
   *            : Cannot be null
   * @return List of latest partition
   * @throws QueryException
   */

  @throws(classOf[QueryException])
  def getLatestEodDates(countryCode: String, sqlContext: HiveContext,
    conf: SparkConf, partitionDate: String,sc: SparkContext):Array[String] = {

    logger.info("inside the getLatestEodDates() method");

    var query = ""  
    var commonDatabase = conf.get("spark.commonDatabase")
    var cdc_eod_Marker = conf.get("spark.cdc_eod_marker")
    var filePath = conf.get("spark.filePath")
    var topTwoEodDates:Array[String] = null

    import sqlContext.implicits._
    try {

      var listBuffer = new ListBuffer[String]()

      listBuffer += filePath
      listBuffer += commonDatabase
      listBuffer += countryName
      listBuffer += systemName + UNDERSCORE + countryName + UNDERSCORE + cdc_eod_Marker.toLowerCase()
      listBuffer += PART_ODS + EQUAL_SIGN + STAR

      var latestPartitionsPath = listBuffer.mkString("/")

      var EodDateRDD = sc.textFile(latestPartitionsPath).map { cols => cols.split(EODDELIMITER)(4) }.toDF()
      var LatestEodDates = EodDateRDD.distinct().withColumnRenamed("_1", "eodDate").orderBy($"eodDate".desc) 
      topTwoEodDates = LatestEodDates.map {x => x(0).toString}.take(2)
      
                 
    } catch {

      case runTimeException: RuntimeException =>
        logger.error(runTimeException.getMessage())
        System.exit(0)
      case e: Exception => throw new QueryException(e.getMessage())

    }

    topTwoEodDates
  }

  /**
   * This method is used to get the max journal time based on partitions.
   *
   * @param countryCode
   *            : cannot be null
   * @param currentAndPreviousEodDate
   *            : Cannot be null
   * @return List of max journal time
   * @throws ProcessException
   * @throws QueryException
   */

  @throws(classOf[QueryException])
  @throws(classOf[ProcessException])
  def getJournalTime(countryCode: String, currentAndPreviousEodDate: Array[String],
    hiveContext: HiveContext, prop: SparkConf, partitionDate: String) = {

    logger.info("inside the getJournalTime() method")
    
    var query = ""
    var JournalTime: Array[Row] = null
    var commonDatabase = prop.get("spark.commonDatabase")
    var cdc_eod_Marker = prop.get("spark.cdc_eod_marker")

    try {

      if (currentAndPreviousEodDate.size >= 1) {

        val testcond = if (currentAndPreviousEodDate.size == 1) (currentAndPreviousEodDate(0).toString() + "'") else (currentAndPreviousEodDate(0)
          .toString() + "' or " + "cast(" + EOD_DATE + " as date)" + "='"
          + currentAndPreviousEodDate(1).toString())

        query = ("select " + "cast("
          + EOD_DATE
          + " as date) as " + EOD_DATE
          + COMMA
          + "max("
          + C_JOURNALTIME
          + ") from "
          + commonDatabase
          + DOT
          + systemName
          + UNDERSCORE
          + countryCode
          + UNDERSCORE
          + cdc_eod_Marker
          + " where "
          + "cast("
          + EOD_DATE
          + " as date)"
          + " ='"
          + testcond
          + "'" + " group by " + EOD_DATE
          + " order by " + EOD_DATE)

        logger.info("Executing Query for getting two journaltime:->" + query)

      JournalTime = getListFromQuery(hiveContext, query)
     
      } else {
        throw new ProcessException(
          "Either today partition or previous day partition is not available");
      }

    } catch {
      case runTimeException: RuntimeException =>
        logger.error(runTimeException.getMessage())
        System.exit(0)
      case exception: Exception =>
        if (exception.isInstanceOf[ProcessException]) {
          throw new ProcessException(exception.getMessage())
        }

        throw new QueryException(exception.getMessage())

    }

    JournalTime
  }

  /**
   * This method is used to get the tables with version.
   *
   * @param columns
   *            : one or more versions with comma separated
   * @return List<Row> List of tables.
   *
   */
  def getTableLatestVersion(countryName: String, hiveContext: HiveContext,
    prop: SparkConf, partitionDate: String) = {

    logger.info("inside the getTableLatestVersion() method")
    var query = ""
    val commonDatabase = prop.get("spark.commonDatabase")
    var tableNameversionList: scala.collection.Map[String, String] = null

    try {

      query = ("select " + TABLE_NAME + "," + " max(" + VERSION
        + ") from " + commonDatabase + DOT + systemName
        + UNDERSCORE + SCB_ALL_TAB + " where " + COUNTRY_NAME
        + EQUAL_SIGN + "'" + countryName.toUpperCase()
        + "' group by " + TABLE_NAME)
        
        logger.info("Executing Query for getting TableLatestVersion:->" + query)
    
     tableNameversionList = hiveContext.sql(query).map { row => (row(0).toString(),row(1).toString())}.collectAsMap()

    } catch {

      case exception: Exception =>
        logger.error(exception.getMessage())
        if (exception.isInstanceOf[RuntimeException]) {
          System.exit(0)
        }

    }

    tableNameversionList

  }

  /**
   * This method is used to get the records for CDC Incremental.
   *
   * @param tableName
   *            : Name of the table
   * @param countryCode
   *            : Name of the country
   * @return DataFrame contains collections of records with I,A,B and D
   *         combination.
   * @throws QueryException
   * @throws ProcessException
   */

  @throws(classOf[ProcessException])
  @throws(classOf[QueryException])
  def executeQueryForIncremental(tableName: String, countryCode: String, partitionDate: String,
    sourceType: String, currentAndyesterdayPartitions: Array[String],
    NextEod: Array[String], eodMarker: Array[Row],
    columnJoins: String, hiveContext: HiveContext, prop: SparkConf) = {

    var startDate = "";
    var Date = "";
    var nextEodDate = ""
    var eodDate = ""
    var query = "";
    var subQuery = ""
    var listOfRecords: java.util.List[Row] = null
    var PreviousDayProcessedData: org.apache.spark.sql.DataFrame = null
    var records: DataFrame = null

    var stagingDatabase = prop.get("spark.stagingDatabase");
    var fromTimezone = prop.get("spark.fromJournalTimeTimeZone");
    var toTimezone = prop.get("spark.toJournalTimeTimeZone");

    try {
      
      query = (" select a." + "`" + "rowid" + "`" + COMMA + "'"
        + partitionDate + "' as s_startdt" + COMMA
        + "from_utc_timestamp(to_utc_timestamp(" + "a."
        + C_JOURNALTIME + "," + "\"" + fromTimezone + "\"" + "),"
        + "\"" + toTimezone + "\"" + ")" + " as s_starttime"
        + COMMA + "'" + END_DATE + "' as s_enddt" + COMMA + "'"
        + END_DATETIME + "' as s_endtime" + COMMA + columnJoins
        + " from " + stagingDatabase + DOT + tableName + " a")

      var nexteodtestcond = if ((nextEodDate == null) || (nextEodDate.isEmpty())) "" else
        (" or " + PART_ODS + " ='" + nextEodDate + "'")

      var eodmarkertestcond1 = if (eodMarker.size == 1) ("1900-01-01 00:00:00") else
        (eodMarker(0)(1).toString())

      var eodmarkertestcond2 = if (eodMarker.size == 2) (eodMarker(1)(1).toString()) else
        (eodMarker(0)(1).toString())

      subQuery = (" where ("
        + PART_ODS
        + " ='"
        + partitionDate
        + "'"
        + nexteodtestcond
        + ")"
        + " and "
        + C_JOURNALTIME
        + " >= '"
        + eodmarkertestcond1
        + "'"
        + " and "
        + C_JOURNALTIME
        + " <= '"
        + eodmarkertestcond2
        + "'")

      query = query + subQuery;
      logger.info("Executing Query for getting data:->" + query);

      records = hiveContext.sql(query)

      if (MASTER.equalsIgnoreCase(sourceType)) {

        var previousDayProcessedRecords = getPriviousDaySnapshotRecords(
          tableName, countryCode, partitionDate, hiveContext, prop)

        records = records.unionAll(previousDayProcessedRecords)

      }

    } catch {
      case runTimeException: RuntimeException => {
        logger.error(runTimeException.getMessage())
        System.exit(0)
      }
      case e: Exception => throw new QueryException(e.getMessage());
    }

    records
  }

  
  @throws(classOf[ProcessException])
  @throws(classOf[QueryException])
  def getPriviousDaySnapshotRecords(tableName: String, countryCode: String, partitionDate: String,
    hiveContext: HiveContext, prop: SparkConf) = {
    logger.info("inside the getPriviousDaySnapshotRecords() method")

    var cdc_eod_Marker = prop.get("spark.cdc_eod_marker");
    var commonDatabase = prop.get("spark.commonDatabase");
    var snapshotDatabase = prop.get("spark.processedDatabase")

    var previousDate: String = ""
    var list: Array[Row] = null
    var previousDayProcessedData: DataFrame = null
    try {
      var yesterdayPartitionquery = ("select " + "cast(" + EOD_DATE
        + " as date)" + " from " + commonDatabase + DOT
        + systemName + UNDERSCORE + countryCode + UNDERSCORE
        + cdc_eod_Marker + " where " + "cast(" + NEXT_EOD_DATE
        + " as date)" + EQUAL_SIGN + "'" + partitionDate + "'")

      logger.info("Executing Query for getting yesterday partition from "
        + tableName + ":->" + yesterdayPartitionquery)

      list = getListFromQuery(hiveContext, yesterdayPartitionquery)

       if (list.size > 0 && list(0)(0) != null) {

        previousDate = list(0)(0).toString()

        var str = ("select * from " + snapshotDatabase + DOT
          + tableName + " where " + PART_ODS + EQUAL_SIGN + "'"
          + previousDate + "'")

        logger.info("Executing query for joining snapshot and staging"
          + str);
        previousDayProcessedData = hiveContext.sql(str)

      }

    } catch {

      case runTimeException: RuntimeException => {
        logger.error(runTimeException.getMessage())
        System.exit(0)
      }
      case e: Exception => throw new QueryException(e.getMessage())
    }

    previousDayProcessedData
  }

  /**
   * @param hiveContext
   *            : HiveContext
   * @param query
   *            : Query to process
   * @return : Processed query is converted to List<Row>
   * @throws QueryException
   */
  
  def getColumnList(sourceName: String, countryCode: String,
    partitionDate: String, hiveContext: HiveContext, sparkConf: SparkConf) = {
    
    logger.info("inside the getColumnList() method");
    var columnList: DataFrame = null;
    var query = ""

    var commonDatabase = sparkConf.get("spark.commonDatabase");
    try {
      query = ("select " + TABLE_NAME + COMMA + COLUMN_NAME + COMMA
        + VERSION + COMMA + PRIMARY_KEY_COULUMN + " from "
        + commonDatabase + DOT + sourceName + UNDERSCORE
        + SCB_ALL_TAB_COLUMNS + " where " + COUNTRY_NAME
        + EQUAL_SIGN + "'" + countryCode.toUpperCase() + "'")

      logger.info("Getting the columnList" + query)
      
      columnList = hiveContext.sql(query)
      
     
    } catch {
      case exception: Exception =>
        logger.error(exception)

        if (exception.isInstanceOf[RuntimeException]) {
          System.exit(0)
        }
    }
    columnList
  }

   def getColumnListWithoutDataType(columnList: Array[Row]):List[String] = {
    logger.info("Inside the getColumnListWithoutDataType() method");

    var columnListWithoutDataType = new ListBuffer[String]()
    
   var iterator = columnList.iterator
   
   while (iterator.hasNext) {
     var row = iterator.next()
     
     columnListWithoutDataType += row.toString()
     
   }
         
     columnListWithoutDataType.insert(1, CJOURNALTIME)
     columnListWithoutDataType.insert(2, CTRANSACTIONID)
     columnListWithoutDataType.insert(3, COPERATIONTYPE)
     columnListWithoutDataType.insert(4, C_USERID)
     
     columnListWithoutDataType.insert(columnListWithoutDataType.size,PART_ODS.toUpperCase())

    columnListWithoutDataType.toList

  }
   
   @throws(classOf[QueryException])
  def changePrimaryKey(recordsWithoutDuplicate: DataFrame,
    sourceName: String, countryCode: String, tableName: String,
    partitionDate: String,
    hiveContext: HiveContext, prop: SparkConf) = {
    logger.info("Inside the changePrimaryKey() method");
    var timestamp = new Timestamp(System.currentTimeMillis());
    var commonDatabase = prop.get("spark.commonDatabase");
    var temptable = "primarykeyTempTable";
    try {
      var recordsWithBRecords = recordsWithoutDuplicate.where(
        "c_operationtype = 'B'").select("ROWID");

      recordsWithBRecords.registerTempTable(temptable)

      var finalQuery = ("INSERT INTO " + commonDatabase + DOT
        + sourceName + UNDERSCORE + DUPLICATE_PRIMARYKEYS
        + " PARTITION(" + PART_ODS + "='" + partitionDate + "')")

      var query = ("select `rowid`,'"
        + sourceName
        + "','"
        + countryCode
        + "','"
        + tableName
        + "','"
        + "Because of Primary key change,this row is inserted into this table"
        + "','" + timestamp + "','" + timestamp + "' from "
        + temptable)

      finalQuery = finalQuery + query;

      logger.info("Executing Query for inserting primary key change row"
        + finalQuery)

      var dataframe = hiveContext.sql(finalQuery)

    } catch {

      case queryException: QueryException => { logger.error(queryException.getMessage()) }
      case exception: Exception => {
        logger.error(exception.getMessage())
        if (exception.isInstanceOf[RuntimeException]) {
          System.exit(0)
        }

      }

    } finally {
      try {
        hiveContext.dropTempTable(temptable)

      } catch {
        case exception: Exception => {

          logger.warn("Could not delete temp table ")
        }

      }

    }

  }

  def deletePreviousPath(ORCpath: String) {
    logger.info("Inside the deletePreviousPath() method");

    try {
      var conf: Configuration = new Configuration();

      var fileSystem: FileSystem = FileSystem.get(conf);

      var path: Path = new Path(ORCpath);

      if (fileSystem.exists(path)) {
        fileSystem.delete(path, true)
      }

    } catch {
      case ixception: IOException => {
        ixception.printStackTrace()
      }

    }

  }
 
  @throws(classOf[QueryException])
  def getListFromQuery(hiveContext: HiveContext, query: String) = {

    var records: Array[Row] = null
    try {

      var dataframe = hiveContext.sql(query)
      if (dataframe.take(1) != null) {
        records = dataframe.collect

      }
    } catch {
      case noSuchElementException: NoSuchElementException => records
      case e: Exception => throw e

    }
    records

  }

}
