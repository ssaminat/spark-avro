package org.capgemini.mrapid.processing.exception

/**
 * This class is for handling the process related exception.
 * 
 *
 */

case class ProcessException(message: String = "", cause: Throwable = null)
              extends Exception(message, cause) {
  

 }
	

