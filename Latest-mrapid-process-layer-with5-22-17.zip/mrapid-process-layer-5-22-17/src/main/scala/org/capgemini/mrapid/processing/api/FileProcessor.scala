package org.capgemini.mrapid.processing.api

import org.capgemini.mrapid.processing.exception.ProcessException
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.hive.HiveContext

trait FileProcessor {
  	/*
	 * Process method performs the Delta or transaction or Full base
	 * functionalities.
	 */
      
  def process(hdfInputs:Array[String],hc:HiveContext,sc:SparkContext,prop:SparkConf)  
	
}