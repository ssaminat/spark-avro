package org.capgemini.mrapid.processing.file.impl

import org.capgemini.mrapid.processing.api.FileProcessor
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.hive.HiveContext

  class BatchFileProcessorImpl extends FileProcessor {
  
   def process(hdfInputs:Array[String],hc:HiveContext,sc:SparkContext,conf:SparkConf) = {
     
     println("batch type")
     
    
   }
  
  
  
}