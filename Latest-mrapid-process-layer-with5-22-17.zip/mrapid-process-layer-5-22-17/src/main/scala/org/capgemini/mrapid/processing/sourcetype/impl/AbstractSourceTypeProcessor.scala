package org.capgemini.mrapid.processing.sourcetype.impl

import org.capgemini.mrapid.processing.api.SourceTypeProcessor
import org.apache.spark.SparkConf
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.Row
import scala.collection.Map
import org.capgemini.mrapid.processing.util.Constants._
import com.typesafe.config.ConfigFactory
import org.apache.log4j.Logger
//import org.capgemini.mrapid.processing.util.CommonUtil
import scala.collection.mutable.ListBuffer
import org.capgemini.mrapid.processing.sparksql.QueryExecutor
import org.apache.spark.sql.DataFrame

abstract class AbstractSourceTypeProcessor extends SourceTypeProcessor {
  val logger = Logger.getLogger(getClass.getName)
  /**
   * This method implements both Delta and Transaction functionalities. <br/>
   *
   * Delta: (I,A,B,D) <br/>
   * 1. Get the records for recent two partitions and merge with previous
   * output ORC table record. <br/>
   * 2. Eliminate the duplicate records. <br/>
   * 3. All the "B" records without "A", will put the entry in
   * "DOTOPAL_DUPLICATE_PRIMARYKEYS" table. <br/>
   * 4. Get the max journal time based on primary keys.<br/>
   * 5. Join the two temporary tables and insert the updated records(I,A) into
   * ORC table. <br/>
   *
   * Transaction: (I,A,B) <br/>
   * 1. Get the records for recent two partitions.<br/>
   * 2. Eliminate the duplicate records. <br/>
   * 3. If table has no primary key, insert the records into ORC table. 4. If
   * table has primary key, then find the max journal time and join two
   * tables. <br/>
   * 5. Insert the updated records into ORC table. <br/>
   */

  def sourceTypeProcess(sourceName: String, tableName: String, countryCode: String,
    partitionDate: String, sourceType: String,
    CurrentAndpreviuosDayPartitions:Array[String], NextEod: Array[String],
    eod_marker: Array[Row], hiveContext: HiveContext, prop: SparkConf,
    tableNameWithVersion: scala.collection.Map[String, String], columnListDataFrame: DataFrame) = {

    logger.info("Inside the AbstractSourceTypeProcessor class sourceTypeProcess() method")

    var sourceTypeProcessor: SourceTypeProcessor = null
    //val commonUtil: CommonUtil = new CommonUtil()
    val processingQuery: QueryExecutor = new QueryExecutor(sourceName, countryCode, partitionDate)

    if (this.isInstanceOf[IncrementalTypeProcessor]) {
      sourceTypeProcessor = this.asInstanceOf[IncrementalTypeProcessor]
    } else if (this.isInstanceOf[TransactionTypeProcessor]) {

      sourceTypeProcessor = this.asInstanceOf[TransactionTypeProcessor]
    }

    var stagingDatabase = prop.get("spark.stagingDatabase")
    var processedDatabase = prop.get("spark.processedDatabase")

    var filePath = prop.get("spark.filePath")

    var tableNameWithoutCountry = tableName
    var tableNameWithDb = sourceName + UNDERSCORE + countryCode + UNDERSCORE + tableName;
    var startDate = ""
    var Date = ""
    var query = ""
    var selectQuery = ""
    var noPrimaryKey = ""
    var records: DataFrame = null
    var recordsWithoutDuplicate: DataFrame = null
    var tableNameUpper = tableNameWithoutCountry.toUpperCase()
    var processWithAllRecords = tableName + "_tmp";
    var processWithPrimaryKey = tableName + "_primarytmp";
    var processRecordsWithoutDup = tableName + "_tmpWithoutDuplicate";
    var processedRecordsWithoutBAndD = tableName + "_processedRecordsWithoutBAndD"
    
   var status = true

    try {
      
      var maxVersion = " "
      var maxVersionresult = tableNameWithVersion.get(tableNameUpper)
      
      if (maxVersionresult.isDefined) {
                   
        maxVersion = maxVersionresult.get
        
      }
      
      var allColumnsDF = columnListDataFrame
        .where(TABLE_NAME + "='"
          + tableNameWithoutCountry.toUpperCase() + "'")
        .where("version ='" + maxVersion + "'")
        
        var df = allColumnsDF.select(COLUMN_NAME)
       

      var columnList = df.collect
      
      if (null == columnList || columnList.isEmpty) {
				throw new IllegalArgumentException(
						"column list EMPTY for table : "
								+ tableName.toUpperCase());
			}
    
      /**
       * Getting the column names with comma separator
       * 
       * 
       */
      var columnListWithoutDataType = processingQuery.getColumnListWithoutDataType(columnList)
      
      var columnListWithoutSquareBrackets = columnListWithoutDataType.mkString(",").replaceAll("[\\[\\]]","").split(",").toList  
      
      var columnJoins = columnListWithoutSquareBrackets.filter{ row => !row.toString().equalsIgnoreCase(ROWID)}
                        .map {col => "a." + "`" + col + "`" }.mkString(",")     
                        
      var columnsWithCommaSeperator = columnListWithoutSquareBrackets.map { col => "`" + col + "`" }.mkString(",")
      
      var columnsWithCommaSeperatorWithoutRowid = columnListWithoutSquareBrackets.filter{ row => !row.toString().equalsIgnoreCase(ROWID)}
                                                  .map {col => "`" + col + "`" }.mkString(",")
                                                  
      records = processingQuery.executeQueryForIncremental(tableNameWithDb, countryCode, partitionDate,
        sourceType, CurrentAndpreviuosDayPartitions,
        NextEod, eod_marker, columnJoins, hiveContext, prop)
        
      records.registerTempTable(processWithAllRecords)

      var primaryColumnDF = allColumnsDF.where(
					PRIMARY_KEY_COULUMN + "='Y'").select(COLUMN_NAME)

      var primaryColumnList = primaryColumnDF.collect
       
      var allColumns = columnListWithoutSquareBrackets.filter{ row => !row.toString().equalsIgnoreCase(ROWID) && 
        !row.toString().equalsIgnoreCase(C_JOURNALTIME) && 
        !row.toString().equalsIgnoreCase(C_TRANSACTIONID) && 
        !row.toString().equalsIgnoreCase(C_OPERATIONTYPE)&& 
        !row.toString().equalsIgnoreCase(C_USERID)
        
      }.map { col => "`" + col + "`" }.mkString(",")
          
			var primaryKeyWithCommaSeperator = primaryColumnList.map {col => "`" + col + "`" }.mkString(",").replaceAll("[\\[\\]]","")
        
      /*
			 * If a table has no primary key,then insert all the records into
			 * ORC.
			 */

      if (primaryColumnList.size == 0) {

        var columnsWithCommaSeperatorForNoPrimaryKey = columnListWithoutSquareBrackets.filter{ row => !row.toString().equalsIgnoreCase(ROWID)}
                                                      .map {col => "`" + col + "`" }.mkString(",")
        var ORCPath = (filePath + FORWARD_SLASH + processedDatabase
          + FORWARD_SLASH + countryCode + FORWARD_SLASH
          + tableNameWithDb + FORWARD_SLASH + PART_ODS + EQUAL_SIGN
          + partitionDate)

        processingQuery.deletePreviousPath(ORCPath)

        var recordsWithoutDuplicateTemp = tableNameWithDb + "_recordsWithoutDuplicate"

        selectQuery = ("select `rowid`"
          + COMMA
          + "`s_startdt`,`s_starttime`,`s_enddt`,`s_endtime`,"
          + columnsWithCommaSeperatorForNoPrimaryKey
          + ","
          + "row_number() over (partition by "
          + allColumns
          + " order by "
          + C_JOURNALTIME
          + " desc) as rn "
          + "from "
          + processWithAllRecords)

        logger.info("Executing Query for removing duplicates" + selectQuery)

        var recordsWithoutDuplicate = hiveContext.sql(selectQuery).where("rn = 1")
        recordsWithoutDuplicate.registerTempTable(recordsWithoutDuplicateTemp)
        query = "select * from " + recordsWithoutDuplicateTemp

        var finalQuery = ("INSERT INTO " + processedDatabase + DOT
          + tableNameWithDb + " PARTITION(" + PART_ODS + "='"
          + partitionDate + "')" + query)
          
        logger.info("Executing query for inserting the records into process layer:->" + finalQuery)

        hiveContext.sql(finalQuery)

        try {
          hiveContext.dropTempTable(recordsWithoutDuplicateTemp);
        } catch {
          case exception: Exception => {

            logger.info("Could not delete the temp table")
          }

        }

        status
      }

      /*
			 * Getting the unique records.
			 */

       
      var queryPartition = ("select `rowid`,`s_startdt`,`s_starttime`,`s_enddt`,`s_endtime`,"
        + columnsWithCommaSeperatorWithoutRowid
        +","
        + "row_number() over (partition by "
        + primaryKeyWithCommaSeperator
        + " order by "
        + C_JOURNALTIME
        + " desc,rowid desc) as rn "
        + "from "
        + processWithAllRecords)

      logger.info("Executing query for removing duplicates from " + tableNameWithDb + ":->" + queryPartition)

      try {

        recordsWithoutDuplicate = hiveContext.sql(queryPartition).where("rn = 1")

      } catch {
        case e: Exception => throw e

      }

      /*
			 * If primary key of 'B' records changed, then that particular
			 * records rowid,sourceName,countryCode,description and execution
			 * time should be enter into dotopal_duplicate_primary table.
			 */

      if (MASTER.equalsIgnoreCase(sourceType)) {
        processingQuery.changePrimaryKey(recordsWithoutDuplicate,
          sourceName, countryCode, tableNameWithDb, partitionDate,hiveContext, prop);
      }

      /*
			 * Clear the previous path content before storing the records into
			 * the path.
			 */
      var processedRecords = recordsWithoutDuplicate.where(
        "C_OPERATIONTYPE <>'D'").where("C_OPERATIONTYPE <>'B'");
      processedRecords.registerTempTable(processedRecordsWithoutBAndD)

      var ORCPath = (filePath + FORWARD_SLASH + processedDatabase
        + FORWARD_SLASH + countryCode + FORWARD_SLASH + tableNameWithDb
        + FORWARD_SLASH + PART_ODS + EQUAL_SIGN + partitionDate)

      processingQuery.deletePreviousPath(ORCPath)

      /*
			 * * Insert the final output for I, A type records into hive tables
			 * in ORC format.
			 */

      logger.info("Storing the records to " + tableNameWithDb)

      query = "select * from " + processedRecordsWithoutBAndD

      var finalQuery = ("INSERT INTO " + processedDatabase + DOT
        + tableNameWithDb + " PARTITION(" + PART_ODS + "='"
        + partitionDate + "')" + query)

      logger.info("Executing query for inserting the records into process layer:->"
        + finalQuery)

      hiveContext.sql(finalQuery)

    } catch {
      case exception: Exception => {
        logger.error(exception.getMessage())
        status = false
        if (exception.isInstanceOf[RuntimeException]) {
          System.exit(0)
        }
      }

    } finally {
      try {
        hiveContext.dropTempTable(processWithAllRecords);
        hiveContext.dropTempTable(processedRecordsWithoutBAndD)
      } catch {
        case exception: Exception => { logger.info("Could not delete the temp table") }

      }

    }

    status
  }

}