package org.capgemini.mrapid.processing.sourcetype.impl

import org.capgemini.mrapid.processing.util.Constants.TRANSACTION

class TransactionTypeProcessor extends AbstractSourceTypeProcessor {
  
   
   def getType():String = {
    
		return TRANSACTION;
	}

}