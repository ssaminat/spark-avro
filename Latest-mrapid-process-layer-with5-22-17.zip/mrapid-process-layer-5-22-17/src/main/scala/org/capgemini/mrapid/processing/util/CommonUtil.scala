/*package org.capgemini.mrapid.processing.util

import org.apache.log4j.Logger
import org.capgemini.mrapid.processing.util.Constants._
import org.apache.spark.SparkContext
import scala.collection.Map
import scala.collection.mutable.ListBuffer
//import scala.collection.JavaConverters._
import org.apache.spark.sql.Row
import org.apache.spark.sql.DataFrame
import org.apache.spark.SparkConf
import org.apache.spark.sql.hive.HiveContext
import org.capgemini.mrapid.processing.exception.QueryException
import com.typesafe.config.ConfigFactory
import java.io.IOException
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.capgemini.mrapid.processing.exception.ProcessException
import org.capgemini.mrapid.processing.sparksql.QueryExecutor
import org.apache.spark.sql.DataFrame
import java.sql.Timestamp
import org.apache.spark.sql.DataFrame

class CommonUtil {

  val logger = Logger.getLogger(getClass.getName)*/

  /*def getColumnsList(filePath: String, commonDatabase: String, sourceName: String, countryCode: String, sc: SparkContext) = {

    var columnsRDD: scala.collection.Map[String, Iterable[String]] = null

    val allTabColumnsPath = """filePath + FORWARD_SLASH + commonDatabase
				+ FORWARD_SLASH + sourceName + UNDERSCORE + SCB_ALL_TAB_COLUMNS
				+ FORWARD_SLASH + STAR""";

    columnsRDD = sc.textFile(allTabColumnsPath).filter { cols => cols.split(DELIMITER)(2).equalsIgnoreCase(countryCode) }
      .map { rec => (rec.split(DELIMITER)(0), rec.split(DELIMITER)(1)) }.groupByKey().collectAsMap()

    logger.info("columns in cdc" + columnsRDD)

    columnsRDD

  }*/

  /**
   * This method used to get the columnList.
   *
   * @param columnList
   * @return Dataframe columnList
   */
  /*def getColumnList(sourceName: String, countryCode: String,
    partitionDate: String, hiveContext: HiveContext, sparkConf: SparkConf) = {
    
    logger.info("inside the getColumnList() method");
    var columnList: DataFrame = null;
    var query = ""

    var commonDatabase = sparkConf.get("spark.commonDatabase");
    try {
      query = ("select " + TABLE_NAME + COMMA + COLUMN_NAME + COMMA
        + VERSION + COMMA + PRIMARY_KEY_COULUMN + " from "
        + commonDatabase + DOT + sourceName + UNDERSCORE
        + SCB_ALL_TAB_COLUMNS + " where " + COUNTRY_NAME
        + EQUAL_SIGN + "'" + countryCode.toUpperCase() + "'")

      logger.info("Getting the columnList" + query)
      
      columnList = hiveContext.sql(query)
      
     
    } catch {
      case exception: Exception =>
        logger.error(exception)

        if (exception.isInstanceOf[RuntimeException]) {
          System.exit(0)
        }
    }
    columnList
  }*/

  /**
   * This method used to get the columnList without DataType.
   *
   * @param columnList
   * @return List<String> columnList
   */ /*
  def getColumnListWithoutDataType(tableName: String, columns: Map[String, Iterable[String]]): java.util.ArrayList[String] = {
    logger.info("Inside the getColumnListWithoutDataType() method");

    var tableNameUpper = tableName.toUpperCase()
    // var columnListWithoutDataType = new ListBuffer[String]()
    //Try to use ListBuffer Later
    var arraylist = new java.util.ArrayList[String]()

    var tableNameFilter = columns.filter { case (key, _) => key == tableNameUpper }

    var columnlist = tableNameFilter.map { t =>
      val myList = t._2
      for (column <- myList) {

        arraylist.add(column)

      }

    }

    //val columnListWithoutDataTypeJava = columnListWithoutDataType.asJava
    arraylist.add(1, CJOURNALTIME)
    arraylist.add(2, CTRANSACTIONID);
    arraylist.add(3, COPERATIONTYPE);
    arraylist.add(4, CUSERID);
    arraylist.add(arraylist.size(), PART_ODS.toUpperCase());

    return arraylist

  }*/

  /**
   * This method used to get the columnList without DataType.
   *
   * @param columnList
   * @return List<String> columnList
   */
  /*def getColumnListWithoutDataType(columnList: Array[Row]) = {
    logger.info("Inside the getColumnListWithoutDataType() method");

    var columnListWithoutDataType = new java.util.ArrayList[String]()

    val iterator = columnList.iterator()

    while (iterator.hasNext()) {

      val row = iterator.next()

      columnListWithoutDataType.add(row.get(0).toString())

    }

    columnListWithoutDataType.add(1, CJOURNALTIME)
    columnListWithoutDataType.add(2, CTRANSACTIONID);
    columnListWithoutDataType.add(3, COPERATIONTYPE);
    columnListWithoutDataType.add(4, CUSERID);
    columnListWithoutDataType.add(columnListWithoutDataType.size(), PART_ODS.toUpperCase());

    columnListWithoutDataType

  }*/
  /*def getColumnListWithoutDataType(columnList: Array[Row]):List[String] = {
    logger.info("Inside the getColumnListWithoutDataType() method");

    var columnListWithoutDataType = new ListBuffer[String]()
    
   var iterator = columnList.iterator
   
   while (iterator.hasNext) {
     var row = iterator.next()
     
     columnListWithoutDataType += row.toString()
     
   }
         
     columnListWithoutDataType.insert(1, CJOURNALTIME)
     columnListWithoutDataType.insert(2, CTRANSACTIONID)
     columnListWithoutDataType.insert(3, COPERATIONTYPE)
     columnListWithoutDataType.insert(4, C_USERID)
     
     columnListWithoutDataType.insert(columnListWithoutDataType.size,PART_ODS.toUpperCase())

    columnListWithoutDataType.toList

  }*/
  /**
   * This method used to append the "a." with all columns for using join in
   * query.
   *
   * @param columnList
   * @return String
   */

  /*def getColumnListForJoins(columnList: java.util.ArrayList[String]) = {

    logger.info("Inside the getColumnListForJoins() method")
    val builder: StringBuilder = StringBuilder.newBuilder
    var i = 0
    for (i <- 0 to columnList.size() - 1) {
      if (!columnList.get(i).equalsIgnoreCase(ROWID)) {
        builder.append("a." + "`" + columnList.get(i) + "`")
        builder.append(",")
      }
    }
    var columnsJoins: String = builder.toString();
    columnsJoins = columnsJoins.substring(0, columnsJoins.length() - 1)

    columnsJoins

  }*/

  /**
   * This method is used to form the columns with comma separator.
   *
   * @param columnList
   *            : list of columns
   * @return String: columns with comma separator.
   *
   */

  /*def getColumnsWithCommaSeperator(columnList: java.util.ArrayList[String]) = {

    logger.info("inside the getColumnsWithCommaSeperator() method");

    val builder: StringBuilder = StringBuilder.newBuilder
    var primaryKeysJoinWithRowId = ""
    var count = 0
    var column = ""
    var x = 0
    for (x <- 0 to columnList.size() - 1) {
      column = "`" + columnList.get(x) + "`"

      if (count == columnList.size() - 1) {
        builder.append(column)
      } else {
        builder.append(column)
        builder.append(",")
      }

      count = count + 1
    }
    primaryKeysJoinWithRowId = builder.toString()

    primaryKeysJoinWithRowId
  }*/

 /* def getColumnsWithCommaSeperatorNoPrimaryKey(columnList: java.util.ArrayList[String]) = {

    logger.info("inside the getColumnsWithCommaSeperatorNoPrimaryKey() method");

    val builder: StringBuilder = StringBuilder.newBuilder
    var primaryKeysJoinNoRowID = ""
    var count = 0
    var column = ""
    var x = 0
    for (x <- 0 to columnList.size() - 1) {
      column = "`" + columnList.get(x) + "`"
      if (count == 0) {

      } else {
        if (count == columnList.size() - 1) {
          builder.append(column)
        } else {
          builder.append(column)
          builder.append(",")
        }
      }
      count = count + 1
    }
    primaryKeysJoinNoRowID = builder.toString()

      primaryKeysJoinNoRowID
  }*/

  /*def getColumnListForDuplicate(columnList: java.util.ArrayList[String]) = {

    logger.info("Inside the getColumnListForDuplicate() method")
    val builder: StringBuilder = StringBuilder.newBuilder
    var y = 0
    for (y <- 0 to columnList.size() - 1) {

      builder.append("t." + "`" + columnList.get(y) + "`")
      builder.append(",")

    }
    var columnsJoins: String = builder.toString();
    columnsJoins = columnsJoins.substring(0, columnsJoins.length() - 1)

    columnsJoins

  }
  
  	*//**
	 * This method used to get column names with comma seperator without rowid
	 * @param columnList
	 * @return
	 *//*

  def getColumnsWithCommaSeperatorWithoutRowid(
    columnList: java.util.ArrayList[String]) = {
    logger.info("inside the getColumnsWithCommaSeperator() method");
    val builder: StringBuilder = StringBuilder.newBuilder
    var primaryKeysJoin = "";
    var count = 0;
    var column = ""
    var z = 0

    for (z <- 0 to columnList.size() - 1) {
      if (!"rowid".equalsIgnoreCase(columnList.get(z))) {
        column = "`" + columnList.get(z) + "`"
        if (count == columnList.size() - 1) {
          builder.append(column)
        } else {
          builder.append(column)
          builder.append(",")

        }
        count = count + 1
      }
    }
    primaryKeysJoin = builder.toString();

    primaryKeysJoin;
  }*/

  /**
   * This method is used to form the columns with comma separator.
   *
   * @param columnList
   * @return
   */

  /*def getColumnsWithCommaSeperatorFornoPK(columnList: String) = {
    logger.info("inside the getColumnsWithCommaSeperator() method")
    var primaryKeysColumn = "";
    val builder: StringBuilder = StringBuilder.newBuilder
    var str = columnList.split(",")
    var count1 = 0;
    var i = 0
    for (i <- 0 to (str.length - 1)) {

      if (!str(i).equalsIgnoreCase("ROWID")
        && !str(i).equalsIgnoreCase("C_JOURNALTIME")
        && !str(i).equalsIgnoreCase("C_TRANSACTIONID")
        && !str(i).equalsIgnoreCase("C_OPERATIONTYPE")
        && !str(i).equalsIgnoreCase("C_USERID")) {
        if (count1 == str.length - 1) {
          builder.append(str(i));

        } else {
          builder.append(str(i));
          builder.append(",");
        }

        count1 = count1 + 1
      }
    }
    primaryKeysColumn = builder.toString()
    primaryKeysColumn
  }*/

  
  /**
	 * This method is used to form the primary keys with comma separator.
	 * 
	 * @param primaryKeyList
	 *            : list of primary Key
	 * @return String: Primary key with comma separator.
	 * @throws ProcessException
	 */
  
  /*@throws(classOf[ProcessException])
  def getPrimaryKeyWithCommaSeperator(primaryListWithComma: java.util.List[Row]) = {
    
    logger.info("inside the getPrimaryKeyWithCommaSeperator() method")
    val builder: StringBuilder = StringBuilder.newBuilder
    var primaryKeysJoin = ""
    var count = 0
    if (primaryListWithComma.size() != 0) {

      val iterator = primaryListWithComma.iterator()

      while (iterator.hasNext()) {

        val primaryKey = iterator.next()

        if (count == primaryListWithComma.size() - 1) {
          builder.append("`" + primaryKey.get(0).toString() + "`");
        } else {
          builder.append("`" + primaryKey.get(0).toString() + "`");
          builder.append(",");
        }
        count = count + 1

      }

      primaryKeysJoin = builder.toString()
    }

    primaryKeysJoin

  }*/

  /**
   * This method is used to form the primary keys with combination of a. and
   * b. a is a alias name for temporary table ProcessWithAllRecords. b is a
   * alias name for temporary table ProcessWithPrimaryKey.
   *
   * @param primaryKeyList
   *            : list of primary Key
   * @return String: Primary key with a. and b.
   */

  /*@throws(classOf[ProcessException])
  def getPrimaryKeys(primaryColumnList: java.util.List[Row]) = {

    logger.info("inside the getPrimaryKeys() method");
    val builder1: StringBuilder = StringBuilder.newBuilder
    var primaryKeysJoins = "";
    var count = 0;

    if (primaryColumnList.size() != 0) {

      val iterator = primaryColumnList.iterator()

      while (iterator.hasNext()) {

        val primaryKey = iterator.next()

        if (count == primaryColumnList.size() - 1) {
          builder1.append("nvl(a." + "`" + primaryKey.get(0).toString() + "`" + ",'1')"
            + "=nvl(b." + "`" + primaryKey.get(0).toString() + "`" + ",'1')");
        } else {
          builder1.append("nvl(a." + "`" + primaryKey.get(0).toString() + "`" + ",'1')"
            + "=nvl(b." + "`" + primaryKey.get(0).toString() + "`" + ",'1')");
          builder1.append(" and ");
        }

        count = count + 1

      }

      primaryKeysJoins = builder1.toString()

    }
    primaryKeysJoins
  }*/

  /**
   * This method handle the change primary key scenario.<br/>
   * All the "B" records without "A", will put the entry in
   * "{SourceName}_DUPLICATE_PRIMARYKEYS" table.
   *
   * @param records
   * @param maxJournalTimeRecord
   * @param sourceName
   * @param countryCode
   * @param tableName
   * @param partitionDate
   */

 /* @throws(classOf[QueryException])
  def changePrimaryKey(recordsWithoutDuplicate: DataFrame,
    sourceName: String, countryCode: String, tableName: String,
    partitionDate: String,
    hiveContext: HiveContext, prop: SparkConf) = {
    logger.info("Inside the changePrimaryKey() method");
    var timestamp = new Timestamp(System.currentTimeMillis());
    var commonDatabase = prop.get("spark.commonDatabase");
    var temptable = "primarykeyTempTable";
    try {
      var recordsWithBRecords = recordsWithoutDuplicate.where(
        "c_operationtype = 'B'").select("ROWID");

      recordsWithBRecords.registerTempTable(temptable)

      var finalQuery = ("INSERT INTO " + commonDatabase + DOT
        + sourceName + UNDERSCORE + DUPLICATE_PRIMARYKEYS
        + " PARTITION(" + PART_ODS + "='" + partitionDate + "')")

      var query = ("select `rowid`,'"
        + sourceName
        + "','"
        + countryCode
        + "','"
        + tableName
        + "','"
        + "Because of Primary key change,this row is inserted into this table"
        + "','" + timestamp + "','" + timestamp + "' from "
        + temptable)

      finalQuery = finalQuery + query;

      logger.info("Executing Query for inserting primary key change row"
        + finalQuery)

      var dataframe = hiveContext.sql(finalQuery)

    } catch {

      case queryException: QueryException => { logger.error(queryException.getMessage()) }
      case exception: Exception => {
        logger.error(exception.getMessage())
        if (exception.isInstanceOf[RuntimeException]) {
          System.exit(0)
        }

      }

    } finally {
      try {
        hiveContext.dropTempTable(temptable)

      } catch {
        case exception: Exception => {

          logger.warn("Could not delete temp table ")
        }

      }

    }

  }

  def deletePreviousPath(ORCpath: String) {
    logger.info("Inside the deletePreviousPath() method");

    try {
      var conf: Configuration = new Configuration();

      var fileSystem: FileSystem = FileSystem.get(conf);

      var path: Path = new Path(ORCpath);

      if (fileSystem.exists(path)) {
        fileSystem.delete(path, true)
      }

    } catch {
      case ixception: IOException => {
        ixception.printStackTrace()
      }

    }

  }
}*/
 
  