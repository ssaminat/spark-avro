package org.capgemini.mrapid.processing.file.impl

import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.hive.HiveContext
import org.capgemini.mrapid.processing.api.FileProcessor
import org.capgemini.mrapid.processing.exception.ProcessException
import org.capgemini.mrapid.processing.exception.QueryException
import org.capgemini.mrapid.processing.sparksql.QueryExecutor
//import org.capgemini.mrapid.processing.util.CommonUtil
import org.capgemini.mrapid.processing.util.Constants._
import scala.collection.Map

import com.typesafe.config.ConfigFactory
import org.capgemini.mrapid.processing.api.SourceTypeProcessor
import org.apache.spark.sql.Row
import org.apache.spark.sql.DataFrame
import org.capgemini.mrapid.processing.factory.SourceTypeProcessorFactory

/**
 * This class decide which process(Delta,Transaction or Full Dump) need to
 * implement for the table based on sourceType. <br/>
 * Based on hdfInput 4th argument (Y or N), decide the table need to implement
 * Full Dumb or not.<br/>
 * If hdfInput 4th argument is 'Y', then 5th hdfInput arguments is table name
 * and process the Full Dump implementations for that table. <br/>
 * If hdfInput 4th argument is 'N', then process the Delta or Transaction
 * implementations. <br/>
 *
 * @author Chandra V
 *
 */

class CDCFileProcessorImpl extends FileProcessor {
	val logger = Logger.getLogger(getClass.getName)
			val CLASSNAME = "CDCFileProcessorImpl"

			@throws(classOf[ProcessException])
			@throws(classOf[QueryException])
			def process(hdfInputs: Array[String], hc: HiveContext, sc: SparkContext, conf: SparkConf) = {

		val commonDatabase = conf.get("spark.commonDatabase")
				var status = false

				logger.info(CLASSNAME + "process method has started")

				/**
				 * hdfInput[0] : sourceName. <br/>
				 * Cannot be null <br/>
				 * hdfInput[1] : countryName. <br/>
				 * Cannot be null <br/>
				 * hdfInput[2] : partitionDate.<br/>
				 * Cannot be null <br/>
				 * hdfInput[3] : 'Y' or 'N'.<br/>
				 * hdfInput[4] : tableName.<br/>
				 * Cannot be null <br/>
				 */

				var sourceName = hdfInputs(0)
				var countryCode = hdfInputs(1)
				var partitionDate = hdfInputs(2)

				val processingQuery: QueryExecutor = new QueryExecutor(sourceName, countryCode, partitionDate);
				//val commonUtil: CommonUtil = new CommonUtil()

				try {

					/*
					 * tableNameWithSourceType is a map, it contains the tableName and
					 * sourceType. tableList is a list, it contains all the tableNames.
					 */

					    //tableNameWithSourceType - Array[(TL_MT199,Transaction)]

					    var tableNameWithSourceType = processingQuery.executeQueryForTableList(SOURCETYPE, countryCode,
						                              	hc, conf, partitionDate,sc)

							//nextEodDate: Array[String] = Array(2017-03-19 00:00:00)

							var eodDate = processingQuery.getNextEodDate(countryCode, partitionDate, hc, conf, sc)

							//topTwoEodDates: Array[String] = Array(2017-03-18 00:00:00, 2017-03-17 00:00:00)

							var latestEodDates = processingQuery.getLatestEodDates(countryCode, hc, conf, partitionDate, sc)

							// journalTime:Array[Row] = Array([2017-03-10 00:00:00,2017-03-11 00:15:00]

							var journalTime = processingQuery.getJournalTime(countryCode, latestEodDates, hc, conf, partitionDate)
							
							//tableNameWithVersion:Map[String,String] = Map[TL_PRIORITY,1]

							var tableNameWithVersion = processingQuery.getTableLatestVersion(countryCode, hc, conf, partitionDate)

							var columnList = processingQuery.getColumnList(sourceName, countryCode, partitionDate, hc, conf)

							tableNameWithSourceType.map(rec => {

								val tableNameExtract = rec._1
										val sourceTypeOfTable = rec._2

										val sourceTypeProcessor = SourceTypeProcessorFactory.createSourceTypeProcessor(sourceTypeOfTable)

										if (sourceTypeProcessor != null) {

											status = sourceTypeProcessor.sourceTypeProcess(sourceName,
													tableNameExtract.toLowerCase(), countryCode, partitionDate, sourceTypeOfTable,
													latestEodDates, eodDate, journalTime, hc: HiveContext,
													conf: SparkConf, tableNameWithVersion: scala.collection.Map[String, String], columnList: DataFrame)

										}

							})

				} catch {
				case queryException: QueryException => { logger.error(queryException.getMessage()) }
				case processException: ProcessException => {
					logger.error(processException.getMessage())
					System.exit(0)
				}
				case exception: Exception => {
					logger.error(exception)

					if (exception.isInstanceOf[RuntimeException]) {
						System.exit(0)
					}
				}
				}

	}

}

