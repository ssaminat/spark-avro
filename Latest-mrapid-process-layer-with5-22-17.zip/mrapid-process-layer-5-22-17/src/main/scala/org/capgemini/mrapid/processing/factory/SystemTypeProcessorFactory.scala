package org.capgemini.mrapid.processing.factory

import org.capgemini.mrapid.processing.api.FileProcessor
import org.capgemini.mrapid.processing.util.Constants._
import org.apache.log4j.Logger
import org.capgemini.mrapid.processing.file.impl.CDCFileProcessorImpl
import org.capgemini.mrapid.processing.file.impl.BatchFileProcessorImpl
import org.capgemini.mrapid.processing.file.impl.XmlFileProcessorImpl

/**
 * This factory class is used to decide which SystemType(CDC,Batch or XML) needs to create a
 * processor.
 *
 * @author Chandra V
 *
 */
object SystemTypeProcessorFactory {

  val logger = Logger.getLogger(getClass.getName)

  /**
   * This method create the object based on systemType.
   * @param systemType
   *            : Name of the System <br/>
   *            Cannot be null <br/>
   * @return Object of FileProcessor
   */
  def createSystemTypeProcessor(systemType: String): FileProcessor = systemType match {
    case CDC if (CDC.equalsIgnoreCase(systemType)) =>
      logger.info("Starting the CDC SystemType")
      new CDCFileProcessorImpl()
    case BATCH if (BATCH.equalsIgnoreCase(systemType)) =>
      logger.info("Starting the BATCH SystemType")
      new BatchFileProcessorImpl()
    case _ =>
      logger.info("Starting the XML SystemType")
      new XmlFileProcessorImpl()

  }

}