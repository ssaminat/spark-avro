package org.capgemini.mrapid.processing.factory

import org.apache.log4j.Logger
import org.capgemini.mrapid.processing.util.Constants._
 
import org.capgemini.mrapid.processing.api.SourceTypeProcessor
import org.capgemini.mrapid.processing.sourcetype.impl.IncrementalTypeProcessor
import org.capgemini.mrapid.processing.sourcetype.impl.TransactionTypeProcessor
 


object SourceTypeProcessorFactory {
  
    val logger = Logger.getLogger(getClass.getName)
    
    
   
   def createSourceTypeProcessor(sourceType: String): SourceTypeProcessor = sourceType match {
                  
    case MASTERUP if (MASTER.equalsIgnoreCase(sourceType)) =>
      logger.info("Starting the Delta processing");
      new IncrementalTypeProcessor()
      
    case TRANSACTIONUP if (TRANSACTION.equalsIgnoreCase(sourceType)) =>
         logger.info("Starting the Transactional processing")
      new TransactionTypeProcessor()
   
    case _ =>
      logger.info("Not a Master or Not a Transaction Table");
      return null

  }

   
}