package org.capgemini.mrapid.processing.integration

import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.hive.HiveContext
import org.capgemini.mrapid.processing.api.FileProcessor
import org.capgemini.mrapid.processing.exception.ProcessException
import org.capgemini.mrapid.processing.factory.SystemTypeProcessorFactory
import org.capgemini.mrapid.processing.exception.QueryException

/**
 * * StartProcessLayer class is the main class to differentiate between system
 * type and call respective system type implementation.<br/>
 * Implementation Logic: <br/>
 * SystemType must be CDC or BATCH or XML. <br/>
 * 1. If System Type is CDC, CDCProcesser class method is called with arguments
 * as Source type, country code and partition date. <br/>
 * 2. If System Type is BATCH, BatchFileImplementation() method is called with
 * arguments as Source type, country code and partition date. <br/>
 * 3. If System Type is XML, XmlImpl() method is called. <br/>
 * 4. Finally reconciliation will executed.
 *
 * @author Chandra V
 *
 */

object StartProcessLayer {

  val logger = Logger.getLogger(getClass.getName)

  val conf = new SparkConf().setAppName("SPARK")
  val sc = new SparkContext(conf)

  val hiveContext = new org.apache.spark.sql.hive.HiveContext(sc)

  @throws(classOf[ProcessException])
  def executeProcessLayer(hdfInputs: Array[String]): Unit = {

    var sourceName = ""
    var countryCode = ""
    var partitionDate = ""

    if (hdfInputs.length < 4) {

      var error = "Please pass 4 arguments for ProcessLayer. <sourceName>,<countryCode>,<partitionDate>,<userName>"

      logger.error(error);

      hdfInputs.length match {

        case 3 =>
          sourceName = hdfInputs(0)
          countryCode = hdfInputs(1)
          partitionDate = hdfInputs(2)

        case 2 =>
          sourceName = hdfInputs(0)
          countryCode = hdfInputs(1)

        case _ => sourceName = hdfInputs(0)

      }
     
      throw new ProcessException(error)

    }

    hdfInputs(0) = hdfInputs(0).toLowerCase()
    hdfInputs(1) = hdfInputs(1).toLowerCase()

    
    var isException: Boolean = false;

    System.setProperty("user.name", hdfInputs(3))

    var systemType = sc.getConf.get("spark.systemType")

    val fileProcessor: FileProcessor = SystemTypeProcessorFactory.createSystemTypeProcessor(systemType)
    
    try {

     var executeRecon = fileProcessor.process(hdfInputs, hiveContext, sc, conf)

    } catch {

      case processException: ProcessException => {
        logger.error(processException.getMessage())
        return
      }
      case queryException: QueryException => {
        logger.error(queryException.getMessage())
        return
      }
      case runTimeException: RuntimeException => {
        logger.error(runTimeException.getMessage())
        System.exit(0)
      }

      case exception: Exception => { logger.error(exception.getMessage()) }

    }
  }

  /**
   * Main method will receive arguments from HDF and start to build the
   * process layer
   *
   * @param hdfInput
   *            hdfInput contains three arguments. <br/>
   *            1. SourceName : Name of the source system <br/>
   *            Cannot be null <br/>
   *            2. CountryCode : Name of the country <br/>
   *            Cannot be null <br/>
   *            3. PartitionDate : Name of the partition to process <br/>
   *            Cannot be null <br/>
   * @throws ProcessException
   *
   */

  @throws(classOf[ProcessException])
  def main(hdfInputs: Array[String]): Unit = {

    executeProcessLayer(hdfInputs)

  }

}