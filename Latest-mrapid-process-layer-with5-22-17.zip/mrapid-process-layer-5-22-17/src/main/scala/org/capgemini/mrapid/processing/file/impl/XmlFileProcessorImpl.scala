package org.capgemini.mrapid.processing.file.impl

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.hive.HiveContext
import org.capgemini.mrapid.processing.api.FileProcessor

 class XmlFileProcessorImpl extends FileProcessor {
  
  def process(hdfInputs:Array[String],hc:HiveContext,sc:SparkContext,conf:SparkConf)  = {
     
      println("xml type")
     
      
   }

 
  }