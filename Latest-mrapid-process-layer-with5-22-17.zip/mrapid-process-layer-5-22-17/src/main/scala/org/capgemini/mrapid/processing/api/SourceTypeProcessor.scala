package org.capgemini.mrapid.processing.api

import org.apache.spark.sql.Row
import org.apache.spark.SparkConf
import org.apache.spark.sql.hive.HiveContext
import scala.collection.Map
import org.apache.spark.sql.DataFrame

trait SourceTypeProcessor extends Serializable {
  
  
  /**
	 * 
	 * @param tableName
	 * @param countryCode
	 * @param partitionDate
	 * @param sourceName
	 * 
	 * 
	 */
	def sourceTypeProcess(tableName:String,countryCode:String,
  
      partitionDate:String,sourceName:String,sourceType:String,
      latestPartition:Array[String], nextPartition:Array[String],
      eod_marker:Array[Row],hiveContext:HiveContext,conf:SparkConf,
      tableNameWithVersion:scala.collection.Map[String,String],columns:DataFrame) : Boolean
      
    def getType():String  
	    
 

   
  
}