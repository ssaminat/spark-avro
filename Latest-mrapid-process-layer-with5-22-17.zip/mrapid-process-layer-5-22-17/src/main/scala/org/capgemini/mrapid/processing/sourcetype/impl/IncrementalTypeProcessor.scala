package org.capgemini.mrapid.processing.sourcetype.impl

import org.apache.log4j.Logger
import org.capgemini.mrapid.processing.util.Constants.MASTER

 
 class IncrementalTypeProcessor extends AbstractSourceTypeProcessor {
  
  //val logger = Logger.getLogger(getClass.getName)
  
 
  def getType():String = {
    
		return MASTER;
	}
  
}