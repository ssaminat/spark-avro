package org.capgemini.mrapid.processing.exception

case class QueryException(message: String = "", cause: Throwable = null)
              extends Exception(message, cause) {
}