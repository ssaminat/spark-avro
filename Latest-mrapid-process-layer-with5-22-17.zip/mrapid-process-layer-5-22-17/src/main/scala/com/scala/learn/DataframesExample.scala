package com.scala.learn
import org.apache.spark._
import org.apache.spark.sql._
 
 
object DataframesExample {
  
  
  def main(args: Array[String]): Unit = {
    
    System.setProperty("hadoop.home.dir", "C://winutil//")
  
	/*val TABLE_NAME = "table_name";
  val SOURCETYPE = "source_type";*/
val config = new SparkConf().setAppName("My DataframesExample").setMaster("local")
val sc = new SparkContext(config)
val sqlContext = new org.apache.spark.sql.hive.HiveContext (sc)
  
 val pairs = sqlContext.sql("select table_name,source_type from dotopal_dev_ops.dotopal_all_tables where country_name='BH'").rdd.map {
   case Row(table_name: String, source_type: String) => table_name -> source_type }  
    
    pairs.collect().foreach(println)
    
    
    
}
  
 
  
}