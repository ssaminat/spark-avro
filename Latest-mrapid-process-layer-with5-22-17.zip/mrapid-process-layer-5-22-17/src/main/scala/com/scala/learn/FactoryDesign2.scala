package com.scala.learn

object FactoryDesign2 {
  
}