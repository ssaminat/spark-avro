package com.scala.learn

import scala.collection.mutable._
import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.spark.sql.Row

//import scala.collection.JavaConverters._

object Test1 {

  def main(args: Array[String]): Unit = {
    
   /* System.setProperty("hadoop.home.dir", "C://winutil//")
    
     val conf =  new SparkConf().setAppName("SPARK").setMaster("local").set("spark.local.dir", "C:/Users/1559461/SparkScala/Spark-temp");
     val sc = new SparkContext(conf)
  
      val hiveContext = new org.apache.spark.sql.hive.HiveContext(sc)
     */
    println("scala class")

    val tableNameWithSourceType = Map(("a12", "Mark"), ("b19", "Michelle"))

    var tableName = "a12"

    var tables = Map("chandra" -> List("a", "b", "c"))

    var columns = tables.get("chandra")

    columns.foreach { println }

    var tab = Map("MBICLINK" -> ArrayBuffer("ROWID", "BICCODE", "BRNCHCD", "BRNCHDS", "TSFIELD", "CREATEDBY"),
      "CDC_EOD_RECON" -> ArrayBuffer("ROWID", "SRC_STM", "SRC_CTRY", "TBL_NAME", "EOD_DATE", "EOD_TIMESTAMP", "ROW_CNT"))

    var sam = tab.filter { case (key, _) => key == "MBICLINK" }

    var columnListWithoutDataType = new ListBuffer[String]()
    var arraylist = new java.util.ArrayList[String]()
    
    sam.map { t =>
      val myList = t._2

      for (column <- myList) {

        println(column.toString())

        arraylist.add(column)
        //columnListWithoutDataType.+=(column)

          }

     
    }
    
    println("arraylistbefore :" + arraylist)
    arraylist.add(1, "C_JOURNALTIME")
    arraylist.add(2, "CTRANSACTIONID");
        arraylist.add(3, "COPERATIONTYPE");
        arraylist.add(4, "CUSERID");
        println("size:" + arraylist.size())
        arraylist.add(arraylist.size(), "PART_ODS".toUpperCase());
        println("arraylistafter :" + arraylist)
         
        println("size is******:" + arraylist.size())
       
        val builder:StringBuilder = StringBuilder.newBuilder
        var columnsJoins=""
        
        var i = 0
                         
        for (i <- 0 to arraylist.size()-1) {
          
        if (!arraylist.get(i).equalsIgnoreCase("ROWID")) {
				builder.append("a." + "`" + arraylist.get(i) + "`");
				builder.append(",");
				  columnsJoins = builder.toString();
				
			}
        }
         
         println("string builder:" + columnsJoins)
         println("length:" + (columnsJoins.length() -1))
         
         columnsJoins = columnsJoins.substring(0, columnsJoins.length() - 1)
         println("string builder after:" + columnsJoins)
       // builder.append(s)
         
         var x = 0
         var column=""
         var count = 0;
         
         val builder1:StringBuilder = StringBuilder.newBuilder
         
      /* for (i <- 1 to arraylist.size()-1) {
         
         column = "`" + arraylist.get(i) + "`";
         
         println("count:" + count)
          println("arraylist.size() :" + arraylist.size())
         if (count == arraylist.size()) {
					builder1.append(column);
				} else {
					builder1.append(column);
					builder1.append(",");
				}
         
         count = count + 1
        }
       
      var primaryKeysJoin = builder1.toString();
      
      println("primaryKeysJoin:" + primaryKeysJoin)*/
         
      for (x <- 0 to arraylist.size()-1 ) {
			column = "`" + arraylist.get(x) + "`";
			if (count == 0) {
			  
			  println("count is zero:")

			} else {
				if (count == arraylist.size() - 1) {
					builder1.append(column);
				} else {
					builder1.append(column);
					builder1.append(",");
				}
			}
			count = count + 1
		}
		var primaryKeysJoin = builder1.toString();
		println("primaryKeysJoin:" + primaryKeysJoin)
		
		
		
		val builder2:StringBuilder = StringBuilder.newBuilder
		  
	  var i1 = 0
	  
		for ( i1 <- 0 to arraylist.size() - 1) {
		  
		 // println("twith columns:" + arraylist.get(i1))
				builder2.append("t." + "`" + arraylist.get(i1) + "`")
				builder2.append(",")

		}
		var columnsJoins1:String = builder2.toString();
		columnsJoins1 = columnsJoins1.substring(0, columnsJoins1.length() - 1)
		println("columns with t. :" + columnsJoins1)
		
	/*	var primaryKeyList:java.util.List[Row]=null
		var arraylist2 = new java.util.ArrayList[String]()
		var query = """select column_name from dotopal_dev_ops.dotopal_all_tab_columns where table_name='MPDTRN' 
                   and country_name='BH' and primary_column_indicator='Y'"""
		
	 primaryKeyList = hiveContext.sql(query).collectAsList()
	 
	 var countvalue=0
	 var primaryKeysJoin1 = ""
	 val builder4: StringBuilder = StringBuilder.newBuilder
	 countvalue = (primaryKeyList.size() - 1)
	 
	 if (primaryKeyList.size() != 0) {
	   
	   if (countvalue == primaryKeyList.size() - 1) {
	   builder4.append("`" + primaryKeyList.get(0).toString() + "`")
	   } else {
	
		builder4.append("`" + primaryKeyList.get(0).toString() + "`");
		builder4.append(",");
	 }
		 }
  
		
  primaryKeysJoin1 = builder4.toString();
  println("primaryKeysJoin1:" + primaryKeysJoin1)
	 	 var records = hiveContext.sql(query).collect().map { row => "`" + row.get(0)  + "`" }.mkString(",")      
		println("records :" + records) */
		
		//var str:Array[java.lang.String]=null
		var str2:Array[java.lang.String]=null
		val builder5: StringBuilder = StringBuilder.newBuilder
		//str = records.split(",")
		
			var primaryKeysJoins2 = "";
		var columnsforTb ="PRDCD,TRNREFN,OPRDCD,TRNREFNO"

    str2 =  columnsforTb.split(",")
  
		for (count <- 0 to (str2.length - 1)) {
		  
		    if(count > 0)
		    {
		      builder5.append(" and ");
		    }
		  builder5.append("nvl(a." +  str2(count) +",'1')"
							+ "=nvl(b." + str2(count) + ",'1')");
							  
		}
		
			primaryKeysJoins2 = builder5.toString()
			println("primaryKeysJoins2:" + primaryKeysJoins2)
			
		var list =	List("Bob", "Fred", "Joe", "Julia", "Kim")
		
		var tableList =	List("chandra", "Fred", "Joe", "Julia", "Kim")
		var tableNameWithSourceType1 = Map("chandra" -> "sekhar")
		
		for (tableName <- tableList) {
      
      println("inside for loop ***:")

      var sourceTypeOfTable = " "

      val result = tableNameWithSourceType1.get(tableName)
      
      println("result :" + result)

      if (result.isDefined) {
        
        println(result.get)
        
        sourceTypeOfTable = result.get
        println("sourceTypeOfTable :" + sourceTypeOfTable)

      }
			
		}
			
			
			
			
			
  }
}