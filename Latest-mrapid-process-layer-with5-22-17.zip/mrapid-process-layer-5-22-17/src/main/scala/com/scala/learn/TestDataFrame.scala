package com.scala.learn
//import scala.collection.Map
//import scala.collection.mutable
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.sql._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.hive.HiveContext
import org.capgemini.mrapid.processing.exception.ProcessException
import org.capgemini.mrapid.processing.exception.QueryException
import org.capgemini.mrapid.processing.util.Constants._
import org.apache.spark.SparkContext
//import scala.collection.JavaConversions._


object TestDataFrame {
  
  def main(args: Array[String]): Unit = {
    
     // val tableNameWithSourceType = scala.collection.mutable.Map[String, String]()
 // var tableNameWithSourceType = scala.collection.mutable.Map[String, String]()
  val conf = new SparkConf().setAppName("SPARK")
  val sc = new SparkContext(conf)
 // var tableNameWithSourceType:scala.collection.Map[String,String] = null
  //val tableNameWithSourceType = scala.collection.mutable.Map[String, String]()
  val hiveContext = new org.apache.spark.sql.hive.HiveContext(sc)
  
  def executeQueryForTableList(columns: String) = {

   var tableNameWithSourceType: scala.collection.Map[String, String] = null
   //var tableNameWithSourceType = new java.util.HashMap[String,String]() 
    
    var commonDatabase="dotopal_dev_ops"
    var systemName = "dotopal"
    var countryName = "bh"
   
      var query = "";
      var ctryNamUpper = countryName.toUpperCase();
      var filePath = "/dev/scudee/dotopal/hdata"
      ///dev/scudee/dotopal/hdata/dotopal_dev_ops/dotopal_all_tables
      
      /*val allTabColumnsPath = (filePath + FORWARD_SLASH + commonDatabase
				+ FORWARD_SLASH + sourceName + UNDERSCORE + SCB_ALL_TAB
				+ FORWARD_SLASH + STAR);*/

      if (columns.length() == 0) {

        query = ("select " + TABLE_NAME + " from "
          + commonDatabase + DOT + systemName + UNDERSCORE
          + SCB_ALL_TAB + " where " + COUNTRY_NAME + EQUAL_SIGN + "'" + ctryNamUpper + "'")

      } else {

          
        query = ("select " + TABLE_NAME + COMMA + columns + COMMA + VERSION + " from " +
          commonDatabase + DOT + systemName + UNDERSCORE + SCB_ALL_TAB + " where "
          + COUNTRY_NAME + EQUAL_SIGN + "'" + ctryNamUpper + "'" + " order by " + VERSION + " asc")
      }

      val resultSetDF = hiveContext.sql(query).rdd.map { case Row(table_name: String, source_type: String,version:String) => table_name -> source_type }
      tableNameWithSourceType = resultSetDF.collectAsMap()
      
     /* val resultSetDF = hiveContext.sql(query).collectAsList()
      
      val iterator = resultSetDF.iterator()
      
      while (iterator.hasNext()) {

      val row = iterator.next()

      tableNameWithSourceType.put(row.get(0).toString(), row.get(1).toString())*/
      
     tableNameWithSourceType
  }
  
  
  
  var columns = "source_type"
  var tableNameWithSourceType1 = executeQueryForTableList(columns:String)
   //to write data to hdfs path with \u0002 delimited file
 /*  val dfs = hiveContext.sql("select * from dotopalt2_dev_ops.dotopalt2_bh_cdc_eod_marker") 
   
     val mapRdd = dfs.map {x => x.toString.replaceAll("[\\[\\]]","")}
     val splitRdd =  mapRdd.map{ rec => rec.toString.replaceAll(",","\u0002")}.saveAsTextFile("C:/Users/1559461/SparkScala/output1")*/
    
  
  var columnsRDD: scala.collection.Map[String, Iterable[String]] = null

  def getColumnsList(filePath: String, commonDatabase: String, sourceName: String, countryCode: String, sc: SparkContext): scala.collection.Map[String, Iterable[String]] = {

    val allTabColumnsPath = """filePath + FORWARD_SLASH + commonDatabase
				+ FORWARD_SLASH + sourceName + UNDERSCORE + SCB_ALL_TAB_COLUMNS
				+ FORWARD_SLASH + STAR""";

    ////sit/scudee/dotopal/hdata/dotopal_dev_ops/dotopal_all_tab_columns/*
    //scala.collection.Map[String,Iterable[String]]
    //res0: scala.collection.Map[String,Iterable[String]] = Map(MBICLINK -> CompactBuffer(ROWID, BICCODE, BRNCHCD, BRNCHDS, TSFIELD, CREATEDBY, CREATEDDT, CREATEDTIME, MODIFIEDBY, MODIFIEDDT, MODIFIEDTIME, ROWID, BICCODE, BRNCHCD, BRNCHDS, TSFIELD, CREATEDBY, CREATEDDT, CREATEDTIME, MODIFIEDBY, MODIFIEDDT, MODIFIEDTIME),
    //CDC_EOD_RECON -> CompactBuffer(ROWID, SRC_STM, SRC_CTRY, TBL_NAME, EOD_DATE, EOD_TIMESTAMP, ROW_CNT, CHKSUM_FLD_NM, CHKSUM_TOT, DATE_FLD_NM, ROWID, SRC_STM, SRC_CTRY, TBL_NAME, EOD_DATE, EOD_TIMESTAMP, ROW_CNT, CHKSUM_FLD_NM, CHKSUM_TOT, DATE_FLD_NM), MDEPTBIC -> CompactBuffer(ROWID, BIC, MSGTYPE, RECSTATUS, ROWID, BIC, MSGTYPE, RECSTATUS), MCHGDTL -> CompactBuffer(ROWID, CHGDTLCD, CHGDTLDS, TSFIELD, CREATEDBY, CREATEDDT, CREATEDTIME, MODIFIEDBY, MODIFIEDDT, MODIFIEDTIME, ROW.
    //"/sit/scudee/dotopal/hdata/*

    /*val columnsRDD = sc.textFile("/sit/scudee/dotopal/hdata/dotopal_dev_ops/dotopal_all_tab_columns/*").filter { cols => cols.split(DELIMITER)(2).equalsIgnoreCase(countryCode) }
      .map { rec => (rec.split(DELIMITER)(0), rec.split(DELIMITER)(1)) }.groupByKey().collectAsMap()*/
      * 
      */
     columnsRDD = sc.textFile(allTabColumnsPath).filter { cols => cols.split(DELIMITER)(2).equalsIgnoreCase(countryCode) }
      .map { rec => (rec.split(DELIMITER)(0), rec.split(DELIMITER)(1)) }.groupByKey().collectAsMap()

    
    return columnsRDD

  }

  //Example
 /* def countWords(text: String)= {
         val counts = mutable.Map.empty[String, Int]
      for (rawWord <- text.split("[ ,!.]+")) {
        val word = rawWord.toLowerCase
       val oldCount = 
           if (counts.contains(word)) counts(word)
        else 0
     counts += (word -> (oldCount + 1))
    }
    counts
    
    
  }*/
  
    
  def getNextEodDate(countryCode: String) = {

     var query = ""
    val commonDatabase="gps_dev_ops"
    val systemName = "gps"
    val countryName = "ALL"
    var cdc_eod_Marker = "tl_eod_marker"
    val partitionDate="2017-02-08"
      query = ("select " + "cast(" + NEXT_EOD_DATE
                + " as date) " + " from " + commonDatabase + DOT
                + systemName + UNDERSCORE + countryCode + UNDERSCORE
                + cdc_eod_Marker + " where " + "cast(" + EOD_DATE
                + " as date) " + EQUAL_SIGN + " '" + partitionDate + "'")

    val Eod_Date = hiveContext.sql(query).collectAsList()
  
    Eod_Date
  }
  
  val countryCode = "all"
  val eodDate = getNextEodDate(countryCode)
  //eodDate: java.util.List[org.apache.spark.sql.Row] = [[2017-02-09]]
  
  val commonDatabase="gps_dev_ops"
  val systemName = "gps"
  val countryName = "ALL"
  val COLUMN_NAME = "column_name";
  val sourceName="gps"
  
 //select table_name,column_name,version,primary_column_indicator from gps_dev_ops.gps_all_tab_columns where country_name='ALL'
  
  var queryDF = ("select " + TABLE_NAME + COMMA + COLUMN_NAME + COMMA
					+ VERSION + COMMA + PRIMARY_KEY_COULUMN + " from "
					+ commonDatabase + DOT + sourceName + UNDERSCORE
					+ SCB_ALL_TAB_COLUMNS + " where " + COUNTRY_NAME
					+ EQUAL_SIGN + "'" + countryCode.toUpperCase() + "'")
					
	var tableNameversionDF = hiveContext.sql(queryDF)
	
	 var arraylist = new java.util.ArrayList[String]()
			
	var df2 = tableNameversionDF
					.where("table_name ='"
							+ "TL_CURR_HOLIDAY_DETAILS" + "'")
					.where("version ='" + "1" + "'")
					.select("column_name")
					
					var columnList = df2.collectAsList();
  
       val iterator =  columnList.iterator()
       
       
       while(iterator.hasNext()) {
         
         val row = iterator.next()
         
         arraylist.add(row.get(0).toString())
         
       }
       
 
       
  def getJournalTime(countryCode: String, LatestPartitions: java.util.List[Row], 
      hiveContext: HiveContext, prop: SparkConf, partitionDate: String) = {

   // logger.info("inside the getJournalTime() method")

    var query = ""
    val JournalTime: java.util.List[Row] = null
    
   // val commonDatabase = prop.get("spark.commonDatabase")
    val cdc_eod_Marker = prop.get("spark.cdc_eod_marker")

    //val currentAndPreviousEodDate = "2017-04-24"

      if (LatestPartitions.size >= 1) {
        
       val testcond =  if (LatestPartitions.size() == 1) (LatestPartitions.get(0).get(0).toString() + "'") else (LatestPartitions.get(0).get(0)
										.toString()
										+ "' or "
										+ "cast("
										+ EOD_DATE
										+ " as date)" + "='" + LatestPartitions
										.get(1).get(0).toString())

        query = ("select " + "cast("
          + EOD_DATE
          + " as date) as " + EOD_DATE
          + COMMA
          + "max("
          + C_JOURNALTIME
          + ") from "
          + commonDatabase
          + DOT
          + systemName
          + UNDERSCORE
          + countryCode
          + UNDERSCORE
          + cdc_eod_Marker
          + " where "
          + "cast("
          + EOD_DATE
          + " as date)"
          + " ='"
          + testcond
					+ "'" + " group by " + EOD_DATE
					+ " order by " + EOD_DATE)

       // logger.info("Executing Query for getting two journaltime:->" + query)

        val JournalTime = hiveContext.sql(query).collectAsList()
        JournalTime

      } 
       
    }
  }
}

  