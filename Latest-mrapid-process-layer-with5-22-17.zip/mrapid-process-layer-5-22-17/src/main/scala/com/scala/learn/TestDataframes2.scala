package com.scala.learn

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.capgemini.mrapid.processing.util.Constants._
import org.apache.spark.sql._
import scala.collection.mutable.ListBuffer

import org.apache.log4j.Logger
object TestDataframes2 {

  
  case class TableWithSourceType(table_name: String, source_type: String)
  val logger = Logger.getLogger(getClass.getName)
  
  def main(args: Array[String]): Unit = {

    val conf = new SparkConf().setAppName("SPARK")
    val sc = new SparkContext(conf)

    val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)
    
       
    var filePath = "/dev/scudee/sts/hdata"
    var commonDatabase="sts_dev_ops"
    var systemName = "sts"
    var countryName = "bh"
    var cdc_eod_Marker ="tl_eod_marker"
    var partitionDate = "2017-03-19"
    
    
    var listBuffer = new ListBuffer[String]()
    
    listBuffer += filePath
    listBuffer += commonDatabase
    listBuffer += systemName + UNDERSCORE + SCB_ALL_TAB
    listBuffer += countryName + UNDERSCORE + SCB_ALL_TAB + UNDERSCORE + STAR
    
        
    var allTablesPath = listBuffer.mkString("/")

    
    
    // /dev/scudee/dotopal/hdata/dotopal_dev_ops/dotopal_all_tables
    // /sit/scudee/sts/hdata/sts_dev_ops/sts_all_tables/bh_all_tables_V1
    
   
      
     /*var allTablesPath1 = (filePath + FORWARD_SLASH + commonDatabase
				+ FORWARD_SLASH + systemName + UNDERSCORE + SCB_ALL_TAB
				+ FORWARD_SLASH + countryName + UNDERSCORE + SCB_ALL_TAB + UNDERSCORE + STAR)*/
    
    def executeQueryForTableList() = {

      var tableNameWithSourceType:  Array[(String, String)] = null
      var listBuffer = new ListBuffer[String]()

      listBuffer += filePath
      listBuffer += commonDatabase
      listBuffer += systemName + UNDERSCORE + SCB_ALL_TAB
      listBuffer += countryName + UNDERSCORE + SCB_ALL_TAB + UNDERSCORE + STAR

      var allTablesPath = listBuffer.mkString("/")
      
		 import sqlContext.implicits._
			 var tableWithSourceRDD = sc.textFile(allTablesPath).filter { cols => cols.split(DELIMITER)(0).equalsIgnoreCase(countryName) }
                                 .map{row => (row.split(DELIMITER)(1),row.split(DELIMITER)(3))}
      
      var tableWithSourceRDDDF = tableWithSourceRDD.toDF().cache()
      tableNameWithSourceType = tableWithSourceRDDDF.map { row => (row(0).toString(),row(1).toString())}.collect()
      
      tableNameWithSourceType
 
    }
    
    var test1 = executeQueryForTableList()
    
      //Array[org.apache.spark.sql.Row] = Array([2017-03-19 00:00:00])
      //tableWithSourceRDDDF: Array[org.apache.spark.sql.Row]
      //tableWithSourceRDDDF: Array[org.apache.spark.sql.Row] = Array([TL_PRIORITY,MASTER], [TL_COUNTRY,MASTER],
      
    //  /dev/scudee/sts/hdata/sts_dev_ops/bh/sts_bh_tl_eod_marker
     
    def getNextEodDate():Array[String] = {
      
       var nextEodDate:Array[String] = null
    
      try {
    var listBuffer1 = new ListBuffer[String]()
   
    import sqlContext.implicits._
    
    listBuffer1 += filePath
    listBuffer1 += commonDatabase
    listBuffer1 += countryName
    listBuffer1 += systemName + UNDERSCORE + countryName + UNDERSCORE + cdc_eod_Marker.toLowerCase()
    listBuffer1 += PART_ODS + EQUAL_SIGN + partitionDate
     //need to declare TL_EOD_MARKER in lower case for path
    
    var nextEodPath = listBuffer1.mkString("/")
      
   	var	nextEodDateRDD = sc.textFile(nextEodPath).map{cols => cols.split(EODDELIMITER)(5)}.toDF() 
   	
      nextEodDate  = nextEodDateRDD.map {x => x(0).toString}.collect()
    
    //nextEodDate
    
      }catch {
      case runTimeException: RuntimeException => { println("error")}
        
       // System.exit(0)}
      }
    
      nextEodDate
    }
   	
    var test2 = getNextEodDate()
    
    import sqlContext.implicits._
    
    def getLatestEodDates():Array[String] = {
      
      var topTwoEodDates:Array[String] = null
      
    try {
      
   	 var listBuffer2 = new ListBuffer[String]()
    
   	 
    listBuffer2 += filePath
    listBuffer2 += commonDatabase
    listBuffer2 += countryName
    listBuffer2 += systemName + UNDERSCORE + countryName + UNDERSCORE + cdc_eod_Marker.toLowerCase()
    listBuffer2 += PART_ODS + EQUAL_SIGN + STAR
    
   	var LatestPartitions = listBuffer2.mkString("/")
   	
   	var	 EodDateRDD = sc.textFile(LatestPartitions).map{cols => cols.split(EODDELIMITER)(4)}.toDF()
   	var  LatestEodDates= EodDateRDD.distinct().withColumnRenamed("_1", "eodDate").orderBy($"eodDate".desc) 
   	      topTwoEodDates = LatestEodDates.map {x => x(0).toString}.take(2)
   	
    }catch {
      case runTimeException: RuntimeException => { println("error")}
        
       // System.exit(0)}
      }
    
      topTwoEodDates
    }
   	
   
    
   	var currentAndPreviousEodDate = getLatestEodDates()
   	
   	def getJournalTime(currentAndPreviousEodDate: Array[String]) = {

    var query = ""
    var dataframe:Array[Row] = null

      if (currentAndPreviousEodDate.size >= 1) {

        val testcond = if (currentAndPreviousEodDate.size == 1) (currentAndPreviousEodDate(0).toString() + "'") else (currentAndPreviousEodDate(0)
          .toString() + "' or " + "cast(" + EOD_DATE + " as date)" + "='"
          + currentAndPreviousEodDate(0).toString())

        query = ("select " + "cast("
          + EOD_DATE
          + " as date) as " + EOD_DATE
          + COMMA
          + "max("
          + C_JOURNALTIME
          + ") from "
          + commonDatabase
          + DOT
          + systemName
          + UNDERSCORE
          + countryName
          + UNDERSCORE
          + cdc_eod_Marker
          + " where "
          + "cast("
          + EOD_DATE
          + " as date)"
          + " ='"
          + testcond
          + "'" + " group by " + EOD_DATE
          + " order by " + EOD_DATE)

              
           dataframe = sqlContext.sql(query).collect

      }
  
    dataframe
  }
   	
   	 var journaltime = getJournalTime(currentAndPreviousEodDate)
   	 
   	 
   	
     
  }

}