package com.scala.learn

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import com.typesafe.config._

object RatingsCounter {
  
  def parse(line:String) = {
    
    val fields = line.split("\t")
    val id = fields(0).toInt
    val rating= fields(2).toInt
    
    (rating,id)
  }

  def main(args: Array[String]): Unit = {
    
  
    //System.setProperty("hadoop.home.dir", "C://winutil//")
    
    //prop.getConfig(args(1)).getString("executionmode").foreach {print}

    //val conf = new SparkConf().setAppName("RatingsCounter").setMaster(prop.getConfig(args(1)).getString("executionmode"))
    
    val conf = new SparkConf().setAppName("RatingsCounter")
    
    val sc = new SparkContext(conf)

    val lines   = sc.textFile(args(0),4)
    val ratingfileds = lines.map(parse)
    
    val ratingscounter = ratingfileds.map(_._1).countByValue().toSeq.sortBy(_._1)
    val ratingscounterwt = ratingscounter.map(x => (x._1 + "\t" + x._2))
    
    val resutls = ratingscounterwt.foreach(println)
    
    
   
  }

}