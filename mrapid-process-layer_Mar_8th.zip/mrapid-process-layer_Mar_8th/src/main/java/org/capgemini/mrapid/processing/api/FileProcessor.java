package org.capgemini.mrapid.processing.api;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.hive.HiveContext;
import org.capgemini.mrapid.processing.exception.ProcessException;
import org.capgemini.mrapid.processing.exception.QueryException;

/**
 * Interface for file type process functionalities(CDC and Batch).
 * 
 * @author ikumarav
 */
public interface FileProcessor {
	/*
	 * Process method performs the Delta or transaction or Full base
	 * functionalities.
	 */
	public boolean process(String[] hdfInputs,HiveContext hiveContext, JavaSparkContext jsCtx,SparkConf prop) throws ProcessException,
			QueryException;
}
