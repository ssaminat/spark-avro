package org.capgemini.mrapid.processing.factory;

import static org.capgemini.mrapid.processing.util.Constants.CDC;
import static org.capgemini.mrapid.processing.util.Constants.BATCH;

import org.apache.log4j.Logger;
import org.capgemini.mrapid.processing.api.FileProcessor;
import org.capgemini.mrapid.processing.file.impl.BatchFileProcessorImpl;
import org.capgemini.mrapid.processing.file.impl.CDCFileProcessorImpl;
import org.capgemini.mrapid.processing.file.impl.XmlFileProcessorImpl;

/**
 * This factory class is used to decide which SystemType(CDC,Batch or XML) needs to create a
 * processor.
 * 
 * @author ikumarav
 *
 */
public class SystemTypeProcessorFactory {
	final static Logger logger = Logger
			.getLogger(SystemTypeProcessorFactory.class);

	/**
	 * This method create the object based on systemType.
	 * @param systemType
	 *            : Name of the System <br/>
	 *            Cannot be null <br/>
	 * @return Object of FileProcessor
	 */
	public static FileProcessor createSystemTypeProcessor(String systemType) {
		if (CDC.equalsIgnoreCase(systemType)) {
			logger.info("Starting the CDC SystemType");
			return new CDCFileProcessorImpl();
		} else if (BATCH.equalsIgnoreCase(systemType)) {
			logger.info("Starting the Batch SystemType");
			return new BatchFileProcessorImpl();
		} else {
			logger.info("Starting the XML SystemType");
			return new XmlFileProcessorImpl();
		}
	}
}
