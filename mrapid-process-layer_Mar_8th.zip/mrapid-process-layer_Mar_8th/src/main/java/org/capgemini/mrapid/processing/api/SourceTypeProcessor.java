package org.capgemini.mrapid.processing.api;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import org.apache.spark.SparkConf;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.hive.HiveContext;

/**
 * Interface for source type processor functionalities.
 * 
 * @author ikumarav
 *
 */
public interface SourceTypeProcessor extends Serializable {
	/**
	 * 
	 * @param tableName
	 * @param countryCode
	 * @param partitionDate
	 * @param sourceName
	 */
	boolean sourceTypeProcess(String tableName, String countryCode,
			String partitionDate, String sourceName, String sourceType,
			List<Row> latestPartition, List<Row> nextPartition,
			List<Row> eod_marker,HiveContext hiveContext,SparkConf prop, Broadcast<Map<String, Iterable<String>>> columns, Broadcast<Map<String, Iterable<String>>> primaryColumns, List<String> metaDateList);

	String getType();
}
