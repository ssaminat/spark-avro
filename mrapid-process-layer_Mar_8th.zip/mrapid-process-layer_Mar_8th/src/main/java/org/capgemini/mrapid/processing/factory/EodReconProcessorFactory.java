package org.capgemini.mrapid.processing.factory;

import static org.capgemini.mrapid.processing.util.Constants.MASTER;

import org.apache.log4j.Logger;
import org.capgemini.mrapid.processing.api.EodReconProcessor;
import org.capgemini.mrapid.processing.recon.impl.EodReconDeltaProcessorImpl;
import org.capgemini.mrapid.processing.recon.impl.EodReconTransactionProcessorImpl;

public class EodReconProcessorFactory {
	final static Logger logger = Logger
			.getLogger(SourceTypeProcessorFactory.class);

	public EodReconProcessor createProcessorForRecon(String sourceType) {
		if (MASTER.equalsIgnoreCase(sourceType)) {
			logger.info("Starting the Delta Recon processing");

			return new EodReconDeltaProcessorImpl();
		} else {
			logger.info("Starting the Transactional Recon processing");

			return new EodReconTransactionProcessorImpl();
		}
	}
}
