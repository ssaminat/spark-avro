package org.capgemini.mrapid.processing.exception;

/**
 * This class is for handling the query related exception.
 * 
 * @author ikumarav
 *
 */

public class QueryException extends Exception {

	private static final long serialVersionUID = 1L;

	public QueryException(String s) {
		super(s);
	}
}
