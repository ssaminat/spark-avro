package org.capgemini.mrapid.processing.file.impl;

import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.hive.HiveContext;
import org.capgemini.mrapid.processing.api.FileProcessor;
import org.capgemini.mrapid.processing.exception.ProcessException;
import org.capgemini.mrapid.processing.exception.QueryException;

/**
 * 
 * This class implements business logic for Batch Implementation. <br/>
 * Batch file format are as follows: H-Header T-Trailer X-Delete. <br/>
 * Implementation Logic: <br/>
 * 1. Get the records from table based on partition date.<br/>
 * 2. Remove the (X)Deleted records from the table.<br/>
 * 3. Save hive tables in ORC format.<br/>
 * Source table name format must be : database.countrycode_tablename. <br/>
 * Destination table name format must be : database.countrycode_tablename_orc. <br/>
 * 
 * @author ikumarav
 */
public class BatchFileProcessorImpl implements FileProcessor {
	final Logger logger = Logger.getLogger(this.getClass());
	public static final String CLASSNAME = "BatchFileProcessorImpl";

	
	/*/ *  * (non-Javadoc)
	 * 
	 * @see
	 * org.capgemini.mrapid.processing.api.FileProcessor#process(java.lang.String
	 * [])*/
	 

	public boolean process(String[] hdfInput, HiveContext hiveContext,JavaSparkContext jsCtx,
			SparkConf prop) throws ProcessException, QueryException {

		/*logger.info(CLASSNAME + "process method has started");

		*//**
		 * hdfInput[0] : sourceName. <br/>
		 * Cannot be null <br/>
		 * hdfInput[1] : countryName. <br/>
		 * Cannot be null <br/>
		 * hdfInput[2] : partitionDate.<br/>
		 * Cannot be null <br/>
		 * hdfInput[3] : 'Y' or 'N'.<br/>
		 * hdfInput[4] : tableName.<br/>
		 * Cannot be null <br/>
		 * *//*

		String sourceName = hdfInput[0];
		String countryCode = hdfInput[1];
		String partitionDate = hdfInput[2];

		Map<String, String> tableNameWithSourceType = new HashMap<String, String>();
		List<String> tableList = null;
		boolean isError = false;
		QueryExecutor queryExecutor = new QueryExecutor(sourceName,
				countryCode, partitionDate);
		MetaDataProcessor metaDataProcessor = new MetaDataProcessor();
		CommonUtil commonUtil = new CommonUtil();
		SourceTypeProcessorFactory sourceTypeProcessorFactory = new SourceTypeProcessorFactory();
		RowCounts rowCount = new RowCounts();
		boolean status = false;
		boolean fullBase = false;
		
		 * tableNameWithSourceType is a map, it contains the tableName and
		 * sourceType. tableList is a list, it contains all the tableNames.
		 

		try {
			tableNameWithSourceType = queryExecutor.executeQueryForTableList(
					SOURCETYPE, countryCode, hiveContext, prop);
			tableList = new ArrayList<String>(tableNameWithSourceType.keySet());

		} catch (QueryException queryException) {
			logger.error(queryException.getMessage());
			isError = true;
			metaDataProcessor.processMetaData(sourceName, countryCode,
					partitionDate, null, FAILURE, queryException.getMessage(),
					PROCESS_LAYER, CDC, hiveContext, prop);
			String description = "Due to " + queryException.getMessage()
					+ PROCESS_LAYER + "is " + FAILURE;
			commonUtil.createFileForRemedy(sourceName, countryCode,
					partitionDate, "FD_NFD", "202", description,
					"process_build", prop);
			throw queryException;
		}
		if (!isError) {
			logger.info("Logging the success stage in BATCH level into process metadata table");
			metaDataProcessor.processMetaData(sourceName, countryCode,
					partitionDate, null, SUCESS,
					"BATCH is successfully started", "Processing Layer",
					"Batch", hiveContext, prop);
		}

		for (String tableName : tableList) {
			logger.info("Getting records from " + tableName);

			SourceTypeProcessor sourceTypeProcessor = sourceTypeProcessorFactory
					.createProcessor(tableNameWithSourceType.get(tableName));

			if (sourceTypeProcessor != null)
				status = sourceTypeProcessor.sourceTypeProcess(sourceName,
						tableName.toLowerCase(), countryCode, partitionDate,
						tableNameWithSourceType.get(tableName),hiveContext,prop);

			if (status) {
				metaDataProcessor.processMetaData(sourceName, countryCode,
						partitionDate, tableName, SUCESS,
						sourceTypeProcessor.getType()
								+ " is successfully completed", PROCESS_LAYER,
						sourceTypeProcessor.getType(),hiveContext,prop);

			}
			status=false;
		}
		if (tableList != null && !tableList.isEmpty()){
			rowCount.rowCount(sourceName, countryCode, partitionDate,
					tableList, fullBase,hiveContext,prop);
		}
		return true;
	}*/
		return true;
}
}
