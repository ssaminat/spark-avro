/*package org.capgemini.mrapid.processing.sourcetype.impl;

import static org.capgemini.mrapid.processing.util.Constants.AVRO;
import static org.capgemini.mrapid.processing.util.Constants.COMMA;
import static org.capgemini.mrapid.processing.util.Constants.C_JOURNALTIME;
import static org.capgemini.mrapid.processing.util.Constants.DOT;
import static org.capgemini.mrapid.processing.util.Constants.END_DATE;
import static org.capgemini.mrapid.processing.util.Constants.END_DATETIME;
import static org.capgemini.mrapid.processing.util.Constants.EQUAL_SIGN;
import static org.capgemini.mrapid.processing.util.Constants.FAILURE;
import static org.capgemini.mrapid.processing.util.Constants.FORWARD_SLASH;
import static org.capgemini.mrapid.processing.util.Constants.FULLBASE;
import static org.capgemini.mrapid.processing.util.Constants.PART_ODS;
import static org.capgemini.mrapid.processing.util.Constants.PROCESS_LAYER;
import static org.capgemini.mrapid.processing.util.Constants.PROCESS_BUILD;

import java.util.List;

import org.apache.spark.SparkConf;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.hive.HiveContext;
import org.capgemini.mrapid.processing.exception.QueryException;
import org.capgemini.mrapid.processing.metadata.MetaDataProcessor;
import org.capgemini.mrapid.processing.sparksql.QueryExecutor;
import org.capgemini.mrapid.processing.util.CommonUtil;

*//**
 * This class implements the full dump implementation. <br/>
 * For Full Base: <br/>
 * 1. Get the records for current partition.It contains I records only.<br/>
 * 2. Save those records into hive tables in ORC format.<br/>
 * 3. Source Table Format: Source country code_tablename in AVRO format.<br/>
 * Destination Table Format: Source country code_tablename in ORC format.<br/>
 * 
 * @author ikumarav
 *
 *//*
@SuppressWarnings("serial")
public class FullBaseTypeProcessor extends AbstractSourceTypeProcessor {

	
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.capgemini.mrapid.processing.sourcetype.impl.AbstractSourceTypeProcessor
	 * #sourceTypeProcess(java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String)
	 
	*//**
	 * @param sourceName
	 * @param tableName
	 * @param countryCode
	 * @param partitionDate
	 * @return
	 *//*
	public boolean sourceTypeProcess(String sourceName, String tableName,
			String countryCode, String partitionDate,
			List<Row> latestPartition, List<Row> nextPartition,
			List<Row> eod_marker, HiveContext hiveContext, SparkConf prop) {
		logger.info("Inside FullBaseTypeProcessor class sourceTypeProcess() method");
		CommonUtil commonUtil = new CommonUtil();
		MetaDataProcessor metaDataProcessor = new MetaDataProcessor();
		// SparkConf prop = Singleton.getSparkConf();
		String filePath = prop.get("spark.filePath");
		String stagingDatabase = prop.get("spark.stagingDatabase");
		String processedDatabase = prop.get("spark.processedDatabase");
		// HiveContext hiveContext = Singleton.getHiveContext();
		try {

			// String startDate = "";
			String query = "";
			// String Date = "";
			String fromTimezone = prop.get("spark.fromJournalTimeTimeZone");
			String toTimezone = prop.get("spark.toJournalTimeTimeZone");

			
			 * if (nextPartition.size() > 0 && nextPartition.get(0).get(0) !=
			 * null) { if ((Date = nextPartition.get(0).get(0).toString())
			 * .contains(":")) { startDate = Date.split(" ")[0]; }else{
			 * startDate = nextPartition.get(0).get(0).toString(); } }
			 

			String ORCPath = filePath + FORWARD_SLASH + processedDatabase
					+ FORWARD_SLASH + countryCode + FORWARD_SLASH + tableName
					+ FORWARD_SLASH + PART_ODS + EQUAL_SIGN + partitionDate;

			String tempTableForFullBase = sourceName + tableName + "_tmp";

			logger.info("Reading the records from " + tableName
					+ " in AVRO format");
			DataFrame dataframe = hiveContext
					.read()
					.format(AVRO)
					.load(filePath + FORWARD_SLASH + stagingDatabase
							+ FORWARD_SLASH + countryCode + FORWARD_SLASH
							+ tableName + FORWARD_SLASH + PART_ODS + EQUAL_SIGN
							+ partitionDate + "/*");

			logger.info("Storing the records into " + tableName
					+ " in ORC format");

			dataframe.registerTempTable(tempTableForFullBase);

			query = "show columns in " + stagingDatabase + DOT + tableName;
			logger.info("Executing query for getting all the columns from"
					+ tableName + ":->" + query);
			List<Row> columnList = QueryExecutor.getListFromQuery(hiveContext,
					query);
			List<String> columnListWithoutDataType = CommonUtil
					.getColumnListWithoutDataType(columnList);
			String columnJoins = CommonUtil
					.getColumnListForJoins(columnListWithoutDataType);

			CommonUtil.deletePreviousPath(ORCPath);
			
			 * hiveContext .setConf("hive.exec.dynamic.partition.mode",
			 * "nonstrict");
			 

			query = " select a." + "`" + "rowid" + "`" + COMMA + "'"
					+ partitionDate + "'" + COMMA
					+ "from_utc_timestamp(to_utc_timestamp(" + "a."
					+ C_JOURNALTIME + "," + "\"" + fromTimezone + "\"" + "),"
					+ "\"" + toTimezone + "\"" + ")" + COMMA + "\"" + END_DATE
					+ "\"" + COMMA + "\"" + END_DATETIME + "\"" + COMMA
					+ columnJoins + " from " + tempTableForFullBase + " a";
			logger.info("Executing query for joining two temporary tables for"
					+ tableName + ":->" + query);
			String finalQuery = "INSERT INTO " + processedDatabase + DOT
					+ tableName + " PARTITION(" + PART_ODS + "='"
					+ partitionDate + "')" + query;
			logger.info("Executing query for inserting the records into process layer:->"
					+ finalQuery);
			QueryExecutor.getDataFrameFromQuery(hiveContext, finalQuery);

		} catch (QueryException queryException) {
			logger.error(queryException);

			metaDataProcessor.processMetaData(sourceName, countryCode,
					partitionDate, tableName, FAILURE,
					queryException.getMessage(), PROCESS_LAYER, FULLBASE,
					hiveContext, prop);
			String description = "Due to " + queryException.getMessage()
					+ FULLBASE + "table " + tableName + " is " + FAILURE;
			commonUtil.createFileForRemedy(sourceName, countryCode,
					partitionDate, "FD", "202", description, PROCESS_BUILD,
					prop);
			return false;
		} catch (Exception exception) {
			logger.error(exception);
			String description = "Due to " + exception.getMessage()
					+ "FullBase table " + tableName + " is " + FAILURE;
			commonUtil.createFileForRemedy(sourceName, countryCode,
					partitionDate, "FD", "202", description, PROCESS_BUILD,
					prop);
			return false;
		}
		return true;
	}

	
	 * (non-Javadoc)
	 * 
	 * @see org.capgemini.mrapid.processing.api.SourceTypeProcessor#getType()
	 
	public String getType() {
		return FULLBASE;
	}

}
*/