package org.capgemini.mrapid.processing.sourcetype.impl;

import static org.capgemini.mrapid.processing.util.Constants.COMMA;
import static org.capgemini.mrapid.processing.util.Constants.C_JOURNALTIME;
import static org.capgemini.mrapid.processing.util.Constants.C_OPERATIONTYPE;
import static org.capgemini.mrapid.processing.util.Constants.DOT;
import static org.capgemini.mrapid.processing.util.Constants.END_DATE;
import static org.capgemini.mrapid.processing.util.Constants.END_DATETIME;
import static org.capgemini.mrapid.processing.util.Constants.EQUAL_SIGN;
import static org.capgemini.mrapid.processing.util.Constants.FAILURE;
import static org.capgemini.mrapid.processing.util.Constants.FORWARD_SLASH;
import static org.capgemini.mrapid.processing.util.Constants.NFD;
import static org.capgemini.mrapid.processing.util.Constants.PART_ODS;
import static org.capgemini.mrapid.processing.util.Constants.PROCESS_BUILD;
import static org.capgemini.mrapid.processing.util.Constants.PROCESS_LAYER;
import static org.capgemini.mrapid.processing.util.Constants.R202;
import static org.capgemini.mrapid.processing.util.Constants.UNDERSCORE;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.hive.HiveContext;
import org.capgemini.mrapid.processing.api.SourceTypeProcessor;
import org.capgemini.mrapid.processing.exception.ProcessException;
import org.capgemini.mrapid.processing.exception.QueryException;
import org.capgemini.mrapid.processing.metadata.MetaDataProcessor;
import org.capgemini.mrapid.processing.sparksql.QueryExecutor;
import org.capgemini.mrapid.processing.util.CommonUtil;
import org.capgemini.mrapid.processing.util.ProcessPrimaryKeyUtil;

/**
 * Abstract class for source type functionalities (Incremental,Transaction and
 * Full Base).<br/>
 * 
 * @author ikumarav
 *
 */
@SuppressWarnings("serial")
public abstract class AbstractSourceTypeProcessor implements
		SourceTypeProcessor {
	final Logger logger = Logger.getLogger(this.getClass());

	/**
	 * This method implements both Delta and Transaction functionalities. <br/>
	 * 
	 * Delta: (I,A,B,D) <br/>
	 * 1. Get the records for recent two partitions and merge with previous
	 * output ORC table record. <br/>
	 * 2. Eliminate the duplicate records. <br/>
	 * 3. All the "B" records without "A", will put the entry in
	 * "DOTOPAL_DUPLICATE_PRIMARYKEYS" table. <br/>
	 * 4. Get the max journal time based on primary keys.<br/>
	 * 5. Join the two temporary tables and insert the updated records(I,A) into
	 * ORC table. <br/>
	 * 
	 * Transaction: (I,A,B) <br/>
	 * 1. Get the records for recent two partitions.<br/>
	 * 2. Eliminate the duplicate records. <br/>
	 * 3. If table has no primary key, insert the records into ORC table. 4. If
	 * table has primary key, then find the max journal time and join two
	 * tables. <br/>
	 * 5. Insert the updated records into ORC table. <br/>
	 */

	public boolean sourceTypeProcess(String sourceName, String tableName,
			String countryCode, String partitionDate, String sourceType,
			List<Row> CurrentAndpreviuosDayPartitions, List<Row> eodAndNextEod,
			List<Row> eod_marker, HiveContext hiveContext, SparkConf prop,
			Broadcast<Map<String, Iterable<String>>> columns,Broadcast<Map<String, Iterable<String>>> primaryColumns, List<String> metaDataList) {
		logger.info("Inside the AbstractSourceTypeProcessor class sourceTypeProcess() method");

		SourceTypeProcessor sourceTypeProcessor = null;
		if (this instanceof IncrementalTypeProcessor) {
			sourceTypeProcessor = (IncrementalTypeProcessor) this;
		} else if (this instanceof TransactionTypeProcessor) {
			sourceTypeProcessor = (TransactionTypeProcessor) this;
		}

		CommonUtil commonUtil = new CommonUtil();
		QueryExecutor queryExecutor = new QueryExecutor(sourceName,
				countryCode, partitionDate);
		MetaDataProcessor metaDataProcessor = new MetaDataProcessor();
		ProcessPrimaryKeyUtil primaryKey = new ProcessPrimaryKeyUtil();

		String filePath = prop.get("spark.filePath");
		String columnsForDuplicate = null;
		String primaryKeyWithCommaSeperator = null;
		String primaryKeysJoins = null;
		String columnsWithCommaSeperator = null;
		String columnsWithCommaSeperatorForNoPrimaryKey = "";
		String primaryKeysColumn = null;
		String processWithAllRecords = tableName + "_tmp";
		String processWithPrimaryKey = tableName + "_primarytmp";
		String processRecordsWithoutDup = tableName + "_tmpWithoutDuplicate";
		String query = "";
		String columnJoins = "";
		String stagingDatabase = prop.get("spark.stagingDatabase");
		String processedDatabase = prop.get("spark.processedDatabase");
		String tableNameWithoutCountry = tableName;
		tableName = sourceName + UNDERSCORE + countryCode + UNDERSCORE
				+ tableName;

		DataFrame records = null;

		List<String> primaryKeyList = new ArrayList<String>();
		List<String> columnListWithoutDataType = new ArrayList<String>();

		String startDate = "";
		String Date = "";
		String fromTimezone = prop.get("spark.fromJournalTimeTimeZone");
		String toTimezone = prop.get("spark.toJournalTimeTimeZone");

		boolean status = true;

		try {

			if (eodAndNextEod.size() > 0 && eodAndNextEod.get(0).get(0) != null) {
				if ((Date = eodAndNextEod.get(0).get(0).toString())
						.contains(":")) {
					startDate = Date.split(" ")[0];
				} else {
					startDate = eodAndNextEod.get(0).get(0).toString();
				}
			}

			/**
			 * Getting the column names with comma separator
			 */
			
			Iterable<String> columnList = columns.value().get(tableNameWithoutCountry
					.toUpperCase());
			logger.info("columnList in query"+columnList);

			/*
			 * query = "show columns in " + stagingDatabase + DOT + tableName;
			 * logger.info("Executing query for getting all the columns from" +
			 * tableName + ":->" + query); columnList =
			 * QueryExecutor.getListFromQuery(hiveContext, query);
			 */columnListWithoutDataType = CommonUtil
					.getColumnListWithoutDataType(columnList);
			columnJoins = CommonUtil
					.getColumnListForJoins(columnListWithoutDataType);
			logger.info("columnJoins "+columnJoins);
			columnsWithCommaSeperator = CommonUtil
					.getColumnsWithCommaSeperator(columnListWithoutDataType);
			columnsWithCommaSeperatorForNoPrimaryKey = CommonUtil
					.getColumnsWithCommaSeperatorNoPrimaryKey(columnListWithoutDataType);
			columnsForDuplicate = CommonUtil
					.getColumnListForDuplicate(columnListWithoutDataType);

			records = queryExecutor.executeQueryForIncremental(tableName,
					countryCode, partitionDate, sourceType,
					CurrentAndpreviuosDayPartitions, eodAndNextEod, eod_marker,
					columnJoins, hiveContext, prop);
			records.registerTempTable(processWithAllRecords);
			//Map<String, Iterable<String>> primaryKeyColumnsMap = CommonUtil.getPrimaryColumnsList();
			//Iterable<String> primaryColumnsList=primaryKeyColumnsMap.get(tableNameWithoutCountry.toUpperCase());
/*			primaryKeyList = queryExecutor.executeQueryForPrimaryKey(
					tableNameWithoutCountry, countryCode, hiveContext, prop,
					partitionDate);
*/			Iterable<String> primaryColumnsList=primaryColumns.value().get(tableNameWithoutCountry.toUpperCase());
			primaryKeyList = ProcessPrimaryKeyUtil.convertIterableToList(primaryColumnsList);
			primaryKeysColumn = CommonUtil
					.getColumnsWithCommaSeperatorFornoPK(columnsWithCommaSeperator);
			primaryKeyWithCommaSeperator = primaryKey
					.getPrimaryKeyWithCommaSeperator(primaryKeyList);
			primaryKeysJoins = primaryKey.getPrimaryKeys(primaryKeyList);
			/*
			 * If a table has no primary key,then insert all the records into
			 * ORC.
			 */
			if (primaryKeyList.size() == 0) {

				String ORCPath = filePath + FORWARD_SLASH + processedDatabase
						+ FORWARD_SLASH + countryCode + FORWARD_SLASH
						+ tableName + FORWARD_SLASH + PART_ODS + EQUAL_SIGN
						+ partitionDate;
				CommonUtil.deletePreviousPath(ORCPath);

				query = " select a." + "`" + "rowid" + "`" + ", " + "'"
						+ startDate + "'" + COMMA
						+ "from_utc_timestamp(to_utc_timestamp(" + "a."
						+ C_JOURNALTIME + "," + "\"" + fromTimezone + "\""
						+ ")," + "\"" + toTimezone + "\"" + ")" + COMMA + "\""
						+ END_DATE + "\"" + COMMA + "\"" + END_DATETIME + "\""
						+ COMMA + columnJoins + " from (select `rowid`" + COMMA
						+ "`s_startdt`,`s_starttime`,`s_enddt`,`s_endtime`,"
						+ columnsWithCommaSeperatorForNoPrimaryKey + ","
						+ "row_number() over (partition by "
						+ primaryKeysColumn + " order by " + C_JOURNALTIME
						+ " desc) rn " + "from " + processWithAllRecords
						+ ") a" + " where a.rn = 1";
				logger.info("Executing Query for removing duplicates" + query);

				String noPrimaryKey = "INSERT INTO " + processedDatabase + DOT
						+ tableName + " PARTITION(" + PART_ODS + "='"
						+ (startDate.equals("") ? partitionDate : startDate)
						+ "') ";
				noPrimaryKey = noPrimaryKey + query;

				logger.info("Inserting records" + noPrimaryKey);
				QueryExecutor.getDataFrameFromQuery(hiveContext, noPrimaryKey);
				return true;
			}

			/*
			 * Getting the unique records.
			 */

			query = "select " + columnsForDuplicate + " from (select "
					+ columnsWithCommaSeperator + ","
					+ "row_number() over (partition by "
					+ primaryKeyWithCommaSeperator + " order by "
					+ C_JOURNALTIME + " desc) rn " + "from "
					+ processWithAllRecords + ") t" + " where t.rn = 1";
			logger.info("Executing query for removing duplicates from "
					+ tableName + ":->" + query);
			DataFrame recordsWithoutDuplicate = QueryExecutor
					.getDataFrameFromQuery(hiveContext, query);
			recordsWithoutDuplicate.registerTempTable(processRecordsWithoutDup);

			/*
			 * Get the max journal time stamp belonging to specific primary
			 * combination for all tables for I, A type records. Create a
			 * temporary table [ProcessWithPrimaryKey] with all max journal time
			 * records.
			 */
/*			query = "select max(" + C_JOURNALTIME + ") as " + C_JOURNALTIME
					+ "," + primaryKeyWithCommaSeperator + " from "
					+ processRecordsWithoutDup + " group by "
					+ primaryKeyWithCommaSeperator;
			logger.info("Executing query for getting maximum journal time from "
					+ tableName + ":->" + query);

			DataFrame maxJournalTimeRecord = QueryExecutor
					.getDataFrameFromQuery(hiveContext, query);
			maxJournalTimeRecord.registerTempTable(processWithPrimaryKey);*/

			/*
			 * If primary key of 'B' records changed, then that particular
			 * records rowid,sourceName,countryCode,description and execution
			 * time should be enter into dotopal_duplicate_primary table.
			 */
			commonUtil.changePrimaryKey(recordsWithoutDuplicate,
					sourceName, countryCode, tableName, partitionDate,
					primaryKeyList, startDate, hiveContext, prop);

			/*
			 * Join the two temporary table with the combination of common
			 * primary keys for Insert, After Update records. Alias name for
			 * processWithAllRecords table is a. Alias name for
			 * processWithPrimaryKey table is b.
			 */

			/*query = " select a." + "`" + "rowid" + "`" + ", " + "'" + startDate
					+ "'" + COMMA + "from_utc_timestamp(to_utc_timestamp("
					+ "a." + C_JOURNALTIME + "," + "\"" + fromTimezone + "\""
					+ ")," + "\"" + toTimezone + "\"" + ")" + COMMA + "\""
					+ END_DATE + "\"" + COMMA + "\"" + END_DATETIME + "\""
					+ COMMA + columnJoins + " from " + processRecordsWithoutDup
					+ " a join " + processWithPrimaryKey + " b on "
					+ primaryKeysJoins + " and a." + C_JOURNALTIME + " = b."
					+ C_JOURNALTIME + " and a." + C_OPERATIONTYPE + " <>'D'"
					+ " and a." + C_OPERATIONTYPE + "<>'B'";
			logger.info("Executing query for joining two temporary tables for"
					+ tableName + ":->" + query);*/
			DataFrame processedRecords=recordsWithoutDuplicate.where("C_OPERATIONTYPE <>'D'").where("C_OPERATIONTYPE <>'B'");
			processedRecords.registerTempTable("processedRecordsTemp");
			//query ="select * from processedRecordsTemp";
			query = " select a." + "`" + "rowid" + "`" + ", " + "'" + startDate
					+ "'" + COMMA + "from_utc_timestamp(to_utc_timestamp("
					+ "a." + C_JOURNALTIME + "," + "\"" + fromTimezone + "\""
					+ ")," + "\"" + toTimezone + "\"" + ")" + COMMA + "\""
					+ END_DATE + "\"" + COMMA + "\"" + END_DATETIME + "\""
					+ COMMA + columnJoins + " from " + "processedRecordsTemp a" ;
			//tt.where("c_operationtype='A'")
			/*
			 * Clear the previous path content before storing the records into
			 * the path.
			 */

			String ORCPath = filePath + FORWARD_SLASH + processedDatabase
					+ FORWARD_SLASH + countryCode + FORWARD_SLASH + tableName
					+ FORWARD_SLASH + PART_ODS + EQUAL_SIGN + partitionDate;
			CommonUtil.deletePreviousPath(ORCPath);

			/*
			 * * Insert the final output for I, A type records into hive tables
			 * in ORC format.
			 */

			logger.info("Storing the records to " + tableName);

			String finalQuery = "INSERT INTO " + processedDatabase + DOT
					+ tableName + " PARTITION(" + PART_ODS + "='"
					+ (startDate.equals("") ? partitionDate : startDate) + "')"
					+ query;
			logger.info("Executing query for inserting the records into process layer:->"
					+ finalQuery);
			QueryExecutor.getDataFrameFromQuery(hiveContext, finalQuery);
		} catch (QueryException queryException) {
			logger.error(queryException);
			status = false;
			metaDataList.add(metaDataProcessor.processMetaData(sourceName, countryCode,
					partitionDate, tableName, FAILURE,
					queryException.getMessage(), PROCESS_LAYER,
					sourceTypeProcessor.getType(), hiveContext, prop));
			String description = "Due to " + queryException.getMessage()
					+ sourceTypeProcessor.getType() + "table " + tableName
					+ " is " + FAILURE;
			commonUtil
					.createFileForRemedy(sourceName, countryCode,
							partitionDate, NFD, R202, description,
							PROCESS_BUILD, prop);
		} catch (ProcessException processException) {
			logger.error(processException);
			status = false;
			metaDataList.add(metaDataProcessor.processMetaData(sourceName, countryCode,
					partitionDate, tableName, FAILURE,
					processException.getMessage(), PROCESS_LAYER,
					sourceTypeProcessor.getType(), hiveContext, prop));
			String description = "Due to " + processException.getMessage()
					+ sourceTypeProcessor.getType() + "table " + tableName
					+ " is " + FAILURE;
			commonUtil
					.createFileForRemedy(sourceName, countryCode,
							partitionDate, NFD, R202, description,
							PROCESS_BUILD, prop);
		} catch (Exception exception) {
			logger.error(exception.getMessage());
			status = false;
			metaDataList.add(metaDataProcessor.processMetaData(sourceName, countryCode,
					partitionDate, tableName, FAILURE, exception.getMessage(),
					PROCESS_LAYER, sourceTypeProcessor.getType(), hiveContext,
					prop));
			String description = "Due to " + exception.getMessage()
					+ sourceTypeProcessor.getType() + "table " + tableName
					+ " is " + FAILURE;
			commonUtil
					.createFileForRemedy(sourceName, countryCode,
							partitionDate, NFD, R202, description,
							PROCESS_BUILD, prop);
			if (exception instanceof RuntimeException) {
				System.exit(0);
			}

		}
		logger.info("end table");
		hiveContext.dropTempTable(processWithAllRecords);
		//hiveContext.dropTempTable(processWithPrimaryKey);
		hiveContext.dropTempTable(processRecordsWithoutDup);
		logger.info("end2 table");
		return status;

	}// method
}// class
