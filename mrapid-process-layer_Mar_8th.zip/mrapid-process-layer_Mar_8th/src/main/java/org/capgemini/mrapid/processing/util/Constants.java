package org.capgemini.mrapid.processing.util;

/**
 * This class is used to use the constants value throughout the project.
 * 
 * @author nisankar
 *
 */
public class Constants {

	
	public static final String CDC = "CDC";
	public static final String BATCH = "BATCH";
	public static final String XML = "XML";
	public static final String SYSTEM_TYPE = "systemType";
	public static final String DOT = ".";
	public static final String UNDERSCORE = "_";
	public static final String COMMA = ",";
	public static final String AND = " and ";
	public static final String EMPTY_STRING = "";
	public static final String SCB_ALL_TAB = "all_tables";
	public static final String PART_ODS = "edmp_partitiondate";
	public static final String EOD_DATE = "eod_date";
	public static final String SCB_ALL_TAB_COLUMNS = "all_tab_columns";
	public static final String PRIMARY_KEY_COULUMN = "primary_column_indicator";
	public static final String MASTER = "Master";
	public static final String TRANSACTION = "transaction";
	public static final String RERUN_MASTER = "ReRun_Master";
	public static final String RERUN_TRANSACTION = "ReRun_Transaction";
	public static final String FULLBASE = "fullbase";
	public static final String SOURCETYPE = "source_type";
	public static final String TABLE_NAME = "table_name";
	public static final String SUCESS = "success";
	public static final String FAILURE = "failure";
	public static final String PROCESS_METADATA = "process_metadata";
	public static final String FORWARD_SLASH = "/";
	public static final String AVRO = "com.databricks.spark.avro";
	public static final String EQUAL_SIGN = "=";
	public static final String GREATERTHNEQ = " >=";
	public static final String LESSTHNEQ = " <=";
	public static final String ORC = "orc";
	public static final String DUPLICATE_PRIMARYKEYS = "duplicate_primarykeys";
	public static final String C_JOURNALTIME = "c_journaltime";
	public static final String C_OPERATIONTYPE = "c_operationtype";
	public static final String TBL_NAME = "tbl_name";
	public static final String ROW_CNT = "row_cnt";
	public static final String DATE_FLD_NM = "date_fld_nm";
	public static final String SOURCE_NAME = "source_name";
	public static final String COUNTRY_NAME = "country_name";
	public static final String PARTITION_DATE = "partition_date";
	public static final String PARTITION_NAME = "partition_name";
	public static final String CHECKSUM_FIELD_NM = "chksum_fld_nm";
	public static final String CHECKSUM_TOTAL = "chksum_tot";
	public static final String NEXT_EOD_DATE = "next_eod_date";
	public static final String CHECK = "_CHK";
	public static final String LIMIT = "limit 1 ";
	public static final String UNIONALL = " union all ";
	public static final String WHERE = " where ";
	public static final String RUNTYPE = "regular";
	public static final String RECON_REPORT = "recon_report";
	public static final String STATUS = "status";
	public static final String MODULE_NAME = "module_name";
	public static final String ROWCOUNTS= "rowcounts";
	public static final String ROWCOUNTS_RCDS = "rcds";
	public static final String SCHEMANAME = "schemaName";
	public static final String TABLENAME = "tablename";
	public static final String ROWCOUNT= "rowcount";
	public static final String FUNCTIONAL_TABLE= "functionaltable";
	public static final String ASOF = "asof";
	public static final String STEP_NAME = "stepname";
	public static final String ATTEMPT_ID = "attempt_id";
	public static final String PROCESS_LAYER= "Processing Layer";
	public static final String FILE_NAME= "filename";
	public static final String END_DATE = "9999-12-31";
	public static final String END_DATETIME = "9999-12-31 23:59:59";
	public static final String PROCESS_BUILD = "process_build";
	public static final String FD_NFD="FD_NFD";
	public static final String NFD = "NFD";
	public static final String RECON_BUILD = "Recon_build";
	public static final String DATA = "data";
	public static final String INVALID_TYPES="invalid_types";
	public static final String ROW_ID = "row_id";
	public static final String RECONCILIATION = "RECONCILIATION";
	public static final String RECON_DELTA = "RECON_DELTA";
	public static final String RECON_TRANSACTION = "RECON_TRANSACTION";
	public static final String STAR = "*";
	public static final String REMEDY_PARTITION = "partition";
	public static final String R202 = "202";
	public static final String R201 = "201";
	public static final String R261 = "261";
	public static final String R231 = "231";
	public static final String R262 = "262";
	public static final String R263 = "263";
	public static final String R264 = "264";
}