package org.capgemini.mrapid.processing.sourcetype.impl;

import static org.capgemini.mrapid.processing.util.Constants.TRANSACTION;

/**
 * This class extends AbstractSourceTypeProcessor class. It uses the base class
 * method for transaction functionalities. <br/>
 * This class doesn't have any special method other than base class method. <br/>
 * 
 * @author ikumarav
 *
 */
@SuppressWarnings("serial")
public class TransactionTypeProcessor extends AbstractSourceTypeProcessor {

	public String getType() {

		return TRANSACTION;
	}
	
	

}
