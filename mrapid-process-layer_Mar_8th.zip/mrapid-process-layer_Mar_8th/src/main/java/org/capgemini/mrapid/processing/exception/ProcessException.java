package org.capgemini.mrapid.processing.exception;

/**
 * This class is for handling the process related exception.
 * 
 * @author ikumarav
 *
 */

public class ProcessException extends Exception {

	private static final long serialVersionUID = 1L;

	public ProcessException(String s) {
		super(s);
	}
}
