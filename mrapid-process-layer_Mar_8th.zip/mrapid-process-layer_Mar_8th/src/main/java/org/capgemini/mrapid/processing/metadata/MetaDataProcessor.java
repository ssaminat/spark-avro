package org.capgemini.mrapid.processing.metadata;

import static org.capgemini.mrapid.processing.util.Constants.COMMA;
import static org.capgemini.mrapid.processing.util.Constants.COUNTRY_NAME;
import static org.capgemini.mrapid.processing.util.Constants.DOT;
import static org.capgemini.mrapid.processing.util.Constants.EMPTY_STRING;
import static org.capgemini.mrapid.processing.util.Constants.FAILURE;
import static org.capgemini.mrapid.processing.util.Constants.FD_NFD;
import static org.capgemini.mrapid.processing.util.Constants.MODULE_NAME;
import static org.capgemini.mrapid.processing.util.Constants.PARTITION_DATE;
import static org.capgemini.mrapid.processing.util.Constants.PART_ODS;
import static org.capgemini.mrapid.processing.util.Constants.PROCESS_BUILD;
import static org.capgemini.mrapid.processing.util.Constants.PROCESS_METADATA;
import static org.capgemini.mrapid.processing.util.Constants.SOURCE_NAME;
import static org.capgemini.mrapid.processing.util.Constants.UNDERSCORE;
import static org.capgemini.mrapid.processing.util.Constants.R202;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.sql.hive.HiveContext;
import org.capgemini.mrapid.processing.exception.QueryException;
import org.capgemini.mrapid.processing.sparksql.QueryExecutor;
import org.capgemini.mrapid.processing.util.CommonUtil;

/**
 * This class is used to log the following scenarios into a table. <br/>
 * 1. Success and failure status.If it is failure, exception type is logged. <br/>
 * 2. SourceName and countryCode. <br/>
 * 3. TableName,ClassName and methodName. <br/>
 * 4. SystemType(CDC,Batch,XML) and sourceType(Delta,Transaction and FullBase). <br/>
 * 5. Execution time,partition name and partition date. <br/>
 * 
 * @author ikumarav
 *
 */
public class MetaDataProcessor {

	final Logger logger = Logger.getLogger(this.getClass());
	Map<String, String> partitions = new HashMap<String, String>();

	public String processMetaData(String sourceName, String countryCode,
			String partitionDate, String tableName, String status,
			String description, String action_name, String module_name,
			HiveContext hiveContext, SparkConf prop) {
		logger.info("inside the processMetaData() method");
		String insertQuery = EMPTY_STRING;
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		if(description!=null){
			description = description.replaceAll(";", "").replaceAll("'", "");
		}
		insertQuery = "SELECT '" + timestamp + "'" + COMMA + "'" + PART_ODS
				+ "'" + COMMA + "'" + tableName + "'" + COMMA + "'" + status
				+ "'" + COMMA + "'" + description + "'" + COMMA + "'"
				+ timestamp + "'" + COMMA + "'" + action_name + "'" + COMMA
				+ null + COMMA + "'" + "runtype'" + COMMA + "'" + partitionDate
				+ "'" + COMMA + null;

		return insertQuery;
	}

	public void insertMetaData(String sourceName, String countryCode,
			String partitionDate, String action_name, String module_name,
			HiveContext hiveContext, SparkConf prop,
			String finalQueryForMetadata) {

		String commonDatabase = prop.get("spark.commonDatabase");

		try {

			String finalQuery = "INSERT INTO " + commonDatabase + DOT
					+ sourceName + UNDERSCORE + PROCESS_METADATA
					+ " PARTITION(" + SOURCE_NAME + "='" + sourceName + "',"
					+ COUNTRY_NAME + "='" + countryCode + "'," + PARTITION_DATE
					+ "='" + partitionDate + "'," + MODULE_NAME + "='"
					+ module_name + "')";

			logger.info("Executing Query for inserting process metadata"
					+ finalQuery);
			finalQuery = finalQuery + finalQueryForMetadata;
			try {
				QueryExecutor.getDataFrameFromQuery(hiveContext, finalQuery);
			} catch (QueryException queryException) {
				logger.error(queryException.getMessage());
				CommonUtil commonUtil = new CommonUtil();
				String descriptionForRemedy = "Due to "
						+ queryException.getMessage() + "Metadata processor"
						+ " is " + FAILURE;
				commonUtil.createFileForRemedy(sourceName, countryCode,
						partitionDate, FD_NFD, R202, descriptionForRemedy,
						PROCESS_BUILD, prop);
			}
		} catch (Exception exception) {
			logger.error(exception.getMessage());
			CommonUtil commonUtil = new CommonUtil();
			String descriptionForRemedy = "Due to " + exception.getMessage()
					+ "Metadata processor" + " is " + FAILURE;
			commonUtil.createFileForRemedy(sourceName, countryCode,
					partitionDate, FD_NFD, R202, descriptionForRemedy,
					PROCESS_BUILD, prop);
			if (exception instanceof RuntimeException) {
				System.exit(0);
			}
		}
	}
}// class end
