package org.capgemini.mrapid.processing.recon.impl;

import static org.capgemini.mrapid.processing.util.Constants.CHECKSUM_FIELD_NM;
import static org.capgemini.mrapid.processing.util.Constants.CHECKSUM_TOTAL;
import static org.capgemini.mrapid.processing.util.Constants.COMMA;
import static org.capgemini.mrapid.processing.util.Constants.DATE_FLD_NM;
import static org.capgemini.mrapid.processing.util.Constants.DOT;
import static org.capgemini.mrapid.processing.util.Constants.EOD_DATE;
import static org.capgemini.mrapid.processing.util.Constants.FAILURE;
import static org.capgemini.mrapid.processing.util.Constants.FD_NFD;
import static org.capgemini.mrapid.processing.util.Constants.PART_ODS;
import static org.capgemini.mrapid.processing.util.Constants.PROCESS_LAYER;
import static org.capgemini.mrapid.processing.util.Constants.RECONCILIATION;
import static org.capgemini.mrapid.processing.util.Constants.RECON_BUILD;
import static org.capgemini.mrapid.processing.util.Constants.ROW_CNT;
import static org.capgemini.mrapid.processing.util.Constants.TBL_NAME;
import static org.capgemini.mrapid.processing.util.Constants.UNDERSCORE;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.hive.HiveContext;
import org.capgemini.mrapid.processing.api.EodReconProcessor;
import org.capgemini.mrapid.processing.exception.QueryException;
import org.capgemini.mrapid.processing.metadata.MetaDataProcessor;
import org.capgemini.mrapid.processing.sparksql.QueryExecutor;
import org.capgemini.mrapid.processing.util.CommonUtil;

/**
 * This AbstractEodReconProcessor is used to build a query Implementation logic:
 * 1. getReconCount - build a query for reconciliation row count which is used
 * for master,transaction <br/>
 * 2. getReconchksum - Query will be built for reconciliation check sum which is
 * used for master,transaction<br/>
 * .
 * 
 * @author suresh
 *
 */
public abstract class AbstractEodReconProcessor implements EodReconProcessor {

	final Logger logger = Logger.getLogger(this.getClass());

	public List<Row> getReconciliation(String sourceName, String countryCode,
			String partitionDate, HiveContext hiveContext, SparkConf prop,List<String> metaDataForRecon) {
		logger.info("inside the getReconciliation() method ");
		String commonDatabase = prop.get("spark.commonDatabase");
		String cdc_eod_recon = prop.get("spark.cdc_eod_recon");
		List<Row> reconTable = new ArrayList<Row>();

		if (!reconTable.isEmpty())
			return reconTable;

		try {

			String query = "select " + TBL_NAME + COMMA + EOD_DATE + COMMA
					+ ROW_CNT + COMMA + DATE_FLD_NM + COMMA + CHECKSUM_FIELD_NM
					+ COMMA + CHECKSUM_TOTAL + " from " + commonDatabase + DOT
					+ sourceName + UNDERSCORE + countryCode + UNDERSCORE
					+ cdc_eod_recon + " where " + PART_ODS + "='"
					+ partitionDate + "'";

			logger.info("Executing Query for getting required data for recon"
					+ query);
			reconTable = QueryExecutor.getListFromQuery(hiveContext, query);

		} catch (QueryException queryException) {
			logger.error(queryException.getMessage());
			MetaDataProcessor metaDataProcessor = new MetaDataProcessor();
			CommonUtil commonUtil = new CommonUtil();
			metaDataForRecon.add(metaDataProcessor.processMetaData(sourceName, countryCode,
					partitionDate, null, FAILURE,
					queryException.getMessage(), PROCESS_LAYER,
					RECONCILIATION, hiveContext, prop));
			String description = "Due to " + queryException.getMessage()
					+ RECONCILIATION 
					+ " is " + FAILURE;
			commonUtil
					.createFileForRemedy(sourceName, countryCode,
							partitionDate, FD_NFD, "202", description,
							RECON_BUILD, prop);
		} catch (Exception exception) {
			logger.error(exception.getMessage());
			MetaDataProcessor metaDataProcessor = new MetaDataProcessor();
			CommonUtil commonUtil = new CommonUtil();
			metaDataForRecon.add(metaDataProcessor.processMetaData(sourceName, countryCode,
					partitionDate, null, FAILURE,
					exception.getMessage(), PROCESS_LAYER,
					RECONCILIATION, hiveContext, prop));
			String description = "Due to " + exception.getMessage()
					+ RECONCILIATION 
					+ " is " + FAILURE;
			commonUtil
					.createFileForRemedy(sourceName, countryCode,
							partitionDate, FD_NFD, "202", description,
							RECON_BUILD, prop);
			if(exception instanceof RuntimeException){
				System.exit(0);
			}
		}
		return reconTable;

	}
	public List<Row> getReconciliationForReRun(String sourceName, String countryCode,
			String tableName,String partitionDate,HiveContext hiveContext,SparkConf prop){
		logger.info("inside the getReconciliation() method ");
		String commonDatabase = prop.get("spark.commonDatabase");
		String cdc_eod_recon = prop.get("spark.cdc_eod_recon");
		List<Row> reconTable = new ArrayList<Row>();

		if (!reconTable.isEmpty())
			return reconTable;
		try {
			String query  = "select " + TBL_NAME + COMMA + EOD_DATE + COMMA
					+ ROW_CNT + COMMA + DATE_FLD_NM + COMMA + CHECKSUM_FIELD_NM
					+ COMMA + CHECKSUM_TOTAL + " from " + commonDatabase + DOT
					+ sourceName + UNDERSCORE + countryCode + UNDERSCORE
					+ cdc_eod_recon + " where " + PART_ODS + "='"
					+ partitionDate + "' and "+TBL_NAME+"='"+tableName.toUpperCase()+"'" ;
			

			logger.info("Executing Query for getting required data for recon"
					+ query);
			reconTable = QueryExecutor.getListFromQuery(hiveContext, query);

		} catch (QueryException queryException) {
			logger.error(queryException.getMessage());
			MetaDataProcessor metaDataProcessor = new MetaDataProcessor();
			CommonUtil commonUtil = new CommonUtil();
			metaDataProcessor.processMetaData(sourceName, countryCode,
					partitionDate, null, FAILURE,
					queryException.getMessage(), PROCESS_LAYER,
					RECONCILIATION, hiveContext, prop);
			String description = "Due to " + queryException.getMessage()
					+ RECONCILIATION 
					+ " is " + FAILURE;
			commonUtil
					.createFileForRemedy(sourceName, countryCode,
							partitionDate, FD_NFD, "202", description,
							RECON_BUILD, prop);
		} catch (Exception exception) {
			logger.error(exception.getMessage());
			MetaDataProcessor metaDataProcessor = new MetaDataProcessor();
			CommonUtil commonUtil = new CommonUtil();
			metaDataProcessor.processMetaData(sourceName, countryCode,
					partitionDate, null, FAILURE,
					exception.getMessage(), PROCESS_LAYER,
					RECONCILIATION, hiveContext, prop);
			String description = "Due to " + exception.getMessage()
					+ RECONCILIATION 
					+ " is " + FAILURE;
			commonUtil
					.createFileForRemedy(sourceName, countryCode,
							partitionDate, FD_NFD, "202", description,
							RECON_BUILD, prop);
			if(exception instanceof RuntimeException){
				System.exit(0);
			}
		}
		return reconTable;
	}
}