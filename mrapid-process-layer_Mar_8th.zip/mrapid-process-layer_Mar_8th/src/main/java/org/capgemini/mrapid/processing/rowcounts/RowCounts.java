package org.capgemini.mrapid.processing.rowcounts;

import static org.capgemini.mrapid.processing.util.Constants.ASOF;
import static org.capgemini.mrapid.processing.util.Constants.ATTEMPT_ID;
import static org.capgemini.mrapid.processing.util.Constants.COMMA;
import static org.capgemini.mrapid.processing.util.Constants.DOT;
import static org.capgemini.mrapid.processing.util.Constants.EMPTY_STRING;
import static org.capgemini.mrapid.processing.util.Constants.EQUAL_SIGN;
import static org.capgemini.mrapid.processing.util.Constants.FAILURE;
import static org.capgemini.mrapid.processing.util.Constants.FILE_NAME;
import static org.capgemini.mrapid.processing.util.Constants.FUNCTIONAL_TABLE;
import static org.capgemini.mrapid.processing.util.Constants.NFD;
import static org.capgemini.mrapid.processing.util.Constants.PART_ODS;
import static org.capgemini.mrapid.processing.util.Constants.PROCESS_BUILD;
import static org.capgemini.mrapid.processing.util.Constants.PROCESS_LAYER;
import static org.capgemini.mrapid.processing.util.Constants.ROWCOUNT;
import static org.capgemini.mrapid.processing.util.Constants.ROWCOUNTS;
import static org.capgemini.mrapid.processing.util.Constants.ROWCOUNTS_RCDS;
import static org.capgemini.mrapid.processing.util.Constants.SCHEMANAME;
import static org.capgemini.mrapid.processing.util.Constants.STEP_NAME;
import static org.capgemini.mrapid.processing.util.Constants.TABLENAME;
import static org.capgemini.mrapid.processing.util.Constants.UNDERSCORE;
import static org.capgemini.mrapid.processing.util.Constants.UNIONALL;

import java.sql.Timestamp;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.sql.hive.HiveContext;
import org.capgemini.mrapid.processing.exception.QueryException;
import org.capgemini.mrapid.processing.metadata.MetaDataProcessor;
import org.capgemini.mrapid.processing.sparksql.QueryExecutor;
import org.capgemini.mrapid.processing.util.CommonUtil;

/**
 * This class is used to record the snapshot row count.
 * 
 * @author ikumarv
 * 
 */

public class RowCounts {
	final static Logger logger = Logger.getLogger(RowCounts.class);

	/**
	 * This method is used to record the snapshot rowcount.
	 * 
	 * @param sourceName
	 * @param countryName
	 * @param partitionDate
	 * @param tableList
	 * @param fullbase
	 */
	public void rowCount(String sourceName, String countryName,
			String partitionDate, List<String> tableList, boolean fullbase,
			HiveContext hiveContext, SparkConf prop) {
		logger.info("inside the rowCount() method");
		String finalQuery = "";
		String processedDatabase = prop.get("spark.processedDatabase");
		String commonDatabase = prop.get("spark.commonDatabase");
		String cdc_eod_Marker = prop.get("spark.cdc_eod_marker");
		String cdc_eod_recon = prop.get("spark.cdc_eod_recon");
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		
		try {

			String insertQuery = "INSERT INTO " + commonDatabase + DOT
					+ sourceName + UNDERSCORE + countryName + UNDERSCORE
					+ ROWCOUNTS + " PARTITION(" + ROWCOUNTS_RCDS + EQUAL_SIGN
					+ "'" + partitionDate + "')";
			for (Iterator<String> iterator = tableList.iterator(); iterator
					.hasNext();) {
				String tableName = iterator.next();
				if (tableName.toLowerCase().contains(
						cdc_eod_Marker.toLowerCase())
						|| tableName.toLowerCase().contains(
								cdc_eod_recon.toLowerCase())) {
					continue;
				}
				String str = "select '" + processedDatabase + "' as "
						+ SCHEMANAME + COMMA + "'" + tableName + "' as "
						+ TABLENAME + COMMA + null + " as " + FILE_NAME + COMMA
						+ "count(1)" + " as " + ROWCOUNT + COMMA + "'"
						+ tableName + "' as " + FUNCTIONAL_TABLE + COMMA + "'"
						+ timestamp + "' as " + ASOF + COMMA + "'"
						+ "EdmHdpScudee-snapshot" + "' as " + STEP_NAME + COMMA
						+ null + " as " + ATTEMPT_ID + " from ";
				if (iterator.hasNext()) {
					finalQuery += str
							+ processedDatabase
							+ DOT
							+ ((fullbase) ? tableName
									: (sourceName + UNDERSCORE + countryName
											+ UNDERSCORE + tableName))
							+ " where " + PART_ODS + " ='" + partitionDate
							+ "'" + UNIONALL;
				} else {
					finalQuery += str
							+ processedDatabase
							+ DOT
							+ ((fullbase) ? tableName
									: (sourceName + UNDERSCORE + countryName
											+ UNDERSCORE + tableName))
							+ " where " + PART_ODS + " ='" + partitionDate
							+ "'";
				}
				logger.info("Executing Query for rowcount table:->"
						+ finalQuery);
			}

			String queryForRowCountTable = "select " + SCHEMANAME + COMMA
					+ TABLENAME + COMMA + FILE_NAME + COMMA + ROWCOUNT + COMMA
					+ FUNCTIONAL_TABLE + COMMA + ASOF + COMMA + STEP_NAME
					+ COMMA + ATTEMPT_ID + " from " + "(";
			String subQueryForRowCountTable = ") t1 ";
			if (!EMPTY_STRING.equals(finalQuery)) {
				queryForRowCountTable = queryForRowCountTable + finalQuery
						+ subQueryForRowCountTable;

			}
			queryForRowCountTable = insertQuery + queryForRowCountTable;
			logger.info("Inserting Query for RowCount Table"
					+ queryForRowCountTable);
			try {
				QueryExecutor.getDataFrameFromQuery(hiveContext,
						queryForRowCountTable);
			} catch (QueryException queryException) {
				logger.error(queryException.getMessage());
				MetaDataProcessor metaDataProcessor = new MetaDataProcessor();
				CommonUtil commonUtil = new CommonUtil();
				metaDataProcessor.processMetaData(sourceName, countryName,
						partitionDate, null, FAILURE,
						queryException.getMessage(), PROCESS_LAYER,
						"RowCount", hiveContext, prop);
				String description = "Due to " + queryException.getMessage()
						+ "RowCount" 
						+ " is " + FAILURE;
				commonUtil
						.createFileForRemedy(sourceName, countryName,
								partitionDate, NFD, "202", description,
								PROCESS_BUILD, prop);
			}
		} catch (Exception exception) {
			logger.error(exception.getMessage());
			MetaDataProcessor metaDataProcessor = new MetaDataProcessor();
			CommonUtil commonUtil = new CommonUtil();
			metaDataProcessor.processMetaData(sourceName, countryName,
					partitionDate, null, FAILURE,
					exception.getMessage(), PROCESS_LAYER,
					"RowCount", hiveContext, prop);
			String description = "Due to " + exception.getMessage()
					+ "RowCount" 
					+ " is " + FAILURE;
			commonUtil
					.createFileForRemedy(sourceName, countryName,
							partitionDate, NFD, "202", description,
							PROCESS_BUILD, prop);
			if(exception instanceof RuntimeException){
				System.exit(0);
			}
		}
	}
}
