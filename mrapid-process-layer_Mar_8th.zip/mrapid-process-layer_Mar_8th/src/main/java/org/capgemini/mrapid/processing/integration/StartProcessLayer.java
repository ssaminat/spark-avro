package org.capgemini.mrapid.processing.integration;

import static org.capgemini.mrapid.processing.util.Constants.FD_NFD;
import static org.capgemini.mrapid.processing.util.Constants.PROCESS_BUILD;

import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.hive.HiveContext;
import org.capgemini.mrapid.processing.api.FileProcessor;
import org.capgemini.mrapid.processing.exception.ProcessException;
import org.capgemini.mrapid.processing.exception.QueryException;
import org.capgemini.mrapid.processing.factory.SystemTypeProcessorFactory;
import org.capgemini.mrapid.processing.recon.impl.EodReconProcessorMain;
import org.capgemini.mrapid.processing.util.CommonUtil;
//import scala.collection.immutable.Seq;

/**
 * * StartProcessLayer class is the main class to differentiate between system
 * type and call respective system type implementation.<br/>
 * Implementation Logic: <br/>
 * SystemType must be CDC or BATCH or XML. <br/>
 * 1. If System Type is CDC, CDCProcesser class method is called with arguments
 * as Source type, country code and partition date. <br/>
 * 2. If System Type is BATCH, BatchFileImplementation() method is called with
 * arguments as Source type, country code and partition date. <br/>
 * 3. If System Type is XML, XmlImpl() method is called. <br/>
 * 4. Finally reconciliation will executed.
 * 
 * @author nisankar
 *
 */

public class StartProcessLayer {
	final static Logger logger = Logger.getLogger(StartProcessLayer.class);
	HiveContext hiveCtx;
	SparkConf prop;
	JavaSparkContext jsCtx;
	
	public StartProcessLayer() {
		prop = new SparkConf().setAppName("SPARK");
		jsCtx = new JavaSparkContext(prop);
		hiveCtx = new HiveContext(jsCtx.sc());
	}

	private void executeProcessLayer(String[] hdfInputs)
			throws ProcessException {
		CommonUtil commonUtil = new CommonUtil();
		logger.info("Starting the processed layer functionalities");
		
		if (hdfInputs.length < 4) {
			String error = "Need 4 arguments for ProcessLayer. <sourceName>,<countryCode>,<partitionDate>,<userName>";
			logger.error(error);

			String sourceName = null;
			String countryCode = null;
			String partitionDate = null;

			if (hdfInputs.length == 3) {
				sourceName = hdfInputs[0];
				countryCode = hdfInputs[1];
				partitionDate = hdfInputs[2];
			} else if (hdfInputs.length == 2) {
				sourceName = hdfInputs[0];
				countryCode = hdfInputs[1];
			} else {
				sourceName = hdfInputs[0];
			}

			commonUtil.createFileForRemedy(sourceName, countryCode,
					partitionDate, FD_NFD, "201", error, PROCESS_BUILD, prop);

			throw new ProcessException(error);
			
		}

		hdfInputs[0] = hdfInputs[0].toLowerCase();
		hdfInputs[1] = hdfInputs[1].toLowerCase();
		boolean isException = false;
		boolean executeRecon = false;

		// CommonUtil.setAttribute(hdfInputs[0], hdfInputs[1]);

		String systemType = jsCtx.getConf().get("spark.systemType");
		logger.info("inside the main class :" + systemType);

		System.setProperty("user.name", hdfInputs[3]);

		FileProcessor fileProcessor = SystemTypeProcessorFactory
				.createSystemTypeProcessor(systemType);

		try {
			executeRecon = fileProcessor.process(hdfInputs, hiveCtx, jsCtx, prop);
		} catch (ProcessException processException) {
			isException = true;
			logger.error(processException.getMessage());
			return;

		} catch (QueryException queryException) {
			isException = true;
			logger.error(queryException.getMessage());
			return;
		} catch (RuntimeException runtimeException) {
			logger.error(runtimeException.getMessage());
			System.exit(0);

		} catch (Exception exception) {
			logger.error(exception.getMessage());

		}
		// EOD Reconciliation
		if (!isException && executeRecon) {
			logger.info("Starting the processed layer RECON functionalities");
			EodReconProcessorMain eodReconProcessorMain = new EodReconProcessorMain(
					hiveCtx, jsCtx, prop);
			eodReconProcessorMain.processRecon(hdfInputs);

		}
	}

	/**
	 * Main method will receive arguments from HDF and start to build the
	 * process layer
	 * 
	 * @param hdfInput
	 *            hdfInput contains three arguments. <br/>
	 *            1. SourceName : Name of the source system <br/>
	 *            Cannot be null <br/>
	 *            2. CountryCode : Name of the country <br/>
	 *            Cannot be null <br/>
	 *            3. PartitionDate : Name of the partition to process <br/>
	 *            Cannot be null <br/>
	 * @throws ProcessException
	 * 
	 */
	public static void main(String[] hdfInputs) throws ProcessException {
		StartProcessLayer startProcessLayer = new StartProcessLayer();
		startProcessLayer.executeProcessLayer(hdfInputs);

	}
}
