package org.capgemini.mrapid.processing.util;

import static org.capgemini.mrapid.processing.util.Constants.COMMA;
import static org.capgemini.mrapid.processing.util.Constants.C_JOURNALTIME;
import static org.capgemini.mrapid.processing.util.Constants.C_OPERATIONTYPE;
import static org.capgemini.mrapid.processing.util.Constants.DOT;
import static org.capgemini.mrapid.processing.util.Constants.DUPLICATE_PRIMARYKEYS;
import static org.capgemini.mrapid.processing.util.Constants.EQUAL_SIGN;
import static org.capgemini.mrapid.processing.util.Constants.FAILURE;
import static org.capgemini.mrapid.processing.util.Constants.FORWARD_SLASH;
import static org.capgemini.mrapid.processing.util.Constants.NFD;
import static org.capgemini.mrapid.processing.util.Constants.PART_ODS;
import static org.capgemini.mrapid.processing.util.Constants.REMEDY_PARTITION;
import static org.capgemini.mrapid.processing.util.Constants.PROCESS_BUILD;
import static org.capgemini.mrapid.processing.util.Constants.PROCESS_LAYER;
import static org.capgemini.mrapid.processing.util.Constants.SCB_ALL_TAB;
import static org.capgemini.mrapid.processing.util.Constants.UNDERSCORE;
import static org.capgemini.mrapid.processing.util.Constants.UNIONALL;
import static org.capgemini.mrapid.processing.util.Constants.SCB_ALL_TAB_COLUMNS;
import static org.capgemini.mrapid.processing.util.Constants.STAR;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.permission.FsPermission;
import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.SparkContext;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.catalyst.expressions.aggregate.Max;
import org.apache.spark.sql.catalyst.expressions.Descending;
import org.apache.spark.sql.catalyst.expressions.aggregate.Max;
import org.apache.spark.sql.hive.HiveContext;
import org.capgemini.mrapid.processing.exception.ProcessException;
import org.capgemini.mrapid.processing.exception.QueryException;
import org.capgemini.mrapid.processing.metadata.MetaDataProcessor;
import org.capgemini.mrapid.processing.sparksql.QueryExecutor;
import org.apache.spark.sql.functions.*;

import scala.Tuple2;

/**
 * This class is used to load the configuration properties files and have common
 * methods used by all classes.
 * 
 * @author nisankar
 *
 */
public class CommonUtil {
	final static Logger logger = Logger.getLogger(CommonUtil.class);

	public static String insertQuery = "";
	static JavaRDD<String> allTabColumnsRecords;

	/**
	 * This method is to load the property file.
	 * 
	 * @param fileName
	 *            : Property file name
	 * @return Properties
	 */

	public static Properties loadPropertiesFile(String fileName) {
		Properties prop = new Properties();
		try {
			prop.load(new FileReader(fileName));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return prop;
	}

	public static DataFrame getEodMarkerData(HiveContext hiveContext) {
		DataFrame eodMarkerDF = hiveContext
				.sql("select * from scudee_dev_ops_ptest.gps_all_tl_eod_marker");
		eodMarkerDF.cache();
		return eodMarkerDF;
	}

	public static List<Row> getEodDate(String countryCode,
			String partitionDate, HiveContext hiveContext, SparkConf prop,
			DataFrame eodMarkerDF) {
		List<Row> Eod_Date = null;
		try {

			DataFrame df1 = eodMarkerDF
					.where("edmp_partitiondate='2017-02-05'").select(
							"eod_date", "next_eod_date");
			Eod_Date = df1.collectAsList();
			if (Eod_Date == null || Eod_Date.isEmpty()) {
				logger.error("Either Eod_Date or Next_Eod_Date is null");

				throw new ProcessException(
						"Either Eod_Date or Next_Eod_Date is null");

			}
		} catch (ProcessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Eod_Date;

	}

	public static List<Row> getLatestPartitions(String countryCode,
			HiveContext hiveContext, SparkConf prop, String partitionDate,
			DataFrame eodMarkerDF) {
		List<Row> df2 = eodMarkerDF
				.sort(eodMarkerDF.col("edmp_partitiondate").desc())
				.select("edmp_partitiondate").distinct().takeAsList(2);
		return df2;
	}

	public static List<Row> getJournalTime(String countryCode,
			List<Row> currentAndPrevDaysPartitions, HiveContext hiveContext,
			SparkConf prop, String partitionDate, DataFrame eodMarkerDF) {
		List<Row> journalTime = null;
		try {
			if (currentAndPrevDaysPartitions.size() >= 1) {
				String eod1 = currentAndPrevDaysPartitions.get(0).get(0)
						.toString().replace("[", "").replace("]", "");
				String eod2 = currentAndPrevDaysPartitions.get(1).get(0)
						.toString().replace("[", "").replace("]", "");

				if (currentAndPrevDaysPartitions.size() == 1) {

					journalTime = eodMarkerDF
							.groupBy("edmp_partitiondate")
							.agg(org.apache.spark.sql.functions.max(
									eodMarkerDF.col("c_journaltime")).as(
									"c_journaltime"))
							.orderBy("c_journaltime")
							.where(eodMarkerDF.col("edmp_partitiondate")
									.equalTo(eod1)).collectAsList();
				}

				else {
					journalTime = eodMarkerDF
							.groupBy("edmp_partitiondate")
							.agg(org.apache.spark.sql.functions.max(
									eodMarkerDF.col("c_journaltime")).as(
									"c_journaltime"))
							.orderBy("c_journaltime")
							.where(eodMarkerDF
									.col("edmp_partitiondate")
									.equalTo(eod1)
									.or(eodMarkerDF.col("edmp_partitiondate")
											.equalTo(eod2))).collectAsList();

				}

			} else {

				throw new ProcessException(
						"Either today partition or previous day partition is not available");

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return journalTime;
	}

	public static Map<String, String> getTablesListWithSourceType(
			String filePath, String commonDatabase, String sourceName,
			final String countryCode, JavaSparkContext JSC) {
		// hdfs://nnscbhaastest/sit/scudee/dotopaltest1/hdata/dotopaltest1_dev_ops/dotopaltest1_all_tables
		String allTablesPath = filePath + FORWARD_SLASH + commonDatabase
				+ FORWARD_SLASH + sourceName + UNDERSCORE + SCB_ALL_TAB
				+ FORWARD_SLASH + STAR;
		logger.info("alltablepath: " + allTablesPath);
		JavaRDD<String> allTablesRecordsRDD = JSC.textFile(allTablesPath);
		JavaRDD<String> allTablesRecordsRDD1 = allTablesRecordsRDD
				.filter(new Function<String, Boolean>() {

					public Boolean call(String v1) throws Exception {

						if (v1.split("\u0002")[0].equalsIgnoreCase(countryCode)) {
							return true;
						}
						return false;
					}
				});
		JavaPairRDD<String, String> tablesWithSourceTypeRDD = allTablesRecordsRDD1
				.mapToPair(new PairFunction<String, String, String>() {

					public Tuple2<String, String> call(String v)
							throws Exception {
						return new Tuple2<String, String>(v.split("\u0002")[1],
								v.split("\u0002")[3]);
					}
				});
		Map<String, String> tablesWithSourceType = tablesWithSourceTypeRDD
				.collectAsMap();
		return tablesWithSourceType;
	}

	public static Broadcast<Map<String, Iterable<String>>> getColumnsList(
			String filePath, String commonDatabase, String sourceName,
			final String countryCode, JavaSparkContext JSC) {

		String allTabColumnsPath = filePath + FORWARD_SLASH + commonDatabase
				+ FORWARD_SLASH + sourceName + UNDERSCORE + SCB_ALL_TAB_COLUMNS
				+ FORWARD_SLASH + STAR;
		allTabColumnsRecords = JSC.textFile(allTabColumnsPath)
				.filter(new Function<String, Boolean>() {

					public Boolean call(String v1) throws Exception {

						if (v1.split("\u0002")[2].equalsIgnoreCase(countryCode)) {
							return true;
						}
						return false;
					}
				}).cache();
		JavaPairRDD<String, Iterable<String>> columnsRDD = allTabColumnsRecords
				.mapToPair(new PairFunction<String, String, String>() {

					public Tuple2<String, String> call(String v)
							throws Exception {
						return new Tuple2<String, String>(v.split("\u0002")[0],
								v.split("\u0002")[1]);
					}
				}).groupByKey();
		Broadcast<Map<String, Iterable<String>>> columns = JSC
				.broadcast(columnsRDD.collectAsMap());
		// columns.value().get(0);
		// logger.info("columns in iterable-------->"+columns);
		return columns;

	}

	public static Broadcast<Map<String, Iterable<String>>> getPrimaryColumnsList(
			JavaSparkContext JSC) {
		JavaRDD<String> primaryKeyRecords = allTabColumnsRecords
				.filter(new Function<String, Boolean>() {

					public Boolean call(String v1) throws Exception {
						if (v1.split("\u0002")[7].equalsIgnoreCase("Y")) {
							return true;
						}
						return false;
					}
				});
		JavaPairRDD<String, Iterable<String>> primaryKeyColumnsRDD = primaryKeyRecords
				.mapToPair(new PairFunction<String, String, String>() {

					public Tuple2<String, String> call(String v)
							throws Exception {
						return new Tuple2<String, String>(v.split("\u0002")[0],
								v.split("\u0002")[1]);
					}
				}).groupByKey();
		Broadcast<Map<String, Iterable<String>>> primaryKeyColumns = JSC
				.broadcast(primaryKeyColumnsRDD.collectAsMap());
		// logger.info("columns in iterable-------->"+primaryKeyColumns);
		return primaryKeyColumns;
	}

	/**
	 * This method used to get the columnList without DataType.
	 * 
	 * @param columnList
	 * @return List<String> columnList
	 */
	public static List<String> getColumnListWithoutDataType(
			Iterable<String> columnList) {
		logger.info("Inside the getColumnListWithoutDataType() method");
		List<String> columnListWithoutDataType = new ArrayList<String>();
		for (String column : columnList) {
			columnListWithoutDataType.add(column);
		}
		columnListWithoutDataType.add(1, "C_JOURNALTIME");
		columnListWithoutDataType.add(2, "C_TRANSACTIONID");
		columnListWithoutDataType.add(3, "C_OPERATIONTYPE");
		columnListWithoutDataType.add(4, "C_USERID");
		columnListWithoutDataType.add(columnListWithoutDataType.size(),
				PART_ODS.toUpperCase());
		return columnListWithoutDataType;

	}

	/**
	 * This method used to append the "a." with all columns for using join in
	 * query.
	 * 
	 * @param columnList
	 * @return String
	 */
	public static String getColumnListForJoins(List<String> columnList) {
		logger.info("Inside the getColumnListForJoins() method");
		StringBuilder builder = new StringBuilder();
		for (int i = 0; i <= columnList.size() - 1; i++) {
			if (!columnList.get(i).equalsIgnoreCase("ROWID")) {
				builder.append("a." + "`" + columnList.get(i) + "`");
				builder.append(",");
			}
		}
		String columnsJoins = builder.toString();
		columnsJoins = columnsJoins.substring(0, columnsJoins.length() - 1);
		return columnsJoins;
	}

	/**
	 * This method used to append the "t." with all columns for using join in
	 * query.
	 * 
	 * @param columnList
	 * @return String
	 */

	public static String getColumnListForDuplicate(List<String> columnList) {
		logger.info("Inside the getColumnListForDuplicate() method");
		StringBuilder builder = new StringBuilder();
		for (String s : columnList) {
			builder.append("t." + "`" + s + "`");
			builder.append(",");
		}
		String columnsJoins = builder.toString();
		columnsJoins = columnsJoins.substring(0, columnsJoins.length() - 1);

		return columnsJoins;
	}

	/**
	 * This method is used to form the columns with comma separator.
	 * 
	 * @param columnList
	 *            : list of columns
	 * @return String: columns with comma separator.
	 * 
	 */
	public static String getColumnsWithCommaSeperator(List<String> columnList) {
		logger.info("inside the getColumnsWithCommaSeperator() method");
		StringBuilder builder = new StringBuilder();
		String primaryKeysJoin = "";
		int count = 0;

		for (String column : columnList) {
			column = "`" + column + "`";
			if (count == columnList.size() - 1) {
				builder.append(column);
			} else {
				builder.append(column);
				builder.append(",");

			}
			count++;
		}
		primaryKeysJoin = builder.toString();

		return primaryKeysJoin;
	}

	public static String getColumnsWithCommaSeperatorNoPrimaryKey(
			List<String> columnList) {
		logger.info("inside the getColumnsWithCommaSeperator() method");
		StringBuilder builder = new StringBuilder();
		String primaryKeysJoin = "";
		int count = 0;

		for (String column : columnList) {
			column = "`" + column + "`";
			if (count == 0) {

			} else {
				if (count == columnList.size() - 1) {
					builder.append(column);
				} else {
					builder.append(column);
					builder.append(",");
				}
			}
			count++;
		}
		primaryKeysJoin = builder.toString();

		return primaryKeysJoin;
	}

	/**
	 * This method is used to form the columns with comma separator.
	 * 
	 * @param columnList
	 * @return
	 */

	public static String getColumnsWithCommaSeperatorFornoPK(String columnList) {
		logger.info("inside the getColumnsWithCommaSeperator() method");
		String primaryKeysColumn = "";
		StringBuilder builder = new StringBuilder();
		String[] str = columnList.split(",");
		int count1 = 0;

		for (int i = 0; i <= (str.length - 1); i++) {
			if (!str[i].equalsIgnoreCase("ROWID")
					&& !str[i].equalsIgnoreCase("C_JOURNALTIME")
					&& !str[i].equalsIgnoreCase("C_TRANSACTIONID")
					&& !str[i].equalsIgnoreCase("C_OPERATIONTYPE")
					&& !str[i].equalsIgnoreCase("C_USERID")) {
				if (count1 == str.length - 1) {
					builder.append(str[i]);

				} else {
					builder.append(str[i]);
					builder.append(",");
				}
				count1++;
			}
		}
		primaryKeysColumn = builder.toString();
		return primaryKeysColumn;
	}

	/**
	 * This method handle the change primary key scenario.<br/>
	 * All the "B" records without "A", will put the entry in
	 * "{SourceName}_DUPLICATE_PRIMARYKEYS" table.
	 * 
	 * @param records
	 * @param maxJournalTimeRecord
	 * @param sourceName
	 * @param countryCode
	 * @param tableName
	 * @param partitionDate
	 */

	public void changePrimaryKey(DataFrame recordsWithoutDuplicate,
			String sourceName, String countryCode, String tableName,
			String partitionDate, List<String> primaryKeyList,
			String startDate, HiveContext hiveContext, SparkConf prop)
			throws QueryException {
		logger.info("Inside the changePrimaryKey() method");
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		String commonDatabase = prop.get("spark.commonDatabase");
		List<Row> rowIdList = new ArrayList<Row>();
		String str = "";
		try {

			DataFrame recordsWithBRecords = recordsWithoutDuplicate
					.where("c_operationtype = 'B'");
			rowIdList = recordsWithBRecords.select("ROWID").collectAsList();
			/*
			 * query = "select r.rowid,r." + C_JOURNALTIME + COMMA +
			 * primaryKeyJoinsWithR + " from " + processWithAllRecords +
			 * " r join " + processRecordsWithoutDup + " m on r." +
			 * C_JOURNALTIME + " = m." + C_JOURNALTIME; for (int i = 0; i <
			 * primaryKeyList.size(); i++) {
			 * 
			 * subQuery = subQuery + " and r." + primaryKeyList.get(i) + " = m."
			 * + primaryKeyList.get(i); } query = query + subQuery + " where " +
			 * C_OPERATIONTYPE + " = 'B'"; logger.info("Getting B records rowid"
			 * + query); //rowIdList =
			 * QueryExecutor.getListFromQuery(hiveContext, query);
			 * 
			 * System.out.println("rowIdList" + rowIdList); rowIdListRemoval =
			 * QueryExecutor.getThresholdARecord(sourceName, countryCode,
			 * tableName, partitionDate, primaryKeyList, prop, hiveContext,
			 * rowIdList); for (int i = 0; i <= rowIdListRemoval.size(); i++) {
			 * if (rowIdList.contains(rowIdListRemoval.get(i))) { int index =
			 * rowIdList.indexOf(rowIdListRemoval.get(i));
			 * rowIdList.remove(index); } } System.out.println("rowIdList final"
			 * + rowIdList);
			 * 
			 * hiveContext.dropTempTable(record_tmp);
			 * hiveContext.dropTempTable(maxJournalTimeRecord_tmp);
			 */
			if (rowIdList.size() >= 1) {
				logger.info("Inserting change primary key records into duplicate_primaryKeys table");
				String finalQuery = "INSERT INTO " + commonDatabase + DOT
						+ sourceName + UNDERSCORE + DUPLICATE_PRIMARYKEYS
						+ " PARTITION(" + PART_ODS + "='"
						+ (startDate.equals("") ? partitionDate : startDate)
						+ "')";
				for (int i = 0; i < rowIdList.size(); i++) {
					str += ((str.equals("")) ? "" : UNIONALL);
					str = str
							+ "SELECT '"
							+ rowIdList.get(i).get(0).toString()
							+ "'"
							+ COMMA
							+ "'"
							+ sourceName
							+ "'"
							+ COMMA
							+ "'"
							+ countryCode
							+ "'"
							+ COMMA
							+ "'"
							+ tableName
							+ "'"
							+ COMMA
							+ "'"
							+ "Because of Primary key change,this row is inserted into this table"
							+ "'" + COMMA + "'" + timestamp + "'" + COMMA + "'"
							+ timestamp + "'";
					if (rowIdList.size() == 1) {
						str = str + " from " + commonDatabase + DOT
								+ sourceName + UNDERSCORE + SCB_ALL_TAB
								+ " limit 1";
					}

				}
				finalQuery += str;
				logger.info("Executing Query for inserting primary key change row"
						+ finalQuery);

				QueryExecutor.getDataFrameFromQuery(hiveContext, finalQuery);
			}
		} catch (QueryException queryException) {
			logger.error(queryException);
			throw queryException;
		} catch (Exception exception) {
			MetaDataProcessor metaDataProcessor = new MetaDataProcessor();
			CommonUtil commonUtil = new CommonUtil();
			logger.error(exception.getMessage());
			metaDataProcessor.processMetaData(sourceName, countryCode,
					partitionDate, tableName, FAILURE, exception.getMessage(),
					PROCESS_LAYER, "Change Primary Key", hiveContext, prop);
			String description = "Due to " + exception.getMessage()
					+ "Change Primary Key" + "table " + tableName + " is "
					+ FAILURE;
			commonUtil
					.createFileForRemedy(sourceName, countryCode,
							partitionDate, NFD, "202", description,
							PROCESS_BUILD, prop);
			if (exception instanceof RuntimeException) {
				System.exit(0);
			}

		}
	}

	/**
	 * This method deletes the path before store the records into the table.
	 * 
	 * @param ORCpath
	 */

	public static void deletePreviousPath(String ORCpath) {
		logger.info("Inside the deletePreviousPath() method");
		try {
			Configuration conf = new Configuration();
			FileSystem fileSystem;

			fileSystem = FileSystem.get(conf);

			Path path = new Path(ORCpath);
			if (fileSystem.exists(path)) {
				fileSystem.delete(path, true);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	/**
	 * This method is used to create a file for remedy.
	 * 
	 * @param sourceName
	 * @param countryCode
	 * @param partitionDate
	 * @param sourceType
	 * @param errorCode
	 * @param description
	 * @param buildType
	 */

	public void createFileForRemedy(String sourceName, String countryCode,
			String partitionDate, String sourceType, String errorCode,
			String description, String buildType, SparkConf prop) {
		logger.info("inside the createFileForRemedy() method");
		try {

			String remedyPath = prop.get("spark.remedyPath");

			String fileContent = "";
			DateFormat df = new SimpleDateFormat("YYYY-MM-DD_HH_mm_ss");
			Date today = Calendar.getInstance().getTime();
			String todayDate = df.format(today);
			String localfile = prop.get("spark.remedyPath");
			Path localFilePath = new Path(localfile);

			String path = remedyPath + FORWARD_SLASH + sourceName
					+ FORWARD_SLASH + countryCode + FORWARD_SLASH
					+ REMEDY_PARTITION + EQUAL_SIGN + partitionDate;
			String fileName = sourceName + UNDERSCORE + countryCode
					+ UNDERSCORE + "spark" + UNDERSCORE + sourceType
					+ UNDERSCORE + buildType + "_" + todayDate + ".err";

			FileSystem hdfs = FileSystem.get(new Configuration());
			Path newFolderPath = new Path(path);
			FsPermission fsPermission = new FsPermission("777");
			if (hdfs.exists(newFolderPath)) {
				hdfs.setPermission(newFolderPath, fsPermission);
				Path newFilePath = new Path(path + FORWARD_SLASH + fileName
						+ ".err");
				FSDataOutputStream fsOutStream = hdfs.create(newFilePath);
				fileContent = errorCode + "§" + prop.get("spark." + errorCode)
						+ "§" + description;
				fsOutStream.writeBytes(fileContent);
				hdfs.copyToLocalFile(newFilePath, localFilePath);
				fsOutStream.close();
			} else {
				hdfs.mkdirs(newFolderPath);
				hdfs.setPermission(newFolderPath, fsPermission);
				Path newFilePath = new Path(path + FORWARD_SLASH + fileName
						+ ".err");
				FSDataOutputStream fsOutStream = hdfs.create(newFilePath);
				fileContent = errorCode + "§" + prop.get("spark." + errorCode)
						+ "§" + description;
				fsOutStream.writeBytes(fileContent);
				hdfs.copyToLocalFile(newFilePath, localFilePath);
				fsOutStream.close();
			}

		} catch (IOException e) {
			logger.error(e.getMessage());

		} catch (Exception exception) {
			logger.error(exception.getMessage());
			/*
			 * if (exception instanceof RuntimeException) { System.exit(0); }
			 */

		}

	}

}
