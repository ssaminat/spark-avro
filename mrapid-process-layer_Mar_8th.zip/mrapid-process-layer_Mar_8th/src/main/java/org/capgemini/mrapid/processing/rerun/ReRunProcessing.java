package org.capgemini.mrapid.processing.rerun;

import static org.capgemini.mrapid.processing.util.Constants.DOT;
import static org.capgemini.mrapid.processing.util.Constants.FAILURE;
import static org.capgemini.mrapid.processing.util.Constants.MASTER;
import static org.capgemini.mrapid.processing.util.Constants.PROCESS_LAYER;
import static org.capgemini.mrapid.processing.util.Constants.RERUN_MASTER;
import static org.capgemini.mrapid.processing.util.Constants.RERUN_TRANSACTION;
import static org.capgemini.mrapid.processing.util.Constants.SCB_ALL_TAB;
import static org.capgemini.mrapid.processing.util.Constants.SUCESS;
import static org.capgemini.mrapid.processing.util.Constants.TRANSACTION;
import static org.capgemini.mrapid.processing.util.Constants.UNDERSCORE;
import static org.capgemini.mrapid.processing.util.Constants.UNIONALL;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.hive.HiveContext;
import org.capgemini.mrapid.processing.api.SourceTypeProcessor;
import org.capgemini.mrapid.processing.exception.ProcessException;
import org.capgemini.mrapid.processing.factory.SourceTypeProcessorFactory;
import org.capgemini.mrapid.processing.metadata.MetaDataProcessor;
import org.capgemini.mrapid.processing.recon.impl.EodReconProcessorMain;
import org.capgemini.mrapid.processing.sparksql.QueryExecutor;
import org.capgemini.mrapid.processing.util.CommonUtil;

/**
 * 
 * @author gopia This class is for re-run the full base,Incremental and
 *         Transaction.
 */

public class ReRunProcessing {

	final static Logger logger = Logger.getLogger(ReRunProcessing.class);

	private HiveContext hiveCtx;
	private SparkConf prop;
	private JavaSparkContext jsCtx;
	private String sourceName;
	private String countryCode;;
	private String tableName;
	private String moduleName = "ReRun";

	private SourceTypeProcessorFactory sourceTypeProcessorFactory = new SourceTypeProcessorFactory();
	private MetaDataProcessor metaDataProcessor = new MetaDataProcessor();

	public ReRunProcessing() {
		prop = new SparkConf().setAppName("SPARK");
		jsCtx = new JavaSparkContext(prop);
		hiveCtx = new HiveContext(jsCtx.sc());
	}

	public static void main(String[] hdfInputs) throws ProcessException {

		if (4 > hdfInputs.length) {
			throw new ProcessException(
					"Required four arguments as in the format of"
							+ "<sourceName> <CountryCode> <tableName> <partitionDate> ");
		}

		String tableName = hdfInputs[2];
		boolean isSuccess = new ReRunProcessing().process(hdfInputs);
		if (isSuccess)
			logger.info("ReRun process successfully done for the table "
					+ tableName);
		else
			logger.error("ReRun process failed for the table " + tableName);

	}

	private boolean process(String[] hdfInputs) {

		this.sourceName = hdfInputs[0];
		this.countryCode = hdfInputs[1];
		this.tableName = hdfInputs[2].toLowerCase();
		String inputPartitionDate = hdfInputs[3];
		Boolean reconStatus = false;
		List<Row> partitions = new ArrayList<Row>();
		boolean processStatus = false;
		List<String> metaDateList = new ArrayList<String>();
		QueryExecutor processingQuery = new QueryExecutor(hdfInputs[0],
				countryCode, inputPartitionDate);
		// Journal time changes from Nifi or spark
		try {

			List<Row> sourceType = processingQuery.getTypeForTable(tableName,
					hiveCtx, prop);
			String tableType = sourceType.get(0).getString(0);
			String commonDatabase = prop.get("spark.commonDatabase");
			String filePath = prop.get("spark.filePath");
			Boolean metaStatus = false;
			Broadcast<Map<String, Iterable<String>>> columns = CommonUtil.getColumnsList(
					filePath, commonDatabase, sourceName, countryCode, jsCtx);
			Broadcast<Map<String, Iterable<String>>> primaryKeyColumnsMap = CommonUtil.getPrimaryColumnsList(jsCtx);
			if (null == tableType || tableType.isEmpty()) {
				throw new ProcessException("Table " + tableName
						+ " source Type is NULL or EMPTY");
			}
			if (TRANSACTION.equalsIgnoreCase(tableType)) {

				String partitionDate = inputPartitionDate;
				partitions = processingQuery.getPartition(inputPartitionDate,
						hiveCtx, prop);
				List<Row> eodAndNextEod = processingQuery.getEodDate(
						countryCode, partitionDate, hiveCtx, prop);
				List<Row> CurrentAndpreviuosDayPartitions = processingQuery
						.getPreviousDayPartitions(partitionDate, hiveCtx, prop);
				List<Row> journalTime = processingQuery.getJournalTime(
						countryCode, CurrentAndpreviuosDayPartitions, hiveCtx,
						prop, partitionDate);

				logger.info("Pulling records from" + tableName);
				SourceTypeProcessor sourceTypeProcessor = sourceTypeProcessorFactory
						.createProcessor(tableType);

				if (sourceTypeProcessor != null) {
					processStatus = sourceTypeProcessor.sourceTypeProcess(
							sourceName, tableName, countryCode, partitionDate,
							tableType, CurrentAndpreviuosDayPartitions,
							eodAndNextEod, journalTime, hiveCtx, prop, columns, primaryKeyColumnsMap,
							metaDateList);
				} else {
					metaDateList.add(metaDataProcessor.processMetaData(
							sourceName, countryCode, partitionDate, tableName,
							FAILURE, "NULL type is successfully completed",
							PROCESS_LAYER, moduleName, hiveCtx, prop));
					metadataProcess(partitionDate, metaDateList);
					throw new ProcessException(
							"Invalid source type for the table " + tableName);
				}

				if (processStatus) {
					metaDateList.add(metaDataProcessor.processMetaData(
							sourceName, countryCode, partitionDate, tableName,
							SUCESS, sourceTypeProcessor.getType()
									+ " is successfully completed",
							PROCESS_LAYER, moduleName, hiveCtx, prop));

				} else {
					metaDateList.add(metaDataProcessor.processMetaData(
							sourceName, countryCode, partitionDate, tableName,
							FAILURE, sourceTypeProcessor.getType()
									+ " is failed", PROCESS_LAYER, moduleName,
							hiveCtx, prop));
				}
				metaStatus = metadataProcess(partitionDate, metaDateList);

			} else {

				partitions = processingQuery.getAllLatestpartitions(
						inputPartitionDate, hiveCtx, prop);

				for (Row partition : partitions) {

					String partitionDate = partition.get(0).toString();
					List<Row> eodAndNextEod = processingQuery.getEodDate(
							countryCode, partitionDate, hiveCtx, prop);
					List<Row> CurrentAndpreviuosDayPartitions = processingQuery
							.getPreviousDayPartitions(partitionDate, hiveCtx,
									prop);
					List<Row> journalTime = processingQuery.getJournalTime(
							countryCode, CurrentAndpreviuosDayPartitions,
							hiveCtx, prop, partitionDate);
					SourceTypeProcessor sourceTypeProcessor = sourceTypeProcessorFactory
							.createProcessor(tableType);

					processStatus = false;

					if (sourceTypeProcessor != null) {

						processStatus = sourceTypeProcessor.sourceTypeProcess(
								sourceName, tableName, countryCode,
								partitionDate, tableType,
								CurrentAndpreviuosDayPartitions, eodAndNextEod,
								journalTime, hiveCtx, prop, columns, primaryKeyColumnsMap,
								metaDateList);
					} else {
						metaDateList.add(metaDataProcessor.processMetaData(
								sourceName, countryCode, partitionDate,
								tableName, FAILURE,
								"NULL type is successfully completed",
								PROCESS_LAYER, null, hiveCtx, prop));
						metadataProcess(partitionDate, metaDateList);
						throw new ProcessException(
								"Invalid source type for the table "
										+ tableName);

					}

					if (processStatus) {

						metaDateList.add(metaDataProcessor.processMetaData(
								sourceName, countryCode, partitionDate,
								tableName, SUCESS,
								sourceTypeProcessor.getType()
										+ " is successfully completed",
								PROCESS_LAYER, moduleName, hiveCtx, prop));

					} else {
						metaDateList.add(metaDataProcessor.processMetaData(
								sourceName, countryCode, partitionDate,
								tableName, FAILURE,
								sourceTypeProcessor.getType() + " is failed",
								PROCESS_LAYER, moduleName, hiveCtx, prop));
					}
					metaStatus = metadataProcess(partitionDate, metaDateList);

				}
			}
			if (!metaStatus) {
				logger.error("Meta data Insertion got failed for table "
						+ tableName);
			}
			if (processStatus) {

				boolean refStatus = processingQuery.tableRefresh(tableName,
						hiveCtx, prop);
				if (refStatus) {
					logger.info("snapshot table refresh done for ReRun");
				} else {
					logger.error("snapshot table refresh failed for ReRun");
				}
				logger.info("Starting the processed layer RECON functionalities");
				EodReconProcessorMain eodReconProcessorMain = new EodReconProcessorMain(
						hiveCtx, jsCtx, prop);
				reconStatus = eodReconProcessorMain.processReconForReRun(
						hdfInputs, partitions);
				if (!reconStatus) {
					logger.info("RECON done with status SUCESS for the table: "
							+ tableName + " in ReRun Process of partition: "
							+ inputPartitionDate);

				} else {
					logger.error("RECON done with status FAILURE for the table: "
							+ tableName
							+ " in ReRun Process of partition: "
							+ inputPartitionDate);
				}
			} else {
				logger.error("RECON done with status FAILURE for the table: "
						+ tableName + " in ReRun Process of partition: "
						+ inputPartitionDate);
			}

		} catch (Exception ae) {

			logger.error("ReRun process failed for the table " + tableName);
			logger.error(ae.getMessage());
		}
		return processStatus;
	}

	private boolean metadataProcess(String partitionDate,
			List<String> metaDateList) {
		String finalQueryForMasterMetadata = "";
		String finalQueryForTransacttionMetadata = "";
		boolean status = false;
		try {
			String commonDatabase = prop.get("spark.commonDatabase");
			for (String stringList : metaDateList) {
				if ((stringList.contains(MASTER))) {

					if (metaDateList.size() == 1) {
						finalQueryForMasterMetadata = finalQueryForMasterMetadata
								+ stringList
								+ " from "
								+ commonDatabase
								+ DOT
								+ sourceName
								+ UNDERSCORE
								+ SCB_ALL_TAB
								+ " limit 1";
					} else {
						finalQueryForMasterMetadata = finalQueryForMasterMetadata
								+ stringList + UNIONALL;
					}
				} else if (metaDateList.size() == 1) {
					finalQueryForTransacttionMetadata = finalQueryForTransacttionMetadata
							+ stringList
							+ " from "
							+ commonDatabase
							+ DOT
							+ sourceName
							+ UNDERSCORE
							+ SCB_ALL_TAB
							+ " limit 1";
				} else {
					finalQueryForTransacttionMetadata = finalQueryForTransacttionMetadata
							+ stringList + UNIONALL;
				}
			}

			if (!metaDateList.isEmpty()) {
				if (finalQueryForMasterMetadata.trim()
						.endsWith(UNIONALL.trim())) {
					finalQueryForMasterMetadata = finalQueryForMasterMetadata
							.substring(0,
									finalQueryForMasterMetadata.length() - 10);
				}
				if (finalQueryForTransacttionMetadata.trim().endsWith(
						UNIONALL.trim())) {
					finalQueryForTransacttionMetadata = finalQueryForTransacttionMetadata
							.substring(
									0,
									finalQueryForTransacttionMetadata.length() - 10);
				}
			}

			if (!finalQueryForMasterMetadata.isEmpty()) {
				metaDataProcessor.insertMetaData(sourceName, countryCode,
						partitionDate, PROCESS_LAYER, RERUN_MASTER, hiveCtx,
						prop, finalQueryForMasterMetadata);
				status = true;
			} else {
				logger.info("Process metadata missing for Master");
			}
			if (!finalQueryForTransacttionMetadata.isEmpty()) {
				metaDataProcessor.insertMetaData(sourceName, countryCode,
						partitionDate, PROCESS_LAYER, RERUN_TRANSACTION,
						hiveCtx, prop, finalQueryForTransacttionMetadata);
				status = true;
			} else {
				logger.info("Process metadata missing Transaction");
			}
		} catch (Exception e) {
			logger.error(e);
			status = false;
		}
		return status;
	}

}