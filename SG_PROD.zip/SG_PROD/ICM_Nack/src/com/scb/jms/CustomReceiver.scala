package com.scb.jms

import java.io.{ BufferedReader, InputStreamReader }
import java.net.Socket
import java.nio.charset.StandardCharsets
import org.apache.spark.SparkConf
import org.apache.spark.storage.StorageLevel
import org.apache.spark.streaming.{ Seconds, StreamingContext }
import org.apache.spark.streaming.receiver.Receiver
//import com.scb.icm.properties.ConfigProperties;
import java.util.Hashtable;
import java.util.Properties;
import java.util.StringTokenizer;
import scala.util.control._
import javax.jms._;
import javax.jms.IllegalStateException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import scala.collection.mutable.ListBuffer
import com.scb.icm.kafkautils.KafkaTopics
import com.scb.icm.ICMHelper
import org.apache.spark.SparkContext
import kafka.serializer.DefaultEncoder
import com.scb.icm.kafkautils.SimplePartitioner
import kafka.producer.ProducerConfig
import scala.io.Source

object CustomReceiver {

  def readMessage(propertyFile1: String, topic1: String, outputPath1: String, brokerList1: String) {

    val excDate = ICMHelper.y_m_dFn()
    val propertyFile = propertyFile1
    val topic = topic1
    val outputPath = outputPath1 + "/" + topic + "/dt=" + excDate + "/data"
    val brokerList = brokerList1
    println("propertyFile>>"++propertyFile)
    val sparkConf = new SparkConf().setAppName("JMSCustomReceiver_" + topic)

    val ssc = new StreamingContext(sparkConf, Seconds(10))

    val lines = ssc.receiverStream(new CustomReceiver(propertyFile))

    lines.saveAsTextFiles(outputPath)

    lines.foreachRDD { x =>

      val sysdate = ICMHelper.getDateFull()
      x.foreach { y =>
        val kafkaTopics = new KafkaTopics(brokerList)
        kafkaTopics.sendText(topic, y, sysdate.toString)

      }

    }

    ssc.start()
    ssc.awaitTermination()
  }
}

class CustomReceiver(filePath: String)
    extends Receiver[String](StorageLevel.MEMORY_AND_DISK_2) {
  var ctx: InitialContext = null

  // val cp = ConfigProperties.getInstance(filePath)
  val cp = Source.fromFile(filePath).bufferedReader()
  // prop.load(reader)
  val properties: Properties = null
  properties.load(cp)
  var f: ConnectionFactory = null
  var con: Connection = null
  var ses: Session = null
  var receiver: TopicSubscriber = null

  def onStart() {

     println("connectionFactory>>>"+properties.getProperty("connectionFactory"))
       println("connUserId>>>"+properties.getProperty("connUserId"))
        println("connPassword>>>"+properties.getProperty("connPassword"))
                println("topic>>>"+properties.getProperty("topic"))
                        println("durablesubscriber>>>"+properties.getProperty("durablesubscriber"))
    new Thread("JMS Receiver") {
      override def run() { receive() }
    }.start()
  }

  def onStop() {

    receiver.close()
    ses.close()
    con.close()
  }

  /** Create a socket connection and receive data until receiver is stopped */
  private def receive() {

    val namingClass = properties.getProperty("initial_context_factory");
    var providerUrl = properties.getProperty("provider_url");
    val failOverList = properties.getProperty("failover_list");
    var failed = false;

    val props: Hashtable[String, String] = new Hashtable[String, String]();

    props.put(Context.INITIAL_CONTEXT_FACTORY, namingClass);
    props.put(Context.PROVIDER_URL, providerUrl);
    props.put("com.webmethods.jms.clientIDSharing", "true");

    try {
      ctx = new InitialContext(props);
    } catch {
      case ex: NamingException => {

        val token = new StringTokenizer(failOverList, ";");

        val loopbreak = new Breaks;

        while (token.hasMoreTokens()) {
          providerUrl = token.nextToken();
          props.put(Context.PROVIDER_URL, providerUrl.trim());

          try {
            ctx = new InitialContext(props);
            failed = false;
          } catch {

            case ex: NamingException => {
              failed = true;
            }

          }
          if (!failed)
            loopbreak.break;
        }
        if (failed) {
          throw new IllegalStateException(
            "Unable to connect to any JNDI provider URL's.");
        }
      }
    }

    try {
     
      f = ctx.lookup(properties.getProperty("connectionFactory")).asInstanceOf[ConnectionFactory]
      con = f.createConnection(properties.getProperty("connUserId"), properties.getProperty("connPassword"));
    } catch {
      case e: Exception => {
        e.printStackTrace();
      }
    }

    try {
      //con.setClientID("EDMi_EDMp_JMS_Client");
      con.start();
      ses = con.createSession(false, Session.CLIENT_ACKNOWLEDGE);
      val t: Topic = ctx.lookup(properties.getProperty("topic")).asInstanceOf[Topic]
      receiver = ses.createDurableSubscriber(t, properties.getProperty("durablesubscriber"));
    } catch {
      case e: Exception => {
        e.printStackTrace();
      }

    }

    val listener: MessageListener = new MessageListener {
      def onMessage(message: Message): Unit = {
        try {
          if (message.isInstanceOf[TextMessage]) {
            val textMessage: TextMessage = message.asInstanceOf[TextMessage]
            store(textMessage.getText().replaceAll("\n", ""))
            textMessage.acknowledge
          }
        } catch {
          case je: JMSException => {
            println(je.getMessage)
          }
        }
      }
    }
    receiver.setMessageListener(listener)
  }

}