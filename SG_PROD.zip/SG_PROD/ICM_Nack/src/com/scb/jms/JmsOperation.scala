package com.scb.jms

import javax.jms.TopicSession
import java.io.BufferedReader
import com.webmethods.jms.impl.WmConnectionFactoryImpl
import javax.jms._;
import javax.jms.IllegalStateException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.util.Properties
import java.util.Hashtable;
import javax.naming.Context;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;

class JmsOperation {
  def sendMessage(prop: Properties, msgxml: String): Unit = {
    try {
      val props: Hashtable[String, String] = new Hashtable[String, String]();
      props.put(Context.INITIAL_CONTEXT_FACTORY, "com.webmethods.jms.naming.WmJmsNamingCtxFactory");
      props.put(Context.PROVIDER_URL, prop.getProperty("PROVIDER_URL"));
      props.put("com.webmethods.jms.clientIDSharing", "true");
      val ctx = new InitialContext(props);
      
       println("connectionFactory--->"+prop.getProperty("connectionFactory"))
       println("connUserId--->"+prop.getProperty("connUserId"))
       println("connPassword>>>"+prop.getProperty("connPassword"))
       println("topic--->"+prop.getProperty("topic"))
       println("durablesubscriber--->"+prop.getProperty("durablesubscriber"))
    
       // retrieve encrypt password from property file for decrypt
        val enc = prop.getProperty("connPassword");
        val seed = "password_key";
       // println("seed:  " + seed)
        val encryptor: StandardPBEStringEncryptor = new StandardPBEStringEncryptor();
        encryptor.setPassword(seed);
        val decrypted = encryptor.decrypt(enc);
        val fc = ctx.lookup(prop.getProperty("JMS_CONNECTION")).asInstanceOf[WmConnectionFactoryImpl]
      // val con = fc.createTopicConnection(prop.getProperty("connUserId"), prop.getProperty("connPassword"));
        val con = fc.createTopicConnection(prop.getProperty("connUserId"), decrypted);
        println("JMS Connection Established")
        con.start();
      val ses = con.createTopicSession(false, Session.AUTO_ACKNOWLEDGE)
      val t = ctx.lookup(prop.getProperty("JMS_TOPIC")).asInstanceOf[Topic]
      val publisher = ses.createPublisher(t);
      val msg = ses.createTextMessage();
      msg.setText(msgxml)
      publisher.publish(msg);
      println("Message successfully sent.");
      con.close();
    } catch {
      case e: Exception => {
        println("Exception while pushing data to jms queue")
        e.printStackTrace
      }
    }

  }
}