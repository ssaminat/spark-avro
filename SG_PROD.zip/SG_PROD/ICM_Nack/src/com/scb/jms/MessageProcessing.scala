package com.scb.jms

import java.util.Properties
import org.apache.log4j.Logger
import collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer
import java.util.Calendar

object MessageProcessing {

  def loadXML(prop: Properties, message: String): String = {
//    val path = prop.getProperty("RESPONSE_XML_LOC")
//    val xml = path + prop.getProperty("RESPONSE_XML_NAME")
//    var file = ""
//    try {
//      file = scala.io.Source.fromFile(xml).mkString
//    } catch {
//      case e: Exception => {
//        println("RESPONSE_XML_LOC or RESPONSE_XML_NAME are not valid ")
//      }
//    }
//    val cola = file.split("<ns2:acknowledgeConsumptionReq>")
//    val topxml = cola(0) + "<ns2:acknowledgeConsumptionReq>"
//    val bottomxml = "</ns2:acknowledgeConsumptionReq>" + cola(1).split("</ns2:acknowledgeConsumptionReq>")(1)   
//    val xmlm = topxml + message + bottomxml
    //xmlm
    message
  }

  def createMessage(country: String, trackingId: String, error_type: String, profileID: String, relationshipID: String, messageSequenceNumber: String, column: String, data: String): String = {
    val date = Calendar.getInstance.getTime
    var errorcode = ""
    var error_message =""
    var ss = error_type match {
      case "data_length_isuee" => {
        errorcode="IN011100"
         error_message ="Data Length Mismatch"
      }
      case "data_type_isuee" => {
        errorcode="IN011101"
         error_message ="Data type mismatch"
      }
    }

    var message ="<?xml version='1.0' encoding='UTF-8' standalone='yes'?>"+
"<acknowledgeConsumptionReq"+
"    xmlns:ns2='http://www.sc.com/referential/v2/DataConsumptionConfirmation'"+
"    xmlns:ns3='http://www.sc.com/SCBML-1'>"+
"    <ns3:header>"+
"        <ns3:messageDetails>"+
"            <ns3:messageVersion>1.0</ns3:messageVersion>"+
"            <ns3:messageType>"+
"                <ns3:typeName>Referential:DataConsumptionConfirmation</ns3:typeName>"+
"                <ns3:subType>"+
"                    <ns3:subTypeName>acknowledgeConsumption</ns3:subTypeName>"+
"                </ns3:subType>"+
"            </ns3:messageType>"+
"            <ns3:multiMessage>"+
"                <ns3:multiMessageKnown>"+
"                    <ns3:multiMessageCount>1</ns3:multiMessageCount>"+
"                    <ns3:messagePosition>1</ns3:messagePosition>"+
"                    <ns3:messageOrder>FIFO</ns3:messageOrder>"+
"                </ns3:multiMessageKnown>"+
"            </ns3:multiMessage>"+
"        </ns3:messageDetails>"+
"        <ns3:originationDetails>"+
"            <ns3:messageSender>"+
"                <ns3:messageSender>EDMp</ns3:messageSender>"+
"                <ns3:senderDomain>"+
"                    <ns3:domainName>Referential</ns3:domainName>"+
"                    <ns3:subDomainName/>"+
"                </ns3:senderDomain>"+
"                <ns3:countryCode>" + country + "</ns3:countryCode>"+
"            </ns3:messageSender>"+
"            <ns3:messageTimestamp>08:00:00.000+08:00</ns3:messageTimestamp>"+
"            <ns3:initiatedTimestamp>08:00:00.000+08:00</ns3:initiatedTimestamp>"+
"            <ns3:trackingId>" + trackingId + "</ns3:trackingId>"+
"            <ns3:correlationID>000000001</ns3:correlationID>"+
"            <ns3:conversationID>000000001</ns3:conversationID>"+
"           <ns3:customSearchID>000000001</ns3:customSearchID>"+
"            <ns3:serviceBusID>12345</ns3:serviceBusID>"+
"            <ns3:validFrom>08:00:00.000+08:00</ns3:validFrom>"+
"            <ns3:validTo>08:00:00.000+08:00</ns3:validTo>"+
"            <ns3:timeToLive>08:00:00.000+08:00</ns3:timeToLive>"+
"            <ns3:priority>1.0</ns3:priority>"+
"            <ns3:checksum/>"+
"            <ns3:encoding>UTF-8</ns3:encoding>"+
"            <ns3:possibleDuplicate>false</ns3:possibleDuplicate>"+
"        </ns3:originationDetails>"+
"        <ns3:captureSystem>ICM</ns3:captureSystem>"+
"        <ns3:process>"+
"            <ns3:processName>acknowledgeConsumption</ns3:processName>"+
"            <ns3:eventType>Notify</ns3:eventType>"+
"        </ns3:process>"+
"    </ns3:header>"+
"    <ns2:acknowledgeConsumptionReqPayload>"+
"        <ns3:payloadFormat>XML</ns3:payloadFormat>"+
"        <ns3:payloadVersion>1.0</ns3:payloadVersion>"+
"        <ns2:acknowledgeConsumptionReq>"+
"            <ns2:Messages>"+
"                <ns2:MessageInfo>"+
"                    <ns2:messageId>1234055060403200</ns2:messageId>"+
"                    <ns2:messageType>NotifyStaticData</ns2:messageType>"+
"                    <ns2:processDate>" + date + "</ns2:processDate>"+
"                    <ns2:publisherId>ICM</ns2:publisherId>"+
"                    <ns2:subscriberId>EDMP</ns2:subscriberId>"+
"                    <ns2:responseCode>NACK</ns2:responseCode>"+
"                    <ns2:keyvalue>"+
"                        <ns2:keyFields>"+
"                            <ns2:name>profileID</ns2:name>"+
"                            <ns2:value>" + profileID + "</ns2:value>"+
"                        </ns2:keyFields>"+
//"                        <ns2:keyFields/>"+
"                        <ns2:keyFields>"+
"                            <ns2:name>relationshipID</ns2:name>"+
"                            <ns2:value>" + relationshipID + "</ns2:value>"+
"                        </ns2:keyFields>"+
"                        <ns2:keyFields>"+
"                            <ns2:name>messageSequenceNumber</ns2:name>"+
"                            <ns2:value>" + messageSequenceNumber + "</ns2:value>"+
"                        </ns2:keyFields>"+
"                    </ns2:keyvalue>"+
"                    <ns2:responseMessageDetails>"+
"                        <ns2:responseMessage>"+
"                            <ns2:code>"+errorcode+"</ns2:code>"+
"                            <ns2:description>"+error_message+"</ns2:description>"+
"                        </ns2:responseMessage>"+
"                    </ns2:responseMessageDetails>"+
"                </ns2:MessageInfo>"+
"            </ns2:Messages>"+
"        </ns2:acknowledgeConsumptionReq>"+
"    </ns2:acknowledgeConsumptionReqPayload>"+
"</acknowledgeConsumptionReq>" 
      
      
      
      
      
      
      
      
      
      
      
      
      
      
//      "<ns2:Messages>" +
//      "<ns2:MessageInfo>" +
//      "<ns2:messageId>1234055060403200</ns2:messageId>" +
//      "<ns2:messageType>NotifyStaticData</ns2:messageType>" +
//      "<ns2:processDate>" + date + "</ns2:processDate>" +
//      "<ns2:publisherId>ICM</ns2:publisherId>" +
//      "<ns2:subscriberId>eBBS</ns2:subscriberId>" +
//      "<ns2:responseCode>NACK</ns2:responseCode>" +
//      "<ns2:keyvalue>" +
//      "<ns2:keyFields>" +
//      "<ns2:name>profileID</ns2:name>" +
//      "<ns2:value>" + profileID + "</ns2:value>" +
//      "</ns2:keyFields>" +
//      "<ns2:keyFields>" +
//      "<ns2:name>messageSequenceNumber</ns2:name>" +
//      "<ns2:value>" + messageSequenceNumber + "</ns2:value>" +
//      "</ns2:keyFields>" +
//      "<ns2:keyFields/>" +
//      "</ns2:keyvalue>" +
//      "<ns2:responseMessageDetails>" +
//      "<ns2:responseMessage>" +
//      "<ns2:code>"+errorcode+"</ns2:code>" +
//      "<ns2:description>Unable to process the column " + column + " with data :  " + data + "</ns2:description>" +
//      "</ns2:responseMessage>" +
//      "</ns2:responseMessageDetails>" +
//      "</ns2:MessageInfo>" +
//      "</ns2:Messages>"
    message

  }

}