package com.scb.main

import java.util.Properties
import org.apache.log4j.Logger
import scala.io.Source
import org.apache.spark.streaming.StreamingContext

object Entry {
  val entry = Entry
  val logger = Logger.getLogger(entry.getClass)

  def main(args: Array[String]): Unit = {
    println("IN MAIN TRACKING>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
    println("*****Contents are reading from SG prod jar*******")
    logger.info("----------------------------------------------------------------------------- ")
    logger.info("-----------------------------------ICM Start--------------------------------- ")
    logger.info("----------------------------------------------------------------------------- ")
    var streaming: StreamingContext = null
    try {
      val brokerlist = args(0)
      val topic = args(1)
      val frequency = args(2).toInt
      logger.info("brokerlist----------------------------------->  " + brokerlist)
      logger.info("topic----------------------------------->  " + topic)
      logger.info("frequency----------------------------------->  " + frequency)
      val property = args(3)
      logger.info("property----------------------------------->  " + property)
      val validation_property = args(4)
      logger.info("validation_property----------------------------------->  " + validation_property)
      val reader = Source.fromFile(property).bufferedReader()
      val prop = new Properties()
      prop.load(reader)
      val reader1 = Source.fromFile(validation_property).bufferedReader()
      val prop1 = new Properties()
      prop1.load(reader1)
      streaming = com.scb.icm.ICM.setupStreamPipeline(topic, brokerlist, frequency, prop, prop1)
      streaming.start()
      streaming.awaitTermination()

    } catch {

      case e: Exception => {
        println("Exception--------------------------: " + e)
        e.printStackTrace
      }
    }
    sys.ShutdownHookThread {
      println("Gracefully stopping ICM message ")
      streaming.stop(true, true)
      println("ICM msg app stopped")
    }
    logger.info("----------------------------------------------------------------------------- ")
    logger.info("-----------------------------------ICM END--------------------------------- ")
    logger.info("----------------------------------------------------------------------------- ")

  }
}