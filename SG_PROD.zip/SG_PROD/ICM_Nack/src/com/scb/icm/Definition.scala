package com.scb.icm

import java.io.StringReader

import scala.collection.JavaConversions.asScalaBuffer
import scala.collection.mutable.HashMap
import scala.xml.Elem

import org.apache.hadoop.hbase.client.Put
import org.apache.hadoop.hbase.util.Bytes
import org.w3c.dom.Node
import org.w3c.dom.NodeList
import org.xml.sax.InputSource

import javax.xml.parsers.DocumentBuilderFactory
import collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
case class DataCapture(countrycode:String, trackingId:String, error_type: String, profileID: String, relationshipID: String, messageSequenceNumber: String, column: String, data: String)
case class Message(
  val values: HashMap[String, String])

object Message {

  def apply(melem: Elem)(): Message = {

    val values = new HashMap[String, String]()

    try {
      val dBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder()
      val doc = dBuilder.parse(new InputSource(new StringReader(melem.toString())))
      //println("Root element :" + doc.getDocumentElement.getNodeName)
      if (doc.hasChildNodes()) {
        readNode(doc.getChildNodes, values)
      }

      println("XML Parsing completed")
      //println("MAP SIZE IS " + values.size)

    } catch {
      case e: Exception => println(e.getMessage)
    }
    Message(
      values)
  }

  private def readNode(nodeList: NodeList, values: HashMap[String, String]) {
    for (count <- 0 until nodeList.getLength) {
      val tempNode = nodeList.item(count)
      if (tempNode.getNodeType == Node.ELEMENT_NODE) {
        var nodeName = tempNode.getNodeName
        var nodeValue: String = null
        if (tempNode.getChildNodes.getLength == 1 || tempNode.getChildNodes.getLength == 0) {
          nodeValue = tempNode.getTextContent
          nodeName = tempNode.getParentNode.getNodeName + ":" + nodeName + "#" + 1.toInt + "#"
          if (values.contains(nodeName)) {
            val d = values.get(nodeName.split("#")(0))
            var z = d.get.toInt
            z = z + 1
            values.put(nodeName.split("#")(0), z.toString())
            nodeName = nodeName.replace("#1#", "#" + z + "#")
          } else {
            values.put(nodeName.split("#")(0), 1.toString())
          }
          values.put(nodeName, nodeValue)
        }
        if (tempNode.hasChildNodes()) {
          readNode(tempNode.getChildNodes, values)
        }
      }
    }
  }

  def convertToPut(datalist: java.util.HashMap[String, String], tx: Message, count: Integer, loaddt: String): (Put) = {
    val putObj = new Put(Bytes.toBytes(tx.values.get("cust:ProfileUniqueId:cust:profileID#1#").get + "_" + tx.values.get("cust:ProfileUniqueId:cust:relationshipID#1#").get + "_" + tx.values.get("ns:originationDetails:ns:messageTimestamp#1#").get + "_" + tx.values.get("cust:ProfileUniqueId:cust:messageSequenceNumber#1#").get + "_" + count))
   // val putObj = new Put(Bytes.toBytes(tx.values.get("cust:ProfileUniqueId:cust:profileID#1#").get + "_" + tx.values.get("cust:ProfileUniqueId:cust:relationshipID#1#").get + "_" + tx.values.get("cust:ProfileUniqueId:cust:messageSequenceNumber#1#").get + "_" + count))
    for ((k, data) <- datalist) {
     // println("k : " + k + " data " + data)
      if (tx.values.contains(data + "#" + count + "#")) {
        if (k.equalsIgnoreCase("country_code")) {
          putObj.addColumn(ICMHelper.default_b, Bytes.toBytes("country_code"), Bytes.toBytes(tx.values.get(data + "#" + count + "#").get))
        } else {
          putObj.addColumn(ICMHelper.default_b, Bytes.toBytes(data.split(":")(3)), Bytes.toBytes(tx.values.get(data + "#" + count + "#").get))
        }
      } else {
        putObj.addColumn(ICMHelper.default_b, Bytes.toBytes(data.split(":")(3)), Bytes.toBytes(""))
      }
    }
    //    val dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    //    val date = new Date();
    putObj.addColumn(ICMHelper.default_b, Bytes.toBytes("loaddatetime"), Bytes.toBytes(loaddt))
    putObj.addColumn(ICMHelper.default_b, Bytes.toBytes("profileID"), Bytes.toBytes(tx.values.get("cust:ProfileUniqueId:cust:profileID#1#").get))
    putObj.addColumn(ICMHelper.default_b, Bytes.toBytes("relationshipID"), Bytes.toBytes(tx.values.get("cust:ProfileUniqueId:cust:relationshipID#1#").get))
    putObj.addColumn(ICMHelper.default_b, Bytes.toBytes("messageSequenceNumber"), Bytes.toBytes(tx.values.get("cust:ProfileUniqueId:cust:messageSequenceNumber#1#").get))
    putObj.addColumn(ICMHelper.default_b, Bytes.toBytes("countryCode"), Bytes.toBytes(tx.values.get("ns:messageSender:ns:countryCode#1#").get))
    putObj.addColumn(ICMHelper.default_b, Bytes.toBytes("messageTimestamp"), Bytes.toBytes(tx.values.get("ns:originationDetails:ns:messageTimestamp#1#").get))
    putObj.addColumn(ICMHelper.default_b, Bytes.toBytes("trackingId"), Bytes.toBytes(tx.values.get("ns:originationDetails:ns:trackingId#1#").get))
    putObj
  }
  def convertToPut1(datalist: java.util.HashMap[String, String], tx: Message, count: Integer, loaddt: String): (Put) = {
    val putObj = new Put(Bytes.toBytes(tx.values.get("cust:ProfileUniqueId:cust:profileID#1#").get + "_" + tx.values.get("cust:ProfileUniqueId:cust:relationshipID#1#").get + "_" + tx.values.get("ns:originationDetails:ns:messageTimestamp#1#").get))
    //val putObj = new Put(Bytes.toBytes(tx.values.get("cust:ProfileUniqueId:cust:profileID#1#").get + "_" + tx.values.get("cust:ProfileUniqueId:cust:relationshipID#1#").get))
    for ((k, data) <- datalist) {
      if (tx.values.contains(data + "#" + count + "#")) {
        putObj.addColumn(ICMHelper.default_b, Bytes.toBytes(data.split(":")(3)), Bytes.toBytes(tx.values.get(data + "#" + count + "#").get))
      } else {
        putObj.addColumn(ICMHelper.default_b, Bytes.toBytes(data.split(":")(3)), Bytes.toBytes(""))
      }
    }
    //    val dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    //    val date = new Date();
    putObj.addColumn(ICMHelper.default_b, Bytes.toBytes("loaddatetime"), Bytes.toBytes(loaddt))
    putObj.addColumn(ICMHelper.default_b, Bytes.toBytes("profileID"), Bytes.toBytes(tx.values.get("cust:ProfileUniqueId:cust:profileID#1#").get))
    putObj.addColumn(ICMHelper.default_b, Bytes.toBytes("relationshipID"), Bytes.toBytes(tx.values.get("cust:ProfileUniqueId:cust:relationshipID#1#").get))
    putObj.addColumn(ICMHelper.default_b, Bytes.toBytes("messageSequenceNumber"), Bytes.toBytes(tx.values.get("cust:ProfileUniqueId:cust:messageSequenceNumber#1#").get))
    putObj.addColumn(ICMHelper.default_b, Bytes.toBytes("countryCode"), Bytes.toBytes(tx.values.get("ns:messageSender:ns:countryCode#1#").get))
    putObj.addColumn(ICMHelper.default_b, Bytes.toBytes("messageTimestamp"), Bytes.toBytes(tx.values.get("ns:originationDetails:ns:messageTimestamp#1#").get))
    putObj
  }

  def convertToPut(datalist: java.util.ArrayList[String], tx: Message, count: Integer): (Put) = {
    val putObj = new Put(Bytes.toBytes(tx.values.get("cust:ProfileUniqueId:cust:profileID#1#").get + "_" + tx.values.get("cust:ProfileUniqueId:cust:relationshipID#1#").get + "_" + tx.values.get("ns:originationDetails:ns:messageTimestamp#1#").get + "_" +tx.values.get("cust:ProfileUniqueId:cust:messageSequenceNumber#1#").get + "_" + count))
    //val putObj = new Put(Bytes.toBytes(tx.values.get("cust:ProfileUniqueId:cust:profileID#1#").get + "_" + tx.values.get("cust:ProfileUniqueId:cust:relationshipID#1#").get + "_" + tx.values.get("cust:ProfileUniqueId:cust:messageSequenceNumber#1#").get + "_" + count))
    for (data <- datalist.toIterable) {
      if (tx.values.contains(data + "#" + count + "#")) {
        putObj.addColumn(ICMHelper.default_b, Bytes.toBytes(data.split(":")(3)), Bytes.toBytes(tx.values.get(data + "#" + count + "#").get))
      } else {
        putObj.addColumn(ICMHelper.default_b, Bytes.toBytes(data.split(":")(3)), Bytes.toBytes(""))
      }
    }
    putObj.addColumn(ICMHelper.default_b, Bytes.toBytes("profileID"), Bytes.toBytes(tx.values.get("cust:ProfileUniqueId:cust:profileID#1#").get))
    putObj.addColumn(ICMHelper.default_b, Bytes.toBytes("relationshipID"), Bytes.toBytes(tx.values.get("cust:ProfileUniqueId:cust:relationshipID#1#").get))
    putObj.addColumn(ICMHelper.default_b, Bytes.toBytes("messageSequenceNumber"), Bytes.toBytes(tx.values.get("cust:ProfileUniqueId:cust:messageSequenceNumber#1#").get))
    putObj.addColumn(ICMHelper.default_b, Bytes.toBytes("countryCode"), Bytes.toBytes(tx.values.get("ns:messageSender:ns:countryCode#1#").get))
    putObj
  }

  def convertToPut(datalist: ArrayBuffer[com.scb.validation.ForError], tx: Message, count: Integer): (Put) = {

    val putObj = new Put(Bytes.toBytes(datalist(0).profileID + "_" + datalist(0).relationshipID + "_" + datalist(0).messageSequenceNumber + "_" + count + "_" + datalist(0).table_name))
    for (data <- datalist) {
      putObj.addColumn(ICMHelper.default_b, Bytes.toBytes(data.table_name + "_" + data.coumn_name + "_" + data.error_type), Bytes.toBytes(data.column_value))

    }
    putObj
  }

  def convertToPut(datalist: ArrayBuffer[com.scb.validation.ForError],tx: Message): java.util.ArrayList[DataCapture] = {
    val countrycode = tx.values.get("ns:messageSender:ns:countryCode#1#").get
        val trackingId = tx.values.get("ns:originationDetails:ns:trackingId#1#").get
    val lis = new java.util.ArrayList[DataCapture]()
    for (data <- datalist) {
      lis += DataCapture(countrycode,trackingId,data.error_type, data.profileID, data.relationshipID, data.messageSequenceNumber, data.coumn_name, data.column_value)
    }
    lis
  }

}