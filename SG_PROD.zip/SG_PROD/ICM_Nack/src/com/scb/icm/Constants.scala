package com.scb.icm

object Constants {

 // val PREFIX_ICM_MY = "icm_my_"
    val PREFIX_ICM_SG = "icm_sg_"
 // val PREFIX_ICM_HK = "icm_hk_"

  val RETRIES = 3

  val HBASE_COUNTER_TABLE =  "icm_partition_counter"
  val HBASE_COUNTER_SG_TABLE = "icm_partition_sg_counter"
  val HBASE_TOT_PARSED =  "icm_total_transactions"
  
  //***********
  val HBASE_CUST_PROFILES =  "cust_profiles"
  val HBASE_CUST_PROFILE_BUSINESS =  "cust_profile_business"
  val HBASE_CUST_CDD_DETAILS = "cust_cdd_details"
  val HBASE_CUST_RISK_INDICATORS =  "cust_risk_indicators"
  val HBASE_CUST_ALIAS =  "cust_alias"
  val HBASE_CUST_NATIONS =  "cust_nations"
  val HBASE_CUST_ADDRESS =  "cust_address"
  val HBASE_CUST_CONTACTS =  "cust_contacts"
  val HBASE_CUST_DOCUMENTS =  "cust_documents"
  val HBASE_CUST_EMPLOYMENTS = "cust_employments"
  val HBASE_CUST_FATCA_DETAILS = "cust_fatca_details"
  val HBASE_CUST_RISK_REASONS =  "cust_risk_reasons"
  val HBASE_CUST_INFO_DETAILS =  "cust_info_details"
  val HBASE_CUST_LINKS =  "cust_links"
  val HBASE_CUST_PRODUCT_REFERENCES =  "cust_product_references"
  val HBASE_CUST_EXT_SYS_REFERENCES =  "cust_ext_sys_references"
  val HBASE_CUST_REMARKS =  "cust_remarks"
  val HBASE_CUST_SI_COUNTRIES =  "cust_si_countries"
  val HBASE_CUST_ML_PROFILES =  "cust_ml_profiles"
  val HBASE_CUST_ML_ALIAS =  "cust_ml_alias"
  val HBASE_CUST_ML_ADDRESS =  "cust_ml_address"
  val HBASE_CUST_CUCOS =  "cust_cucos"
  val HBASE_SG_VALIDATION = "cust_sg_validation"
  

  //*****************
  val COL_TOT = "count"

  val HBASE_COL_TOT_TX_CNT_DUPLICATE = "count_duplicate"
  val HBASE_COL_TOT_TX_CNT_VALID = "count_valid"
  val HBASE_COL_TOT_TX_CNT_INVALID = "count_invalid"
  val HBASE_COL_TOT_TX_CNT_PARSED = "count_parsed"

  val HBASE_DEFAULT_CF = "d"

  val HBASE_COL_COUNTER_TOP = "topic"
  val HBASE_COL_COUNTER_KPART = "kafka_partition"
  val HBASE_COL_COUNTER_NEXT = "next_pos"
}