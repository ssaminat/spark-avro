package com.scb.icm

import com.scb.icm.Constants._
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.Path
import org.apache.hadoop.hbase.client.{ HBaseAdmin, HTable, Put, Result }
import org.apache.hadoop.hbase.util.Bytes
import org.apache.hadoop.hbase.{ HBaseConfiguration, HColumnDescriptor, HTableDescriptor, TableName }

import scala.collection.JavaConversions._

object HBaseHelper {

  def getKey(result: Result)(): String = {
    Bytes.toString(result.getRow)
  }

  def getValue(result: Result, cf: String, qual: String): String = {
    Bytes.toString(result.getValue(Bytes.toBytes(cf), Bytes.toBytes(qual)))
  }

  def getValueAsLong(result: Result, cf: String, qual: String): Long = {
    val res = result.getValue(Bytes.toBytes(cf), Bytes.toBytes(qual))
    if (res == null)
      return 0
    Bytes.toLong(res)
  }

  def getValueAsInt(result: Result, cf: String, qual: String): Int = {
    val res = result.getValue(Bytes.toBytes(cf), Bytes.toBytes(qual))
    if (res == null)
      return 0
    Bytes.toInt(res)
  }

  def getValueAsDouble(result: Result, cf: String, qual: String): Double = {
    val res = result.getValue(Bytes.toBytes(cf), Bytes.toBytes(qual))
    if (res == null)
      return 0
    Bytes.toDouble(res)
  }

  def createTable(hadmin: HBaseAdmin, name: String): TableName = {
    val tableName = TableName.valueOf(name)

    if (!hadmin.tableExists(tableName)) {
      val tableDesc = new HTableDescriptor(tableName)
      tableDesc.addFamily(new HColumnDescriptor(HBASE_DEFAULT_CF))
      hadmin.createTable(tableDesc)
      println("%s hbase table didnt exist; created".format(tableName))
      if (!hadmin.isTableEnabled(tableName)) {
        println("%s hbase table was not enabled; enabling".format(tableName))
        hadmin.enableTable(tableName)
      }
    }
    tableName
  }

  def deleteTable(hadmin: HBaseAdmin, tableName: String) {
    deleteTable(hadmin, TableName.valueOf(tableName))
  }

  def deleteTable(hadmin: HBaseAdmin, tableName: TableName) {
    if (hadmin.tableExists(tableName)) {
      if (hadmin.isTableEnabled(tableName)) {
        hadmin.disableTable(tableName)
      }
      hadmin.deleteTable(tableName)
    }
  }

  def appendDataToTable(dhwconf: Configuration, name: String, putList: List[Put]): Unit = {
    appendDataToTable(dhwconf, TableName.valueOf(name), putList)
  }
  def appendDataToTable(dhwconf: Configuration, tableName: TableName, putList: List[Put]): Unit = {
    val hTable: HTable = new HTable(dhwconf, tableName)
    hTable.put(putList)
    hTable.close
  }

  def getHbaseConfiguration(): Configuration = {
    val dhwconf = HBaseConfiguration.create()
    dhwconf.addResource(new Path("/etc/hbase/conf/hbase-site.xml"))
    dhwconf.addResource(new Path("/etc/hadoop/conf/core-site.xml"))
    dhwconf.addResource(new Path("/etc/hadoop/conf/hdfs-site.xml"))
    dhwconf.set("hbase.client.retries.number", RETRIES.toString)
    dhwconf
  }
}
