package com.scb.icm

import scala.xml.Elem

import org.apache.hadoop.fs.Path
import org.apache.hadoop.hbase.HBaseConfiguration
import org.apache.hadoop.hbase.client.HTable
import org.apache.hadoop.hbase.client.Put
import org.apache.hadoop.hbase.client.Result
import org.apache.hadoop.hbase.io.ImmutableBytesWritable
import org.apache.hadoop.hbase.mapreduce.TableInputFormat
import org.apache.hadoop.hbase.util.Bytes
import org.apache.spark.SparkConf
import org.apache.spark.TaskContext
import org.apache.spark.rdd.RDD.rddToPairRDDFunctions
import org.apache.spark.streaming.Seconds
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.dstream.InputDStream
import org.apache.spark.streaming.kafka.HasOffsetRanges
import org.apache.spark.streaming.kafka.KafkaUtils
import org.apache.spark.streaming.kafka.OffsetRange

import kafka.common.TopicAndPartition
import kafka.message.MessageAndMetadata
import kafka.serializer.StringDecoder
import java.util.Properties
import org.apache.log4j.Logger
import collection.JavaConversions._

import com.scb.icm.Constants.HBASE_COL_COUNTER_KPART
import com.scb.icm.Constants.HBASE_COL_COUNTER_NEXT
import com.scb.icm.Constants.HBASE_COL_COUNTER_TOP
import com.scb.icm.Constants.HBASE_COUNTER_TABLE
import com.scb.icm.Constants.HBASE_CUST_ADDRESS
import com.scb.icm.Constants.HBASE_CUST_ALIAS
import com.scb.icm.Constants.HBASE_CUST_CDD_DETAILS
import com.scb.icm.Constants.HBASE_CUST_CONTACTS
import com.scb.icm.Constants.HBASE_CUST_CUCOS
import com.scb.icm.Constants.HBASE_CUST_DOCUMENTS
import com.scb.icm.Constants.HBASE_CUST_EMPLOYMENTS
import com.scb.icm.Constants.HBASE_CUST_EXT_SYS_REFERENCES
import com.scb.icm.Constants.HBASE_CUST_FATCA_DETAILS
import com.scb.icm.Constants.HBASE_CUST_INFO_DETAILS
import com.scb.icm.Constants.HBASE_CUST_LINKS
import com.scb.icm.Constants.HBASE_CUST_ML_ADDRESS
import com.scb.icm.Constants.HBASE_CUST_ML_ALIAS
import com.scb.icm.Constants.HBASE_CUST_ML_PROFILES
import com.scb.icm.Constants.HBASE_CUST_NATIONS
import com.scb.icm.Constants.HBASE_CUST_PRODUCT_REFERENCES
import com.scb.icm.Constants.HBASE_CUST_PROFILES
import com.scb.icm.Constants.HBASE_CUST_PROFILE_BUSINESS
import com.scb.icm.Constants.HBASE_CUST_REMARKS
import com.scb.icm.Constants.HBASE_CUST_RISK_INDICATORS
import com.scb.icm.Constants.HBASE_CUST_RISK_REASONS
import com.scb.icm.Constants.HBASE_CUST_SI_COUNTRIES
import com.scb.icm.Constants.HBASE_DEFAULT_CF
import com.scb.icm.Constants.HBASE_TOT_PARSED
import com.scb.icm.Constants.HBASE_COUNTER_SG_TABLE

import com.scb.icm.Constants.HBASE_SG_VALIDATION
//import com.scb.icm.Constants.PREFIX_ICM_HK
//import com.scb.icm.Constants.PREFIX_ICM_MY
import com.scb.icm.Constants.COL_TOT
import com.scb.icm.Constants.PREFIX_ICM_SG
import com.scb.icm.Constants.RETRIES


object ICM {
  val icm = ICM
  val logger = Logger.getLogger(icm.getClass)
  def setupStreamPipeline(
    topic: String,
    brokerlist: String,
    freq: Int, //hdfsDir: String
    prop: Properties, validation_property: Properties): StreamingContext = {

    @transient val sparkConf = new SparkConf().setAppName("ICM_" + topic)
    @transient val streaming = new StreamingContext(sparkConf, Seconds(freq))
    val sc = streaming.sparkContext

    //hbase conf for reading from hbase
    @transient val dhrconf = HBaseConfiguration.create()
    dhrconf.addResource(new Path("/etc/hbase/conf/hbase-site.xml"))
    dhrconf.addResource(new Path("/etc/hadoop/conf/core-site.xml"))
    dhrconf.set("hbase.client.retries.number", prop.getProperty("RETRIES"))

    //New counter for singapore
    dhrconf.set(TableInputFormat.INPUT_TABLE, prop.getProperty("HBASE_COUNTER_SG_TABLE"))

    // reading kafka offset from hbase..of form id => kpart, topic, counter, next_pos
    val topicsAndOffsets: scala.collection.immutable.Map[TopicAndPartition, Long] =
      sc.newAPIHadoopRDD(dhrconf, classOf[TableInputFormat],
        classOf[ImmutableBytesWritable],
        classOf[Result])
        .map(x => x._2)
        .map(result => (
          TopicAndPartition(
            HBaseHelper.getValue(result, prop.getProperty("HBASE_DEFAULT_CF"), prop.getProperty("HBASE_COL_COUNTER_TOP")),
            HBaseHelper.getValueAsInt(result, prop.getProperty("HBASE_DEFAULT_CF"), prop.getProperty("HBASE_COL_COUNTER_KPART"))),
            HBaseHelper.getValueAsLong(result, prop.getProperty("HBASE_DEFAULT_CF"), prop.getProperty("HBASE_COL_COUNTER_NEXT"))))
        .collectAsMap.toMap
    
    val kafkaParams = Map[String, String](
      "metadata.broker.list" -> brokerlist,
      "auto.offset.reset" -> "smallest",
      "fetch.message.max.bytes"->"6300000",
     "message.max.bytes"->"6300000")

    //reading kafka as stream
    var messages: Option[InputDStream[(String, String)]] = None
    if (topicsAndOffsets.isEmpty) {
      // Start the stream
      println("INSIDE_FIRST")
      messages = Some(KafkaUtils.createDirectStream[String, String, StringDecoder, StringDecoder](
        streaming, kafkaParams, Set(topic)))

    } else {
      println("INSIDE_SECOND")
      messages = Some(KafkaUtils.createDirectStream[String, String, StringDecoder, StringDecoder, (String, String)](
        streaming, kafkaParams, topicsAndOffsets, (mmd: MessageAndMetadata[String, String]) => (mmd.key, mmd.message)))

    }
    //iterating through the stream
    messages.get.foreachRDD { rdd =>

      if (!rdd.isEmpty) {
        val offsetRanges = rdd.asInstanceOf[HasOffsetRanges].offsetRanges

        val nParts = rdd.partitions.size

        rdd.foreachPartition { sparkPartition =>

          if (!sparkPartition.isEmpty) {

            //kafka partition details
            val currid = TaskContext.get.partitionId
            val osr: OffsetRange = offsetRanges(currid)
            val untilOffset = osr.untilOffset //exclusive
            println("UNTILOFFSET--->>>>"+untilOffset)
            val id = osr.partition
            val topic = osr.topic
            logger.info("id --------->  " + id)
            println("id-------------->  " + id)
            val dt = ICMHelper.getNowFullN()

            //open up connections to the tables to update
            @transient val whwconf = HBaseConfiguration.create()
            whwconf.addResource(new Path("/etc/hbase/conf/hbase-site.xml"))
            whwconf.addResource(new Path("/etc/hadoop/conf/core-site.xml"))
            whwconf.set("hbase.client.retries.number", prop.getProperty("RETRIES"))

            val hCounter: HTable = new HTable(whwconf, prop.getProperty("HBASE_COUNTER_SG_TABLE"))
            val hTxs: HTable = new HTable(whwconf, prop.getProperty("HBASE_TOT_PARSED"))

            sparkPartition.foreach { arr =>
              val sysdate = ICMHelper.ymdFn()

              // Remove unwanted XML11 characters
              val msg = ICMHelper.cleanXML(arr._2)
              var valid_xml = true
              var melem: Elem = null
              try {
                melem = scala.xml.XML.loadString(msg)
              } catch {
                case ex: Exception => {
                  ex.printStackTrace()
                  valid_xml = false
                }
              }

              if (valid_xml) {

                val loaddt = ICMHelper.getNowFull
                val tx = Message(melem)

                var countryprefix: String = null
                var countryxmlvalue: String = null
                var countrycheck: Boolean = false
                if (tx.values.contains("ns:messageSender:ns:countryCode#1#")) {
                  countryxmlvalue = tx.values.get("ns:messageSender:ns:countryCode#1#").get
                
                 if (countryxmlvalue == prop.getProperty("COUNTRY_CODE_SG")) {
                    countryprefix = prop.getProperty("PREFIX_ICM_SG")
                    countrycheck = true
                  }
                     /* if (countryxmlvalue == "HK") {
                    countryprefix = PREFIX_ICM_HK
                    countrycheck = true
                  }*/
              
                  if (countrycheck) {
                    println("C : " + countryxmlvalue + " P  : " + tx.values.get("cust:ProfileUniqueId:cust:profileID#1#").get + "  R  : " + tx.values.get("cust:ProfileUniqueId:cust:relationshipID#1#").get + " M  : " + tx.values.get("cust:ProfileUniqueId:cust:messageSequenceNumber#1#").get)

                    val hbasemap_main = new java.util.HashMap[String, java.util.HashMap[String, Put]]()
                    val errormap_main = new java.util.HashMap[String, java.util.HashMap[String, java.util.ArrayList[DataCapture]]]()

                    //1 For CUSTOMER Profile table

                    try {

                      var count = 0;
                      if (tx.values.contains("cust:Profile:cust:operationMode")) {
                        count = tx.values.get("cust:Profile:cust:operationMode").get.toInt
                        count = count + 1;
                      }
                      val customerprofile = new com.scb.validation.CustomerProfile()
                      val hbasemap = new java.util.HashMap[String, Put]()
                      val errormap = new java.util.HashMap[String, java.util.ArrayList[DataCapture]]()
                      for (c <- 1 until count) {

                        val datamap = customerprofile.forCUSTOMERProfile()
                        val validationarray = customerprofile.validateCUSTOMERProfile(datamap, validation_property, tx, c)
                        if (validationarray.size == 0) {
                          val cust_profile = Message.convertToPut1(datamap, tx, c, loaddt)
                          cust_profile.addColumn(ICMHelper.default_b, Bytes.toBytes("date"), Bytes.toBytes(sysdate))
                          // hCustProfile.put(cust_profile)
                          hbasemap.put("hCustProfile" + c, cust_profile)
                        } else {

                          val cust_profile = Message.convertToPut(validationarray,tx)
                          errormap.put("hCustProfile" + c, cust_profile)
                        }

                      }
                      hbasemap_main.put("hCustProfile", hbasemap)
                      if (errormap.size != 0) {
                        errormap_main.put("hCustProfile", errormap)
                      }
                    } catch {
                      case e: Exception => {
                        println("cust profile - Exception while inserting data to hbase: " + e)
                        e.printStackTrace
                      }
                    }

                    try {

                      // 2 For  Customer Profile Business

                      var count = 0;
                      if (tx.values.contains("cust:BusinessProfile:cust:operationMode")) {
                        count = tx.values.get("cust:BusinessProfile:cust:operationMode").get.toInt
                        count = count + 1;
                      }
                      val customerprofile = new com.scb.validation.CustomerProfileBusiness()
                      val hbasemap = new java.util.HashMap[String, Put]()
                      val errormap = new java.util.HashMap[String, java.util.ArrayList[DataCapture]]()
                      for (c <- 1 until count) {

                        val datamap = customerprofile.forCUSTOMERProfile()
                        val validationarray = customerprofile.validateCUSTOMERProfile(datamap, validation_property, tx, c)
                        if (validationarray.size == 0) {
                          val cust_profile = Message.convertToPut1(datamap, tx, c, loaddt)
                          cust_profile.addColumn(ICMHelper.default_b, Bytes.toBytes("date"), Bytes.toBytes(sysdate))
                          // hCustProfile.put(cust_profile)
                          hbasemap.put("hCustProfileBus" + c, cust_profile)
                        } else {
                          val cust_profile = Message.convertToPut(validationarray,tx)
                          errormap.put("hCustProfileBus" + c, cust_profile)
                        }

                      }
                      hbasemap_main.put("hCustProfileBus", hbasemap)
                      if (errormap.size != 0) {
                        errormap_main.put("hCustProfileBus", errormap)
                      }

                    } catch {
                      case e: Exception => {
                        println("cust profile bus - Exception while inserting data to hbase: " + e)
                        e.printStackTrace
                      }
                    }

                    // 3 CDD Details

                    try {

                      var count = 0;
                      if (tx.values.contains("cust:CDDDetails:cust:operationMode")) {
                        count = tx.values.get("cust:CDDDetails:cust:operationMode").get.toInt
                        count = count + 1;
                      }
                      val ccddetails = new com.scb.validation.CDDDetails()
                      val hbasemap = new java.util.HashMap[String, Put]()
                      val errormap = new java.util.HashMap[String, java.util.ArrayList[DataCapture]]()
                      for (c <- 1 until count) {

                        val datamap = ccddetails.dataMapping()
                        val validationarray = ccddetails.validateRecods(datamap, validation_property, tx, c)
                        if (validationarray.size == 0) {
                          val msgput = Message.convertToPut(datamap, tx, c, loaddt)
                          msgput.addColumn(ICMHelper.default_b, Bytes.toBytes("date"), Bytes.toBytes(sysdate))
                          // hCustProfile.put(cust_profile)
                          hbasemap.put("hCustCDD" + c, msgput)
                        } else {
                          val cust_profile = Message.convertToPut(validationarray,tx)
                          errormap.put("hCustCDD" + c, cust_profile)
                        }

                      }
                      hbasemap_main.put("hCustCDD", hbasemap)
                      if (errormap.size != 0) {
                        errormap_main.put("hCustCDD", errormap)
                      }
                    } catch {
                      case e: Exception => {
                        println("cust address Exception while inserting data to hbase: " + e)
                        e.printStackTrace
                      }
                    }

                    // 4 Alias Information

                    try {

                      var count = 0;
                      if (tx.values.contains("cust:AliasInformation:cust:operationMode")) {
                        count = tx.values.get("cust:AliasInformation:cust:operationMode").get.toInt
                        count = count + 1;
                      }
                      val tableobj = new com.scb.validation.AliasInformation()
                      val hbasemap = new java.util.HashMap[String, Put]()
                      val errormap = new java.util.HashMap[String, java.util.ArrayList[DataCapture]]()
                      for (c <- 1 until count) {

                        val datamap = tableobj.dataMapping()
                        val validationarray = tableobj.validateRecods(datamap, validation_property, tx, c)
                        if (validationarray.size == 0) {
                          val msgput = Message.convertToPut(datamap, tx, c, loaddt)
                          msgput.addColumn(ICMHelper.default_b, Bytes.toBytes("date"), Bytes.toBytes(sysdate))
                          // hCustProfile.put(cust_profile)
                          hbasemap.put("hCustAlias" + c, msgput)
                        } else {
                          val cust_profile = Message.convertToPut(validationarray,tx)
                          errormap.put("hCustAlias" + c, cust_profile)
                        }

                      }
                      hbasemap_main.put("hCustAlias", hbasemap)
                      if (errormap.size != 0) {
                        errormap_main.put("hCustAlias", errormap)
                      }
                    } catch {
                      case e: Exception => {
                        println("cust alias Exception while inserting data to hbase: " + e)
                        e.printStackTrace
                      }
                    }

                    // 5 NationalityInformation

                    try {

                      var count = 0;
                      if (tx.values.contains("cust:NationalityInformation:cust:operationMode")) {
                        count = tx.values.get("cust:NationalityInformation:cust:operationMode").get.toInt
                        count = count + 1;
                      }

                      val tableobj = new com.scb.validation.NationalityInformation()
                      val hbasemap = new java.util.HashMap[String, Put]()
                      val errormap = new java.util.HashMap[String, java.util.ArrayList[DataCapture]]()
                      for (c <- 1 until count) {

                        val datamap = tableobj.dataMapping()
                        val validationarray = tableobj.validateRecods(datamap, validation_property, tx, c)
                        if (validationarray.size == 0) {
                          val msgput = Message.convertToPut(datamap, tx, c, loaddt)
                          msgput.addColumn(ICMHelper.default_b, Bytes.toBytes("date"), Bytes.toBytes(sysdate))
                          // hCustProfile.put(cust_profile)
                          hbasemap.put("hCustnations" + c, msgput)
                        } else {
                          val cust_profile = Message.convertToPut(validationarray,tx)
                          errormap.put("hCustnations" + c, cust_profile)
                        }

                      }
                      hbasemap_main.put("hCustnations", hbasemap)
                      if (errormap.size != 0) {
                        errormap_main.put("hCustnations", errormap)
                      }
                    } catch {
                      case e: Exception => {
                        println("cust nationality Exception while inserting data to hbase: " + e)
                        e.printStackTrace
                      }
                    }

                    // 6 AddressInformation----cust_address

                    try {

                      var count = 0;
                      if (tx.values.contains("cust:AddressInformation:cust:operationMode")) {
                        count = tx.values.get("cust:AddressInformation:cust:operationMode").get.toInt
                        count = count + 1;
                      }

                      val tableobj = new com.scb.validation.AddressInformation()
                      val hbasemap = new java.util.HashMap[String, Put]()
                      val errormap = new java.util.HashMap[String, java.util.ArrayList[DataCapture]]()
                      for (c <- 1 until count) {
                        // println("-------------------------cust addresss  ------------------------------" )
                        val datamap = tableobj.dataMapping()
                        val validationarray = tableobj.validateRecods(datamap, validation_property, tx, c)
                        if (validationarray.size == 0) {
                          val msgput = Message.convertToPut(datamap, tx, c, loaddt)
                          msgput.addColumn(ICMHelper.default_b, Bytes.toBytes("date"), Bytes.toBytes(sysdate))
                          // hCustProfile.put(cust_profile)
                          hbasemap.put("hCustaddress" + c, msgput)
                        } else {
                          val cust_profile = Message.convertToPut(validationarray,tx)
                          errormap.put("hCustaddress" + c, cust_profile)
                        }

                      }
                      hbasemap_main.put("hCustaddress", hbasemap)
                      if (errormap.size != 0) {
                        errormap_main.put("hCustaddress", errormap)
                      }
                    } catch {
                      case e: Exception => {
                        println("cust addresss Exception while inserting data to hbase: " + e)
                        e.printStackTrace
                      }
                    }

                    // 7 ContactInformation

                    try {

                      var count = 0;
                      if (tx.values.contains("cust:ContactInformation:cust:operationMode")) {
                        count = tx.values.get("cust:ContactInformation:cust:operationMode").get.toInt
                        count = count + 1;
                      }
                      val tableobj = new com.scb.validation.ContactInformation()
                      val hbasemap = new java.util.HashMap[String, Put]()
                      val errormap = new java.util.HashMap[String, java.util.ArrayList[DataCapture]]()
                      for (c <- 1 until count) {

                        val datamap = tableobj.dataMapping()
                        val validationarray = tableobj.validateRecods(datamap, validation_property, tx, c)
                        if (validationarray.size == 0) {
                          val msgput = Message.convertToPut(datamap, tx, c, loaddt)
                          msgput.addColumn(ICMHelper.default_b, Bytes.toBytes("date"), Bytes.toBytes(sysdate))
                          // hCustProfile.put(cust_profile)
                          hbasemap.put("hCustcontacts" + c, msgput)
                        } else {
                          val cust_profile = Message.convertToPut(validationarray,tx)
                          errormap.put("hCustcontacts" + c, cust_profile)
                        }

                      }
                      hbasemap_main.put("hCustcontacts", hbasemap)
                      if (errormap.size != 0) {
                        errormap_main.put("hCustcontacts", errormap)
                      }
                    } catch {
                      case e: Exception => {
                        println("cust contacts Exception while inserting data to hbase: " + e)
                        e.printStackTrace
                      }
                    }

                    // 8 DocumentInformation
                    try {

                      var count = 0;
                      if (tx.values.contains("cust:DocumentInformation:cust:operationMode")) {
                        count = tx.values.get("cust:DocumentInformation:cust:operationMode").get.toInt
                        count = count + 1;
                      }
                      val tableobj = new com.scb.validation.DocumentInformation()
                      val hbasemap = new java.util.HashMap[String, Put]()
                      val errormap = new java.util.HashMap[String, java.util.ArrayList[DataCapture]]()
                      for (c <- 1 until count) {

                        val datamap = tableobj.dataMapping()
                        val validationarray = tableobj.validateRecods(datamap, validation_property, tx, c)
                        if (validationarray.size == 0) {
                          val msgput = Message.convertToPut(datamap, tx, c, loaddt)
                          msgput.addColumn(ICMHelper.default_b, Bytes.toBytes("date"), Bytes.toBytes(sysdate))
                          // hCustProfile.put(cust_profile)
                          hbasemap.put("hCustdocs" + c, msgput)
                        } else {
                          val cust_profile = Message.convertToPut(validationarray,tx)
                          errormap.put("hCustdocs" + c, cust_profile)
                        }

                      }
                      hbasemap_main.put("hCustdocs", hbasemap)
                      if (errormap.size != 0) {
                        errormap_main.put("hCustdocs", errormap)
                      }
                    } catch {
                      case e: Exception => {
                        println("cust documents Exception while inserting data to hbase: " + e)
                        e.printStackTrace
                      }
                    }

                    // 9 EmploymentInformation------------Cust_employments

                    try {

                      var count = 0;
                      if (tx.values.contains("cust:EmploymentInformation:cust:operationMode")) {
                        count = tx.values.get("cust:EmploymentInformation:cust:operationMode").get.toInt
                        count = count + 1;
                      }
                      val tableobj = new com.scb.validation.CustEmployers()
                      val hbasemap = new java.util.HashMap[String, Put]()
                      val errormap = new java.util.HashMap[String, java.util.ArrayList[DataCapture]]()
                      for (c <- 1 until count) {

                        val datamap = tableobj.dataMapping()
                        val validationarray = tableobj.validateRecods(datamap, validation_property, tx, c)
                        if (validationarray.size == 0) {
                          val msgput = Message.convertToPut1(datamap, tx, c, loaddt)
                          msgput.addColumn(ICMHelper.default_b, Bytes.toBytes("date"), Bytes.toBytes(sysdate))
                          // hCustProfile.put(cust_profile)
                          hbasemap.put("hCustemploymns" + c, msgput)
                        } else {
                          val cust_profile = Message.convertToPut(validationarray,tx)
                          errormap.put("hCustemploymns" + c, cust_profile)
                        }

                      }
                      hbasemap_main.put("hCustemploymns", hbasemap)
                      if (errormap.size != 0) {
                        errormap_main.put("hCustemploymns", errormap)
                      }
                    } catch {
                      case e: Exception => {
                        println("cust employments Exception while inserting data to hbase: " + e)
                        e.printStackTrace
                      }
                    }

                    // 10 FatcaInformation------Cust_fatca_details
                    try {

                      var count = 0;
                      if (tx.values.contains("cust:FATCAInformation:cust:operationMode")) {
                        count = tx.values.get("cust:FATCAInformation:cust:operationMode").get.toInt
                        count = count + 1;
                      }

                      val tableobj = new com.scb.validation.CustFatcaDetails()
                      val hbasemap = new java.util.HashMap[String, Put]()
                      val errormap = new java.util.HashMap[String, java.util.ArrayList[DataCapture]]()
                      for (c <- 1 until count) {

                        val datamap = tableobj.dataMapping()
                        val validationarray = tableobj.validateRecods(datamap, validation_property, tx, c)
                        if (validationarray.size == 0) {
                          val msgput = Message.convertToPut(datamap, tx, c, loaddt)
                          msgput.addColumn(ICMHelper.default_b, Bytes.toBytes("date"), Bytes.toBytes(sysdate))
                          // hCustProfile.put(cust_profile)
                          hbasemap.put("hCustfatca" + c, msgput)
                        } else {
                          val cust_profile = Message.convertToPut(validationarray,tx)
                          errormap.put("hCustfatca" + c, cust_profile)
                        }

                      }
                      hbasemap_main.put("hCustfatca", hbasemap)
                      if (errormap.size != 0) {
                        errormap_main.put("hCustfatca", errormap)
                      }
                    } catch {
                      case e: Exception => {
                        println("cust fatca details Exception while inserting data to hbase: " + e)
                        e.printStackTrace
                      }
                    }

                    // 11 CustomerRiskReason
                    try {
                      var count = 0;
                      if (tx.values.contains("cust:RiskReason:cust:operationMode")) {
                        count = tx.values.get("cust:RiskReason:cust:operationMode").get.toInt
                        count = count + 1;
                      }

                      val tableobj = new com.scb.validation.CustRiskReasons()
                      val hbasemap = new java.util.HashMap[String, Put]()
                      val errormap = new java.util.HashMap[String, java.util.ArrayList[DataCapture]]()
                      for (c <- 1 until count) {

                        val datamap = tableobj.dataMapping()
                        val validationarray = tableobj.validateRecods(datamap, validation_property, tx, c)
                        if (validationarray.size == 0) {
                          val msgput = Message.convertToPut(datamap, tx, c, loaddt)
                          msgput.addColumn(ICMHelper.default_b, Bytes.toBytes("date"), Bytes.toBytes(sysdate))
                          // hCustProfile.put(cust_profile)
                          hbasemap.put("hCustrisk" + c, msgput)
                        } else {
                          val cust_profile = Message.convertToPut(validationarray,tx)
                          errormap.put("hCustrisk" + c, cust_profile)
                        }

                      }
                      hbasemap_main.put("hCustrisk", hbasemap)
                      if (errormap.size != 0) {
                        errormap_main.put("hCustrisk", errormap)
                      }
                    } catch {
                      case e: Exception => {
                        println("cust risk reasons Exception while inserting data to hbase: " + e)
                        e.printStackTrace
                      }
                    }

                    // 12 RelationshipLinks----CUST_LINKS
                    try {
                      var count = 0;
                      if (tx.values.contains("cust:RelationshipLinks:cust:operationMode")) {
                        count = tx.values.get("cust:RelationshipLinks:cust:operationMode").get.toInt
                        count = count + 1;
                      }

                      val tableobj = new com.scb.validation.CustLinks()
                      val hbasemap = new java.util.HashMap[String, Put]()
                      val errormap = new java.util.HashMap[String, java.util.ArrayList[DataCapture]]()
                      for (c <- 1 until count) {

                        val datamap = tableobj.dataMapping()
                        val validationarray = tableobj.validateRecods(datamap, validation_property, tx, c)
                        if (validationarray.size == 0) {
                          val msgput = Message.convertToPut(datamap, tx, c, loaddt)
                          msgput.addColumn(ICMHelper.default_b, Bytes.toBytes("date"), Bytes.toBytes(sysdate))
                          // hCustProfile.put(cust_profile)
                          hbasemap.put("hCustlinks" + c, msgput)
                        } else {
                          val cust_profile = Message.convertToPut(validationarray,tx)
                          errormap.put("hCustlinks" + c, cust_profile)
                        }

                      }
                      hbasemap_main.put("hCustlinks", hbasemap)
                      if (errormap.size != 0) {
                        errormap_main.put("hCustlinks", errormap)
                      }
                    } catch {
                      case e: Exception => {
                        println("cust relationship links Exception while inserting data to hbase: " + e)
                        e.printStackTrace
                      }
                    }

                    // 13 ExternalSystemReferenceInformation-------- Cust_ext_sys_references
                    try {
                      var count = 0;
                      if (tx.values.contains("cust:ExternalSystemReferenceInformation:cust:operationMode")) {
                        count = tx.values.get("cust:ExternalSystemReferenceInformation:cust:operationMode").get.toInt
                        count = count + 1;
                      }
                      val tableobj = new com.scb.validation.CustExtSysReferences()
                      val hbasemap = new java.util.HashMap[String, Put]()
                      val errormap = new java.util.HashMap[String, java.util.ArrayList[DataCapture]]()
                      for (c <- 1 until count) {

                        val datamap = tableobj.dataMapping()
                        val validationarray = tableobj.validateRecods(datamap, validation_property, tx, c)
                        if (validationarray.size == 0) {
                          val msgput = Message.convertToPut1(datamap, tx, c, loaddt)
                          msgput.addColumn(ICMHelper.default_b, Bytes.toBytes("date"), Bytes.toBytes(sysdate))
                          // hCustProfile.put(cust_profile)
                          hbasemap.put("hCustsysreferns" + c, msgput)
                        } else {
                          val cust_profile = Message.convertToPut(validationarray,tx)
                          errormap.put("hCustsysreferns" + c, cust_profile)
                        }

                      }
                      hbasemap_main.put("hCustsysreferns", hbasemap)
                      if (errormap.size != 0) {
                        errormap_main.put("hCustsysreferns", errormap)
                      }
                    } catch {
                      case e: Exception => {
                        println("cust external systemsreference Exception while inserting data to hbase: " + e)
                        e.printStackTrace
                      }
                    }

                    // 14 RelationshipRemarks--CustRemarks

                    try {
                      var count = 0;
                      if (tx.values.contains("cust:RelationshipRemarks:cust:operationMode")) {
                        count = tx.values.get("cust:RelationshipRemarks:cust:operationMode").get.toInt
                        count = count + 1;
                      }

                      val tableobj = new com.scb.validation.CustRemarks()
                      val hbasemap = new java.util.HashMap[String, Put]()
                      val errormap = new java.util.HashMap[String, java.util.ArrayList[DataCapture]]()
                      for (c <- 1 until count) {

                        val datamap = tableobj.dataMapping()
                        val validationarray = tableobj.validateRecods(datamap, validation_property, tx, c)
                        if (validationarray.size == 0) {
                          val msgput = Message.convertToPut(datamap, tx, c, loaddt)
                          msgput.addColumn(ICMHelper.default_b, Bytes.toBytes("date"), Bytes.toBytes(sysdate))
                          // hCustProfile.put(cust_profile)
                          hbasemap.put("hCustremarks" + c, msgput)
                        } else {
                          val cust_profile = Message.convertToPut(validationarray,tx)
                          errormap.put("hCustremarks" + c, cust_profile)
                        }

                      }
                      hbasemap_main.put("hCustremarks", hbasemap)
                      if (errormap.size != 0) {
                        errormap_main.put("hCustremarks", errormap)
                      }
                    } catch {
                      case e: Exception => {
                        println("cust relationship remarks Exception while inserting data to hbase: " + e)
                        e.printStackTrace
                      }
                    }

                    // 15 RiskIndicatorsDetails
                    try {
                      var count = 0;
                      if (tx.values.contains("cust:RiskIndicatorDetails:cust:operationMode")) {
                        count = tx.values.get("cust:RiskIndicatorDetails:cust:operationMode").get.toInt
                        count = count + 1;
                      }

                      val tableobj = new com.scb.validation.CustRiskIndicators()
                      val hbasemap = new java.util.HashMap[String, Put]()
                      val errormap = new java.util.HashMap[String, java.util.ArrayList[DataCapture]]()
                      for (c <- 1 until count) {

                        val datamap = tableobj.dataMapping()
                        val validationarray = tableobj.validateRecods(datamap, validation_property, tx, c)
                        if (validationarray.size == 0) {
                          val msgput = Message.convertToPut(datamap, tx, c, loaddt)
                          msgput.addColumn(ICMHelper.default_b, Bytes.toBytes("date"), Bytes.toBytes(sysdate))
                          // hCustProfile.put(cust_profile)
                          hbasemap.put("hCustriskindic" + c, msgput)
                        } else {
                          val cust_profile = Message.convertToPut(validationarray,tx)
                          errormap.put("hCustriskindic" + c, cust_profile)
                        }

                      }
                      hbasemap_main.put("hCustriskindic", hbasemap)
                      if (errormap.size != 0) {
                        errormap_main.put("hCustriskindic", errormap)
                      }
                    } catch {
                      case e: Exception => {
                        println("cust risk indicator Exception while inserting data to hbase: " + e)
                        e.printStackTrace
                      }
                    }

                    // 16 MISInformation Type ---CUST_INFO_DETAILS
                    try {
                      var count = 0;
                      if (tx.values.contains("cust:MISInformation:cust:operationMode")) {
                        count = tx.values.get("cust:MISInformation:cust:operationMode").get.toInt
                        count = count + 1;
                      }
                      val tableobj = new com.scb.validation.MISInformation()
                      val hbasemap = new java.util.HashMap[String, Put]()
                      val errormap = new java.util.HashMap[String, java.util.ArrayList[DataCapture]]()
                      for (c <- 1 until count) {

                        val datamap = tableobj.dataMapping()
                        val validationarray = tableobj.validateRecods(datamap, validation_property, tx, c)
                        if (validationarray.size == 0) {
                          val msgput = Message.convertToPut(datamap, tx, c, loaddt)
                          msgput.addColumn(ICMHelper.default_b, Bytes.toBytes("date"), Bytes.toBytes(sysdate))
                          // hCustProfile.put(cust_profile)
                          hbasemap.put("hCustdetails" + c, msgput)
                        } else {
                          val cust_profile = Message.convertToPut(validationarray,tx)
                          errormap.put("hCustdetails" + c, cust_profile)
                        }

                      }
                      hbasemap_main.put("hCustdetails", hbasemap)
                      if (errormap.size != 0) {
                        errormap_main.put("hCustdetails", errormap)
                      }
                    } catch {
                      case e: Exception => {
                        println("cust MIS Exception while inserting data to hbase: " + e)
                        e.printStackTrace
                      }
                    }

                    // 17 FatcaSI----CUST_SI_COUNTRIES
                    try {
                      var count = 0;
                      if (tx.values.contains("cust:SITOCountriesInformation:cust:operationMode")) {
                        count = tx.values.get("cust:SITOCountriesInformation:cust:operationMode").get.toInt
                        count = count + 1;
                      }
                      val tableobj = new com.scb.validation.CustSiCountries()
                      val hbasemap = new java.util.HashMap[String, Put]()
                      val errormap = new java.util.HashMap[String, java.util.ArrayList[DataCapture]]()
                      for (c <- 1 until count) {

                        val datamap = tableobj.dataMapping()
                        val validationarray = tableobj.validateRecods(datamap, validation_property, tx, c)
                        if (validationarray.size == 0) {
                          val msgput = Message.convertToPut(datamap, tx, c, loaddt)
                          msgput.addColumn(ICMHelper.default_b, Bytes.toBytes("date"), Bytes.toBytes(sysdate))
                          // hCustProfile.put(cust_profile)
                          hbasemap.put("hCustsicountry" + c, msgput)
                        } else {
                          val cust_profile = Message.convertToPut(validationarray,tx)
                          errormap.put("hCustsicountry" + c, cust_profile)
                        }

                      }
                      hbasemap_main.put("hCustsicountry", hbasemap)
                      if (errormap.size != 0) {
                        errormap_main.put("hCustsicountry", errormap)
                      }
                    } catch {
                      case e: Exception => {
                        println("cust FatCaSI Exception while inserting data to hbase: " + e)
                        e.printStackTrace
                      }
                    }
                    // 18 CustomerChoiceInfo----CUST_DND

                    try {
                      var count = 0;
                      if (tx.values.contains("cust:CustomerChoiceInfo:cust:choiceQuestionSequence")) {
                       // println("count top 1: " + count )
                        count=tx.values.get("cust:CustomerChoiceInfo:cust:choiceQuestionSequence").get.toInt
                        //println("count top 2: " + count )
                        count = count + 1;
                      }
                      val tableobj = new com.scb.validation.Custdnd()
                      val hbasemap = new java.util.HashMap[String, Put]()
                      val errormap = new java.util.HashMap[String, java.util.ArrayList[DataCapture]]()

                      for (c <- 1 until count) {
                        //println("count : " + count + " c : " + c)
                        val datamap = tableobj.dataMapping()
                        val validationarray = tableobj.validateRecods(datamap, validation_property, tx, c)
                        if (validationarray.size == 0) {
                          val msgput = Message.convertToPut(datamap, tx, c, loaddt)
                          msgput.addColumn(ICMHelper.default_b, Bytes.toBytes("date"), Bytes.toBytes(sysdate))
                          // hCustProfile.put(cust_profile)
                          hbasemap.put("hCustdnd" + c, msgput)
                        } else {
                          val cust_profile = Message.convertToPut(validationarray,tx)
                          errormap.put("hCustdnd" + c, cust_profile)
                        }

                      }
                      hbasemap_main.put("hCustdnd", hbasemap)
                      if (errormap.size != 0) {
                        errormap_main.put("hCustdnd", errormap)
                      }
                    } catch {
                      case e: Exception => {
                        println("cust CustDND Exception while inserting data to hbase: " + e)
                        e.printStackTrace
                      }
                    }
                    
                  // 19 Cust_Cucos Table  
                    // Cust_CUCOS
                    try {
                      var count = 0;
                      if(tx.values.contains("cust:CUCODetails:cust:CUCOFlag")) {
                       count = tx.values.get("cust:CUCODetails:cust:CUCOFlag").get.toInt
                       count = count + 1;
                      }
                      val custCuco = new com.scb.validation.CUCODetails()
                      val hbasemap = new java.util.HashMap[String, Put]()
                      val errormap = new java.util.HashMap[String, java.util.ArrayList[DataCapture]]()
                      
                      for (c <- 1 until count) {
                        val datamap = custCuco.dataMapping()
                        val validationarray = custCuco.validateRecods(datamap, validation_property, tx, c)
                        if (validationarray.size == 0) {
                          val msgput = Message.convertToPut(datamap, tx, c, loaddt)
                          msgput.addColumn(ICMHelper.default_b, Bytes.toBytes("date"), Bytes.toBytes(sysdate))
                          hbasemap.put("hCustcucos" + c, msgput)
                        } else {
                          val cust_profile = Message.convertToPut(validationarray,tx)
                          errormap.put("hCustcucos" + c, cust_profile)
                        }
                        
                      }
                       hbasemap_main.put("hCustcucos", hbasemap)
                      if (errormap.size != 0) {
                        errormap_main.put("hCustcucos", errormap)
                      }

                    }
                    catch {
                      case e: Exception => {
                        println("cust CustCucos Exception while inserting data to hbase: " + e)
                        e.printStackTrace
                      }
                    }

                    hTxs.incrementColumnValue(Bytes.toBytes(sysdate), ICMHelper.default_b, Bytes.toBytes(countryprefix + prop.getProperty("COL_TOT")), 1)

                    val dataoperations = new com.scb.icm.hbase.DataOperations()
                    val savedatab = dataoperations.saveData(whwconf, countryprefix, prop, errormap_main, hbasemap_main)
                    //------------Add Data to Hbase tables Start------------------------------

                    //------------Add Data to Hbase tables Start------------------------------

                  } else {
                    println("Unknown Country code found")
                  }

                } //end of if, country code check
                else {
                  println("No country code found in the messsage")
                }

                //end of valid xml                
              }
              //end of foreach message
            }
            // Commit offset to partition counter table
            val cPut = new Put(Bytes.toBytes(id))
            cPut.addColumn(ICMHelper.default_b, Bytes.toBytes(prop.getProperty("HBASE_COL_COUNTER_KPART")), Bytes.toBytes(id))
            cPut.addColumn(ICMHelper.default_b, Bytes.toBytes(prop.getProperty("HBASE_COL_COUNTER_TOP")), Bytes.toBytes(topic))
            cPut.addColumn(ICMHelper.default_b, Bytes.toBytes(prop.getProperty("HBASE_COL_COUNTER_NEXT")), Bytes.toBytes(untilOffset))
            hCounter.put(cPut) //ioexception

            try {
              hCounter.close
              hTxs.close
            } catch {
              case e: Exception => {
                println("Exception in closing connection to kafka topic counter: " + e)
                e.printStackTrace
              }
            }

            //end of if, sparkPartition not empty
          }
          //end of foreachPartitionS
        }
        //end of if, rdd not empty
      }
      //end of first foreachRDD
    }

    //    sys.ShutdownHookThread {
    //      println("Gracefully stopping ICM message " + topic)
    //      streaming.stop(true, true)
    //      println("ICM msg app stopped")
    //    }

    //end of the code
    streaming
  }

}