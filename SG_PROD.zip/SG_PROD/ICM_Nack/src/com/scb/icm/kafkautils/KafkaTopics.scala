package com.scb.icm.kafkautils

import java.util.Properties

import scala.util.Random

import com.scb.icm.ICMHelper

import kafka.producer.KeyedMessage
import kafka.producer.Producer
import kafka.producer.ProducerConfig
import kafka.serializer.StringEncoder

class KafkaTopics(brokers: String) //extends Serializable  
{

  private val random = new Random
  private val props = new Properties()
  props.put("metadata.broker.list", brokers)
  props.put("serializer.class", classOf[StringEncoder].getCanonicalName)
  props.put("partitioner.class", classOf[SimplePartitioner].getCanonicalName)
  props.put("message.send.max.retries", "10")
  props.put("retry.backoff.ms", "1000")

  val producer = new Producer[String, String](new ProducerConfig(props))

  def sendText(topic: String, txt: String, key: String) = {
    //System.out.println(ICMHelper.getDateFull() + " Posting to kafka topic " + topic + " with key: " + key)
    producer.send(new KeyedMessage[String, String](topic, key, txt))
  }

  def close() {
    try {
      producer.close()
    } catch {
      case e: Exception => {
        println("Exception : " + e)
        e.printStackTrace
      }
    }
  }
}
