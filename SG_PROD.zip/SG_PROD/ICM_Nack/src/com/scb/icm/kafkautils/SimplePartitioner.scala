package com.scb.icm.kafkautils

import kafka.producer.Partitioner
import kafka.utils.VerifiableProperties

class SimplePartitioner(props: VerifiableProperties) extends Partitioner //with  Serializable
{

  def partition(key: Any, numPartitions: Int): Int = {
    return key.hashCode().abs % numPartitions;
  }
}