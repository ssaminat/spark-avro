package com.scb.icm

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date

import scala.collection.Seq
import org.apache.hadoop.hbase.util.Bytes
import com.scb.icm.Constants.HBASE_DEFAULT_CF

object ICMHelper {
  final val default_b = Bytes.toBytes(HBASE_DEFAULT_CF)

  private val datef = new SimpleDateFormat("yyyy-MM-dd")
  private val timef = new SimpleDateFormat("HH:mm:ss")
  private val sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")
  private val weekFormat = new SimpleDateFormat("wwyyyy")
  final val xml11pattern = "[^\u0001-\uD7FF\uE000-\uFFFD\ud800\udc00-\udbff\udfff]+"
  final val replacementChar = " "

  def getNow(): (String, String) = {
    val today = Calendar.getInstance.getTime
    (datef.format(today), timef.format(today))
  }

  def getDateFull(): String = {
    getDateFull(Calendar.getInstance.getTime)
  }

  def getDateFull(d: Date): String = {
    sdf.format(d)
  }

  def getDate(d: String): Date = {
    sdf.parse(d)
  }

  def getBigDecimal(intPart: String, decPart: String)(): String = {
    "%s.%s".format(if (intPart.trim.isEmpty) "0" else intPart.trim, if (decPart.trim.isEmpty) "0" else decPart.trim)
  }

  def daily(tablename: String, ymd: String)(): String = {
    val ret = "%s_%s".format(tablename, ymd)
    ret
  }

  def y_m_dFn(): String = {
    datef.format(Calendar.getInstance.getTime)
  }

  def y_m_dFn(d: Date): String = {
    datef.format(d)
  }

  def getWeek(d: Date): String = {
    weekFormat.format(d)
  }

  def csvSplit(line: String): Seq[String] = {
    line.split(";(?=([^\"]*\"[^\"]*\")*[^\"]*$)", -1).map { x =>
      var y = x.trim
      // println(">>>>>>>>>>>"+y)
      if (y.startsWith("\"") && y.endsWith("\"")) {
        y = y.substring(1, y.length - 1)
      }
      y
    }
  }

  def boolToString(b: Boolean) = {
    if (b) "Yes" else "No"
  }
  def cleanXML(inp: String)(): String = {
    try {

      val repl =
        inp.replaceAll(ICMHelper.xml11pattern, replacementChar)

      repl
    } catch {
      case e: Exception => {
        println("Exception : " + e)
        inp
      }
    }
  }

  def toInt(v: String): Int = {
    try { v.toInt } catch { case e: Exception => return 0 }
  }

  def toDouble(v: String): Double = {
    try { v.toDouble } catch { case e: Exception => return 0 }
  }

  def ymdhmFn(): String = {
    val datef = new SimpleDateFormat("yyyyMMddHHmm")
    retDate(datef)
  }

  def ymdFn(): String = {
    val datef = new SimpleDateFormat("yyyy-MM-dd")
    retDate(datef)
  }

  def retDate(f: SimpleDateFormat): String = {
    val today = Calendar.getInstance.getTime
    val ret = f.format(today)
    ret
  }
  def getNowFull(): String = {
    val sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")
    val today = Calendar.getInstance.getTime
    sdf.format(today)
  }
  def getNowFullN(): String = {
    val sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH-mm-ss")
    val today = Calendar.getInstance.getTime
    sdf.format(today)
  }
  def getRdate(): String = {
    var date = new java.util.Date()
    val dat = Long.MaxValue - date.getTime().toLong
    dat.toString()
  }
  
  def getDate(): String = {
    val sdf = new SimpleDateFormat("yyyy-MM-dd")
    val today = Calendar.getInstance.getTime
    sdf.format(today)
  }

}
