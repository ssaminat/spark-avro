package com.scb.icm.hbase
import org.apache.hadoop.hbase.HBaseConfiguration
import org.apache.hadoop.hbase.client.HTable
import org.apache.hadoop.hbase.client.Put
import java.util.Properties
import org.apache.log4j.Logger
import collection.JavaConversions._
import org.apache.hadoop.conf.Configuration
import com.scb.jms.MessageProcessing
import com.scb.jms.JmsOperation
import com.scb.icm.DataCapture
import org.apache.hadoop.hbase.client.Put
import org.apache.hadoop.hbase.util.Bytes

class DataOperations {

  def saveData(whwconf: Configuration, countryprefix: String, prop: Properties, errormap_main: java.util.HashMap[String, java.util.HashMap[String, java.util.ArrayList[com.scb.icm.DataCapture]]], hbasemap_main: java.util.HashMap[String, java.util.HashMap[String, Put]]): Boolean = {

    val hCustProfile: HTable = new HTable(whwconf, countryprefix + prop.getProperty("HBASE_CUST_PROFILES"))
    val hCustProfileBus: HTable = new HTable(whwconf, countryprefix + prop.getProperty("HBASE_CUST_PROFILE_BUSINESS"))
    val hCustCDD: HTable = new HTable(whwconf, countryprefix + prop.getProperty("HBASE_CUST_CDD_DETAILS"))
    val hCustriskindic: HTable = new HTable(whwconf, countryprefix + prop.getProperty("HBASE_CUST_RISK_INDICATORS"))
    val hCustAlias: HTable = new HTable(whwconf, countryprefix + prop.getProperty("HBASE_CUST_ALIAS"))
    val hCustnations: HTable = new HTable(whwconf, countryprefix + prop.getProperty("HBASE_CUST_NATIONS"))
    val hCustaddress: HTable = new HTable(whwconf, countryprefix + prop.getProperty("HBASE_CUST_ADDRESS"))
    val hCustcontacts: HTable = new HTable(whwconf, countryprefix + prop.getProperty("HBASE_CUST_CONTACTS"))
    val hCustdocs: HTable = new HTable(whwconf, countryprefix + prop.getProperty("HBASE_CUST_DOCUMENTS"))
    val hCustemploymns: HTable = new HTable(whwconf, countryprefix + prop.getProperty("HBASE_CUST_EMPLOYMENTS"))
    val hCustfatca: HTable = new HTable(whwconf, countryprefix + prop.getProperty("HBASE_CUST_FATCA_DETAILS"))
    val hCustrisk: HTable = new HTable(whwconf, countryprefix + prop.getProperty("HBASE_CUST_RISK_REASONS"))
    val hCustdetails: HTable = new HTable(whwconf, countryprefix + prop.getProperty("HBASE_CUST_INFO_DETAILS"))
    val hCustlinks: HTable = new HTable(whwconf, countryprefix + prop.getProperty("HBASE_CUST_LINKS"))
    val hCustreferns: HTable = new HTable(whwconf, countryprefix + prop.getProperty("HBASE_CUST_PRODUCT_REFERENCES"))
    val hCustsysreferns: HTable = new HTable(whwconf, countryprefix + prop.getProperty("HBASE_CUST_EXT_SYS_REFERENCES"))
    val hCustremarks: HTable = new HTable(whwconf, countryprefix + prop.getProperty("HBASE_CUST_REMARKS"))
    val hCustsicountry: HTable = new HTable(whwconf, countryprefix + prop.getProperty("HBASE_CUST_SI_COUNTRIES"))
    //val hCustmlprofiles: HTable = new HTable(whwconf, countryprefix + prop.getProperty("HBASE_CUST_ML_PROFILES"))
    //val hCustmlalias: HTable = new HTable(whwconf, countryprefix + prop.getProperty("HBASE_CUST_ML_ALIAS"))
    //val hCustmladdress: HTable = new HTable(whwconf, countryprefix + prop.getProperty("HBASE_CUST_ML_ADDRESS"))
    val hCustcucos: HTable = new HTable(whwconf, countryprefix + prop.getProperty("HBASE_CUST_CUCOS"))
    val hCustvalidation: HTable = new HTable(whwconf, countryprefix + prop.getProperty("HBASE_VALIDATION_ERROR"))
    val hCustdnd: HTable = new HTable(whwconf, countryprefix + prop.getProperty("HBASE_CUST_DND"))
    
    val hValidation : HTable = new HTable(whwconf, countryprefix + prop.getProperty("HBASE_SG_VALIDATION"))


    println("errormap_main size ------------------> " + errormap_main.size)
    if (errormap_main.size == 0) {
      //1
      try {
        for ((k, data) <- hbasemap_main.get("hCustProfile")) {
          hCustProfile.put(data)
        }
      } catch {
        case e: Exception => {
          println("hCustProfile no data ")
        }
      }
      //2
      try {
        for ((k, data) <- hbasemap_main.get("hCustProfileBus")) {
          hCustProfileBus.put(data)
        }
      } catch {
        case e: Exception => {
          println("hCustProfileBus no data ")
        }
      }
      //3
      try {

        for ((k, data) <- hbasemap_main.get("hCustCDD")) {
          hCustCDD.put(data)
        }
      } catch {
        case e: Exception => {
          println("hCustCDD no data ")
        }
      }
      //4
      try {

        for ((k, data) <- hbasemap_main.get("hCustAlias")) {
          hCustAlias.put(data)
        }
      } catch {
        case e: Exception => {
          println("hCustAlias no data ")
        }
      }
      //5
      try {

        for ((k, data) <- hbasemap_main.get("hCustnations")) {
          hCustnations.put(data)
        }
      } catch {
        case e: Exception => {
          println("hCustnations no data ")
        }
      }
      //6
      try {

        for ((k, data) <- hbasemap_main.get("hCustaddress")) {
          hCustaddress.put(data)
        }
      } catch {
        case e: Exception => {
          println("hCustaddress no data ")
        }
      }
      //7
      try {

        for ((k, data) <- hbasemap_main.get("hCustcontacts")) {
          hCustcontacts.put(data)
        }
      } catch {
        case e: Exception => {
          println("hCustcontacts no data ")
        }
      }
      //8
      try {

        for ((k, data) <- hbasemap_main.get("hCustdocs")) {
          hCustdocs.put(data)
        }
      } catch {
        case e: Exception => {
          println("hCustdocs no data ")
        }
      }
      //9
      try {

        for ((k, data) <- hbasemap_main.get("hCustemploymns")) {
          hCustemploymns.put(data)
        }
      } catch {
        case e: Exception => {
          println("hCustemploymns no data ")
        }
      }
      //10
      try {

        for ((k, data) <- hbasemap_main.get("hCustfatca")) {
          hCustfatca.put(data)
        }
      } catch {
        case e: Exception => {
          println("hCustfatca no data ")
        }
      }
      //11
      try {

        for ((k, data) <- hbasemap_main.get("hCustrisk")) {
          hCustrisk.put(data)
        }
      } catch {
        case e: Exception => {
          println("hCustrisk no data ")
        }
      }
      //12
      try {

        for ((k, data) <- hbasemap_main.get("hCustlinks")) {
          hCustlinks.put(data)
        }
      } catch {
        case e: Exception => {
          println("hCustlinks no data ")
        }
      }

      //13
      try {

        for ((k, data) <- hbasemap_main.get("hCustsysreferns")) {
          hCustsysreferns.put(data)
        }
      } catch {
        case e: Exception => {
          println("hCustsysreferns no data ")
        }
      }
      //14

      try {

        for ((k, data) <- hbasemap_main.get("hCustremarks")) {
          hCustremarks.put(data)
        }
      } catch {
        case e: Exception => {
          println("hCustremarks no data ")
        }
      }
      //15
      try {

        for ((k, data) <- hbasemap_main.get("hCustriskindic")) {
          hCustriskindic.put(data)
        }
      } catch {
        case e: Exception => {
          println("hCustriskindic no data ")
        }
      }
      //16
      try {

        for ((k, data) <- hbasemap_main.get("hCustdetails")) {
          hCustdetails.put(data)
        }
      } catch {
        case e: Exception => {
          println("hCustdetails no data ")
        }
      }
      //17
      try {

        for ((k, data) <- hbasemap_main.get("hCustsicountry")) {
          hCustsicountry.put(data)
        }
      } catch {
        case e: Exception => {
          println("hCustsicountry no data ")
        }
      }

      //18
      try {
        for ((k, data) <- hbasemap_main.get("hCustdnd")) {
          hCustdnd.put(data)
        }
      } catch {
        case e: Exception => {
          println("hCustdnd no data ")
        }
      }
      // 19
      
      try {

        for ((k, data) <- hbasemap_main.get("hCustcucos")) {
          hCustcucos.put(data)
        }
      } catch {
        case e: Exception => {
          println("problem in hCustcucos loading")
        }
      }
    } 
   
    else {
      
      val vdate = com.scb.icm.ICMHelper.getDate()
      var message = ""
      for ((k, data) <- errormap_main) {
        for ((ki, data1) <- data) {
          for (dd <- data1) {
            message += MessageProcessing.createMessage(dd.countrycode, dd.trackingId, dd.error_type, dd.profileID, dd.relationshipID, dd.messageSequenceNumber, dd.column, dd.data)
           
           // Table added for get error profile id's
           val putValidate = new Put(Bytes.toBytes(dd.profileID+"_"+dd.trackingId+"_"+dd.messageSequenceNumber))
           putValidate.addColumn(Bytes.toBytes((prop.getProperty("HBASE_DEFAULT_CF"))), Bytes.toBytes("profile_id"), Bytes.toBytes(dd.profileID))
           putValidate.addColumn(Bytes.toBytes((prop.getProperty("HBASE_DEFAULT_CF"))), Bytes.toBytes("track_id"), Bytes.toBytes(dd.trackingId))
           putValidate.addColumn(Bytes.toBytes((prop.getProperty("HBASE_DEFAULT_CF"))), Bytes.toBytes("date"), Bytes.toBytes(vdate))
           putValidate.addColumn(Bytes.toBytes((prop.getProperty("HBASE_DEFAULT_CF"))), Bytes.toBytes("error_type"), Bytes.toBytes(dd.error_type))
           putValidate.addColumn(Bytes.toBytes((prop.getProperty("HBASE_DEFAULT_CF"))), Bytes.toBytes("column_name"), Bytes.toBytes(dd.column))
           hValidation.put(putValidate)
          }
        }
      }

      val xmlmess = MessageProcessing.loadXML(prop, message)
      val date = com.scb.icm.ICMHelper.getRdate
      val putObj = new Put(Bytes.toBytes(date))
      val jmsoperation = new JmsOperation()
      println("Error in XML----->Pushing to EDMi jms queue")
      jmsoperation.sendMessage(prop, message)
      putObj.addColumn(Bytes.toBytes(prop.getProperty("HBASE_DEFAULT_CF")), Bytes.toBytes("xml"), Bytes.toBytes(message))
      //hCustvalidation.put(putObj)

     // println(xmlmess)
    }
    true
  }

}