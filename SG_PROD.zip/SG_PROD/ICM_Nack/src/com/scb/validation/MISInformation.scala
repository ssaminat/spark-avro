package com.scb.validation

import java.util.Properties
import org.apache.log4j.Logger
import collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer
import com.scb.icm.Message

class MISInformation {
  def dataMapping(): java.util.HashMap[String, String] = {
    val map = new java.util.HashMap[String, String]()
    map.put("operationMode", "cust:MISInformation:cust:operationMode")
    map.put("infoCd", "cust:MISInformation:cust:infoCd")
    map.put("seqNo", "cust:MISInformation:cust:seqNo")
    map.put("infoVal", "cust:MISInformation:cust:infoVal")
    map.put("profileID", "cust:ProfileUniqueId:cust:profileID")
    map.put("relationshipID", "cust:ProfileUniqueId:cust:relationshipID")
    map.put("messageSequenceNumber", "cust:ProfileUniqueId:cust:messageSequenceNumber")
    map.put("countryCode", "ns:messageSender:ns:countryCode")
    map.put("messageTimestamp", "ns:originationDetails:ns:messageTimestamp")
    map
  }

  def validateRecods(datama: java.util.HashMap[String, String], validation_property: Properties, tx: Message, count: Integer): ArrayBuffer[ForError] = {
    val util = new Util()
    var error = ArrayBuffer[ForError]()
    val profileID = tx.values.get(datama.get("profileID") + "#1#").get
    val relationshipID = tx.values.get(datama.get("relationshipID") + "#1#").get
    val messageSequenceNumber = tx.values.get(datama.get("messageSequenceNumber") + "#1#").get
    val tablename = "MISInformation"
    //1
    if (tx.values.contains(datama.get("infoCd") + "#" + count + "#")) {
      val countryCode = tx.values.get(datama.get("infoCd") + "#" + count + "#").get
      val status = util.checkDataLength(countryCode, validation_property.getProperty("INFO_TYPE_CODE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, countryCode, "infoCd", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //2
    if (tx.values.contains(datama.get("seqNo") + "#" + count + "#")) {
      val countryCode = tx.values.get(datama.get("seqNo") + "#" + count + "#").get
      val status = util.checkDataLength(countryCode, validation_property.getProperty("SEQUENCE_NUMBER"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, countryCode, "seqNo", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //3
    if (tx.values.contains(datama.get("infoVal") + "#" + count + "#")) {
      val countryCode = tx.values.get(datama.get("infoVal") + "#" + count + "#").get
      val status = util.checkDataLength(countryCode, validation_property.getProperty("INFO_CODE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, countryCode, "infoVal", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }

    error
  }
}