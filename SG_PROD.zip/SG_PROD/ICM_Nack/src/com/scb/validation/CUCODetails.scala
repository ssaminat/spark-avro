package com.scb.validation

import java.util.Properties
import org.apache.log4j.Logger
import collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer
import com.scb.icm.Message


class CUCODetails {
  
 /* <cust:CUCODetails>
          <cust:CUCOFlag forModify="true">Y</cust:CUCOFlag>
          <cust:dyingICMId forModify="true">4580000000151604</cust:dyingICMId>
          <cust:dyingRelationshipId forModify="true">0410000000024200</cust:dyingRelationshipId>
          <cust:CUCOReason forModify="true">CUSID</cust:CUCOReason>
          <cust:CUCOComment forModify="true">ASMY/BRANCH/JOH/21062017/26</cust:CUCOComment>
    </cust:CUCODetails> */
  
  def dataMapping(): java.util.HashMap[String, String] = {
    val map = new java.util.HashMap[String, String]()
    map.put("dyingICMId", "cust:CUCODetails:cust:dyingICMId")
    map.put("CUCOFlag","cust:CUCODetails:cust:CUCOFlag")
    map.put("dyingRelationshipId", "cust:CUCODetails:cust:dyingRelationshipId")
    map.put("CUCOReason", "cust:CUCODetails:cust:CUCOReason")
    map.put("CUCOComment","cust:CUCODetails:cust:CUCOComment")
    map.put("combineDate","cust:CUCODetails:cust:combineDate")
    map.put("makerBranch","cust:CUCODetails:cust:makerBranch")
    map.put("makerTimeStamp","cust:CUCODetails:cust:makerTimeStamp")
    map.put("makerId","cust:CUCODetails:cust:makerId")
    map.put("makerIpAddress","cust:CUCODetails:cust:makerIpAddress")
    map.put("checkerBranch","cust:CUCODetails:cust:checkerBranch")
    map.put("checkerIpAddress","cust:CUCODetails:cust:checkerIpAddress")
    map.put("checkerTimeStamp","cust:CUCODetails:cust:checkerTimeStamp")
    map.put("checkerId","cust:CUCODetails:cust:checkerId")
    map.put("profileID", "cust:ProfileUniqueId:cust:profileID")
    map.put("relationshipID", "cust:ProfileUniqueId:cust:relationshipID")
    map.put("messageSequenceNumber", "cust:ProfileUniqueId:cust:messageSequenceNumber")
    map.put("countryCode", "ns:messageSender:ns:countryCode")
    map.put("messageTimestamp", "ns:originationDetails:ns:messageTimestamp")
    map
  }
  
 def validateRecods(datama: java.util.HashMap[String, String], validation_property: Properties, tx: Message, count: Integer): ArrayBuffer[ForError] = {
    val util = new Util()
    var error = ArrayBuffer[ForError]()
     val profileID = tx.values.get(datama.get("profileID") + "#1#").get
    val relationshipID = tx.values.get(datama.get("relationshipID") + "#1#").get
    val messageSequenceNumber = tx.values.get(datama.get("messageSequenceNumber") + "#1#").get
    val tablename = "CustCucos"
    
    if (tx.values.contains(datama.get("CUCOFlag") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("CUCOFlag") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("CUCO_FLAG"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "CUCOFlag", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    
    if (tx.values.contains(datama.get("dyingICMId") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("dyingICMId") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("DYING_ICM_ID"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "dyingICMId", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    
    if (tx.values.contains(datama.get("dyingRelationshipId") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("dyingRelationshipId") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("DYING_RELATIONSHIP_ID"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "dyingRelationshipId", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    
    if (tx.values.contains(datama.get("CUCOReason") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("CUCOReason") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("CUCO_REASON"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "CUCOReason", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    
    if (tx.values.contains(datama.get("CUCOComment") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("CUCOComment") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("CUCO_COMMENT"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "CUCOComment", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    
    return error
    
 }
  
}