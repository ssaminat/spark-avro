package com.scb.validation

import java.util.Properties
import org.apache.log4j.Logger
import collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer
import com.scb.icm.Message

class ContactInformation {
  def dataMapping(): java.util.HashMap[String, String] = {
    val map = new java.util.HashMap[String, String]()
    map.put("operationMode", "cust:ContactInformation:cust:operationMode")
    map.put("customerContactNumber", "cust:ContactInformation:cust:customerContactNumber")
    map.put("contactType", "cust:ContactInformation:cust:contactType")
    map.put("contactTypeClassification", "cust:ContactInformation:cust:contactTypeClassification")
    map.put("contactSequenceNo", "cust:ContactInformation:cust:contactSequenceNo")
    map.put("contactCountryCode", "cust:ContactInformation:cust:contactCountryCode")
    map.put("areaCode", "cust:ContactInformation:cust:areaCode")
    map.put("extensionNumber", "cust:ContactInformation:cust:extensionNumber")
    map.put("contactReference", "cust:ContactInformation:cust:contactReference")
    map.put("preferredContact", "cust:ContactInformation:cust:preferredContact")
    map.put("contactInvalidInd", "cust:ContactInformation:cust:contactInvalidInd")
    map.put("dndregistryInd", "cust:ContactInformation:cust:dndregistryInd")
    map.put("dndUpdateDate", "cust:ContactInformation:cust:dndUpdateDate")
    map.put("dndExpiryDate", "cust:ContactInformation:cust:dndExpiryDate")
    map.put("primaryContactidentifier", "cust:ContactInformation:cust:primaryContactidentifier")
    map.put("contactInd", "cust:ContactInformation:cust:contactInd")
    map.put("profileID", "cust:ProfileUniqueId:cust:profileID")
    map.put("relationshipID", "cust:ProfileUniqueId:cust:relationshipID")
    map.put("messageSequenceNumber", "cust:ProfileUniqueId:cust:messageSequenceNumber")
    map.put("countryCode", "ns:messageSender:ns:countryCode")
    map.put("messageTimestamp", "ns:originationDetails:ns:messageTimestamp")
    map
  }

  def validateRecods(datama: java.util.HashMap[String, String], validation_property: Properties, tx: Message, count: Integer): ArrayBuffer[ForError] = {
    val util = new Util()
    var error = ArrayBuffer[ForError]()
     val profileID = tx.values.get(datama.get("profileID") + "#1#").get
    val relationshipID = tx.values.get(datama.get("relationshipID") + "#1#").get
    val messageSequenceNumber = tx.values.get(datama.get("messageSequenceNumber") + "#1#").get
    val tablename = "ContactInformation"
    //1
    if (tx.values.contains(datama.get("contactTypeClassification") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("contactTypeClassification") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("CONTACT_CLASSIFICATION_CODE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "contactTypeClassification", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //2
    if (tx.values.contains(datama.get("contactSequenceNo") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("contactSequenceNo") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("SEQUENCE_NUMBER"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "contactSequenceNo", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //3
    if (tx.values.contains(datama.get("contactType") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("contactType") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("CONTACT_TYPE_CODE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "contactType", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //4
    if (tx.values.contains(datama.get("contactInd") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("contactInd") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("HOME_OFFICE_IND"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "contactInd", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //5
    if (tx.values.contains(datama.get("areaCode") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("areaCode") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("CONTACT_AREA_CODE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "areaCode", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }

    //6
    if (tx.values.contains(datama.get("contactReference") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("contactReference") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("CONTACT_REFERENCE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "contactReference", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //7
    if (tx.values.contains(datama.get("contactInvalidInd") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("contactInvalidInd") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("INVALID_INDICATOR"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "contactInvalidInd", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //8
    if (tx.values.contains(datama.get("dndregistryInd") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("dndregistryInd") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("DND_REGISTRY"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "dndregistryInd", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //9
    if (tx.values.contains(datama.get("dndUpdateDate") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("dndUpdateDate") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("DND_LAST_UPDATE_DATE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "dndUpdateDate", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //10
    if (tx.values.contains(datama.get("dndExpiryDate") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("dndExpiryDate") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("DND_EXPIRY_DATE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "dndExpiryDate", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //11
    if (tx.values.contains(datama.get("preferredContact") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("preferredContact") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("PREFERRED_CONTACT"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "preferredContact", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //12
    if (tx.values.contains(datama.get("primaryContactidentifier") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("primaryContactidentifier") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("PRIMARY_CONTACT"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "primaryContactidentifier", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //13
    if (tx.values.contains(datama.get("contactCountryCode") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("contactCountryCode") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("CONTACT_COUNTRY_CODE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "contactCountryCode", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //14
    if (tx.values.contains(datama.get("extensionNumber") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("extensionNumber") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("CONTACT_EXTENSION"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "extensionNumber", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //14
    if (tx.values.contains(datama.get("customerContactNumber") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("customerContactNumber") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("CONTACT_NUMBER"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "customerContactNumber", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    error
  }
}