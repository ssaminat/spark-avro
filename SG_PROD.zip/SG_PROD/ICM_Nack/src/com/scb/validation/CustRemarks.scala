package com.scb.validation

import java.util.Properties
import org.apache.log4j.Logger
import collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer
import com.scb.icm.Message

class CustRemarks {
  def dataMapping(): java.util.HashMap[String, String] = {
    val map = new java.util.HashMap[String, String]()
    map.put("operationMode", "cust:RelationshipRemarks:cust:operationMode")
    map.put("internalRemarkTypeCode", "cust:RelationshipRemarks:cust:internalRemarkTypeCode")
    map.put("sequenceNumber", "cust:RelationshipRemarks:cust:sequenceNumber")
    map.put("internalRemarkExpiryDate", "cust:RelationshipRemarks:cust:internalRemarkExpiryDate")
    map.put("internalRemarksDetails", "cust:RelationshipRemarks:cust:internalRemarksDetails")
    map.put("remarkDepartmentCode", "cust:RelationshipRemarks:cust:remarkDepartmentCode")
    map.put("profileID", "cust:ProfileUniqueId:cust:profileID")
    map.put("relationshipID", "cust:ProfileUniqueId:cust:relationshipID")
    map.put("messageSequenceNumber", "cust:ProfileUniqueId:cust:messageSequenceNumber")
    map.put("countryCode", "ns:messageSender:ns:countryCode")
    map.put("lastModifiedDate", "cust:RelationshipRemarks:cust:lastModifiedDate")
    map.put("reviewFlag", "cust:RelationshipRemarks:cust:reviewFlag")
    map.put("messageTimestamp", "ns:originationDetails:ns:messageTimestamp")
    map
  }

  def validateRecods(datama: java.util.HashMap[String, String], validation_property: Properties, tx: Message, count: Integer): ArrayBuffer[ForError] = {
    val util = new Util()
    var error = ArrayBuffer[ForError]()
     val profileID = tx.values.get(datama.get("profileID") + "#1#").get
    val relationshipID = tx.values.get(datama.get("relationshipID") + "#1#").get
    val messageSequenceNumber = tx.values.get(datama.get("messageSequenceNumber") + "#1#").get
    val tablename = "CustRemarks"
    //1
    if (tx.values.contains(datama.get("internalRemarkTypeCode") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("internalRemarkTypeCode") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("INTERNAL_REMARK_TYPE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "internalRemarkTypeCode", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //2
    if (tx.values.contains(datama.get("sequenceNumber") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("sequenceNumber") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("SEQUENCE_NUMBER"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "sequenceNumber", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //3
    if (tx.values.contains(datama.get("internalRemarkExpiryDate") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("internalRemarkExpiryDate") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("INTERNAL_REMARK_EXPIRY_DATE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "internalRemarkExpiryDate", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //4
    if (tx.values.contains(datama.get("internalRemarksDetails") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("internalRemarksDetails") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("INTERNAL_REMARK_DETAIL"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "internalRemarksDetails", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //5
    if (tx.values.contains(datama.get("remarkDepartmentCode") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("remarkDepartmentCode") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("REMARK_DEPARTMENT_CODE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "remarkDepartmentCode", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //6
    if (tx.values.contains(datama.get("lastModifiedDate") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("lastModifiedDate") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("LAST_MODIFIED_DATE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "lastModifiedDate", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //7
    if (tx.values.contains(datama.get("reviewFlag") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("reviewFlag") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("REVIEW_FLAG"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "reviewFlag", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }

    error
  }
}