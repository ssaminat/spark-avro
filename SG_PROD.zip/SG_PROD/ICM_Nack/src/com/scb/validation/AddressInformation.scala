package com.scb.validation

import java.util.Properties
import org.apache.log4j.Logger
import collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer
import com.scb.icm.Message

class AddressInformation {

  def dataMapping(): java.util.HashMap[String, String] = {
    val map = new java.util.HashMap[String, String]()
    map.put("operationMode", "cust:AddressInformation:cust:operationMode")
    map.put("customerAddressSequenceNumber", "cust:AddressInformation:cust:customerAddressSequenceNumber") // This missed in table def
    map.put("customerAddressLine1", "cust:AddressInformation:cust:customerAddressLine1")
    map.put("customerAddressLine2", "cust:AddressInformation:cust:customerAddressLine2")
    map.put("customerAddressLine3", "cust:AddressInformation:cust:customerAddressLine3")
    map.put("customerAddressType", "cust:AddressInformation:cust:customerAddressType")
    map.put("cityName", "cust:AddressInformation:cust:cityName")
    map.put("state", "cust:AddressInformation:cust:state")
    map.put("landMark", "cust:AddressInformation:cust:landMark")
    map.put("changeAddressInd", "cust:AddressInformation:cust:changeAddressInd")
    map.put("mailingAddressInd", "cust:AddressInformation:cust:mailingAddressInd")
    map.put("profileID", "cust:ProfileUniqueId:cust:profileID")
    map.put("relationshipID", "cust:ProfileUniqueId:cust:relationshipID")
    map.put("messageSequenceNumber", "cust:ProfileUniqueId:cust:messageSequenceNumber")
    map.put("addressClassification", "cust:AddressInformation:cust:addressClassification")
    map.put("country_code", "cust:AddressInformation:cust:countryCode")
    map.put("test_column", "cust:AddressInformation:cust:postalCode")
    map.put("postalCode", "cust:AddressInformation:cust:postalCode")
    map.put("customerAddressReturnInd", "cust:AddressInformation:cust:customerAddressReturnInd")
    map.put("messageTimestamp", "ns:originationDetails:ns:messageTimestamp")

    map
  }

  def validateRecods(datama: java.util.HashMap[String, String], validation_property: Properties, tx: Message, count: Integer): ArrayBuffer[ForError] = {
    val util = new Util()
    var error = ArrayBuffer[ForError]()

    val profileID = tx.values.get(datama.get("profileID") + "#1#").get
    val relationshipID = tx.values.get(datama.get("relationshipID") + "#1#").get
    val messageSequenceNumber = tx.values.get(datama.get("messageSequenceNumber") + "#1#").get
    val tablename = "AddressInformation"
    //1
    if (tx.values.contains(datama.get("customerAddressType") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("customerAddressType") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("ADDRESS_TYPE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "customerAddressType", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //2
    if (tx.values.contains(datama.get("customerAddressLine1") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("customerAddressLine1") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("ADDRESS_1"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "customerAddressLine1", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //3
    if (tx.values.contains(datama.get("customerAddressLine2") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("customerAddressLine2") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("ADDRESS_2"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "customerAddressLine2", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //4
    if (tx.values.contains(datama.get("customerAddressLine3") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("customerAddressLine3") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("ADDRESS_3"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "customerAddressLine3", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //5
    if (tx.values.contains(datama.get("landMark") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("landMark") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("NEAREST_LANDMARK"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "landMark", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //6
    if (tx.values.contains(datama.get("cityName") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("cityName") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("CITY_NAME"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "cityName", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }

    //7
    if (tx.values.contains(datama.get("state") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("state") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("STATE_NAME"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "state", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    } //8
    if (tx.values.contains(datama.get("countryCode1") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("countryCode1") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("COUNTRY_CODE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "countryCode1", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //9
    if (tx.values.contains(datama.get("postalCode") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("postalCode") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("POSTAL_CODE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "postalCode", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //10
    if (tx.values.contains(datama.get("customerAddressReturnInd") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("customerAddressReturnInd") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("WAU_FLAG"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "customerAddressReturnInd", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //11
    if (tx.values.contains(datama.get("mailingAddressInd") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("mailingAddressInd") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("MAIL_ADDR_IND"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "mailingAddressInd", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //12
    if (tx.values.contains(datama.get("addressClassification") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("addressClassification") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("ADDRESS_CLASSIFICATION"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "addressClassification", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }

    error
  }
}