package com.scb.validation

import java.util.Properties
import org.apache.log4j.Logger
import collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer
import com.scb.icm.Message

class CustExtSysReferences {
  def dataMapping(): java.util.HashMap[String, String] = {
    val map = new java.util.HashMap[String, String]()
    map.put("operationMode", "cust:ExternalSystemReferenceInformation:cust:operationMode")
    map.put("systemReferenceName", "cust:ExternalSystemReferenceInformation:cust:systemReferenceName")
    map.put("systemReferenceID", "cust:ExternalSystemReferenceInformation:cust:systemReferenceID")
    map.put("extSysReferenceRemarks", "cust:ExternalSystemReferenceInformation:cust:extSysReferenceRemarks")
    map.put("extSysReferenceStatus", "cust:ExternalSystemReferenceInformation:cust:extSysReferenceStatus")
    map.put("profileID", "cust:ProfileUniqueId:cust:profileID")
    map.put("relationshipID", "cust:ProfileUniqueId:cust:relationshipID")
    map.put("messageSequenceNumber", "cust:ProfileUniqueId:cust:messageSequenceNumber")
    map.put("countryCode", "ns:messageSender:ns:countryCode")
    map.put("messageTimestamp", "ns:originationDetails:ns:messageTimestamp")
    map.put("trackingId", "ns:originationDetails:ns:trackingId")
    map
  }

  def validateRecods(datama: java.util.HashMap[String, String], validation_property: Properties, tx: Message, count: Integer): ArrayBuffer[ForError] = {
    val util = new Util()
    var error = ArrayBuffer[ForError]()
    val profileID = tx.values.get(datama.get("profileID") + "#1#").get
    val relationshipID = tx.values.get(datama.get("relationshipID") + "#1#").get
    val messageSequenceNumber = tx.values.get(datama.get("messageSequenceNumber") + "#1#").get
    val tablename = "CustExtSysReferences"
    //1
    if (tx.values.contains(datama.get("systemReferenceID") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("systemReferenceID") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("EXT_SYS_REFERENCE_ID"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "systemReferenceID", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
     //2
    if (tx.values.contains(datama.get("systemReferenceName") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("systemReferenceName") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("EXT_SYS_REFERENCE_NAME"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "systemReferenceName", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
     //3
    if (tx.values.contains(datama.get("extSysReferenceStatus") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("extSysReferenceStatus") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("EXT_SYS_REFERENCE_STATUS"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "extSysReferenceStatus", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
     //4
    if (tx.values.contains(datama.get("extSysReferenceRemarks") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("extSysReferenceRemarks") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("EXT_SYS_REFERENCE_REMARKS"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "extSysReferenceRemarks", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }

    error
  }
}