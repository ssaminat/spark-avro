package com.scb.validation

import java.util.Properties
import org.apache.log4j.Logger
import collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer
import com.scb.icm.Message

class CustCucos {
  
  def dataMapping(): java.util.HashMap[String, String] = {
    val map = new java.util.HashMap[String, String]()
    map.put("CUCOFlag", "cust:CUCODetails:cust:CUCOFlag")
    map.put("dyingICMId", "cust:CUCODetails:cust:dyingICMId")
    map.put("dyingRelationshipId", "cust:CUCODetails:cust:dyingRelationshipId")
    map.put("CUCOReason", "cust:CUCODetails:cust:CUCOReason")
    map.put("CUCOComment","cust:CUCODetails:cust:CUCOComment")
    map.put("profileID", "cust:ProfileUniqueId:cust:profileID")
    map.put("relationshipID", "cust:ProfileUniqueId:cust:relationshipID")
    map.put("messageSequenceNumber", "cust:ProfileUniqueId:cust:messageSequenceNumber")
    map.put("countryCode", "ns:messageSender:ns:countryCode")
    map.put("messageTimestamp", "ns:originationDetails:ns:messageTimestamp")
    map.put("trackingId","ns:originationDetails:ns:trackingId")
    map
  }

}