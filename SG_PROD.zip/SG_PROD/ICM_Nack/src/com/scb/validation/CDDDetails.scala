package com.scb.validation

import java.util.Properties
import org.apache.log4j.Logger
import collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer
import com.scb.icm.Message

class CDDDetails {
  def dataMapping(): java.util.HashMap[String, String] = {
    val map = new java.util.HashMap[String, String]()
    map.put("operationMode", "cust:CDDDetails:cust:operationMode")
    map.put("cddRiskCode", "cust:CDDDetails:cust:cddRiskCode")
    map.put("cddLastReviewDate", "cust:CDDDetails:cust:cddLastReviewDate")
    map.put("cddNextReviewDate", "cust:CDDDetails:cust:cddNextReviewDate")
    map.put("customerCDDStatus", "cust:CDDDetails:cust:customerCDDStatus")
    map.put("cddReason", "cust:CDDDetails:cust:cddReason")
    map.put("sddEligibleStatus", "cust:CDDDetails:cust:sddEligibleStatus")
    map.put("sddEligibleDate", "cust:CDDDetails:cust:sddEligibleDate")
    map.put("cddRiskRatingDate", "cust:CDDDetails:cust:cddRiskRatingDate")
    map.put("profileID", "cust:ProfileUniqueId:cust:profileID")
    map.put("relationshipID", "cust:ProfileUniqueId:cust:relationshipID")
    map.put("messageSequenceNumber", "cust:ProfileUniqueId:cust:messageSequenceNumber")
    map.put("cddReviewedflag", "cust:CDDDetails:cust:cddReviewedflag")
    map.put("cddLastreviewedby", "cust:CDDDetails:cust:cddLastreviewedby")
    map.put("countryCode", "ns:messageSender:ns:countryCode")
    map.put("messageTimestamp", "ns:originationDetails:ns:messageTimestamp")
    map
  }

  def validateRecods(datama: java.util.HashMap[String, String], validation_property: Properties, tx: Message, count: Integer): ArrayBuffer[ForError] = {
    val util = new Util()
    var error = ArrayBuffer[ForError]()
     val profileID = tx.values.get(datama.get("profileID") + "#1#").get
    val relationshipID = tx.values.get(datama.get("relationshipID") + "#1#").get
    val messageSequenceNumber = tx.values.get(datama.get("messageSequenceNumber") + "#1#").get
    val tablename = "CDDDetails"
    //1
    if (tx.values.contains(datama.get("countryCode") + "#" + count + "#")) {
      val countryCode = tx.values.get(datama.get("countryCode") + "#" + count + "#").get
      val status = util.checkDataLength(countryCode, validation_property.getProperty("COMPANY_ID"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, countryCode, "countryCode", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //2
    if (tx.values.contains(datama.get("profileID") + "#" + count + "#")) {
      val profileID = tx.values.get(datama.get("profileID") + "#" + count + "#").get
      val status = util.checkDataLength(profileID, validation_property.getProperty("PROFILE_ID"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, profileID, "profileID", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //3
    if (tx.values.contains(datama.get("cddRiskCode") + "#" + count + "#")) {
      val cddRiskCode = tx.values.get(datama.get("cddRiskCode") + "#" + count + "#").get
      val status = util.checkDataLength(cddRiskCode, validation_property.getProperty("CDD_RISK_CODE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, cddRiskCode, "cddRiskCode", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //4
    if (tx.values.contains(datama.get("cddLastReviewDate") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("cddLastReviewDate") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("CDD_LAST_REVIEW_DATE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "cddLastReviewDate", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //5
   if (tx.values.contains(datama.get("cddNextReviewDate") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("cddNextReviewDate") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("CDD_NEXT_REVIEW_DATE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "cddNextReviewDate", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    
    //6
   if (tx.values.contains(datama.get("customerCDDStatus") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("customerCDDStatus") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("CDD_REVIEW_STATUS"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "customerCDDStatus", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }//7
    if (tx.values.contains(datama.get("sddEligibleStatus") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("sddEligibleStatus") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("SDD_ELIGIBLE_STATUS"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "sddEligibleStatus", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //8
   if (tx.values.contains(datama.get("sddEligibleDate") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("sddEligibleDate") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("SDD_ELIGIBLE_DATE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "sddEligibleDate", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //9
   if (tx.values.contains(datama.get("cddRiskRatingDate") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("cddRiskRatingDate") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("CDD_RISK_RATING_DATE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "cddRiskRatingDate", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //10
   if (tx.values.contains(datama.get("cddReviewedflag") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("cddReviewedflag") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("CDD_REVIEWED_FLAG"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "cddReviewedflag", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //11
   if (tx.values.contains(datama.get("cddLastreviewedby") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("cddLastreviewedby") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("CDD_LAST_REVIEWED_BY"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "cddLastreviewedby", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //12
   if (tx.values.contains(datama.get("cddReason") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("cddReason") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("CDD_REASON"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "cddReason", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    
   


    error
  }
}