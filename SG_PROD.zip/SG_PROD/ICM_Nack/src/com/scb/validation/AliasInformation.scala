package com.scb.validation

import java.util.Properties
import org.apache.log4j.Logger
import collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer
import com.scb.icm.Message

class AliasInformation {
  def dataMapping(): java.util.HashMap[String, String] = {
    val map = new java.util.HashMap[String, String]()
    map.put("operationMode", "cust:AliasInformation:cust:operationMode")
    map.put("aliasType", "cust:AliasInformation:cust:aliasType")
    map.put("aliasName", "cust:AliasInformation:cust:aliasName")
    map.put("sequenceNo", "cust:AliasInformation:cust:sequenceNo")
    map.put("profileID", "cust:ProfileUniqueId:cust:profileID")
    map.put("relationshipID", "cust:ProfileUniqueId:cust:relationshipID")
    map.put("messageSequenceNumber", "cust:ProfileUniqueId:cust:messageSequenceNumber")
    map.put("countryCode", "ns:messageSender:ns:countryCode")
    map.put("messageTimestamp", "ns:originationDetails:ns:messageTimestamp")
    map
  }

  def validateRecods(datama: java.util.HashMap[String, String], validation_property: Properties, tx: Message, count: Integer): ArrayBuffer[ForError] = {
    val util = new Util()
    var error = ArrayBuffer[ForError]()
    val profileID = tx.values.get(datama.get("profileID") + "#1#").get
    val relationshipID = tx.values.get(datama.get("relationshipID") + "#1#").get
    val messageSequenceNumber = tx.values.get(datama.get("messageSequenceNumber") + "#1#").get
    val tablename = "AliasInformation"
    //1
    if (tx.values.contains(datama.get("countryCode") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("countryCode") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("COMPANY_ID"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "countryCode", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //2
    if (tx.values.contains(datama.get("profileID") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("profileID") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("PROFILE_ID"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "profileID", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //3
    if (tx.values.contains(datama.get("aliasType") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("aliasType") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("ALIAS_TYPE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "aliasType", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //4
    if (tx.values.contains(datama.get("sequenceNo") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("sequenceNo") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("SEQUENCE_NUMBER"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "sequenceNo", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //5
    if (tx.values.contains(datama.get("aliasName") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("aliasName") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("ALIAS_NAME"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "aliasName", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }


    error
  }
}