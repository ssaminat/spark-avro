package com.scb.validation

import java.util.Properties
import org.apache.log4j.Logger
import collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer
import com.scb.icm.Message

class CustomerProfile {
  def forCUSTOMERProfile(): java.util.HashMap[String, String] = {
    val datamap = new java.util.HashMap[String, String]()
    datamap.put("operationMode", "cust:Profile:cust:operationMode")
    datamap.put("clientTypeInd", "cust:Profile:cust:clientTypeInd")
    datamap.put("customerSalutationCode", "cust:Profile:cust:customerSalutationCode")
    datamap.put("customerFirstName", "cust:Profile:cust:customerFirstName")
    datamap.put("customerMiddleName", "cust:Profile:cust:customerMiddleName")
    datamap.put("customerLastName", "cust:Profile:cust:customerLastName")
    datamap.put("customerFullName", "cust:Profile:cust:customerFullName")
    datamap.put("mothersMaidenName", "cust:Profile:cust:mothersMaidenName")
    datamap.put("customerGender", "cust:Profile:cust:customerGender")
    datamap.put("dateOfBirth", "cust:Profile:cust:dateOfBirth")
    datamap.put("countryOfBirth", "cust:Profile:cust:countryOfBirth")
    datamap.put("customerEducationalQualification", "cust:Profile:cust:customerEducationalQualification")
    datamap.put("customerMaritalStatus", "cust:Profile:cust:customerMaritalStatus")
    datamap.put("customersDependants", "cust:Profile:cust:customersDependants")
    datamap.put("preferredLanguage", "cust:Profile:cust:preferredLanguage")
    datamap.put("customerResidenceCountry", "cust:Profile:cust:customerResidenceCountry")
    datamap.put("customerResidentStatusIdentifier", "cust:Profile:cust:customerResidentStatusIdentifier")
    datamap.put("relationshipStatus", "cust:Profile:cust:relationshipStatus")
    datamap.put("activationDate", "cust:Profile:cust:activationDate")
    datamap.put("lastStatusUpdateDate", "cust:Profile:cust:lastStatusUpdateDate")
    datamap.put("relationshipClosedReasonCode", "cust:Profile:cust:relationshipClosedReasonCode")
    datamap.put("relationshipReopenReasonCode", "cust:Profile:cust:relationshipReopenReasonCode")
    datamap.put("relationshipReopenIndicator", "cust:Profile:cust:relationshipReopenIndicator")
    datamap.put("closeInitiatedBy", "cust:Profile:cust:closeInitiatedBy")
    datamap.put("ethnicType", "cust:Profile:cust:ethnicType")
    datamap.put("GSTResidentStatus", "cust:Profile:cust:GSTResidentStatus")
    datamap.put("makerID", "cust:Profile:cust:makerID")
    datamap.put("makerDate", "cust:Profile:cust:makerDate")
    datamap.put("checkerID", "cust:Profile:cust:checkerID")
    datamap.put("checkerDate", "cust:Profile:cust:checkerDate")
    datamap.put("taxResidenceStatus", "cust:Profile:cust:taxResidenceStatus")
    datamap.put("consolidatedStatementFlag", "cust:Profile:cust:consolidatedStatementFlag")
    datamap.put("relationshipCreateDate", "cust:Profile:cust:relationshipCreateDate")
    datamap.put("makerBranch", "cust:Profile:cust:makerBranch")
    datamap.put("makerIpAddress", "cust:Profile:cust:makerIpAddress")
    datamap.put("checkerBranch", "cust:Profile:cust:checkerBranch")
    datamap.put("checkerIpAddress", "cust:Profile:cust:checkerIpAddress")
    datamap.put("statusFlag", "cust:Profile:cust:statusFlag")
    datamap.put("dataFlag", "cust:Profile:cust:dataFlag")
    datamap.put("revisionNumber", "cust:Profile:cust:revisionNumber")
    datamap.put("dedupRequired", "cust:Profile:cust:dedupRequired")
    datamap.put("fullNameoverride", "cust:Profile:cust:fullNameoverride")
    datamap.put("profileID", "cust:ProfileUniqueId:cust:profileID")
    datamap.put("relationshipID", "cust:ProfileUniqueId:cust:relationshipID")
    datamap.put("messageSequenceNumber", "cust:ProfileUniqueId:cust:messageSequenceNumber")
    datamap.put("countryCode", "ns:messageSender:ns:countryCode")
    datamap.put("messageTimestamp", "ns:originationDetails:ns:messageTimestamp")
    datamap.put("placeOfBirth", "cust:Profile:cust:placeOfBirth")
    datamap.put("trackingId", "ns:originationDetails:ns:trackingId")
    

    datamap
  }

  def validateCUSTOMERProfile(datama: java.util.HashMap[String, String], validation_property: Properties, tx: Message, count: Integer): ArrayBuffer[ForError] = {
    val util = new Util()
    var error = ArrayBuffer[ForError]()
    val profileID = tx.values.get(datama.get("profileID") + "#1#").get
    val relationshipID = tx.values.get(datama.get("relationshipID") + "#1#").get
    val messageSequenceNumber = tx.values.get(datama.get("messageSequenceNumber") + "#1#").get
    val tablename = "CustomerProfile"
    //1
    if (tx.values.contains(datama.get("countryCode") + "#" + count + "#")) {
      val status = util.checkDataLength(tx.values.get(datama.get("countryCode") + "#" + count + "#").get, validation_property.getProperty("COMPANY_ID"))
      // println("countryCode ----------------->  " + status)
      //      var ss = datava(0) match {
      //        case "data_length_isuee" => {
      //          error += ForError(status, tx.values.get(datama.get("countryCode") + "#" + count + "#").get, "countryCode", tablename, profileID, relationshipID, messageSequenceNumber)
      //        }
      //        case "data_type_isuee" => {
      //          error += ForError(status, tx.values.get(datama.get("countryCode") + "#" + count + "#").get, "countryCode", tablename, profileID, relationshipID, messageSequenceNumber)
      //        }
      //
      //      }
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, tx.values.get(datama.get("countryCode") + "#" + count + "#").get, "countryCode", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //2
    if (tx.values.contains(datama.get("profileID") + "#" + count + "#")) {
      val status = util.checkDataLength(tx.values.get(datama.get("profileID") + "#" + count + "#").get, validation_property.getProperty("PROFILE_ID"))
      //  println("profileID ----------------->  " + status)
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, tx.values.get(datama.get("profileID") + "#" + count + "#").get, "profileID", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //3
    if (tx.values.contains(datama.get("relationshipID") + "#" + count + "#")) {
      val status = util.checkDataLength(tx.values.get(datama.get("relationshipID") + "#" + count + "#").get, validation_property.getProperty("RELATIONSHIP_NUMBER"))
      //  println("relationshipID ----------------->  " + status)
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, tx.values.get(datama.get("relationshipID") + "#" + count + "#").get, "relationshipID", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //4
    if (tx.values.contains(datama.get("clientTypeInd") + "#" + count + "#")) {
      val status = util.checkDataLength(tx.values.get(datama.get("clientTypeInd") + "#" + count + "#").get, validation_property.getProperty("PROFILE_TYPE"))
      // println("clientTypeInd ----------------->  " + status)
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, tx.values.get(datama.get("clientTypeInd") + "#" + count + "#").get, "clientTypeInd", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //5
    if (tx.values.contains(datama.get("customerSalutationCode") + "#" + count + "#")) {
      val status = util.checkDataLength(tx.values.get(datama.get("customerSalutationCode") + "#" + count + "#").get, validation_property.getProperty("SALUTATION_CODE"))
      // println("customerFirstName ----------------->  " + status)
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, tx.values.get(datama.get("customerSalutationCode") + "#" + count + "#").get, "customerSalutationCode", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //6
    if (tx.values.contains(datama.get("customerFirstName") + "#" + count + "#")) {
      val status = util.checkDataLength(tx.values.get(datama.get("customerFirstName") + "#" + count + "#").get, validation_property.getProperty("FIRST_NAME"))
      // println("customerFirstName ----------------->  " + status)
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, tx.values.get(datama.get("customerFirstName") + "#" + count + "#").get, "customerFirstName", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //7
    if (tx.values.contains(datama.get("customerMiddleName") + "#" + count + "#")) {
      val status = util.checkDataLength(tx.values.get(datama.get("customerMiddleName") + "#" + count + "#").get, validation_property.getProperty("MIDDLE_NAME"))
      // println("customerMiddleName ----------------->  " + status)
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, tx.values.get(datama.get("customerMiddleName") + "#" + count + "#").get, "customerMiddleName", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //8
    if (tx.values.contains(datama.get("customerLastName") + "#" + count + "#")) {
      val status = util.checkDataLength(tx.values.get(datama.get("customerLastName") + "#" + count + "#").get, validation_property.getProperty("LAST_NAME"))
      // println("customerLastName ----------------->  " + status)
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, tx.values.get(datama.get("customerLastName") + "#" + count + "#").get, "customerLastName", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //9
    if (tx.values.contains(datama.get("customerFullName") + "#" + count + "#")) {
      val status = util.checkDataLength(tx.values.get(datama.get("customerFullName") + "#" + count + "#").get, validation_property.getProperty("FULL_NAME"))
      // println("customerFullName ----------------->  " + status)
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, tx.values.get(datama.get("customerFullName") + "#" + count + "#").get, "customerFullName", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //10
    if (tx.values.contains(datama.get("mothersMaidenName") + "#" + count + "#")) {
      val status = util.checkDataLength(tx.values.get(datama.get("mothersMaidenName") + "#" + count + "#").get, validation_property.getProperty("MOTHERS_MAIDEN_NAME"))
      // println("mothersMaidenName ----------------->  " + status)
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, tx.values.get(datama.get("mothersMaidenName") + "#" + count + "#").get, "mothersMaidenName", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //11
    if (tx.values.contains(datama.get("customerGender") + "#" + count + "#")) {
      val status = util.checkDataLength(tx.values.get(datama.get("customerGender") + "#" + count + "#").get, validation_property.getProperty("GENDER"))
      //  println("customerGender ----------------->  " + status)
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, tx.values.get(datama.get("customerGender") + "#" + count + "#").get, "customerGender", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //12
    if (tx.values.contains(datama.get("dateOfBirth") + "#" + count + "#")) {
      val status = util.checkDataLength(tx.values.get(datama.get("dateOfBirth") + "#" + count + "#").get, validation_property.getProperty("DATE_OF_BIRTH"))
      //  println("dateOfBirth ----------------->  " + status)
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, tx.values.get(datama.get("dateOfBirth") + "#" + count + "#").get, "dateOfBirth", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //13
    if (tx.values.contains(datama.get("customerEducationalQualification") + "#" + count + "#")) {
      val status = util.checkDataLength(tx.values.get(datama.get("customerEducationalQualification") + "#" + count + "#").get, validation_property.getProperty("QUALIFICATION_CODE"))
      //  println("customerEducationalQualification ----------------->  " + status)
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, tx.values.get(datama.get("customerEducationalQualification") + "#" + count + "#").get, "customerEducationalQualification", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //14
    if (tx.values.contains(datama.get("customerMaritalStatus") + "#" + count + "#")) {
      val status = util.checkDataLength(tx.values.get(datama.get("customerMaritalStatus") + "#" + count + "#").get, validation_property.getProperty("MARITAL_STATUS"))
      //   println("customerMaritalStatus ----------------->  " + status)
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, tx.values.get(datama.get("customerMaritalStatus") + "#" + count + "#").get, "customerMaritalStatus", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //15
    if (tx.values.contains(datama.get("customersDependants") + "#" + count + "#")) {
      val status = util.checkDataLength(tx.values.get(datama.get("customersDependants") + "#" + count + "#").get, validation_property.getProperty("TOT_NO_OF_DEPENDANT"))
      //  println("customersDependants ----------------->  " + status)
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, tx.values.get(datama.get("customersDependants") + "#" + count + "#").get, "customersDependants", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //16
    if (tx.values.contains(datama.get("preferredLanguage") + "#" + count + "#")) {
      val status = util.checkDataLength(tx.values.get(datama.get("preferredLanguage") + "#" + count + "#").get, validation_property.getProperty("PREFERRED_LANGUAGE"))
      //  println("preferredLanguage ----------------->  " + status)
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, tx.values.get(datama.get("preferredLanguage") + "#" + count + "#").get, "preferredLanguage", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //17
    if (tx.values.contains(datama.get("customerResidenceCountry") + "#" + count + "#")) {
      val status = util.checkDataLength(tx.values.get(datama.get("customerResidenceCountry") + "#" + count + "#").get, validation_property.getProperty("RESIDENT_COUNTRY"))
      //  println("customerResidenceCountry ----------------->  " + status)
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, tx.values.get(datama.get("customerResidenceCountry") + "#" + count + "#").get, "customerResidenceCountry", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //18
    if (tx.values.contains(datama.get("customerResidentStatusIdentifier") + "#" + count + "#")) {
      val status = util.checkDataLength(tx.values.get(datama.get("customerResidentStatusIdentifier") + "#" + count + "#").get, validation_property.getProperty("RESIDENT_STATUS"))
      // println("customerResidentStatusIdentifier ---------->  " + status)
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, tx.values.get(datama.get("customerResidentStatusIdentifier") + "#" + count + "#").get, "customerResidentStatusIdentifier", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //19
    if (tx.values.contains(datama.get("makerBranch") + "#" + count + "#")) {
      val status = util.checkDataLength(tx.values.get(datama.get("makerBranch") + "#" + count + "#").get, validation_property.getProperty("MAKER_BRANCH"))
      //  println("makerBranch ---------->  " + status)
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, tx.values.get(datama.get("makerBranch") + "#" + count + "#").get, "makerBranch", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //20
    if (tx.values.contains(datama.get("makerDate") + "#" + count + "#")) {
      val status = util.checkDataLength(tx.values.get(datama.get("makerDate") + "#" + count + "#").get, validation_property.getProperty("MAKER_TIMESTAMP"))
      //   println("makerDate ---------->  " + status)
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, tx.values.get(datama.get("makerDate") + "#" + count + "#").get, "makerDate", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }

    //21
    if (tx.values.contains(datama.get("makerID") + "#" + count + "#")) {
      val status = util.checkDataLength(tx.values.get(datama.get("makerID") + "#" + count + "#").get, validation_property.getProperty("MAKER_ID"))
      //   println("makerID ----------------->  " + status)
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, tx.values.get(datama.get("makerID") + "#" + count + "#").get, "makerID", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //22
    if (tx.values.contains(datama.get("makerIpAddress") + "#" + count + "#")) {
      val status = util.checkDataLength(tx.values.get(datama.get("makerIpAddress") + "#" + count + "#").get, validation_property.getProperty("MAKER_IP_ADDRESS"))
      //   println("makerIpAddress ----------------->  " + status)
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, tx.values.get(datama.get("makerIpAddress") + "#" + count + "#").get, "makerIpAddress", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //23
    if (tx.values.contains(datama.get("checkerBranch") + "#" + count + "#")) {
      val status = util.checkDataLength(tx.values.get(datama.get("checkerBranch") + "#" + count + "#").get, validation_property.getProperty("CHECKER_BRANCH"))
      //   println("checkerBranch ----------------->  " + status)
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, tx.values.get(datama.get("checkerBranch") + "#" + count + "#").get, "checkerBranch", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }

    //24
    if (tx.values.contains(datama.get("checkerDate") + "#" + count + "#")) {
      val status = util.checkDataLength(tx.values.get(datama.get("checkerDate") + "#" + count + "#").get, validation_property.getProperty("CHECKER_TIMESTAMP"))
      //   println("checkerDate ----------------->  " + status)
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, tx.values.get(datama.get("checkerDate") + "#" + count + "#").get, "checkerDate", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //25
    if (tx.values.contains(datama.get("checkerID") + "#" + count + "#")) {
      val status = util.checkDataLength(tx.values.get(datama.get("checkerID") + "#" + count + "#").get, validation_property.getProperty("CHECKER_ID"))
      //   println("checkerID ----------------->  " + status)
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, tx.values.get(datama.get("checkerID") + "#" + count + "#").get, "checkerID", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //26
    if (tx.values.contains(datama.get("checkerIpAddress") + "#" + count + "#")) {
      val status = util.checkDataLength(tx.values.get(datama.get("checkerIpAddress") + "#" + count + "#").get, validation_property.getProperty("CHECKER_IP_ADDRESS"))
      //   println("checkerIpAddress ----------------->  " + status)
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, tx.values.get(datama.get("checkerIpAddress") + "#" + count + "#").get, "checkerIpAddress", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //27
    if (tx.values.contains(datama.get("statusFlag") + "#" + count + "#")) {
      val status = util.checkDataLength(tx.values.get(datama.get("statusFlag") + "#" + count + "#").get, validation_property.getProperty("STATUS_FLAG"))
      //   println("statusFlag ----------------->  " + status)
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, tx.values.get(datama.get("statusFlag") + "#" + count + "#").get, "statusFlag", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //28
    if (tx.values.contains(datama.get("GSTResidentStatus") + "#" + count + "#")) {
      val status = util.checkDataLength(tx.values.get(datama.get("GSTResidentStatus") + "#" + count + "#").get, validation_property.getProperty("GST_RESIDENT_STATUS"))
      //   println("GSTResidentStatus ----------------->  " + status)
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, tx.values.get(datama.get("GSTResidentStatus") + "#" + count + "#").get, "GSTResidentStatus", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }

    //29
    if (tx.values.contains(datama.get("revisionNumber") + "#" + count + "#")) {
      val status = util.checkDataLength(tx.values.get(datama.get("revisionNumber") + "#" + count + "#").get, validation_property.getProperty("REVISION_NUMBER"))
      //   println("revisionNumber ----------------->  " + status)
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, tx.values.get(datama.get("revisionNumber") + "#" + count + "#").get, "revisionNumber", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //30
    if (tx.values.contains(datama.get("dataFlag") + "#" + count + "#")) {
      val status = util.checkDataLength(tx.values.get(datama.get("dataFlag") + "#" + count + "#").get, validation_property.getProperty("DATA_FLAG"))
      //   println("dataFlag ----------------->  " + status)
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, tx.values.get(datama.get("dataFlag") + "#" + count + "#").get, "dataFlag", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //31
    if (tx.values.contains(datama.get("dedupRequired") + "#" + count + "#")) {
      val status = util.checkDataLength(tx.values.get(datama.get("dedupRequired") + "#" + count + "#").get, validation_property.getProperty("DEDUP_REQUIRED"))
      //   println("dedupRequired ----------------->  " + status)
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, tx.values.get(datama.get("dedupRequired") + "#" + count + "#").get, "dedupRequired", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }

    //32
    if (tx.values.contains(datama.get("countryOfBirth") + "#" + count + "#")) {
      val status = util.checkDataLength(tx.values.get(datama.get("countryOfBirth") + "#" + count + "#").get, validation_property.getProperty("COUNTRY_OF_BIRTH"))
      //   println("countryOfBirth ----------------->  " + status)
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, tx.values.get(datama.get("countryOfBirth") + "#" + count + "#").get, "countryOfBirth", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //33
    if (tx.values.contains(datama.get("taxResidenceStatus") + "#" + count + "#")) {
      val status = util.checkDataLength(tx.values.get(datama.get("taxResidenceStatus") + "#" + count + "#").get, validation_property.getProperty("TAX_RESIDENT_STATUS"))
      //   println("taxResidenceStatus ----------------->  " + status)
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, tx.values.get(datama.get("taxResidenceStatus") + "#" + count + "#").get, "taxResidenceStatus", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //34
    if (tx.values.contains(datama.get("fullNameoverride") + "#" + count + "#")) {
      val status = util.checkDataLength(tx.values.get(datama.get("fullNameoverride") + "#" + count + "#").get, validation_property.getProperty("FULL_NAME_OVERRIDE"))
      //   println("fullNameoverride ----------------->  " + status)
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, tx.values.get(datama.get("fullNameoverride") + "#" + count + "#").get, "fullNameoverride", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //35 
    if (tx.values.contains(datama.get("placeOfBirth") + "#" + count + "#")) {
      val status = util.checkDataLength(tx.values.get(datama.get("placeOfBirth") + "#" + count + "#").get, validation_property.getProperty("BIRTH_PLACE"))
      //   println("fullNameoverride ----------------->  " + status)
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, tx.values.get(datama.get("placeOfBirth") + "#" + count + "#").get, "placeOfBirth", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //35
    //    if (tx.values.contains(datama.get("date") + "#" + count + "#")) {
    //      val status = util.checkDataLength(tx.values.get(datama.get("date") + "#" + count + "#").get, validation_property.getProperty("EXEC_DATE"))
    //      println("date ----------------->  " + status)
    //      if (status == "data_length_isuee" || status == "data_type_isuee") {
    //        error += ForError(status, tx.values.get(datama.get("date") + "#" + count + "#").get, "date", tablename, profileID, relationshipID, messageSequenceNumber)
    //      }
    //    }

    // println("error array size--------------->  " + error.length)
    //    println("error array size--------------->  " + error.size)
    //    for (err <- error) {
    //      println(" error ----------------------->  " + err.coumn_name)
    //    }
    error
  }
}