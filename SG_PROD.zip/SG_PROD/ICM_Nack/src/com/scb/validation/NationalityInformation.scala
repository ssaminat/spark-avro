package com.scb.validation

import java.util.Properties
import org.apache.log4j.Logger
import collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer
import com.scb.icm.Message

class NationalityInformation {

  def dataMapping(): java.util.HashMap[String, String] = {
    val map = new java.util.HashMap[String, String]()
    map.put("operationMode", "cust:NationalityInformation:cust:operationMode")
    map.put("customerNationality", "cust:NationalityInformation:cust:customerNationality")
    map.put("profileID", "cust:ProfileUniqueId:cust:profileID")
    map.put("relationshipID", "cust:ProfileUniqueId:cust:relationshipID")
    map.put("messageSequenceNumber", "cust:ProfileUniqueId:cust:messageSequenceNumber")
    map.put("countryCode", "ns:messageSender:ns:countryCode")
    map.put("messageTimestamp", "ns:originationDetails:ns:messageTimestamp")
    map
  }

  def validateRecods(datama: java.util.HashMap[String, String], validation_property: Properties, tx: Message, count: Integer): ArrayBuffer[ForError] = {
    val util = new Util()
    var error = ArrayBuffer[ForError]()
    val profileID = tx.values.get(datama.get("profileID") + "#1#").get
    val relationshipID = tx.values.get(datama.get("relationshipID") + "#1#").get
    val messageSequenceNumber = tx.values.get(datama.get("messageSequenceNumber") + "#1#").get
    val tablename = "NationalityInformation"
    //1
    if (tx.values.contains(datama.get("countryCode") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("countryCode") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("COMPANY_ID"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "countryCode", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //2
    if (tx.values.contains(datama.get("profileID") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("profileID") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("PROFILE_ID"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "profileID", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //3
    if (tx.values.contains(datama.get("customerNationality") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("customerNationality") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("NATIONALITY_CODE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "customerNationality", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }

    error
  }

}