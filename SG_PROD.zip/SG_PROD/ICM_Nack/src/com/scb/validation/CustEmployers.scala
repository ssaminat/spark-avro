package com.scb.validation

import java.util.Properties
import org.apache.log4j.Logger
import collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer
import com.scb.icm.Message

class CustEmployers {
  def dataMapping(): java.util.HashMap[String, String] = {
    val map = new java.util.HashMap[String, String]()
    map.put("operationMode", "cust:EmploymentInformation:cust:operationMode")
    map.put("typeofEmployement", "cust:EmploymentInformation:cust:typeofEmployement")
    map.put("customerProfession", "cust:EmploymentInformation:cust:customerProfession")
    map.put("customerEmployerCode", "cust:EmploymentInformation:cust:customerEmployerCode")
    map.put("employerName", "cust:EmploymentInformation:cust:employerName")
    map.put("staffCategory", "cust:EmploymentInformation:cust:staffCategory")
    map.put("employeeCategorization", "cust:EmploymentInformation:cust:employeeCategorization")
    map.put("customerOrganizationName", "cust:EmploymentInformation:cust:customerOrganizationName")
    map.put("employeeBankingInd", "cust:EmploymentInformation:cust:employeeBankingInd")
    map.put("employeeIdentification", "cust:EmploymentInformation:cust:employeeIdentification")
    map.put("salaryMode", "cust:EmploymentInformation:cust:salaryMode")
    map.put("declaredIncomeCurrency", "cust:EmploymentInformation:cust:declaredIncomeCurrency")
    map.put("annualIncomeDeclaration", "cust:EmploymentInformation:cust:annualIncomeDeclaration")
    map.put("derivedIncomeCurrency", "cust:EmploymentInformation:cust:derivedIncomeCurrency")
    map.put("annualDerivedIncome", "cust:EmploymentInformation:cust:annualDerivedIncome")
    map.put("documentedIncomeCurrency", "cust:EmploymentInformation:cust:documentedIncomeCurrency")
    map.put("annaulDocumentedIncome", "cust:EmploymentInformation:cust:annaulDocumentedIncome")
    map.put("proxyIncomeCurrency", "cust:EmploymentInformation:cust:proxyIncomeCurrency")
    map.put("annualSurrogateIncome", "cust:EmploymentInformation:cust:annualSurrogateIncome")
    map.put("wealthClassificationCode", "cust:EmploymentInformation:cust:wealthClassificationCode")
    map.put("clientInvestPortfolio", "cust:EmploymentInformation:cust:clientInvestPortfolio")
    map.put("cipRatingEffectiveDate", "cust:EmploymentInformation:cust:cipRatingEffectiveDate")
    map.put("overseasInvestor", "cust:EmploymentInformation:cust:overseasInvestor")
    map.put("vulnerableCustomer", "cust:EmploymentInformation:cust:vulnerableCustomer")
    map.put("wealthInvestmentExpiryDate", "cust:EmploymentInformation:cust:wealthInvestmentExpiryDate")
    map.put("clientInvestmentProfileStatus", "cust:EmploymentInformation:cust:clientInvestmentProfileStatus")
    map.put("clientInvestmentProfileVerified", "cust:EmploymentInformation:cust:clientInvestmentProfileVerified")
    map.put("isicCode", "cust:EmploymentInformation:cust:isicCode")
    map.put("profileID", "cust:ProfileUniqueId:cust:profileID")
    map.put("relationshipID", "cust:ProfileUniqueId:cust:relationshipID")
    map.put("messageSequenceNumber", "cust:ProfileUniqueId:cust:messageSequenceNumber")
    map.put("countryCode", "ns:messageSender:ns:countryCode")
    map.put("messageTimestamp", "ns:originationDetails:ns:messageTimestamp")
    map.put("trackingId", "ns:originationDetails:ns:trackingId")
    map
  }

  def validateRecods(datama: java.util.HashMap[String, String], validation_property: Properties, tx: Message, count: Integer): ArrayBuffer[ForError] = {
    val util = new Util()
    var error = ArrayBuffer[ForError]()
     val profileID = tx.values.get(datama.get("profileID") + "#1#").get
    val relationshipID = tx.values.get(datama.get("relationshipID") + "#1#").get
    val messageSequenceNumber = tx.values.get(datama.get("messageSequenceNumber") + "#1#").get
    val tablename = "CustEmployers"
    //1
    if (tx.values.contains(datama.get("customerEmployerCode") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("customerEmployerCode") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("EMPLOYER_CODE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "customerEmployerCode", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //2
    if (tx.values.contains(datama.get("employerName") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("employerName") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("EMPLOYER_NAME"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "employerName", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //3
    if (tx.values.contains(datama.get("staffCategory") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("staffCategory") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("STAFF_CATEGORY_CODE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "staffCategory", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //4
    if (tx.values.contains(datama.get("employeeCategorization") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("employeeCategorization") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("PRICING_CATEGORY_CODE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "employeeCategorization", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //5
    if (tx.values.contains(datama.get("customerOrganizationName") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("customerOrganizationName") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("OWN_ORGANISATION_NAME"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "customerOrganizationName", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //6
    if (tx.values.contains(datama.get("employeeBankingInd") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("employeeBankingInd") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("EMP_BANKING_INDICATOR"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "employeeBankingInd", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //7
    if (tx.values.contains(datama.get("employeeIdentification") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("employeeIdentification") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("STAFF_EMPLOYMENT_ID"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "employeeIdentification", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //8
    if (tx.values.contains(datama.get("salaryMode") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("salaryMode") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("SALARY_MODE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "salaryMode", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //9
    if (tx.values.contains(datama.get("declaredIncomeCurrency") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("declaredIncomeCurrency") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("DECLARED_INCOME_CCY"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "declaredIncomeCurrency", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //10
    if (tx.values.contains(datama.get("annualIncomeDeclaration") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("annualIncomeDeclaration") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("DECLARED_INCOME"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "annualIncomeDeclaration", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //11
    if (tx.values.contains(datama.get("derivedIncomeCurrency") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("derivedIncomeCurrency") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("DERIVED_INCOME_CCY"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "derivedIncomeCurrency", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //12
    if (tx.values.contains(datama.get("annualDerivedIncome") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("annualDerivedIncome") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("DERIVED_INCOME"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "annualDerivedIncome", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //13
    if (tx.values.contains(datama.get("documentedIncomeCurrency") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("documentedIncomeCurrency") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("DOCUMENTED_INCOME_CCY"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "documentedIncomeCurrency", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //14
    if (tx.values.contains(datama.get("annaulDocumentedIncome") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("annaulDocumentedIncome") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("DOCUMENTED_INCOME"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "annaulDocumentedIncome", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //15
    if (tx.values.contains(datama.get("proxyIncomeCurrency") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("proxyIncomeCurrency") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("PROXY_INCOME_CCY"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "proxyIncomeCurrency", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //16
    if (tx.values.contains(datama.get("annualSurrogateIncome") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("annualSurrogateIncome") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("PROXY_INCOME"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "annualSurrogateIncome", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }

    //17
    if (tx.values.contains(datama.get("wealthClassificationCode") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("wealthClassificationCode") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("WEALTH_CLASSIFICATION_CODE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "wealthClassificationCode", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //18
    if (tx.values.contains(datama.get("clientInvestPortfolio") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("clientInvestPortfolio") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("INVESTMENT_CODE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "clientInvestPortfolio", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //19
    if (tx.values.contains(datama.get("cipRatingEffectiveDate") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("cipRatingEffectiveDate") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("CIP_EFFECTIVE_DATE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "cipRatingEffectiveDate", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //20
    if (tx.values.contains(datama.get("overseasInvestor") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("overseasInvestor") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("OVERSEAS_INVESTOR"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "overseasInvestor", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //21
    if (tx.values.contains(datama.get("vulnerableCustomer") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("vulnerableCustomer") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("VULNERABLE_CUSTOMER"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "vulnerableCustomer", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    } //22
    if (tx.values.contains(datama.get("wealthInvestmentExpiryDate") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("wealthInvestmentExpiryDate") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("WEALTH_INV_EXPIRY_DATE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "wealthInvestmentExpiryDate", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //23
    if (tx.values.contains(datama.get("clientInvestmentProfileStatus") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("clientInvestmentProfileStatus") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("CLIENT_INV_PROFILE_STATUS"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "clientInvestmentProfileStatus", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //24
    if (tx.values.contains(datama.get("clientInvestmentProfileVerified") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("clientInvestmentProfileVerified") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("CLIENT_INV_PROFILE_VERIFIED"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "clientInvestmentProfileVerified", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //25
    if (tx.values.contains(datama.get("isicCode") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("isicCode") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("ISIC_CODE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "isicCode", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //26
    if (tx.values.contains(datama.get("typeofEmployement") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("typeofEmployement") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("WORK_TYPE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "typeofEmployement", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //27
    if (tx.values.contains(datama.get("customerProfession") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("customerProfession") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("PROFESSION_CODE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "customerProfession", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }

    error
  }
}