package com.scb.validation

import java.util.Properties
import org.apache.log4j.Logger
import collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer
import com.scb.icm.Message

class CustSiCountries {
  def dataMapping(): java.util.HashMap[String, String] = {
    val map = new java.util.HashMap[String, String]()
    map.put("operationMode", "cust:SITOCountriesInformation:cust:operationMode")
    map.put("siToCountry", "cust:SITOCountriesInformation:cust:siToCountry")
    map.put("beneficiaryBankName", "cust:SITOCountriesInformation:cust:beneficiaryBankName")
    map.put("profileID", "cust:ProfileUniqueId:cust:profileID")
    map.put("relationshipID", "cust:ProfileUniqueId:cust:relationshipID")
    map.put("messageSequenceNumber", "cust:ProfileUniqueId:cust:messageSequenceNumber")
    map.put("siFlag", "cust:SITOCountriesInformation:cust:siFlag")
    map.put("closedSoflag", "cust:SITOCountriesInformation:cust:closedSoflag")
    map.put("activeSoflag", "cust:SITOCountriesInformation:cust:activeSoflag")
    map.put("updatedSodate", "cust:SITOCountriesInformation:cust:updatedSodate")
    map.put("processedStatus", "cust:SITOCountriesInformation:cust:processedStatus")
    map.put("soRecordstatus", "cust:SITOCountriesInformation:cust:soRecordstatus")
    map.put("countryCode", "ns:messageSender:ns:countryCode")
    map.put("messageTimestamp", "ns:originationDetails:ns:messageTimestamp")
    map
  }

  def validateRecods(datama: java.util.HashMap[String, String], validation_property: Properties, tx: Message, count: Integer): ArrayBuffer[ForError] = {
    val util = new Util()
    var error = ArrayBuffer[ForError]()
    val profileID = tx.values.get(datama.get("profileID") + "#1#").get
    val relationshipID = tx.values.get(datama.get("relationshipID") + "#1#").get
    val messageSequenceNumber = tx.values.get(datama.get("messageSequenceNumber") + "#1#").get
    val tablename = "CustSiCountries"
    //1
    if (tx.values.contains(datama.get("siToCountry") + "#" + count + "#")) {
      val countryCode = tx.values.get(datama.get("siToCountry") + "#" + count + "#").get
      val status = util.checkDataLength(countryCode, validation_property.getProperty("SI_TO_COUNTRY"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, countryCode, "siToCountry", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //2
    if (tx.values.contains(datama.get("beneficiaryBankName") + "#" + count + "#")) {
      val countryCode = tx.values.get(datama.get("beneficiaryBankName") + "#" + count + "#").get
      val status = util.checkDataLength(countryCode, validation_property.getProperty("BENEFICIARY_BANK_NAME"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, countryCode, "beneficiaryBankName", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //3
    if (tx.values.contains(datama.get("siFlag") + "#" + count + "#")) {
      val countryCode = tx.values.get(datama.get("siFlag") + "#" + count + "#").get
      val status = util.checkDataLength(countryCode, validation_property.getProperty("SI_FLAG"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, countryCode, "siFlag", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //4
    if (tx.values.contains(datama.get("closedSoflag") + "#" + count + "#")) {
      val countryCode = tx.values.get(datama.get("closedSoflag") + "#" + count + "#").get
      val status = util.checkDataLength(countryCode, validation_property.getProperty("CLOSED_SO_FLAG"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, countryCode, "closedSoflag", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //5
    if (tx.values.contains(datama.get("activeSoflag") + "#" + count + "#")) {
      val countryCode = tx.values.get(datama.get("activeSoflag") + "#" + count + "#").get
      val status = util.checkDataLength(countryCode, validation_property.getProperty("ACTIVE_SO_FLAG"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, countryCode, "activeSoflag", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //6
    if (tx.values.contains(datama.get("updatedSodate") + "#" + count + "#")) {
      val countryCode = tx.values.get(datama.get("updatedSodate") + "#" + count + "#").get
      val status = util.checkDataLength(countryCode, validation_property.getProperty("UPDATED_SO_DATE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, countryCode, "updatedSodate", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //7
    if (tx.values.contains(datama.get("processedStatus") + "#" + count + "#")) {
      val countryCode = tx.values.get(datama.get("processedStatus") + "#" + count + "#").get
      val status = util.checkDataLength(countryCode, validation_property.getProperty("PROCESSED_STATUS"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, countryCode, "processedStatus", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //8
    if (tx.values.contains(datama.get("soRecordstatus") + "#" + count + "#")) {
      val countryCode = tx.values.get(datama.get("soRecordstatus") + "#" + count + "#").get
      val status = util.checkDataLength(countryCode, validation_property.getProperty("SO_RECORD_STATUS"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, countryCode, "soRecordstatus", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    error
  }
}