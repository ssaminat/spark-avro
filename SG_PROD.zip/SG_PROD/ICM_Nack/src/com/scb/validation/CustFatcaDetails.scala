package com.scb.validation
import java.util.Properties
import org.apache.log4j.Logger
import collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer
import com.scb.icm.Message
class CustFatcaDetails {
  def dataMapping(): java.util.HashMap[String, String] = {
    val map = new java.util.HashMap[String, String]()
    map.put("operationMode", "cust:FATCAInformation:cust:operationMode")
    map.put("fatcaUSResidentInd", "cust:FATCAInformation:cust:fatcaUSResidentInd")
    map.put("fatcaUSCitizenInd", "cust:FATCAInformation:cust:fatcaUSCitizenInd")
    map.put("fatcaGreenCardHolderInd", "cust:FATCAInformation:cust:fatcaGreenCardHolderInd")
    map.put("fatcaOnBoardDispensation", "cust:FATCAInformation:cust:fatcaOnBoardDispensation")
    map.put("fatcaUSIndicaIdentifier", "cust:FATCAInformation:cust:fatcaUSIndicaIdentifier")
    map.put("fatcaUSpersonInd", "cust:FATCAInformation:cust:fatcaUSpersonInd")
    map.put("fatcaReportIRSInd", "cust:FATCAInformation:cust:fatcaReportIRSInd")
    map.put("fatcaJointAccountInd", "cust:FATCAInformation:cust:fatcaJointAccountInd")
    map.put("fatcaRecalInd", "cust:FATCAInformation:cust:fatcaRecalInd")
    map.put("fatcaRecalIdentifierAssignedDate", "cust:FATCAInformation:cust:fatcaRecalIdentifierAssignedDate")
    map.put("fatcaRecalcitrantIndClearedDate", "cust:FATCAInformation:cust:fatcaRecalcitrantIndClearedDate")
    map.put("fatcaWithHoldInd", "cust:FATCAInformation:cust:fatcaWithHoldInd")
    map.put("fatcaEnhancedReviewInd", "cust:FATCAInformation:cust:fatcaEnhancedReviewInd")
    map.put("fatcaEnhancedReviewStartDate", "cust:FATCAInformation:cust:fatcaEnhancedReviewStartDate")
    map.put("fatcaEnhancedReviewEndDate", "cust:FATCAInformation:cust:fatcaEnhancedReviewEndDate")
    map.put("documentSubmissionInd", "cust:FATCAInformation:cust:documentSubmissionInd")
    map.put("profileID", "cust:ProfileUniqueId:cust:profileID")
    map.put("relationshipID", "cust:ProfileUniqueId:cust:relationshipID")
    map.put("messageSequenceNumber", "cust:ProfileUniqueId:cust:messageSequenceNumber")
    map.put("countryCode", "ns:messageSender:ns:countryCode")
    map.put("messageTimestamp", "ns:originationDetails:ns:messageTimestamp")
    map.put("documentDueDate", "cust:FATCAInformation:cust:documentDueDate")
    map
  }

  def validateRecods(datama: java.util.HashMap[String, String], validation_property: Properties, tx: Message, count: Integer): ArrayBuffer[ForError] = {
    val util = new Util()
    var error = ArrayBuffer[ForError]()
    val profileID = tx.values.get(datama.get("profileID") + "#1#").get
    val relationshipID = tx.values.get(datama.get("relationshipID") + "#1#").get
    val messageSequenceNumber = tx.values.get(datama.get("messageSequenceNumber") + "#1#").get
    val tablename = "CustFatcaDetails"
    //1
    if (tx.values.contains(datama.get("fatcaUSResidentInd") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("fatcaUSResidentInd") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("USA_RESIDENT"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "fatcaUSResidentInd", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //2
    if (tx.values.contains(datama.get("fatcaUSCitizenInd") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("fatcaUSCitizenInd") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("USA_CITIZEN"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "fatcaUSCitizenInd", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //3
    if (tx.values.contains(datama.get("fatcaGreenCardHolderInd") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("fatcaGreenCardHolderInd") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("USA_GREENCARD_HOLDER"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "fatcaGreenCardHolderInd", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //4
    if (tx.values.contains(datama.get("fatcaOnBoardDispensation") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("fatcaOnBoardDispensation") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("ONBOARD_WITH_DISP"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "fatcaOnBoardDispensation", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //5
    if (tx.values.contains(datama.get("fatcaUSIndicaIdentifier") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("fatcaUSIndicaIdentifier") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("USA_INDICIA_INDICATOR"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "fatcaUSIndicaIdentifier", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //6
    if (tx.values.contains(datama.get("fatcaUSpersonInd") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("fatcaUSpersonInd") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("USA_PERSON_INDICATOR"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "fatcaUSpersonInd", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //7
    if (tx.values.contains(datama.get("fatcaReportIRSInd") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("fatcaReportIRSInd") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("REPORT_TO_IRS_IND"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "fatcaReportIRSInd", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //8
    if (tx.values.contains(datama.get("fatcaJointAccountInd") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("fatcaJointAccountInd") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("JOINT_ACCT_IDENTIFIER"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "fatcaJointAccountInd", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //9
    if (tx.values.contains(datama.get("fatcaRecalInd") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("fatcaRecalInd") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("RECAL_FLAG"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "fatcaRecalInd", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //10
    if (tx.values.contains(datama.get("fatcaRecalIdentifierAssignedDate") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("fatcaRecalIdentifierAssignedDate") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("RECAL_IDEN_ASSIGN_DATE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "fatcaRecalIdentifierAssignedDate", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }

    //11
    if (tx.values.contains(datama.get("fatcaRecalcitrantIndClearedDate") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("fatcaRecalcitrantIndClearedDate") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("RECAL_ID_CLEARED_DATE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "fatcaRecalcitrantIndClearedDate", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //12
    if (tx.values.contains(datama.get("fatcaWithHoldInd") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("fatcaWithHoldInd") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("WITHHOLD_IND"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "fatcaWithHoldInd", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //13
    if (tx.values.contains(datama.get("fatcaEnhancedReviewInd") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("fatcaEnhancedReviewInd") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("ENHANCED_REVIEW_IND"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "fatcaEnhancedReviewInd", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //14
    if (tx.values.contains(datama.get("fatcaEnhancedReviewStartDate") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("fatcaEnhancedReviewStartDate") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("ENHANCED_REVIEW_START_DATE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "fatcaEnhancedReviewStartDate", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //15
    if (tx.values.contains(datama.get("fatcaEnhancedReviewEndDate") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("fatcaEnhancedReviewEndDate") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("ENHANCED_REVIEW_END_DATE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "fatcaEnhancedReviewEndDate", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //16
    if (tx.values.contains(datama.get("documentSubmissionInd") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("documentSubmissionInd") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("SUPPORT_DOC_IND"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "documentSubmissionInd", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //17
    if (tx.values.contains(datama.get("documentDueDate") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("documentDueDate") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("DOCUMENT_DUE_DATE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "documentDueDate", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    error
  }
}