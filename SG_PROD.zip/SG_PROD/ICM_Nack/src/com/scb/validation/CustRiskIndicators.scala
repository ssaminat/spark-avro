package com.scb.validation

import java.util.Properties
import org.apache.log4j.Logger
import collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer
import com.scb.icm.Message

class CustRiskIndicators {

  def dataMapping(): java.util.HashMap[String, String] = {
    val map = new java.util.HashMap[String, String]()
    map.put("operationMode", "cust:RiskIndicatorDetails:cust:operationMode")
    map.put("riskCode", "cust:RiskIndicatorDetails:cust:riskCode")
    map.put("riskDescription", "cust:RiskIndicatorDetails:cust:riskDescription")
    map.put("startDate", "cust:RiskIndicatorDetails:cust:startDate")
    map.put("expiryDate", "cust:RiskIndicatorDetails:cust:expiryDate")
    map.put("reasonRemarks", "cust:RiskIndicatorDetails:cust:reasonRemarks")
    map.put("profileID", "cust:ProfileUniqueId:cust:profileID")
    map.put("relationshipID", "cust:ProfileUniqueId:cust:relationshipID")
    map.put("messageSequenceNumber", "cust:ProfileUniqueId:cust:messageSequenceNumber")
    map.put("assignedReasoncode", "cust:RiskIndicatorDetails:cust:assignedReasoncode")
    map.put("countryCode", "ns:messageSender:ns:countryCode")
    map.put("messageTimestamp", "ns:originationDetails:ns:messageTimestamp")
    map
  }

  def validateRecods(datama: java.util.HashMap[String, String], validation_property: Properties, tx: Message, count: Integer): ArrayBuffer[ForError] = {
    val util = new Util()
    var error = ArrayBuffer[ForError]()
     val profileID = tx.values.get(datama.get("profileID") + "#1#").get
    val relationshipID = tx.values.get(datama.get("relationshipID") + "#1#").get
    val messageSequenceNumber = tx.values.get(datama.get("messageSequenceNumber") + "#1#").get
    val tablename = "CustRiskIndicators"
    //1
    if (tx.values.contains(datama.get("riskCode") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("riskCode") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("RISK_CODE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "riskCode", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //2
//    if (tx.values.contains(datama.get("riskDescription") + "#" + count + "#")) {
//      val columnvalue = tx.values.get(datama.get("riskDescription") + "#" + count + "#").get
//      val status = util.checkDataLength(columnvalue, validation_property.getProperty("FFFF"))
//      if (status == "data_length_isuee" || status == "data_type_isuee") {
//        error += ForError(status, columnvalue, "riskDescription", tablename, profileID, relationshipID, messageSequenceNumber)
//      }
//    }
    //3
    if (tx.values.contains(datama.get("startDate") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("startDate") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("RISK_START_DATE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "startDate", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //4
    if (tx.values.contains(datama.get("expiryDate") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("expiryDate") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("RISK_EXPIRY_DATE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "expiryDate", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //5
    if (tx.values.contains(datama.get("reasonRemarks") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("reasonRemarks") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("RISK_REASON_REMARKS"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "reasonRemarks", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }

    error
  }
}