package com.scb.validation

import java.util.Properties
import org.apache.log4j.Logger
import collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer
import com.scb.icm.Message

//case class ForError(coumn_name: String, table_name: String, profileID: String, relationshipID: String, messageSequenceNumber: String)

class CustomerProfileBusiness {

  def forCUSTOMERProfile(): java.util.HashMap[String, String] = {
    val map = new java.util.HashMap[String, String]()
    map.put("operationMode", "cust:BusinessProfile:cust:operationMode")
    //map.put("relationshipStatus", "cust:BusinessProfile:cust:relationshipStatus")
    map.put("armCode", "cust:BusinessProfile:cust:armCode")
    map.put("segmentCode", "cust:BusinessProfile:cust:segmentCode")
    map.put("subSegmentCode", "cust:BusinessProfile:cust:subSegmentCode")
    map.put("serviceIndCode", "cust:BusinessProfile:cust:serviceIndCode")
    map.put("referralID", "cust:BusinessProfile:cust:referralID")
    map.put("sourcingID", "cust:BusinessProfile:cust:sourcingID")
    map.put("closingID", "cust:BusinessProfile:cust:closingID")
    map.put("acquisitionChannel", "cust:BusinessProfile:cust:acquisitionChannel")
    map.put("homeBranch", "cust:BusinessProfile:cust:homeBranch")
    map.put("referralRelationshipNo", "cust:BusinessProfile:cust:referralRelationshipNo")
    map.put("referralName", "cust:BusinessProfile:cust:referralName")
    //map.put("closeInitiatedBy", "cust:BusinessProfile:cust:closeInitiatedBy")
    //map.put("relationshipReopenIndicator", "cust:BusinessProfile:cust:relationshipReopenIndicator")
    //map.put("activationDate", "cust:BusinessProfile:cust:activationDate")
    map.put("ibnkInd", "cust:BusinessProfile:cust:ibnkInd")
    map.put("phonebankingId", "cust:BusinessProfile:cust:phonebankingId")
    map.put("relationshipClosedReasonCode", "cust:BusinessProfile:cust:relationshipClosedReasonCode")
    map.put("profileID", "cust:ProfileUniqueId:cust:profileID")
    map.put("relationshipID", "cust:ProfileUniqueId:cust:relationshipID")
    map.put("messageSequenceNumber", "cust:ProfileUniqueId:cust:messageSequenceNumber")
    map.put("dataSyncflag", "cust:BusinessProfile:cust:dataSyncflag")
    map.put("profileCreatedate", "cust:Profile:cust:relationshipCreateDate")
    map.put("lastStatusUpdateDate","cust:Profile:cust:lastStatusUpdateDate")
    map.put("profileActivatedate", "cust:BusinessProfile:cust:profileActivatedate")
    map.put("profileClosedate", "cust:BusinessProfile:cust:profileClosedate")
    map.put("countryCode", "ns:messageSender:ns:countryCode")
    map.put("messageTimestamp", "ns:originationDetails:ns:messageTimestamp")
    map.put("relationshipStatus", "cust:Profile:cust:relationshipStatus")
    map.put("activationDate", "cust:Profile:cust:activationDate")
    map.put("relationshipReopenIndicator", "cust:Profile:cust:relationshipReopenIndicator")
    map.put("closeInitiatedBy", "cust:Profile:cust:closeInitiatedBy")
    map.put("trackingId", "ns:originationDetails:ns:trackingId")
    map
  }

  def validateCUSTOMERProfile(datama: java.util.HashMap[String, String], validation_property: Properties, tx: Message, count: Integer): ArrayBuffer[ForError] = {
    val util = new Util()
    var error = ArrayBuffer[ForError]()
     val profileID = tx.values.get(datama.get("profileID") + "#1#").get
    val relationshipID = tx.values.get(datama.get("relationshipID") + "#1#").get
    val messageSequenceNumber = tx.values.get(datama.get("messageSequenceNumber") + "#1#").get
    val tablename = "CustomerProfileBusiness"
    //1
    if (tx.values.contains(datama.get("countryCode") + "#" + count + "#")) {
      val countryCode = tx.values.get(datama.get("countryCode") + "#" + count + "#").get
      val status = util.checkDataLength(countryCode, validation_property.getProperty("COMPANY_ID"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, countryCode, "countryCode", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //2
    if (tx.values.contains(datama.get("profileID") + "#" + count + "#")) {
      val profileID = tx.values.get(datama.get("profileID") + "#" + count + "#").get
      val status = util.checkDataLength(profileID, validation_property.getProperty("PROFILE_ID"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, profileID, "profileID", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //3
    if (tx.values.contains(datama.get("relationshipStatus") + "#" + count + "#")) {
      val relationshipStatus = tx.values.get(datama.get("relationshipStatus") + "#" + count + "#").get
      val status = util.checkDataLength(relationshipStatus, validation_property.getProperty("REL_STATUS"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, relationshipStatus, "relationshipStatus", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //4
    if (tx.values.contains(datama.get("armCode") + "#" + count + "#")) {
      val armCode = tx.values.get(datama.get("armCode") + "#" + count + "#").get
      val status = util.checkDataLength(armCode, validation_property.getProperty("ARM_CODE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, armCode, "armCode", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //5
    if (tx.values.contains(datama.get("segmentCode") + "#" + count + "#")) {
      val segmentCode = tx.values.get(datama.get("segmentCode") + "#" + count + "#").get
      val status = util.checkDataLength(segmentCode, validation_property.getProperty("SEGMENT_CODE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, segmentCode, "segmentCode", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //6
    if (tx.values.contains(datama.get("subSegmentCode") + "#" + count + "#")) {
      val subSegmentCode = tx.values.get(datama.get("subSegmentCode") + "#" + count + "#").get
      val status = util.checkDataLength(subSegmentCode, validation_property.getProperty("CUST_SEGMENT_CODE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, subSegmentCode, "subSegmentCode", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //7
    if (tx.values.contains(datama.get("serviceIndCode") + "#" + count + "#")) {
      val serviceIndCode = tx.values.get(datama.get("serviceIndCode") + "#" + count + "#").get
      val status = util.checkDataLength(serviceIndCode, validation_property.getProperty("SERVICE_INDICATOR"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, serviceIndCode, "serviceIndCode", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //8
    if (tx.values.contains(datama.get("referralID") + "#" + count + "#")) {
      val referralID = tx.values.get(datama.get("referralID") + "#" + count + "#").get
      val status = util.checkDataLength(referralID, validation_property.getProperty("REFERRAL_ID"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, referralID, "referralID", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //9
    if (tx.values.contains(datama.get("sourcingID") + "#" + count + "#")) {
      val sourcingID = tx.values.get(datama.get("sourcingID") + "#" + count + "#").get
      val status = util.checkDataLength(sourcingID, validation_property.getProperty("SOURCING_ID"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, sourcingID, "sourcingID", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //10
    if (tx.values.contains(datama.get("closingID") + "#" + count + "#")) {
      val closingID = tx.values.get(datama.get("closingID") + "#" + count + "#").get
      val status = util.checkDataLength(closingID, validation_property.getProperty("CLOSING_ID"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, closingID, "closingID", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //11
    if (tx.values.contains(datama.get("acquisitionChannel") + "#" + count + "#")) {
      val acquisitionChannel = tx.values.get(datama.get("acquisitionChannel") + "#" + count + "#").get
      val status = util.checkDataLength(acquisitionChannel, validation_property.getProperty("ACQUISTION_CHANNEL_ID"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, acquisitionChannel, "acquisitionChannel", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }

    //12
    if (tx.values.contains(datama.get("homeBranch") + "#" + count + "#")) {
      val homeBranch = tx.values.get(datama.get("homeBranch") + "#" + count + "#").get
      val status = util.checkDataLength(homeBranch, validation_property.getProperty("HOME_BRANCH"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, homeBranch, "homeBranch", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    } //13
    if (tx.values.contains(datama.get("closeInitiatedBy") + "#" + count + "#")) {
      val closeInitiatedBy = tx.values.get(datama.get("closeInitiatedBy") + "#" + count + "#").get
      val status = util.checkDataLength(closeInitiatedBy, validation_property.getProperty("CLOSE_INITIATED_BY"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, closeInitiatedBy, "closeInitiatedBy", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }

    //14
    if (tx.values.contains(datama.get("relationshipClosedReasonCode") + "#" + count + "#")) {
      val relationshipClosedReasonCode = tx.values.get(datama.get("relationshipClosedReasonCode") + "#" + count + "#").get
      val status = util.checkDataLength(relationshipClosedReasonCode, validation_property.getProperty("CLOSE_REASON_CODE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, relationshipClosedReasonCode, "relationshipClosedReasonCode", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //15
    if (tx.values.contains(datama.get("dataSyncflag") + "#" + count + "#")) {
      val dataSyncflag = tx.values.get(datama.get("dataSyncflag") + "#" + count + "#").get
      val status = util.checkDataLength(dataSyncflag, validation_property.getProperty("DATA_SYNC_FLAG"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, dataSyncflag, "dataSyncflag", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //16
    if (tx.values.contains(datama.get("relationshipReopenIndicator") + "#" + count + "#")) {
      val relationshipReopenIndicator = tx.values.get(datama.get("relationshipReopenIndicator") + "#" + count + "#").get
      val status = util.checkDataLength(relationshipReopenIndicator, validation_property.getProperty("REOPENED_INDICATOR"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, relationshipReopenIndicator, "relationshipReopenIndicator", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //17
    if (tx.values.contains(datama.get("activationDate") + "#" + count + "#")) {
      val activationDate = tx.values.get(datama.get("activationDate") + "#" + count + "#").get
      val status = util.checkDataLength(activationDate, validation_property.getProperty("RELSTATUS_CHANGE_DATE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, activationDate, "activationDate", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //18
    if (tx.values.contains(datama.get("profileCreatedate") + "#" + count + "#")) {
      val profileCreatedate = tx.values.get(datama.get("profileCreatedate") + "#" + count + "#").get
      val status = util.checkDataLength(profileCreatedate, validation_property.getProperty("PROFILE_CREATE_DATE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, profileCreatedate, "profileCreatedate", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //19
    if (tx.values.contains(datama.get("profileActivatedate") + "#" + count + "#")) {
      val profileActivatedate = tx.values.get(datama.get("profileActivatedate") + "#" + count + "#").get
      val status = util.checkDataLength(profileActivatedate, validation_property.getProperty("PROFILE_ACTIVATE_DATE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, profileActivatedate, "profileActivatedate", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //20
    if (tx.values.contains(datama.get("referralRelationshipNo") + "#" + count + "#")) {
      val referralRelationshipNo = tx.values.get(datama.get("referralRelationshipNo") + "#" + count + "#").get
      val status = util.checkDataLength(referralRelationshipNo, validation_property.getProperty("REFERRED_BY_RELATIONSHIP_NO"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, referralRelationshipNo, "referralRelationshipNo", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //21
    if (tx.values.contains(datama.get("ibnkInd") + "#" + count + "#")) {
      val ibnkInd = tx.values.get(datama.get("ibnkInd") + "#" + count + "#").get
      val status = util.checkDataLength(ibnkInd, validation_property.getProperty("IBANKING_INDICATOR"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, ibnkInd, "ibnkInd", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //22
    if (tx.values.contains(datama.get("phonebankingId") + "#" + count + "#")) {
      val phonebankingId = tx.values.get(datama.get("phonebankingId") + "#" + count + "#").get
      val status = util.checkDataLength(phonebankingId, validation_property.getProperty("PHONE_BANKING_INDICATOR"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, phonebankingId, "phonebankingId", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //23
    if (tx.values.contains(datama.get("profileClosedate") + "#" + count + "#")) {
      val profileClosedate = tx.values.get(datama.get("profileClosedate") + "#" + count + "#").get
      val status = util.checkDataLength(profileClosedate, validation_property.getProperty("PROFILE_CLOSE_DATE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        val relationshipStatus = tx.values.get(datama.get("relationshipStatus") + "#" + count + "#").get
        error += ForError(status, profileClosedate, "profileClosedate", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //24
    if (tx.values.contains(datama.get("referralName") + "#" + count + "#")) {
      val referralName = tx.values.get(datama.get("referralName") + "#" + count + "#").get
      val status = util.checkDataLength(referralName, validation_property.getProperty("REFERRED_BY_NAME"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, referralName, "referralName", tablename, profileID, relationshipID, messageSequenceNumber)
      }

    }
    //25
    //    if (tx.values.contains(datama.get("date") + "#" + count + "#")) {
    //      val status = util.checkDataLength(date, validation_property.getProperty("EXEC_DATE"))
    //      if (status == "data_length_isuee" || status == "data_type_isuee") {
    //        error += ForError(status, date, "date", tablename, profileID, relationshipID, messageSequenceNumber)
    //      }
    //
    //    }

    error
  }

}