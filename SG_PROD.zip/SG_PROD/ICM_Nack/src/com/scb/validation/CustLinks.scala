package com.scb.validation

import java.util.Properties
import org.apache.log4j.Logger
import collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer
import com.scb.icm.Message
class CustLinks {
  def dataMapping(): java.util.HashMap[String, String] = {
    val map = new java.util.HashMap[String, String]()
    map.put("operationMode", "cust:RelationshipLinks:cust:operationMode")
    map.put("relationTypeCode", "cust:RelationshipLinks:cust:relationTypeCode")
    map.put("linkedRelationshipName", "cust:RelationshipLinks:cust:linkedRelationshipName")
    map.put("linkedRelationshipNO", "cust:RelationshipLinks:cust:linkedRelationshipNO")
    map.put("profileID", "cust:ProfileUniqueId:cust:profileID")
    map.put("relationshipID", "cust:ProfileUniqueId:cust:relationshipID")
    map.put("messageSequenceNumber", "cust:ProfileUniqueId:cust:messageSequenceNumber")
    map.put("countryCode", "ns:messageSender:ns:countryCode")
    map.put("messageTimestamp", "ns:originationDetails:ns:messageTimestamp")
    map
  }

  def validateRecods(datama: java.util.HashMap[String, String], validation_property: Properties, tx: Message, count: Integer): ArrayBuffer[ForError] = {
    val util = new Util()
    var error = ArrayBuffer[ForError]()
    val profileID = tx.values.get(datama.get("profileID") + "#1#").get
    val relationshipID = tx.values.get(datama.get("relationshipID") + "#1#").get
    val messageSequenceNumber = tx.values.get(datama.get("messageSequenceNumber") + "#1#").get
    val tablename = "CustLinks"
    //1
    if (tx.values.contains(datama.get("relationTypeCode") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("relationTypeCode") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("RELATIONSHIP_TYPE_CODE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "relationTypeCode", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }

    //2
    if (tx.values.contains(datama.get("linkedRelationshipNO") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("linkedRelationshipNO") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("LINK_RELATIONSHIP_NUMBER"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "linkedRelationshipNO", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }

    error
  }
}