package com.scb.validation

import java.util.Properties
import org.apache.log4j.Logger
import collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer
import com.scb.icm.Message

class DocumentInformation {
  def dataMapping(): java.util.HashMap[String, String] = {
    val map = new java.util.HashMap[String, String]()
    map.put("operationMode", "cust:DocumentInformation:cust:operationMode")
    map.put("documentCategory", "cust:DocumentInformation:cust:documentCategory")
    map.put("documentName", "cust:DocumentInformation:cust:documentName")
    map.put("documentNumber", "cust:DocumentInformation:cust:documentNumber")
    map.put("documentSequenceNumber", "cust:DocumentInformation:cust:documentSequenceNumber")
    map.put("documentExpiryDate", "cust:DocumentInformation:cust:documentExpiryDate")
    map.put("documentDueDate", "cust:DocumentInformation:cust:documentDueDate")
    map.put("documentReceivedDate", "cust:DocumentInformation:cust:documentReceivedDate")
    map.put("documentSignatoryDate", "cust:DocumentInformation:cust:documentSignatoryDate")
    map.put("documentEvidenceLink", "cust:DocumentInformation:cust:documentEvidenceLink")
    map.put("countryOfTaxResidence", "cust:DocumentInformation:cust:countryOfTaxResidence")
    map.put("countryofTreaty", "cust:DocumentInformation:cust:countryofTreaty")
    map.put("W8NsupportDocumentIndicator", "cust:DocumentInformation:cust:W8NsupportDocumentIndicator")
    map.put("reasonCode", "cust:DocumentInformation:cust:reasonCode")
    map.put("comments", "cust:DocumentInformation:cust:comments")
    map.put("expiryCheckFlag", "cust:DocumentInformation:cust:expiryCheckFlag")
    map.put("profileID", "cust:ProfileUniqueId:cust:profileID")
    map.put("relationshipID", "cust:ProfileUniqueId:cust:relationshipID")
    map.put("messageSequenceNumber", "cust:ProfileUniqueId:cust:messageSequenceNumber")
    //map.put("sequenceNo", "cust:DocumentInformation:cust:sequenceNo")
    map.put("countryCode", "ns:messageSender:ns:countryCode")
    map.put("messageTimestamp", "ns:originationDetails:ns:messageTimestamp")
    map
  }

  def validateRecods(datama: java.util.HashMap[String, String], validation_property: Properties, tx: Message, count: Integer): ArrayBuffer[ForError] = {
    val util = new Util()
    var error = ArrayBuffer[ForError]()
    val profileID = tx.values.get(datama.get("profileID") + "#1#").get
    val relationshipID = tx.values.get(datama.get("relationshipID") + "#1#").get
    val messageSequenceNumber = tx.values.get(datama.get("messageSequenceNumber") + "#1#").get
    val tablename = "DocumentInformation"
    //1
    if (tx.values.contains(datama.get("documentCategory") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("documentCategory") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("DOCUMENT_CATEGORY"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "documentCategory", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //2
    if (tx.values.contains(datama.get("documentName") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("documentName") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("DOCUMENT_TYPE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "documentName", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //3
    if (tx.values.contains(datama.get("documentSequenceNumber") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("documentSequenceNumber") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("SEQUENCE_NUMBER"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "documentSequenceNumber", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //4
    if (tx.values.contains(datama.get("documentNumber") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("documentNumber") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("DOCUMENT_NUMBER"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "documentNumber", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    } //5
    if (tx.values.contains(datama.get("documentExpiryDate") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("documentExpiryDate") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("DOCUMENT_EXPIRY_DATE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "documentExpiryDate", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    } //6
    if (tx.values.contains(datama.get("documentDueDate") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("documentDueDate") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("DOCUMENT_DUE_DATE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "documentDueDate", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //7
    if (tx.values.contains(datama.get("documentReceivedDate") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("documentReceivedDate") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("DOCUMENT_RECEIVE_DATE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "documentReceivedDate", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //8
    if (tx.values.contains(datama.get("documentSignatoryDate") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("documentSignatoryDate") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("DOCUMENT_SIGNATORY_DATE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "documentSignatoryDate", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //9
    if (tx.values.contains(datama.get("documentEvidenceLink") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("documentEvidenceLink") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("DOCUMENT_EVIDENCE_LINK"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "documentEvidenceLink", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //10
    if (tx.values.contains(datama.get("countryOfTaxResidence") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("countryOfTaxResidence") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("TAX_RESIDENT_COUNTRY"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "countryOfTaxResidence", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //11
    if (tx.values.contains(datama.get("countryofTreaty") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("countryofTreaty") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("COUNTRY_TREATY"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "countryofTreaty", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //12
    if (tx.values.contains(datama.get("W8NsupportDocumentIndicator") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("W8NsupportDocumentIndicator") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("W8N_SUPPORT_DOC_IND"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "W8NsupportDocumentIndicator", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //13
    if (tx.values.contains(datama.get("reasonCode") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("reasonCode") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("DOCUMENT_REASON_CODE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "reasonCode", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //14
    if (tx.values.contains(datama.get("comments") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("comments") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("DOCUMENT_REMARKS"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "comments", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //15
    if (tx.values.contains(datama.get("expiryCheckFlag") + "#" + count + "#")) {
      val columnvalue = tx.values.get(datama.get("expiryCheckFlag") + "#" + count + "#").get
      val status = util.checkDataLength(columnvalue, validation_property.getProperty("EXPIRY_CHECK_OVERRIDE"))
      if (status == "data_length_isuee" || status == "data_type_isuee") {
        error += ForError(status, columnvalue, "expiryCheckFlag", tablename, profileID, relationshipID, messageSequenceNumber)
      }
    }
    //16
   // if (tx.values.contains(datama.get("sequenceNo") + "#" + count + "#")) {
   //   val columnvalue = tx.values.get(datama.get("sequenceNo") + "#" + count + "#").get
   //   val status = util.checkDataLength(columnvalue, validation_property.getProperty("SEQUENCE_NUMBER"))
   //   if (status == "data_length_isuee" || status == "data_type_isuee") {
   //     error += ForError(status, columnvalue, "sequenceNo", tablename, profileID, relationshipID, messageSequenceNumber)
   //   }
   // }
    error
  }
}