package com.scb.validation

import java.util.Properties
import org.apache.log4j.Logger
import collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer
case class ForError(error_type: String, column_value: String, coumn_name: String, table_name: String, profileID: String, relationshipID: String, messageSequenceNumber: String)
class Util {

  def checkDataLength(variable: String, datavalid: String): String = {
    var returnval = ""
    val datava = datavalid.split("_")
    var ss = datava(0) match {
      case "VARCHAR" => {
        val len = datava(1).toInt
        if (variable.length <= len) {
          returnval = "no_isseue"
        } else {
          returnval = "data_length_isuee"
        }
      }
      case "SMALLINT" => {
        try {
          val vv = Integer.parseInt(variable)
          val vvv = vv.asInstanceOf[Int]
          returnval = "no_isseue"
        } catch {
          case e: Exception => {
            returnval = "data_type_isuee"
            println("Exception--Int")
          }
        }
      }
      case "DECIMAL" => {
        try {
          var float_val = variable
          if (float_val.trim.isEmpty) {
            float_val = "0"
          }
          val vv = float_val.toFloat
          returnval = "no_isseue"
        } catch {
          case e: Exception => {
            returnval = "data_type_isuee"
            println("Exception--DECIMAL")
          }
        }
      }
    }
    returnval
  }

}