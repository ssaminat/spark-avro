package org.capgemini.mrapid.processing.metadata;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.hive.HiveContext;

public class parallelProcessingQueries {
	public static void main(String args[])
	{
		System.out.println("sddd");
		SparkConf conf = new SparkConf().setAppName("practiceavro").setMaster("local");
		final JavaSparkContext sparkContext =new JavaSparkContext(new SparkConf()
	    .setAppName("practiceavro").setMaster("local"));
		SQLContext sqlContext = new org.apache.spark.sql.SQLContext(sparkContext);
final HiveContext hc =new HiveContext(sparkContext);
	    ExecutorService executorService = Executors.newFixedThreadPool(2);
	    Future<Long> future1 = executorService.submit(new Callable<Long>() {
	        public Long call() throws Exception {
	        	DataFrame df=hc.sql("select * from rcms.test1");
				return df.count();
	        }
	    });
	    Future<Long> future2 = executorService.submit(new Callable<Long>() {
	        public Long call() throws Exception {
	        	DataFrame df1=hc.sql("select * from rcms.test");
	            return df1.count();
	        }
	    });
	    try {
			System.out.println("File1:"+future1.get());
		    System.out.println("File2:"+future2.get());

		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		}
	    executorService.shutdown();
}
}
