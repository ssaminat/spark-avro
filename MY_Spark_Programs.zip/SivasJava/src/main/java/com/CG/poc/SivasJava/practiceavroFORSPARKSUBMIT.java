package org.capgemini.mrapid.processing.metadata;
//import com.databricks.spark.avro.*;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.*;
import org.apache.spark.sql.hive.HiveContext;
import org.capgemini.mrapid.processing.util.Singleton;

public class practiceavroFORSPARKSUBMIT {
public static void main(String args[])
{
	System.out.println("sddd");
	//SparkConf conf = new SparkConf().setAppName("practiceavro").setMaster("local");
	//JavaSparkContext sparkContext =new JavaSparkContext(new SparkConf()
    //.setAppName("practiceavro").setMaster("local"));
	//SQLContext sqlContext = new org.apache.spark.sql.SQLContext(sparkContext);
//SparkConf conf1=Singleton.getSparkConf();
	JavaSparkContext sparkContext=Singleton.getJavaSparkContext();
SQLContext sqlContext = new SQLContext(sparkContext);
//HiveContext hive = Singleton.getHiveContext();
  //DataFrame df1 = sqlContext.read().format("com.databricks.spark.avro").load("D:/Users/ssaminat/Desktop/Avroexperiment/avroinput/000000_0_copy_12.avro");
//DataFrame df1 = sqlContext.read().format("com.databricks.spark.avro").load("hdfs://ip-172-16-1-44.ec2.internal:8020/user/centos/mrapid/hive/data/avro/DOTOPAL/BH/MCHGDTL/ods=2016-11-18/000000_0_copy_1");
//DataFrame df1 = sqlContext.read().format("com.databricks.spark.avro").load("D:/Users/ssaminat/Desktop/Inputavrofiles/stg_oninfo_av_cp/staging/iii.avro");
System.out.println("before avro");
//DataFrame df1 = sqlContext.read().format("com.databricks.spark.avro").load("hdfs://ip-172-16-1-44.ec2.internal:8020/user/centos/mrapid/hive/data/avro/DOTOPAL/BH/MCHGDTL/ods=2016-11-18/000000_0_copy_1");
DataFrame df1 = sqlContext.read().format("com.databricks.spark.avro").load("file:///home/centos/jar/000000_0_copy_1.avro");
System.out.println("schema + Data ......................");
df1.printSchema();
df1.show();
System.out.println("schema + Data ......................");

DataFrame df2 =df1.select("rowid");
// use datum
//df1.registerTempTable("avrotable");
//DataFrame d2=sqlContext.sql("Select * from avrotable");
//d2.show();
/*JavaRDD<Integer> rdd1 = df2.javaRDD().map(new Function<Row,Integer>()
		{
	public Integer call(Row s)
	{
		return s.length();
	}
		});*/
//println("Loading " + rdd1.count + " records from " + inStream)
//df1.write().format("com.databricks.spark.avro").save("file:///home/centos/jar/output");

System.out.println("ddddddddddddd: "+df1.select("rowid"));

//System.out.println("ddddddddddddd: "+df1.show());
//System.out.println(df1.count());

//df1.show();
//df1.filter("country = CN").write().format("com.databricks.spark.avro").save("D:/Users/ssaminat/Desktop/Avroexperiment/output/");
}

}
