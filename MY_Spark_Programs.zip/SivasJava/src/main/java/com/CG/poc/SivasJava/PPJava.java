package com.CG.poc.SivasJava;

import java.util.Arrays;

import org.apache.spark.SparkConf;
import org.apache.spark.SparkContext;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.api.java.function.PairFunction;

import scala.Tuple1;
import scala.Tuple2;

/*import org.apache.spark.api.java.JavaRDD;
 import org.apache.spark.SparkConf; 
 */
public class PPJava {
	public static void main(String[] args) throws Exception {

		SparkConf conf = new SparkConf().setAppName("PPJava")
				.setMaster("local");
		JavaSparkContext sc = new JavaSparkContext(conf);
		JavaRDD<String> input = sc
				.textFile("D:/Users/ssaminat/Downloads/inputdir1");
		JavaRDD<String> input1 = input.flatMap(new FlatMapFunction<String,String>()
				{
			public Iterable<String> call(String s)
			{
				return Arrays.asList(s.split(" "));
			}
				});
		JavaPairRDD<String, Integer> input2 = input1
				.mapToPair(new PairFunction<String, String, Integer>() {
					public Tuple2<String, Integer> call(String x) {
						return new Tuple2(x, 1);
					}
				});
		JavaPairRDD<String, Integer> input3 = input2
				.reduceByKey(new Function2<Integer, Integer, Integer>() {
					public Integer call(Integer x, Integer y) {
						return x + y;
					}
				});
		input3.saveAsTextFile("D:/Users/ssaminat/Downloads/outputdir1/");

	}

	class FlatMapImpl implements FlatMapFunction<String, String> {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		public Iterable<String> call(String t) throws Exception {
			return Arrays.asList(t.split(" "));
		}

	}
}