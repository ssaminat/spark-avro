package com.CG.sparksql.Sparksql1stprogram
import org.apache.spark
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD.rddToPairRDDFunctions
import org.apache.spark.SparkContext;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SQLContext;
//import org.apache.spark.sql.hive.HiveContext;
//import org.apache.spark.sql.SparkSession
object SparkSQLprg {
 /* val spark = SparkSession
  .builder()
  .appName("Spark SQL basic example")
  .config("spark.some.config.option", "some-value")
  .getOrCreate()*/
  println("hiiiiii")
  def main(args: Array[String]) = {
println("hiiiiii")
   val conf = new SparkConf()
      .setAppName("SparkSQLprg")
      .setMaster("local")
      val sc = new SparkContext(conf) // An existing SparkContext.
val sqlContext = new org.apache.spark.sql.SQLContext(sc)

 // val sc: SparkContext
//val df = sqlContext.read.json("examples/src/main/resources/people.json")
val result = sqlContext.sql("select * from cgfspoc5.stg_eod_av")
val d=result.map(x => x(0))
for(dd <- d)
{
println(d)
}
}
}
  