package com.CG.Scalaprogram
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.hive.HiveContext
import java.io.File
import java.io._

object hello2 {

  def main(args: Array[String]) {
    val conf = new SparkConf()
      .setAppName("processing_filterdata")
      .setMaster("local")
    val sparkContext = new SparkContext(conf)
    val hiveContext = new HiveContext(sparkContext)
    hiveContext.read
     //   val sqlContext = new sqlContext(sparkContext)

    val df1 = hiveContext.sql("select * from cgfspoc5.meta_table1")
    val df2 = df1.columns
    val avtablenames = df1.select(df2(0))
    val orctablenames = df1.select(df2(1))
    val primarykey = df1.select(df2(2))
    val maxdatecolumn = df1.select(df2(3))

    val avtablenameslist = avtablenames.collectAsList()
    val orctablenameslist = orctablenames.collectAsList()
    val primarykeylist = primarykey.collectAsList()
    val maxdatecolumnlist = maxdatecolumn.collectAsList()
    for (a <- 0 to (avtablenameslist.size() - 1)) {
      var PKeys=primarykeylist.get(a).toString.replace("[", "").replace("]", "")
      var len =PKeys.split(",").length
      var PKey =PKeys.split(",")
      var pk1=PKey(0)
	    var pk2=PKey(1)  
	    var hh=primarykeylist.get(a).toString()
	    var builder = getpk(hh)
	    println("builder inside main method: "+builder)
      var t1 = hiveContext.sql("select " + primarykeylist.get(a).toString.replace("[", "").replace("]", "") + "," + "max(" + maxdatecolumnlist.get(a).toString.replace("[", "").replace("]", "") + ") as c_transactionid from " + avtablenameslist.get(a).toString.replace("[", "").replace("]", "") + " GROUP BY " + primarykeylist.get(a).toString.replace("[", "").replace("]", ""))
      println(t1)
      t1.registerTempTable("processtable1")
      var t2 = hiveContext.sql("select * from " + avtablenameslist.get(a).toString.replace("[", "").replace("]", ""))
      println(t2)
      t2.registerTempTable("processtable2")
      var t3 = hiveContext.sql("select a.* from processtable2 a join processtable1 b on  " + builder + " and a." + maxdatecolumnlist.get(a).toString.replace("[", "").replace("]", "") + "= b." + maxdatecolumnlist.get(a).toString.replace("[", "").replace("]", "") + " and a.c_operationtype <>'D' ")
      println(t3)
      t3.registerTempTable("processtable3")

      hiveContext.sql("insert into table " + orctablenameslist.get(a).toString.replace("[", "").replace("]", "") + " select * from processtable3")

    }
    
count_validation(hiveContext)
sparkContext.stop
  }
  def getpk(ff : String): String=
{
   var PKeys=ff.replace("[", "").replace("]", "")
   var Pkey =PKeys.split(",")
   var len =PKeys.split(",").length
     var l: List[String] = List()
     var ggg =new String
     val builder = StringBuilder.newBuilder
     for(pk <- Pkey)
     {
     if(Pkey(len-1)==pk)
     {
     ggg = "a." +pk + "=b." +pk
     }
     else
     {
     ggg= "a." +pk + "=b." +pk +" and "     
     }
     builder.append(ggg)
     }
   println("builder inside pkk: "+builder.toString())

   return builder.toString()
}
  def count_validation(hc : HiveContext)
  {
    
    var recon =hc.sql("select * from cgfspoc5.stg_EOD_ProcessRecon")
    var reconcolumn =recon.columns
    var column1 = recon.select(reconcolumn(0)).collectAsList()
    var column2 = recon.select(reconcolumn(1)).collectAsList()
    val file = new File("file:///opt/cgfspoc5/poc/A/input/countstatusfile")
    val bw = new BufferedWriter(new FileWriter(file))

    for(a <- 0 to column1.size()-1)
    {
      var table_name=column1.get(a).toString.replace("[", "").replace("]", "")
      var count=column2.get(a).toString.replace("[", "").replace("]", "")
      var table_name1 =table_name.replace("_av", "_orc")
      var count1=hc.sql("select count(*) from cgfspoc5."+table_name1)
      if(count == count1)
      {
        bw.write(table_name+"|"+count+"||"+table_name1+"|"+count1+"||"+"Recon Success")
      }
      else
      {
        bw.write(table_name+"|"+count+"||"+table_name1+"|"+count1+"||"+"Recon Failure")

      }
    }
bw.close
  }
  
  
}