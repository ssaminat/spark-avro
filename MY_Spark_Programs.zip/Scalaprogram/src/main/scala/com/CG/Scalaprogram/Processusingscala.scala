package com.CG.Scalaprogram
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD.rddToPairRDDFunctions
import org.apache.spark.sql.hive.HiveContext;
import org.apache.spark.api.java.JavaRDD
import org.apache.spark.sql.Row
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.LocatedFileStatus;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.RemoteIterator;
import java.util.List
import java.io.File
import java.io._
import java.util.HashMap
import java.lang.Iterable;
import java.util.Arrays.ArrayList
import java.util.Arrays.ArrayList
import java.util.ArrayList
import scala.collection.mutable.ArrayBuffer
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.DataFrameReader
import com.databricks.spark.avro._
import org.apache.spark.sql.SQLContext
import  org.apache.hadoop.fs.{FileSystem,Path}


object Processusingscala {
  def main(args: Array[String]){
     println("Hwwwi");
        val conf = new SparkConf()
      .setAppName("CHuma")
      .setMaster("local")    
      val sc = new SparkContext(conf)
	val hc = new HiveContext(sc);
   val sqlContext = new org.apache.spark.sql.SQLContext(sc)
val result = hc.sql("select max(batch_date) from cgfspoc5.stg_eod_av")
result.show()
var maxdate = result.head.get(0).toString()
    	//Path path = new Path("hdfs://horton-nn-1.aws.sho.com:8020/apps/hive/warehouse/staging");
       val path = new File("hdfs://horton-nn-1.aws.sho.com:8020/apps/hive/warehouse/staging");
var files = path.listFiles();
/*FileSystem.get( sc.hadoopConfiguration ).listStatus( new Path("hdfs://horton-nn-1.aws.sho.com:8020/apps/hive/warehouse/staging")).foreach(    
    x => println(x.getPath )
    val file=sc.textfile(x)
)*/



}
}