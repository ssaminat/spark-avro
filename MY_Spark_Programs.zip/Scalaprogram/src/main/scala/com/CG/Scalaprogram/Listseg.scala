package com.CG.Scalaprogram
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD.rddToPairRDDFunctions
import org.apache.spark.sql.hive.HiveContext;
import org.apache.spark.sql.DataFrame
import com.sun.org.apache.xalan.internal.xsltc.compiler.ForEach

class Listseg {

 
 		 var primarykeylist = "[aaaaaaaaaaa,bbbbbbbbbbbbbbb]"
                                                  //> primarykeylist  : String = [aaaaaaaaaaa,bbbbbbbbbbbbbbb]
     var PKeys=primarykeylist.toString.replace("[", "").replace("]", "")
                                                  //> PKeys  : String = aaaaaaaaaaa,bbbbbbbbbbbbbbb
		 var Pkey =PKeys.split(",")       //> Pkey  : Array[String] = Array(aaaaaaaaaaa, bbbbbbbbbbbbbbb)
     var len =PKeys.split(",").length             //> len  : Int = 2
     var l: List[String] = List()                 //> l  : List[String] = List()
     var ggg =new String                          //> ggg  : String = ""
     var gggg =new String                         //> gggg  : String = ""
     val builder = StringBuilder.newBuilder       //> builder  : StringBuilder = 
     ggg="ff"
     for(pk <- Pkey)
     {
    // println(Pkey(len-1))
    // println(pk)
     if(Pkey(len-1)==pk)
     {
    /// println("inside if "+pk)
    // println("1")
     ggg = "a." +pk + "=b." +pk
     }
     else
     {
     //println("inside else "+pk)
          //println("2")
     
     ggg= "a." +pk + "=b." +pk +" and "
     
     }
     builder.append(ggg)
     l = ggg :: l
     // l =List() ::: List(ggg)
     
    
}
println("gggg: "+builder)                         //> gggg: a.aaaaaaaaaaa=b.aaaaaaaaaaa and a.bbbbbbbbbbbbbbb=b.bbbbbbbbbbbbbbb

 var lll=l.reverse                                //> lll  : List[String] = List("a.aaaaaaaaaaa=b.aaaaaaaaaaa and ", a.bbbbbbbbbb
                                                  //| bbbbb=b.bbbbbbbbbbbbbbb)
// for( j <- 0 to  len-1)
// {
 //var fi = lll(j).append(
// }
     
}
