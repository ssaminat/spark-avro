package com.CG.spark
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD.rddToPairRDDFunctions
import java.io.File
import java.io._
object WordCount {
  def main(args: Array[String]) = {
println("ffffff")
    val conf = new SparkConf()
      .setAppName("WordCount")
      .setMaster("local")    
      val sc = new SparkContext(conf)
    val test = sc.textFile("file:///opt/cgfspoc5/poc/word.txt")
//test.map{ll => ll.split(" ")}
    test.flatMap { line => 
      line.split(" ") 
    }
     val test1= test.map { word => 
        (word, 1) 
      }
     test1 .reduceByKey(_ + _) 
      .saveAsTextFile("file:///opt/cgfspoc5/poc/output2221") 

    sc.stop
/*        val file = new File("file:///opt/cgfspoc5/poc/output2221")
    val bw = new BufferedWriter(new FileWriter(file))
    bw.write("hiiiiiiiiiiii")
*/
  }
}

