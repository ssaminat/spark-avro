/*package com.CG.spark
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD.rddToPairRDDFunctions
import java.io.File
import java.io._
import java.util.HashMap
import java.lang.Iterable;
import java.util.Arrays.ArrayList
import java.util.Arrays.ArrayList
import java.util.ArrayList
import scala.collection.mutable.ArrayBuffer

object Parallelprocessing1 {
  
  def main(args: Array[String]) = {
println("zzzzzzzzzzzzzzzzzzzzzzz")
    val conf = new SparkConf()
      .setAppName("ParallelProcessing")
      .setMaster("local")    
      val sc = new SparkContext(conf)

    val test = sc.wholeTextFiles("D:/Users/ssaminat/Downloads/inputdir")    
    val test1 =test.flatMapValues{value =>
      value.split(" ") 
      }
    val test2=test1.mapValues{value =>(value,1)
      
    }
    val files = test.map { case (filename, content) => filename}
    val contents = test.map{case (filename,content) => content.toUpperCase()}
    val contents1 = test2.map{case (filename,content) => content}
    val contents2 = contents1.reduceByKey(_ + _) 
    val content4=contents2.map( (f,c) => c.split(" "))
    val content4=contents2.collect
    val contents3=contents2.groupByKey()
      val nums: Map[String, Int] = Map()
String str="fff"
for(content5 <- content4)
{
  nums.addString(content5)
}
    
    //val test4=test3.map{case (filename,content) => content}
  //  test2.mapValues{value=>value.split()
      
 //   }+
    contents2.saveAsTextFile("D:/Users/ssaminat/Downloads/Downloadsoutput2chuma4.txt")
    var count =0
    map<String,Integer> wordCounts = new HashMap<String, Integer>();

  var list = new java.util.ArrayList[String]()
var fruits = ArrayBuffer[String]()
   for (s <- files.collect) {  
     
     if(s.contains("inputdir"))
     {
       val path =s.substring(6,34)+"/output/"+"output-"+count
       //fruits.addString(path.toString())
val file = new File(s.substring(6,34)+"/output/"+"output-"+count)
val bw = new BufferedWriter(new FileWriter(file))
val sss = contents.collect
  //bw.write(coo(count))
  bw.write(sss(count))
bw.close()
      
   }
     count =count+1
     }
    var count1=0
   for (coo <- contents.collect) {  
    val file = new File(list(count))
val bw = new BufferedWriter(new FileWriter(file))
val sss = contents.collect
  //bw.write(coo(count))
  bw.write(sss(count))
bw.close()
     
     count=count+1
   }
    
    // files.saveAsTextFile("D:/Users/ssaminat/Downloads/Downloadsoutput4.txt") 
    contents2.saveAsTextFile("D:/Users/ssaminat/Downloads/Downloadsoutput2chuma4.txt")
    sc.stop
    

  }
}*/