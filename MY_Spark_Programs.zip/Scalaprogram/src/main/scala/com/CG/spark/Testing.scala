package com.CG.spark

import org.apache.log4j.Logger;
import scala.sys.process._
import java.util.Calendar
import scala.util.Properties
import com.typesafe.config.{ Config, ConfigFactory }
import java.io.File
import org.apache.spark.SparkConf
import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.rdd.RDD.rddToPairRDDFunctions
import org.apache.hadoop.conf.Configuration

object Testing {
	val log = Logger.getLogger(getClass.getName)
			def recon(ar: String*) ={
		val nargs = 4
				if (ar.length < nargs){
					log.error(ar.length + "Parameters are passed: required parameters are 4 : <COUNTRY> <SOURCE> <ORDER DATE> <PARTITION DATE>")
					System.exit(1)
				}
		val country = ar(0).toLowerCase()
				val source = ar(1).toLowerCase()
				val eod_date = ar(2).toLowerCase()
				val ep_name = ar(3).toLowerCase()
				val start_time = Calendar.getInstance().getTime
				println(start_time)
				val config = ConfigFactory.parseFile(new File("set_environment_variables.conf"))
				val app_base_path = config.getString("APPLICATION_BASE_PATH")
				val processing_base_path = config.getString("PROCESSING_BASE_PATH")
				val base_path = app_base_path + "/edmp_data_lake/extended_framework/sourcing/"
				println(ar(0)+":::" + ar(1) +":::" + ar(2) + ":::" + ar(3))
				val REC_VAL_SYSTEM = "EBS"
				val LOG_FILE_PATH = processing_base_path + "/" + source + "/" + country + "logs/eod_reconcilation";
		val OPL_SCRIPT_PATH = app_base_path + "/" + "edmp_data_lake/ebbs_extended_framework/sourcing/operation_metadata_bin"
				log.info("EOD Reconcilation for country started for" +country)
				val HIVE_SCRIPT = app_base_path + "/" + "edmp_data_lake/ebbs_extended_framework/sourcing/common/bin"
						val Conf = new SparkConf().setAppName("Recon Module").setMaster("local")
						val sc = new SparkContext()
								//val sc = new SparkContext()

		val recon_file = sc.textFile("D:/Users/rjittuka/Documents/Recon")
		val recon_pair = recon_file.map(x=> (x.split("\001")(2),x.split("\001")(3))) // changed code
		val incoming_file =sc.wholeTextFiles("D:/Users/rjittuka/Documents/Recon_hourly")
		val output = incoming_file.map{case(k,v) => (k.split("\001")(7),v.split("\\r?\\n"))} 
		output.cache()
		val change_type = output.map{case (k,v) => (k,(v.toList.map( x => x.split("\001")(3))))} //changed code
		val change_delete_account = change_type.map{case(k,v) => (k,(v.filter{ x => x == "D" }).length)}
		val change_valid_count = change_type.map{case(k,v) => (k,(v.filter{ x => x =="A" || x == "I"}).length)}
		val valid_record = change_valid_count.reduceByKey((x,y)=> x+y)
		val deleted_record = change_delete_account.reduceByKey((x,y)=> x+y)
		for ((key,file)<- output){
			for ( i<- 0 until file.length){
				if (file(i).split("\001")(3) == "A" || file(i).split("\001")(3) == "I"){  //changed code
					val path = "C:/Users/rjittuka/" + key + "/" + key + ".txt"
							scala.tools.nsc.io.File(path).appendAll(file(i)+ "\n")
							val conf = new org.apache.hadoop.conf.Configuration()
					val fs = org.apache.hadoop.fs.FileSystem.get(conf)
					try
					{
						val writer = fs.append(new org.apache.hadoop.fs.Path(path))
								writer.write(file(i).getBytes)
								writer.close
					} catch {
					  case t: Throwable => { val writer = fs.create(new org.apache.hadoop.fs.Path(path))
								writer.write(file(i).getBytes)
								writer.close
						}
					}
				}else{
					val path = "D:/Users/rjittuka/Documents/" + key + "/" + key + ".txt"
							scala.tools.nsc.io.File(path).appendAll(file(i)+ "\n")
							val conf = new org.apache.hadoop.conf.Configuration()
					val fs = org.apache.hadoop.fs.FileSystem.get(conf)
					try{
						val writer = fs.append(new org.apache.hadoop.fs.Path(path))
								writer.write(file(i).getBytes)
								writer.close
					} catch {
					case t: Throwable => { val writer = fs.create(new org.apache.hadoop.fs.Path(path))
							writer.write(file(i).getBytes)
							writer.close
					}
					}
				}
			}
		}
	}

	def main(args: Array[String]){
		recon("Germany", "EBBS", "30082016", "30082016")
		val Conf = new SparkConf().setAppName("Recon Module").setMaster("local")
						//val sc = new SparkContext()
	}
}
