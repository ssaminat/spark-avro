/*package com.cg.org.practiceproject;
import org.apache.spark.sql.*;
import org.apache.spark.sql.functions;

public class avroProcessing {
	SparkSession spark = SparkSession.builder().master("local").getOrCreate();
	Dataset<Row> df = spark.read().format("com.databricks.spark.avro")
			  .load("src/test/resources/episodes.avro");

			// Saves the subset of the Avro records read in
			df.filter(functions.expr("doctor > 5")).write()
			  .format("com.databricks.spark.avro")
			  .save("/tmp/output");

}
*/