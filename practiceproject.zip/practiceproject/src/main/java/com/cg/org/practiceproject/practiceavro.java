package com.cg.org.practiceproject;
import com.databricks.spark.avro.*;

import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.*;
import org.apache.spark.SparkConf;
import org.apache.spark.SparkContext;
import org.apache.spark.sql.hive.HiveContext;

import java.io.*;

import org.apache.spark.sql.SQLContext;

class practiceavro {
  //val spark = SparkSession.builder().master("local").getOrCreate()
public static void main(String args[])
{
	System.out.println("sddd");
	//SparkConf conf = new SparkConf().setAppName("practiceavro").setMaster("local");
	JavaSparkContext sparkContext = new JavaSparkContext(new SparkConf()
    .setAppName("practiceavro").setMaster("local"));
SQLContext sqlContext = new SQLContext(sparkContext);
      DataFrame df = sqlContext.read().format("com.databricks.spark.avro").load("D:/Users/ssaminat/Desktop/Avroexperiment/twitter.avsc");
      DataFrame df1 = sqlContext.read().format("com.databricks.spark.avro").load("D:/Users/ssaminat/Desktop/Avroexperiment/twitter.json");

}

}
