

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.hive.HiveContext;

public class parallelProcessingQueries {
	public static void main(String args[])
	{
		System.out.println("sddd");
	      long startTime = System.currentTimeMillis();

		SparkConf conf = new SparkConf().setAppName("practiceavro").setMaster("local");
		final JavaSparkContext sparkContext =new JavaSparkContext(new SparkConf()
	    .setAppName("practiceavro").setMaster("local"));
		SQLContext sqlContext = new org.apache.spark.sql.SQLContext(sparkContext);

final HiveContext hc =new HiveContext(sparkContext);
 final HiveContext hc1 =new HiveContext(sparkContext);
 final HiveContext hc2 =new HiveContext(sparkContext);
 final HiveContext hc3=new HiveContext(sparkContext);
 final HiveContext hc4 =new HiveContext(sparkContext);

 

	    ExecutorService executorService = Executors.newFixedThreadPool(5);
	    Future<Long> future = executorService.submit(new Callable<Long>() {
	        public Long call() throws Exception {
	        	DataFrame df=hc.sql("select * from dotopal_avro.dotopal_bh_mobrmain");
				df.show();
	        	return null;
	        }
	    });
	    Future<Long> future1 = executorService.submit(new Callable<Long>() {
	        public Long call() throws Exception {
	        	DataFrame df=hc.sql("select * from dotopal_avro.dotopal_bh_mcprmain");
	           df.show();
	        	return null;
	        }
	    });
	    Future<Long> future3 = executorService.submit(new Callable<Long>() {
	        public Long call() throws Exception {
	        	DataFrame df=hc.sql("select * from dotopal_avro.dotopal_bh_mobrmain");
				df.show();
	        	return null;
	        }
	    });
	    Future<Long> future4 = executorService.submit(new Callable<Long>() {
	        public Long call() throws Exception {
	        	DataFrame df=hc.sql("select * from dotopal_avro.dotopal_bh_mobrmain");
				df.show();
	        	return null;
	        }
	    });
	    Future<Long> future5 = executorService.submit(new Callable<Long>() {
	        public Long call() throws Exception {
	        	DataFrame df=hc.sql("select * from dotopal_avro.dotopal_bh_mobrmain");
				df.show();
	        	return null;
	        }
	    });
	    try {
			System.out.println("File1:"+future1.get());
		    System.out.println("File2:"+future3.get());

		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		}
	    executorService.shutdown();
	      long stopTime = System.currentTimeMillis();
	      long elapsedTime = stopTime - startTime;
	      System.out.println("--------------------------------------------------------------------------------------------------------------");
	      System.out.println(elapsedTime);

}
}
