package provenance

import cats.data.Writer
import org.apache.spark.rdd.RDD

object Ops {

  implicit class toW(s: String) {
    def ~>[A](rdd: RDD[A]): Writer[List[String], RDD[A]] = Writer(s :: Nil, rdd)
  }

}
