/*
 * Copyright 2017 Standard Chartered Bank
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package models

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.FileSystem
import org.apache.spark.sql.types._
import utils.Constants

import scala.collection.JavaConverters._
import scala.collection.mutable

object XmlParser {

  case class TableKeyColInfo(tableName: String, keyCols: String)

  case class TableSourceInfo(tableName: String, typee: String)

  case class ColTransformationRule(columnName: String, rules: String)

  case class TableTransformationRule(tableName: String, rulesList: List[ColTransformationRule])

  case class Property(name: String, value: String) {
    override def toString: String = {
      "\n<property>\n\t<name>" + name + "</name>\n\t<value>" + value + "</value>\n</property>"
    }
  }

  case class CdcConfiguration(list: List[Property]) {
    override def toString: String = {
      "<configuration>\n" + list.map(_.toString).mkString("") + "\n</configuration>"
    }
  }

  object ColTransformationRule {
    def apply(column: String): ColTransformationRule = {
      val split: Array[String] = column.trim.split(Array('[', ']'))
      new ColTransformationRule(split(0), split(1))
    }
  }

  case class TableConfig(private val _name: String, sourceType: String, keyCols: String, colSchema: String, reconQuery: String, deleteIndex: String, deleteValue: String) {

    val name = _name.toLowerCase

    def isDeltaSource: Boolean = {
      sourceType.equals("delta")
    }

    def isTxnSource: Boolean = {
      sourceType.equals("txn")
    }
  }

  case class ColumnConfig(name: String, typee: String)

  case class ColumnConfigSparkDF(name: String, typee: DataType)

  def fetchColumnConfig(tableConfig: TableConfig): List[ColumnConfig] =
    tableConfig.colSchema.split("\\^").foldRight(Nil: List[ColumnConfig]) {
      (colSchema: String, list: List[ColumnConfig]) =>
        val splitValues: Array[String] = colSchema.split(" ")
        ColumnConfig(splitValues(0), splitValues(1)) :: list
    }

  def fetchKeyIndiciesFromTable(tableConfig: TableConfig): List[Int] = {
    val columnNames: List[String] = fetchColumnConfig(tableConfig).map(_.name)
    tableConfig.keyCols.split(",").foldRight(Nil: List[Int])((x, y) => columnNames.indexOf(x) :: y)
  }

  def parseXmlConfig(tableXml: String, fs: FileSystem): List[TableConfig] = {
    val conf: Configuration = utils.SriUtils.getParamConf(fs, tableXml)

    val patternR = (Constants.PREFIX_CONFIG_EDMHDPIF_TABLE + "(.*)" + Constants.SUFFIX_CONFIG_COLSCHEMA).r
    val parseTableName: String => String = {
      case patternR(name) => name
    }

    val tables: mutable.Map[String, String] = conf.getValByRegex(patternR.toString()).asScala
    tables.keys.foldRight(Nil: List[TableConfig]) {
      (key: String, tableList: List[TableConfig]) =>
        val tableName: String = parseTableName(key)
        val sourceType: String = conf.get(Constants.PREFIX_CONFIG_EDMHDPIF_TABLE + tableName + Constants.SUFFIX_CONFIG_SOURCETYPE)
        val keyCols: String = conf.get(Constants.PREFIX_CONFIG_EDMHDPIF_TABLE + tableName + Constants.SUFFIX_CONFIG_KEYCOLS)
        val col_schema: String = conf.get(Constants.PREFIX_CONFIG_EDMHDPIF_TABLE + tableName + Constants.SUFFIX_CONFIG_COLSCHEMA)
        val recon_query: String = conf.get(Constants.PREFIX_CONFIG_EDMHDPIF_TABLE + tableName + Constants.SUFFIX_CONFIG_RECONQUERY)
        val deleteValue: String = conf.get(Constants.PREFIX_CONFIG_EDMHDPIF_TABLE + tableName + Constants.SUFFIX_CONFIG_DELETEVALUE)
        val deleteField: String = conf.get(Constants.PREFIX_CONFIG_EDMHDPIF_TABLE + tableName + Constants.SUFFIX_CONFIG_DELETEFIELDNAME, "")

        val deleteIndex: String = if (deleteField.nonEmpty) {
          (col_schema.split("\\^").map(_.split(" ")(0)).indexOf(deleteField) + 1).toString
        }
        else {
          (conf.getInt(Constants.PREFIX_CONFIG_EDMHDPIF_TABLE + tableName + Constants.SUFFIX_CONFIG_DELETEINDEX, -2) + 1).toString
        }
        TableConfig(tableName, sourceType, keyCols, col_schema, recon_query, deleteIndex, deleteValue) :: tableList
    }
  }
}
