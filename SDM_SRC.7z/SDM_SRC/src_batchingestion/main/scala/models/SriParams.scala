/*
 * Copyright 2017 Standard Chartered Bank
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package models

import java.io.File
import java.util.UUID

import org.apache.commons.lang3.StringUtils
import org.apache.hadoop.conf.Configuration

import scala.util.{Failure, Success, Try}
import scala.util.control.Breaks

object ParameterUtils {

  import utils.Constants._

  val getBusinessDate: SriParams => String = _.businessDate
  val getSriPartitionF: String => String = { x => x.replaceAll("-", "_") }
  val getSriPartition: SriParams => String = { x => formatter(`sri partititon format`) print (formatter(`business date format`) parseDateTime getBusinessDate(x)) }
  val getVerifyTypePartitionFromBusinessDateFormat: String => String = { x => formatter(`verify types partition format`) print (formatter(`business date format`) parseDateTime x) }

}

case class SriParams(source: String, country: String, hdfsBaseDir: String,
                     sriOpenSchema: String, sriNonOpenSchema: String, verifyTypesSchema: String, opsSchema: String,
                     sriOpenPartitionColumn: String, sriNonOpenPartitionColumn: String, verifyTypesPartitionColumn: String,
                     hdfsTmpDir: String, tableConfigXml: String, fileDelimiter: String,
                     reconTableName: String, reconTableNameColumn: Int, reconCountColumn: Int,
                     fullDump: Boolean, businessDate: String, batchPartition: String, eodMarker: String, sourcingType: String, lastVerifyTypePartition: String, eodTableName: String) {

  def getSriOpenPartitionPath(tableName: String, partition: String): String = {
    getSriOpenPath(tableName) + sriOpenPartitionColumn + "=" + ParameterUtils.getSriPartitionF(partition) + "/"
  }

  def getSriOpenPath(tableName: String): String = {
    hdfsBaseDir + sriOpenSchema + "/" + tableName + "/"
  }

  def getSriOpenTmpPath(tableName: String): String = {
    hdfsTmpDir + "/" + sriOpenSchema + "/" + tableName + "/"
  }

  def getSriNonOpenPartitionPath(tableName: String, partition: String): String = {
    getSriNonOpenPath(tableName) + sriNonOpenPartitionColumn + "=" + ParameterUtils.getSriPartitionF(partition) + "/"
  }

  def getSriNonOpenPath(tableName: String): String = {
    hdfsBaseDir + sriNonOpenSchema + "/" + tableName + "/"
  }

  def getSriNonOpenTmpPath(tableName: String): String = {
    hdfsTmpDir + "/" + sriNonOpenSchema + "/" + tableName + "/"
  }

  def getVerifyTypesPartitionPath(tableName: String, partition: String): String = {
    getVerifyTypesPath(tableName) + verifyTypesPartitionColumn + "=" + partition + "/"
  }

  def getVerifyTypesPath(tableName: String): String = {
    hdfsBaseDir + verifyTypesSchema + "/" + getVerifyTypesTableName(tableName) + "/"
  }

  def getVerifyTypesTmpPath(tableName: String): String = {
    hdfsTmpDir + "/" + verifyTypesSchema + "/" + getVerifyTypesTableName(tableName) + "/"
  }

  def getVerifyTypesTableName(tableName: String): String = {
    tableName
  }

  def isCdcSource: Boolean = {
    sourcingType.equals("cdc")
  }

  def isBatchSource: Boolean = {
    sourcingType.equals("batch")
  }

  def getLastVerifyPatition: String = {
    if (StringUtils.isEmpty(lastVerifyTypePartition)) "2000_01_01_00" else lastVerifyTypePartition
  }
}

object SriParams {
  def apply(paramConf: Configuration): SriParams = {
    apply(paramConf, "", "", "", "", "")
  }

  def clone(sriParams: SriParams)(marker: String): SriParams = {
    import sriParams._
    SriParams(source, country, hdfsBaseDir,
      sriOpenSchema, sriNonOpenSchema, verifyTypesSchema, opsSchema,
      sriOpenPartitionColumn, sriNonOpenPartitionColumn, verifyTypesPartitionColumn,
      hdfsTmpDir, tableConfigXml, fileDelimiter,
      reconTableName, reconTableNameColumn, reconCountColumn,
      fullDump, businessDate, batchPartition, marker, sourcingType, lastVerifyTypePartition, eodTableName)
  }

  def apply(paramConf: Configuration, partition: String, businessDate: String, runType: String, eodMarker: String, lastVerifyTypesPartition: String): SriParams = {

    val country: String = paramConf.get("country")
    val source: String = paramConf.get("source")
    val hdfsDataParentDir = paramConf.get("hdfsDataParentDir") + "/"
    val sriOpenSchema = paramConf.get("sriOpenSchema")
    val sriNonOpenSchema = paramConf.get("sriNonOpenSchema")
    val verifyTypesSchema = paramConf.get("verifyTypesSchema")
    val opsSchema: String = paramConf.get("opsSchemaName")

    val sriOpenPartitionName = "ods"
    val sriNonOpenPartitionName = "nds"
    val verifyTypesPartitionName = "vds"

    val hdfsTmpDir = paramConf.get("hdfsTmpDir", "/tmp") + "/" + UUID.randomUUID.toString
    val tableConfigXml = paramConf.get("tableConfigXmlHdfsPath")
    val fileDelimiter = Try(new String(Character.toChars(paramConf.getInt("fileDelimiter", 1)))) match {
      case Success(x) => x
      case Failure(x) => x.printStackTrace()
        throw new IllegalArgumentException(" File delimiter " + paramConf.get("fileDelimiter") + " was not a integer code point value .Please specify a code-point value")
    }
    val reconTable = paramConf.get("recon.tableName", "")
    val tableNameColNum = paramConf.getInt("recon.tableNameColNum", -1)
    val tableCountColNum = paramConf.getInt("recon.tableCountColNum", -1)

    val fullDump = if (runType.trim.compareToIgnoreCase("fulldump") == 0) true else false
    val sourcingType = paramConf.get("sourcingType", "cdc")

    val eodTableName = paramConf.get("edmhdpif.config.eod.table.name")

    new SriParams(source, country, hdfsDataParentDir, sriOpenSchema, sriNonOpenSchema, verifyTypesSchema, opsSchema,
      sriOpenPartitionName, sriNonOpenPartitionName, verifyTypesPartitionName,
      hdfsTmpDir, tableConfigXml, fileDelimiter,
      reconTable, tableNameColNum, tableCountColNum, fullDump, businessDate, partition, eodMarker, sourcingType, lastVerifyTypesPartition, eodTableName)
  }

  //For Test
  def apply(partition: String, businessDate: String, eodMarker: String, sourcingType: String, base: String = "target/batchIngestion", schmPrefix: String = ""): SriParams = {
    new SriParams("gps", "all", new File(s"$base/roothdfs/").getAbsoluteFile.toString.replaceAll("\\\\", "/") + "/", "gps_sri_open",
      "gps_sri_nonopen", "gps_storage", schmPrefix + "gps_ops", "ods", "nds", "vds",
      s"$base/tmp" + UUID.randomUUID().toString.substring(1, 5) + "/fw", "sampleconfig/gps_all_tables_config.xml", "\u0001", "", -1, -1,
      false, businessDate, partition, eodMarker, sourcingType, "", "eod_table")
  }
}