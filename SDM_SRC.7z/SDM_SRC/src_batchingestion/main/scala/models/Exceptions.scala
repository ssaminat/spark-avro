package models

object Exceptions {

  case class TableProcessingFailureException(message: String) extends Exception

  case class TableSriNonOpenGenerationException(msg: String) extends Exception

  case class TableSriOpenGenerationException(msg: String) extends Exception

}
