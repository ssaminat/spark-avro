/*
 * Copyright 2017 Standard Chartered Bank
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package models

import bif.utils.EdmHdpIfCommon
import models.XmlParser.TableConfig

import org.apache.spark.{Accumulator, SparkContext}

case class SriAccumulators(sriOpen: Accumulator[Long], sriNonOpen: Accumulator[Long], bDrops: Accumulator[Long],
                           verifyTypes: Accumulator[Long], earlyArrival: Accumulator[Long], verifyTypesDuplicates: Accumulator[Long]) {

  def getRowCount(sriParams: SriParams, tableConfig: TableConfig, attemptId: String): Seq[RowCounts] = {
    val partitionName = sriParams.businessDate
    val tableName: String = tableConfig.name
    val unixTime: String = EdmHdpIfCommon.getUnixTime

    val sriRowCounts: Seq[RowCounts] = if (tableConfig.sourceType.equals("delta")) {
      Seq(RowCounts(sriParams.sriOpenSchema, tableName, sriOpen.value, tableName, unixTime, "SRI OPEN", attemptId, partitionName),
        RowCounts(sriParams.sriNonOpenSchema, tableName, sriNonOpen.value, tableName, unixTime, "SRI NONOPEN", attemptId, partitionName))
    } else {
      Seq(RowCounts(sriParams.sriOpenSchema, tableName, sriOpen.value, tableName, unixTime, "SRI TXN", attemptId, partitionName))
    }

    sriRowCounts ++ Seq(
      RowCounts(sriParams.verifyTypesSchema, "B records", bDrops.value, sriParams.getVerifyTypesTableName(tableName), unixTime, "B Records", attemptId, partitionName),
      RowCounts(sriParams.opsSchema, "Duplicates", verifyTypesDuplicates.value, tableName, unixTime, "Duplicates", attemptId, partitionName),
      RowCounts(sriParams.verifyTypesSchema, "VerifyTypes", verifyTypes.value, sriParams.getVerifyTypesTableName(tableName), unixTime, "VerifyTypes", attemptId, partitionName),
      RowCounts(sriParams.verifyTypesSchema, "Early Arrival", earlyArrival.value, sriParams.getVerifyTypesTableName(tableName), unixTime, "Early Arrival", attemptId, partitionName)
    )
  }
}

object SriAccumulators {
  def apply(sc: SparkContext): SriAccumulators = {
    val sriOpen: Accumulator[Long] = sc.accumulator[Long](0, "Sri Open")
    val sriNonOpen: Accumulator[Long] = sc.accumulator[Long](0, "Sri NonOpen")
    val bDrops: Accumulator[Long] = sc.accumulator[Long](0, "B Drops")
    val verifyTypes: Accumulator[Long] = sc.accumulator[Long](0, "VerifyTypes")
    val earlyArrival: Accumulator[Long] = sc.accumulator[Long](0, "Early Arrival Records")
    val verifyTypesDuplicates: Accumulator[Long] = sc.accumulator[Long](0, "Verify Types Duplicates Records")

    new SriAccumulators(sriOpen, sriNonOpen, bDrops, verifyTypes, earlyArrival, verifyTypesDuplicates)
  }
}

case class RowCounts(schemaName: String, tableName: String, rowCounts: Long, functionalTableName: String, timeStamp: String, comment: String, attemptId: String, rcds: String)