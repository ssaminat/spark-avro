package models

/*
 * Copyright 2017 Standard Chartered Bank
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import cats.data.Writer
import models.XmlParser.TableConfig
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{Row, SQLContext}
import utils.CdcSourceUtils._
import utils.SriUtils._

object Misc {

  case class VerifyTypesInputModel(verifyTypesPathList: List[String], sriOpenPrevPartitionPath: String, prevPartitionEarly: String, prevPartitionLate: String)

  case class Recon(sourceCount: Long, tableName: String, ingestedCount: Long, status: Boolean, batch: String)

  case class TableLevelEodMarkers(tableName: String, marker: String)

  case class EODTableRecord(source: String, country: String, markerTime: String, businessDate: String, previousBusinessDate: String)

  type VerifyTypesWriterRDD = Writer[List[String], RDD[(String, String)]]
  type NormalizedRowFormWriterRDD = Writer[List[String], RDD[NormalizedRowForm]]
  type GroupNormalRowFormWriterRDD = Writer[List[String], RDD[GroupedNormalForm]]
  type VerifyTypesWriterGroupedRDD = Writer[List[String], RDD[(String, Iterable[String])]]
  type RowWriterRDD = Writer[List[String], RDD[Row]]
  type EventScope = String
  type Description = String

  case class PackedInputs(verifyTypesInputModel: VerifyTypesInputModel, sriParams: SriParams, tableConfig: TableConfig, sriAccumulators: SriAccumulators, inputFormat: String)

  /**
    * Normlizer normalizes normal tupled key-value pairs into NormalizedROwForm
    */
  val normalize: ((String, String)) => NormalizedRowForm = { tup: (String, String) => NormalizedRowForm(tup._1, tup._2) }
  /**
    * Group Normlizer normalizes normal tupled key-value pairs into NormalizedROwForm
    */
  val groupNormalize: ((String, Iterable[NormalizedRowForm])) => GroupedNormalForm = { tup: (String, Iterable[NormalizedRowForm]) => GroupedNormalForm(tup._1, tup._2.map(_.value)) }

  /**
    * Lifted normalizer for RDDs
    */
  val normalizeRDDs: VerifyTypesWriterRDD => NormalizedRowFormWriterRDD = _.map(_.map(normalize))

  case class NormalizedRowForm(key: String, value: String) {
    val toTuple: (String, String) = (key, value)
  }

  case class GroupedNormalForm(key: String, value: Iterable[String]) {
    val toTuple: (String, Iterable[String]) = (key, value)
  }

  /**
    * PKV if its a CDC source , otherwise return the same input
    */
  val primaryKeyValidation: PackedInputs => GroupedNormalForm => GroupedNormalForm = {
    case packedInputs if packedInputs.sriParams.isCdcSource => input => {
      import packedInputs._

      val bCount = input.value.count(ifBRecords(_, sriParams.fileDelimiter))
      val aCount = input.value.count(ifARecords(_, sriParams.fileDelimiter))
      val values = if (bCount > aCount) {
        input.value.filter(ifBRecords(_, sriParams.fileDelimiter))
          .map(changeToDeleteType(_, sriParams.fileDelimiter)) ++
          input.value.filterNot(ifBRecords(_, sriParams.fileDelimiter))
      } else {
        input.value
      }
      GroupedNormalForm(input.key, values)
    }
    case packedInputs =>
      input => input

  }
  /**
    * Specifically seek B records if CDC , otherwise return none
    */
  val `filter Group record B`: GroupedNormalForm => PackedInputs => GroupedNormalForm = input => {
    case packInput if packInput.sriParams.isCdcSource => GroupedNormalForm(input.key, input.value.filter(ifBRecords(_, packInput.sriParams.fileDelimiter)))
    case packInput => GroupedNormalForm(input.key, Iterable.empty[String])
  }
  /**
    * Remove all B records
    */
  val `remove Group record B`: GroupedNormalForm => PackedInputs => GroupedNormalForm = input => {
    case packInput if packInput.sriParams.isCdcSource => GroupedNormalForm(input.key, input.value.filterNot(ifBRecords(_, packInput.sriParams.fileDelimiter)))
    case packInput => input
  }


}
