/*
 * Copyright 2017 Standard Chartered Bank
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package processor

import models.SriParams
import models.XmlParser.TableConfig
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileStatus, FileSystem, Path}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.Row
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.{SparkConf, SparkContext}
import org.joda.time.{DateTime, Days}
import utils.ParitionUtils.PartitionInformation
import utils.SchemaEvolutionUtils.SchemaCompare
import utils.SriUtils._
import utils.{FileSystemUtils, SchemaUtils, SriUtils, TransformationUtils}

object SchemaEvolution {

  def main(args: Array[String]): Unit = {

    val Array(cdcXmlFileName: String, keyColFileName: String, sourceTypeFileName: String,
    transRulesFileName: String, tableConfigFileName: String, paramPath: String,
    startMarker: String, endMarker: String) = args


    val fs: FileSystem = FileSystemUtils.fetchFileSystem
    val paramConf: Configuration = SriUtils.getParamConf(fs, paramPath)

    val sriParams: SriParams = SriParams(paramConf)

    val schemaCompare = utils.SchemaEvolutionUtils.schemaEvolution(cdcXmlFileName, keyColFileName, sourceTypeFileName, transRulesFileName, tableConfigFileName, sriParams)

    updateSchema(schemaCompare, sriParams, fs, startMarker, endMarker)
  }

  def updateSchema(schemaCompare: List[(TableConfig, List[(SchemaCompare.Value, Int)])], sriParams: SriParams, fs: FileSystem, startMarker: String, endMarker: String): Unit = {
    import utils.Constants._
    val converter: String => DateTime = utils.Constants.formatter(`business date format`).parseDateTime
    val numberOfPartitions: Int = Days.daysBetween(converter(startMarker), converter(endMarker)).getDays
    val allPartitions: List[String] = startMarker :: utils.ParitionUtils.allPartitions(PartitionInformation(startMarker.replace("-", "_"),
      "yyyy_MM_dd", "days(1)", numberOfPartitions)).map(_.replace("_", "-"))

    val conf = new SparkConf().setAppName("SriMigration")
    val sc = new SparkContext(conf)

    val sqlContext = new HiveContext(sc)


    schemaCompare.foreach {
      schemaTable =>
        val newTableConfig: TableConfig = schemaTable._1

        val schemaCompareResult = schemaTable._2

        val addEndCount: Int = schemaCompareResult.count(_._1.equals(SchemaCompare.ADD_END))
        val deleteEndCount: Int = schemaCompareResult.count(_._1.equals(SchemaCompare.DELETE_END))

        val hiveQueries = SchemaUtils.getSriTablesSchema(newTableConfig, sriParams).split(";", -1)
        if (addEndCount != schemaCompareResult.length && deleteEndCount != schemaCompareResult.length) {
          val deleteColumns = schemaCompareResult.filter(x => x._1.equals(SchemaCompare.DELETE_END) || x._1.equals(SchemaCompare.DELETE_BETWEEN)).map(_._2).sorted(Ordering.Int.reverse)
          val addColumns = schemaCompareResult.filter(x => x._1.equals(SchemaCompare.ADD_END) || x._1.equals(SchemaCompare.ADD_BETWEEN)).map(_._2).sorted(Ordering.Int.reverse)

          migrateData(deleteColumns, addColumns, sriParams, allPartitions, sqlContext, newTableConfig, sriParams.sriOpenPartitionColumn, sriParams.sriOpenSchema, fs)
          migrateData(deleteColumns, addColumns, sriParams, allPartitions, sqlContext, newTableConfig, sriParams.sriNonOpenPartitionColumn, sriParams.sriNonOpenSchema, fs)
        }
        hiveQueries.foreach(sqlContext.sql)
    }
  }

  def migrateData(deleteColumns: List[Int], addColumns: List[Int], sriParams: SriParams,
                  allPartitions: List[String], sqlContext: HiveContext, newTableConfig: TableConfig, partitionColumn: String, sriDir: String, fs: FileSystem): Unit = {
    val allPartitionDir: List[String] = allPartitions.map(partition => sriParams.hdfsBaseDir + "/" + sriDir + "/"
      + newTableConfig.name + "/" + partitionColumn + "=" + partition + "/")

    val allPartitionFiles: List[String] = allPartitionDir.flatMap {
      dir =>
        val path: Path = new Path(dir)
        if (fs.exists(path)) {
          val fileList: Array[FileStatus] = fs.listStatus(path).filterNot(_.getPath.getName.startsWith("_")).filterNot(_.getPath.getName.startsWith("."))
          fileList.map(_.toString)
        } else {
          List[String]()
        }
    }

    val newTableSchema = utils.SriUtils.fetchSriStructure(newTableConfig)(partitionColumn)(sriParams.isCdcSource)

    val oldSriData = sqlContext.read.format("orc").load(allPartitionFiles: _*).rdd.map(TransformationUtils.convertRowToList)

    val newSriData: RDD[List[Any]] = oldSriData.map(dropColumn(_, deleteColumns)).map(addColumn(_, addColumns))

    val newSriRow: RDD[Row] = newSriData.map(x => x.map(_.toString)).map(Row.fromSeq)

    sqlContext.createDataFrame(newSriRow, newTableSchema).write.format("orc").partitionBy(partitionColumn).save(sriParams.hdfsTmpDir + "/" + sriDir + "/" + newTableConfig.name)
    moveHdfsFiles(sriParams.hdfsTmpDir + "/" + sriDir + newTableConfig.name, sriParams.hdfsBaseDir + sriDir + newTableConfig.name, sqlContext)
  }

  def dropColumn(list: List[Any], position: List[Int]): List[Any] = {
    if (position.isEmpty) {
      list
    }
    else {
      val list1: List[Any] = list.take(position.head) ++ list.drop(position.head + 1)
      dropColumn(list1, position.drop(1))
    }
  }

  def addColumn(list: List[Any], position: List[Int]): List[Any] = {
    if (position.isEmpty) {
      list
    }
    else {
      val list1: List[Any] = list.take(position.head) ++ List("") ++ list.drop(position.head)
      addColumn(list1, position.drop(1))
    }
  }
}
