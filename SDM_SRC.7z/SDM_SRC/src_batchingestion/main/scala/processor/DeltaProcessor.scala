/*
 * Copyright 2017 Standard Chartered Bank
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package processor


import models.Misc.{GroupedNormalForm, NormalizedRowForm, PackedInputs}
import models.{SriAccumulators, SriParams}
import org.apache.spark.rdd.RDD
import utils.SriUtils
import models.Misc._
object DeltaProcessor {

  import SriUtils._

  def removeDuplicates(packedInputs: PackedInputs, nonBRecords: RDD[GroupedNormalForm]): RDD[NormalizedRowForm] = {
    import packedInputs._
    val groupByData: RDD[(String, Map[String, Iterable[String]])] = nonBRecords.map(_.toTuple).map(x => (x._1,
      x._2.groupBy(getRecordData(_)(sriParams.fileDelimiter)(sriParams.isCdcSource))))
    val nonDuplicateRecords: RDD[(String, String)] = getNonDuplicateRecords(sriParams, groupByData)
    val duplicateRecords: RDD[(String, String)] = getDuplicateRecords(sriParams, groupByData)

    sriAccumulators.verifyTypesDuplicates += duplicateRecords.count()
    nonDuplicateRecords.map(normalize)
  }

  def getDuplicateRecords(sriParams: SriParams, groupByData: RDD[(String, Map[String, Iterable[String]])]): RDD[(String, String)] = {
    groupByData.flatMap {
      x =>
        val columns: Iterable[String] = x._2.flatMap(duplicateRecords(sriParams, _))
        columns.drop(1).map((x._1, _))
    }
  }

  def duplicateRecords(sriParams: SriParams, records: (String, Iterable[String])): TraversableOnce[String] = {
    if (records._2.size > 1) {
      records._2.drop(1).foldLeft(Seq[String](records._2.head)) {
        foldDuplicateRecords(sriParams)
      }
    } else {
      Iterator[String]()
    }
  }

  def foldDuplicateRecords(sriParams: SriParams): (Seq[String], String) => Seq[String] = {
    (a, b) =>
      if (a.exists(z => !`if D records`(z)(sriParams) && !`if D records`(b)(sriParams))) {
        b +: a
      }
      else {
        a
      }
  }

  def getNonDuplicateRecords(sriParams: SriParams, groupByData: RDD[(String, Map[String, Iterable[String]])]): RDD[(String, String)] = {
    groupByData.flatMap {
      x =>
        val columns: Iterable[String] = x._2.flatMap(nonDuplicateRecords(sriParams, _))
        columns.map((x._1, _))
    }
  }

  def nonDuplicateRecords(sriParams: SriParams, y: (String, Iterable[String])): Iterable[String] = {
    if (y._2.size == 1) {
      y._2
    }
    else {
      y._2.drop(1).foldLeft(Seq[String](y._2.head)) {
        foldNonDuplicateRecords(sriParams)
      }
    }
  }

  def foldNonDuplicateRecords(sriParams: SriParams): (Seq[String], String) => Seq[String] = {
    (a, b) =>
      if (a.exists(z => !`if D records`(z)(sriParams) && !`if D records`(b)(sriParams))) {
        a
      }
      else {
        b +: a
      }
  }
}
