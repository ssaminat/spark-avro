/*
 * Copyright 2017 Standard Chartered Bank
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package utils

import org.apache.hadoop.conf.Configuration
import org.apache.http.client.methods.{CloseableHttpResponse, HttpPost}
import org.apache.http.entity.{ContentType, StringEntity}
import org.apache.http.impl.client.HttpClients
import org.apache.spark.SparkContext

object ProvenanceUtils {


  def putProvenanceInfoToElastic(sc: SparkContext,
                                 businessDate: String, runType: String, paramConf: Configuration): CloseableHttpResponse = {

    val provenance_info = provenance_info_json(
      sc.applicationAttemptId.getOrElse("attemptIdNotFound"), businessDate, runType,
      paramConf.get("source"), paramConf.get("country")
    )
    val httpClient = HttpClients.createDefault()
    val elasticSearchGateway = getElasticSearchConnection(paramConf)
    val req_entity = new StringEntity(provenance_info, ContentType.APPLICATION_JSON)

    val postMethod = new HttpPost(elasticSearchGateway)
    postMethod.setEntity(req_entity)
    val response = httpClient.execute(postMethod)
    response
  }

  def getElasticSearchConnection(conf: Configuration): String = {
    val es_URL = conf.get("elasticsearchURL")
    val es_index = conf.get("elasticsearchIndex")
    val es_type = conf.get("elasticsearchType")
    "http://" + es_URL + "/" + es_index + "/" + es_type
  }

  def provenance_info_json(attemptID: String, businessDate: String, runType: String,
                           source: String, country: String): String = {
    "{\"SparkJob-AttemptID\":\"" + attemptID + "\", " +
      "\"BusinessDay\":\"" + businessDate + "\"," +
      "\"RunType\":\"" + runType + "\", " +
      "\"Source\":\"" + source + "\"," +
      "\"Country\":\"" + country + "\"}"
  }

}
