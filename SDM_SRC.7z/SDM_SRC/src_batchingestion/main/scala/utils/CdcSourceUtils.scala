/*
 * Copyright 2017 Standard Chartered Bank
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package utils

import java.text.SimpleDateFormat
import java.util.Date
import implicits.Implicits._
import models.Misc.PackedInputs
import org.apache.spark.sql.Row
import org.apache.spark.sql.types.{StringType, StructField}
import utils.VerifyTypeUtils.chosenJournalFormat

import scala.util.{Failure, Success, Try}

object CdcSourceUtils {

  def ifBRecords(data: String, fileDelimiter: String): Boolean = {
    Try(data.split(fileDelimiter, -1)(9).equalsIgnoreCase("B")) match {
      case Success(x) => x
      case Failure(x) => val msg = "Cannot fetch operation type from record " + data + " while poaition 9 was tried"
        x.printStackTrace()
        throw new IllegalStateException(msg)
    }
  }

  def ifARecords(data: String, fileDelimiter: String): Boolean = {
    Try(data.split(fileDelimiter, -1)(9).equalsIgnoreCase("A")) match {
      case Success(x) => x
      case Failure(x) => val msg = "Cannot fetch operation type from record " +
        data + " with delimiter " +
        fileDelimiter + " while position 9 was tried while length was only " + data.split(fileDelimiter, -1).length
        x.printStackTrace()
        throw new IllegalStateException(msg)
    }
  }

  /**
    * Split the event based on journal timestamp
    */
  val `is event after Watermark`: PackedInputs => Row => Boolean = packedInputs => { row =>
    val xx = TransformationUtils.convertRowToList(row)
    val journalDate: Date = chosenJournalFormat(packedInputs.inputFormat).parse(xx(2).toString)
    journalDate.compareTo(Constants.`business date format`.parse(packedInputs.sriParams.eodMarker)) > 0
  }

  def changeToDeleteType(data: String, fileDelimiter: String): String = {
    val columns: Array[String] = data.split(fileDelimiter, -1)
    if (columns.length < 5) {
      throw new IllegalStateException(" Cannot change delete flag type to D for " + data + " with position 5")
    }
    columns(5) = "1"
    columns.mkString(fileDelimiter)
  }

  def cdcColumnSchema: Seq[StructField] = {
    Seq(StructField("journalTS", StringType), StructField("transactionId", StringType), StructField("operationType", StringType), StructField("userId", StringType))
  }
}
