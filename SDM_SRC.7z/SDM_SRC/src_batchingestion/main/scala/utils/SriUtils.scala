package utils

import bif.utils.EdmHdpIfCommon
import models.Misc.{NormalizedRowForm, PackedInputs}
import models.XmlParser.TableConfig
import models.{SriParams, XmlParser}
import org.apache.commons.lang3.StringEscapeUtils
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileStatus, FileSystem, Path, PathFilter}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, Row, SQLContext}
import org.joda.time.{DateTime, Hours}
import utils.Constants._
import utils.FileSystemUtils.fetchFileSystem
import utils.ParitionUtils.{PartitionInformation, getPreviousBusinessDatePartition}

import scala.util.Try

/**
  * Created by 1396254 on 2/25/2017.
  */
object SriUtils {

  val logger: Logger = Logger.getLogger(SriUtils.getClass)

  def sriOpenRow[A](x: A, y: A, compare: Int): A = {
    if (compare > 0) x else y
  }

  def sriNonOpenRow[A](x: A, y: A, compare: Int): (A, A) = {
    if (compare > 0) (y, x) else (x, y)
  }

  val compareOpenRows: String => String => String => Boolean => String = row1Raw => row2Raw => fileDelimiter => cdcSource => {
    sriOpenRow(row1Raw, row2Raw, compareRows(row1Raw.split(fileDelimiter, -1),
      row2Raw.split(fileDelimiter, -1), cdcSource))
  }

  def compareRows(row1: Array[String], row2: Array[String], cdcSource: Boolean): Int = {
    val compareTime = if (cdcSource) {
      compareJournalTime(row1)(row2)
    } else {
      compareStartDataTime(row1)(row2)
    }
    val compareResult = if (compareTime == 0) {
      compareRowId(row1)(row2)
    }
    else {
      compareTime
    }
    compareResult
  }

  val compareRowId: Array[String] => Array[String] => Int = row1 => row2 => {
    row1(0).compareTo(row2(0))
  }

  val compareJournalTime: Array[String] => Array[String] => Int = row1 => row2 => {
    row1(6).compareTo(row2(6))
  }

  val compareStartDataTime: Array[String] => Array[String] => Int = row1 => row2 => {
    if (row1(1).compareTo(row2(1)) == 0) {
      row1(2).compareTo(row2(2))
    }
    else {
      row1(1).compareTo(row2(1))
    }
  }

  def compareNonOpenRows(row1Raw: String, row2Raw: String, sriParams: SriParams): String = {
    import sriParams._
    val row1: Array[String] = row1Raw.split(fileDelimiter, -1)
    val row2: Array[String] = row2Raw.split(fileDelimiter, -1)

    val endDate = businessDate
    val endTime = EdmHdpIfCommon.getUnixTime

    val resultRow = if (`if D records`(row1Raw)(sriParams)) {
      UpdateEndDate(row1, endDate, endTime)
    } else if (`if D records`(row2Raw)(sriParams)) {
      UpdateEndDate(row2, endDate, endTime)
    } else {
      val compareResult: Int = compareRows(row1, row2, sriParams.isCdcSource)
      val (nonOpenrow, otherRow) = sriNonOpenRow(row1, row2, compareResult)
      UpdateEndDate(nonOpenrow, otherRow(1), otherRow(2))
    }
    StringEscapeUtils.unescapeJava(resultRow.mkString(fileDelimiter))
  }

  private def UpdateEndDate(row: Array[String], endDate: String, endTime: String) = {
    row(3) = endDate
    row(4) = endTime
    row
  }

  val fetchSriStructure: TableConfig => String => Boolean => StructType = tableConfig => partitionColumn => cdcSource => {
    StructType(Seq(StructField("rowid", StringType)) ++
      getSriTimeColumnsSchema ++
      (if (cdcSource) CdcSourceUtils.cdcColumnSchema else Seq()) ++
      TypeUtils.transformStructFields(tableConfig) ++ Seq(StructField(partitionColumn, StringType)))
  }

  private def getSriTimeColumnsSchema = {
    Seq(StructField("start_date", StringType), StructField("start_time", StringType), StructField("end_date", StringType)
      , StructField("end_time", StringType), StructField("del_flag", StringType))
  }

  val fetchVerifyStructure: TableConfig => String => Boolean => String => StructType = tableConfig => verifyTypesPartitionColumn => cdcSource => {

    case _ => StructType(Seq(StructField("rowid", StringType)) ++
      Seq(StructField(verifyTypesPartitionColumn, StringType)) ++
      (if (cdcSource) CdcSourceUtils.cdcColumnSchema else Seq()) ++
      TypeUtils.transformStructFieldsAvro(tableConfig))
  }

  val getVerifyTypesFirstDataColumnPosition: Boolean => Int = cdcSource => {
    if (cdcSource) {
      `verify types prefix column count` + `cdc column count`
    } else 1
  }

  val getSriFirstDataColumnPosition: Boolean => Int = cdcSource => {
    `sri time col count` + 1 + (if (cdcSource) `cdc column count` + 1 else 0)
  }

  val getRecordData: String => String => Boolean => String = record => fileDelimiter => cdcSource => {
    record.split(fileDelimiter, -1)
      .drop(getSriFirstDataColumnPosition(cdcSource))
      .mkString(fileDelimiter)
  }


  val `if D records`: String => SriParams => Boolean = data => sriParams => {
    data.split(sriParams.fileDelimiter, -1)(5).equalsIgnoreCase("1")
  }

  val `if EndDate exists`: String => String => Boolean = data => fileDelimiter => {
    !data.split(fileDelimiter, -1)(4).isEmpty
  }

  type DeleteColumn = (Int, String)

  /**
    * Convert storage events into key-value pair format
    * Keys for delta tables are its PKV keys
    * Keys for transaction tables are "txn#rowid"
    *
    * @param packedInputs
    * @param deleteColumn
    * @param row
    * @return
    */
  def `prepare key-value format for storage event`(packedInputs: PackedInputs, deleteColumn: DeleteColumn, row: Row): NormalizedRowForm = {
    val xx = TransformationUtils.convertRowToList(row)
    val result = if (packedInputs.tableConfig.isTxnSource) {
      val deleteFlag = "0"
      ("txn" + "#" + xx.head, rowWithData(xx)(packedInputs.sriParams.businessDate)(packedInputs.sriParams.fileDelimiter)(deleteFlag))
    } else {
      val deleteFlag = if (xx(deleteColumn._1).asInstanceOf[String].equals(deleteColumn._2)) "1" else "0"
      val indices: List[Int] = XmlParser.fetchKeyIndiciesFromTable(packedInputs.tableConfig)
      (extractDeltaKeyFromData(xx)(indices)(packedInputs.tableConfig.name)(packedInputs.sriParams.isCdcSource),
        rowWithData(xx)(packedInputs.sriParams.businessDate)(packedInputs.sriParams.fileDelimiter)(deleteFlag))
    }
    NormalizedRowForm(result._1, result._2)
  }

  /**
    * Lift the KVP function onto RDDs
    */
  val `lifted Storage Event Key-Value-Pair Formatter`: PackedInputs => DeleteColumn => RDD[Row] => RDD[NormalizedRowForm] = packedInputs => delCol => rdd => {
    rdd.map(x => `prepare key-value format for storage event`(packedInputs, delCol, x))
  }

  val rowWithData: List[Any] => String => String => String => String = xx => businessDate => fileDelimiter => deleteFlag => {
    Seq(xx.head ,businessDate,EdmHdpIfCommon.getUnixTime , "" , "" ,deleteFlag).mkString(fileDelimiter) +
      xx.drop(1)
        .foldRight("") {
          (x, y) => fileDelimiter + x + y
        } + fileDelimiter + businessDate
  }

  val extractDeltaKeyFromData: List[Any] => List[Int] => String => Boolean => String = data => indices => tableName => cdcSource => {
    "#" + tableName + indices.foldRight("") {
      (x, y) => "#" + data(x + getVerifyTypesFirstDataColumnPosition(cdcSource)).toString + y
    }
  }

  /**
    * TODO segregate HDFS site config from config constructor to separate compute from store cluster
    *
    * @param sourcePathString
    * @param destPathString
    * @param hiveContext
    * @param fileNamePrefix
    */
  def moveHdfsFiles(sourcePathString: String, destPathString: String, hiveContext: SQLContext, fileNamePrefix: String = "", deletePreviousFiles: Boolean = true): Unit = {
    logger.info("Moving Hdfs files from " + sourcePathString + " to " + destPathString)
    val sourcePath = new Path(sourcePathString)
    val destinationPath = new Path(destPathString)

    val fs: FileSystem = FileSystemUtils.fetchFileSystem
    logger.info(" default FS is " + fs.getConf.get("fs.defaultFS"))
    val database = sourcePath.getParent.getName
    val tableName = destinationPath.getName

    fs.deleteOnExit(sourcePath)

    if (fs.exists(sourcePath)) {
      fs.listStatus(sourcePath).filter(_.isDirectory).foreach {
        level1 =>
          val partitionDir: String = level1.getPath.getName
          val dstPartition: Path = new Path(destinationPath.toString + "/" + partitionDir + "/")
          if (fs.exists(dstPartition) && deletePreviousFiles) {
            fs.delete(dstPartition, true)
          }
          val fileList: Array[FileStatus] = fs.listStatus(level1.getPath).filterNot(_.getPath.getName.startsWith("_")).filterNot(_.getPath.getName.startsWith("."))
          if (fileList.nonEmpty) {
            val split: Array[String] = partitionDir.split("=")
            val partitionName = split(0) + "='" + split(1) + "'"
            createHivePartition(hiveContext, database, tableName, partitionName)
          }

          fileList.foreach {
            name =>
              val path1: String = sourcePath.toString + "/" + level1.getPath.getName + "/" + name.getPath.getName
              val path2: String = destinationPath.toString + "/" + level1.getPath.getName + "/" + fileNamePrefix + name.getPath.getName
              logger.info("Moving path : " + path1 + "; to " + path2)
              val path: Path = new Path(path2)
              fs.mkdirs(path.getParent)
              if (!fs.rename(new Path(path1), path)) throw new IllegalStateException(s"Application failed renaming from $sourcePath to $destinationPath")
          }
      }
    }
  }

  def createHivePartition(hiveContext: SQLContext, database: String, tableName: String, partitionName: String): DataFrame = {
    val sqlQuery: String = s"alter table $database." + tableName + " add if not exists partition(" + partitionName + ")"
    logger.info("Executing Partition query (database: " + database + ") - " + sqlQuery)
    hiveContext.synchronized {
      hiveContext.sql(sqlQuery)
    }
  }

  /**
    * TODO segregate the conf creation for cases,
    * when you'd like to run spark compute cluster away from HDFS
    *
    * @param sriOpenPrevPartitionPath
    * @return
    */
  def `does previous sri open exist ?`(sriOpenPrevPartitionPath: String): Boolean = {

    val fs: FileSystem = fetchFileSystem
    fs.exists(new Path(sriOpenPrevPartitionPath).getParent) && fs.listStatus(new Path(sriOpenPrevPartitionPath).getParent, new PathFilter {
      override def accept(path: Path): Boolean = {
        path.getName.matches("(.*)orc$")
      }
    }).nonEmpty
  }

  def previousExistingPartition(sriParams: SriParams, businessDate: String, tableName: String, limit: Int): String = {
    val nextBusinessDay: String = getPreviousBusinessDatePartition(businessDate.replace('-', '_'), "yyyy_MM_dd", "days(1)").replace('_', '-')
    val path: String = sriParams.getSriOpenPartitionPath(tableName, nextBusinessDay) + "*.orc"

    if (`does previous sri open exist ?`(path) || limit == 0) {
      nextBusinessDay
    }
    else {
      previousExistingPartition(sriParams, nextBusinessDay, tableName, limit - 1)
    }
  }


  def getParamConf(fs: FileSystem, xmlPath: String): Configuration = {
    val xmlHdfs = new Path(xmlPath)
    val paramConf: Configuration = new Configuration()
    paramConf.addResource(fs.open(xmlHdfs), xmlPath)
    paramConf
  }

  implicit val convertVerifyTypesDateToHour: String => DateTime = formatter(`verify types partition format`) parseDateTime


  def getInputFiles(sriParams: SriParams, fs: FileSystem, tableConfig: TableConfig)(implicit inputFormat: String = "orc"): (String, String, List[String], String) = {
    val tableName: String = tableConfig.name

    val previousPartition: String = previousExistingPartition(sriParams, sriParams.businessDate, tableName, 10)
    val hours: Int = Math.max(250, Hours.hoursBetween(sriParams.batchPartition, sriParams.getLastVerifyPatition).getHours)
    val allPartitions: List[String] = sriParams.batchPartition ::
      utils.ParitionUtils.allPartitions(PartitionInformation(sriParams.batchPartition,
        `verify types partition format`, "hours(1)", hours))
    logger.info(s"$tableName seeking from " + sriParams.getVerifyTypesPartitionPath(tableName, "X") + " from list" + allPartitions.mkString("|"))

    val prevEodVerifyTypePartition: String = allPartitions.last
    import implicits.Implicits._
    val earlyPartitionFromPrevRun: String = `sri partititon format`.format(Constants.`verify types partition format`.parse(prevEodVerifyTypePartition))
    val prevPartitionEarly = sriParams.getVerifyTypesPartitionPath(tableName, earlyPartitionFromPrevRun+"_early")
    val prevPartitionLate = sriParams.getVerifyTypesPartitionPath(tableName, prevEodVerifyTypePartition + "_late")

    logger.info(" seeking early path from " + prevPartitionEarly)
    logger.info(" seeking late path from " + prevPartitionLate)


    val prevPartitionEarlyPath = if (fs.exists(new Path(prevPartitionEarly))) prevPartitionEarly + tableName + "part-r-*" else ""
    val prevPartitionLatePath = if (VerifyTypeUtils.`does verify types input exists?`(fs)(prevPartitionLate)(tableName)) prevPartitionLate + tableName + ".*" else ""

    val verifyTypesDirList: List[String] = VerifyTypeUtils.fetchVerifyTypesInputList(sriParams)(fs)(tableConfig.name)(allPartitions)

    val sriOpenPrevPartitionPath: String = sriParams.getSriOpenPartitionPath(tableName, previousPartition) + s"*"
    logger.info(" looking for storage files in " + verifyTypesDirList.mkString(","))
    (prevPartitionEarlyPath, prevPartitionLatePath, verifyTypesDirList, sriOpenPrevPartitionPath)
  }

  /**
    * check utils.SriUtilsProperties for conformance property
    *
    * @param submitTime
    * @return
    */
  def getBusinessDayPartition(submitTime: String): Option[(String, String)] = {
    val businessDay = Try(formatter(`business date format`) parseDateTime submitTime).toOption
    val partition = businessDay.map(formatter(`verify types partition format`) print _)
    val businessDate = businessDay.map(formatter(`sri partititon format`) print _)
    (partition zip businessDate).headOption
  }
}
