/*
 * Copyright 2017 Standard Chartered Bank
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package utils

import java.text.SimpleDateFormat

import cats.implicits._
import models.Misc._
import models.SriParams
import org.apache.commons.lang3.StringUtils
import org.apache.hadoop.fs.{FileSystem, Path, PathFilter}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{Row, SQLContext}
import org.apache.spark.sql.types.StructType
import provenance.Ops._
import utils.SriUtils.`does previous sri open exist ?`
import implicits.Implicits._
import org.apache.spark.{Accumulator, SparkContext}
import utils.CdcSourceUtils._
import utils.FileSystemUtils._

object VerifyTypeUtils {
  val logger: Logger = Logger.getLogger(VerifyTypeUtils.getClass)

  /**
    * Checks if stoage inputs are incremental and returns true or false
    */
  val `storage inputs are incremental`: PackedInputs => Boolean = {
    packedInputs =>
      packedInputs.tableConfig.isDeltaSource &&
        !packedInputs.sriParams.fullDump &&
        `does previous sri open exist ?`(packedInputs.verifyTypesInputModel.sriOpenPrevPartitionPath)

  }
  /**
    * Reads into RDD the previous Sri Open only if its a delta table
    */
  val readPreviouoSriOpen: SparkContext => SQLContext => PackedInputs => RDD[Row] = sc => sqlContext => {
    case packedInput if packedInput.tableConfig.isDeltaSource &&
      fetchFileSystem.exists(new Path(packedInput.verifyTypesInputModel.sriOpenPrevPartitionPath)) =>
      sqlContext.read.format("orc").load(packedInput.verifyTypesInputModel.sriOpenPrevPartitionPath).rdd
    case packedInput => sc.emptyRDD[Row]
  }
  /**
    * This brings together data from Previous SRI Open into the normalized form , namely (Key,Value)
    */
  val normalizeToSriFormat: SparkContext => SQLContext => RDD[(String, String)] => PackedInputs => NormalizedRowFormWriterRDD = sc => sqlContext => storageInputs => {
    case packedInput if `storage inputs are incremental`(packedInput) =>

      for {
        sriOpenPrevious <- s"Loading previous SRI Open partition for ${packedInput.tableConfig.name}" ~> readPreviouoSriOpen(sc)(sqlContext)(packedInput)
        deltaSourcedFormat <- s" Sourcing delta format for ${packedInput.tableConfig.name}" ~> sriOpenPrevious.map {
          row =>
            DeltaSourceUtils.normalizePrevSriOpen(packedInput)(row)
        }
        unionInputs <- s" union of storage inputs with previous SRI ${packedInput.tableConfig.name}" ~> storageInputs
        preparedInputs <- s"Prepared Inputs for SRI Processing for ${packedInput.tableConfig.name} " ~> (unionInputs map normalize)

      } yield preparedInputs

    case packedInput => s"Prepared Inputs for SRI Processing for ${packedInput.tableConfig.name} " ~> (storageInputs map normalize)
  }
  /**
    * Checks if the given hdfs location holds storage files
    */
  val `does verify types input exists?`: FileSystem => String => String => Boolean = fs => verifyTypesPath => tableName => {
    val inputPath = new Path(verifyTypesPath)
    fs.exists(inputPath)
  }
  /**
    * Prepares a list of hdfs locations which contain storage inputs for the given batch
    */
  val fetchVerifyTypesInputList: SriParams => FileSystem => String => List[String] => List[String] = sriParams => fs => tableName => allPartitions => {
    allPartitions
      .dropRight(1)
      .map(sriParams.getVerifyTypesPartitionPath(tableName, _))
      .filter(`does verify types input exists?`(fs)(_)(tableName))
  }


  /**
    * Based on input format the journal time format is chosen
    */
  val chosenJournalFormat: String => String = {
    case "com.databricks.spark.avro" => Constants.`journal time format_avro`
    case _ => Constants.`journal time format`
  }
  /**
    * Splitting evetns based on water mark
    */
  val earlyArrival: SparkContext => PackedInputs => RDD[Row] => RowWriterRDD = sc => {
    case packedInputs if packedInputs.sriParams.isCdcSource =>
      verifyTypes =>
        s"Filtering Storage Events that arrived early for ${packedInputs.tableConfig.name} " ~> verifyTypes.filter { row =>
          `is event after Watermark`(packedInputs)(row)
        }
    case packedInputs => _ => s"Non CDC Source have no water-marks ${packedInputs.tableConfig.name}" ~> sc.emptyRDD
  }
  /**
    * Splitting evetns based on water mark
    */
  val lateArrival: SparkContext => PackedInputs => RDD[Row] => RowWriterRDD = sc => {

    case packedInputs if packedInputs.sriParams.isCdcSource =>
      verifyTypes =>
        s"Filtering Storage Events that arrived late for ${packedInputs.tableConfig.name} " ~> verifyTypes.filter { row =>
          !`is event after Watermark`(packedInputs)(row)
        }


    case packedInputs => input => s"Non CDC Source have no water-marks ${packedInputs.tableConfig.name}" ~> input
  }
  /**
    * Load storage inputs into an RDD
    */
  val `load storage inputs into RDD`: SparkContext => SQLContext => PackedInputs => RDD[Row] = sc => sqlContext => {
    packedInput =>
      import packedInput._
      sqlContext.read.format(inputFormat).load(verifyTypesInputModel.verifyTypesPathList: _*).drop("filename").rdd
  }
  /**
    * Load Early storage events into an RDD
    */
  val `load early storage inputs into RDD`: SparkContext => SQLContext => PackedInputs => RDD[Row] = sc => sqlContext => {
    case packedInputs if StringUtils.isNotEmpty(packedInputs.verifyTypesInputModel.prevPartitionEarly) =>
      import packedInputs._
      sqlContext.read.format(inputFormat).load(verifyTypesInputModel.prevPartitionEarly).rdd
    case packedInputs => sc.emptyRDD[Row]

  }
  /**
    * Load Late storage events into an RDD
    */
  val `load late storage inputs into RDD`: SparkContext => SQLContext => PackedInputs => RDD[Row] = sc => sqlContext => {
    case packedInputs if StringUtils.isNotEmpty(packedInputs.verifyTypesInputModel.prevPartitionLate) =>
      import packedInputs._
      sqlContext.read.format("orc").load(verifyTypesInputModel.prevPartitionLate).rdd
    case packedInputs => sc.emptyRDD[Row]

  }
  /**
    * Parking events that came in early into Early storage partition
    */
  val `park early events onto storage`: SparkContext => SQLContext => RDD[Row] => PackedInputs => RDD[Row] = sc => sqlContext => events => packedInput => {
    import packedInput._
    val verifyTypesSchema = SriUtils.fetchVerifyStructure(tableConfig)(sriParams.verifyTypesPartitionColumn)(sriParams.isCdcSource)(inputFormat)
    val residual = events.
      map { row => val values = row.toSeq
        modifyVdsToEarly(values)
      }
    sqlContext.createDataFrame(residual, verifyTypesSchema).write.format(inputFormat).partitionBy(sriParams.verifyTypesPartitionColumn).save(sriParams.getVerifyTypesTmpPath(tableConfig.name))
    SriUtils.moveHdfsFiles(sriParams.getVerifyTypesTmpPath(tableConfig.name), sriParams.getVerifyTypesPath(tableConfig.name), sqlContext, tableConfig.name + "-")
    events
  }

  /**
    * Appens the string _early to suffix the partition column
    * The partition , which is hourly for verifytypes is converted to business date like format
    * @param values
    * @return
    */
  def modifyVdsToEarly(values: Seq[Any]): Row = {
    val partitionColumn: String = values(1).toString
    val finalEarlyPath = Constants.`sri partititon format`.format(Constants.`verify types partition format`.parse(partitionColumn))
    Row.fromSeq(Seq(values.head) ++ Seq(finalEarlyPath + "_early") ++ values.drop(2))
  }

  val `fetch delete index`: PackedInputs => (Int, String) = {
    case packedInput if packedInput.tableConfig.isDeltaSource =>
      import packedInput._
      if (sriParams.isCdcSource) (4, "D") else (tableConfig.deleteIndex.toInt, tableConfig.deleteValue)
    case _ => (-1, "")
  }

}
