/*
 * Copyright 2017 Standard Chartered Bank
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package utils


import org.joda.time.format.{DateTimeFormat, DateTimeFormatter}

object Constants {
  lazy val formatter: String => DateTimeFormatter = { str: String => DateTimeFormat forPattern str }

  val `business date format` = "yyyy-MM-dd HH:mm:ss"
  val `journal time format` = "yyyy-MM-dd HH:mm:ss.SSSSSS"
  val `journal time format_avro` = "yyyy-MM-dd HH:mm:ss"


  val `verify types partition format` = "yyyy_MM_dd_HH"
  val `sri partititon format` = "yyyy-MM-dd"
  val `verify types frequency` = "hours(1)"
  val `verify types prefix column count` = 2 // rowId as well as vds
  val `cdc column count` = 4 // journal time, transaction ID, op Type, user
  val `sri time col count` = 5 // start date, start time, end date, end time, delete flag
  val `table level eod` = "table_level_eod" // table level eod

  // Table Config Constants
  val PREFIX_CONFIG_EDMHDPIF_TABLE = "edmhdpif.table."
  val SUFFIX_CONFIG_COLSCHEMA = ".col_schema"
  val SUFFIX_CONFIG_KEYCOLS = ".keycols"
  val SUFFIX_CONFIG_SOURCETYPE = ".sourcetype"
  val SUFFIX_CONFIG_RECONQUERY = ".query"
  val SUFFIX_CONFIG_DELETEVALUE = ".deletevalue"
  val SUFFIX_CONFIG_DELETEINDEX = ".deleteindex"
  val SUFFIX_CONFIG_DELETEFIELDNAME = ".deletefield"

}
