package utils

import java.util.Date

import models.Misc.{Description, EODTableRecord, TableLevelEodMarkers}
import models.SriParams
import org.apache.hadoop.conf.Configuration
import org.apache.spark.SparkContext
import org.apache.spark.sql.{Row, SQLContext}
import utils.Constants.`table level eod`
import implicits.Implicits._
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.hive.HiveContext
import utils.SriUtils.moveHdfsFiles

/**
  * Created by Ganesh on 7/31/2017.
  */
object EodUtils {

  val isTableLevelEod: Configuration => Boolean = conf => conf.get("edmhdpif.config.eod.marker.strategy", "source_level_eod").equals(`table level eod`)
  implicit val dateFormatter: Date => String = Constants.`journal time format_avro`.format

  def parseEodMarkerForTable(sc: SparkContext, sqlContext: SQLContext, sriParams: SriParams, paramConf: Configuration, inputFormat: String): List[TableLevelEodMarkers] = paramConf match {
    case `paramConf` if isTableLevelEod(paramConf) => val markerTable = sriParams. getVerifyTypesPath(paramConf.get("edmhdpif.config.eod.marker.table.name"))
      val reconTablePartitionPath = sriParams.getVerifyTypesPartitionPath(markerTable, sriParams.lastVerifyTypePartition)
      val colName = paramConf.get("edmhdpif.config.eod.marker.column.name")
      val tableColName = paramConf.get("edmhdpif.config.eod.marker.column.table.name")
      val markerDetails = sqlContext.read.format(inputFormat).load(reconTablePartitionPath + "*")
        .select(colName, tableColName).rdd
        .map { row =>
          val marker = Constants.`journal time format_avro`.parse(row.getString(0))
          val tableName = row.getString(1)
          (tableName, marker)
        }.groupByKey()
        .mapValues(x => x.max(Ordering.by[Date, Long](_.getTime())))
        .collect()
      markerDetails.map { x => TableLevelEodMarkers(x._1, x._2) }.toList
    case _ => List.empty
  }

  def writeEodTableAndMarker(fs: FileSystem, paramConf: Configuration, sriParams: SriParams, sqlContext: HiveContext, makerLocation: Description, previousBusinessDate: String): Unit = {
    import sriParams._
    val eodTableRecord = Seq(EODTableRecord(source, country, sriParams.eodMarker, sriParams.businessDate, previousBusinessDate))
    val tableName = paramConf.get("edmhdpif.config.eod.table.name")
    val tempPath = hdfsTmpDir + "/" + opsSchema + "/" + tableName
    sqlContext.createDataFrame(eodTableRecord)
      .write.format("orc")
      .partitionBy("businessDate")
      .save(tempPath)
    moveHdfsFiles(tempPath, sriParams.hdfsTmpDir + "/" + sriParams.opsSchema + "/" + tableName, sqlContext)
    fs.delete(new Path(makerLocation), false)
    FileSystemUtils.writeIntoFile(new Path(makerLocation))(fs)(sriParams.businessDate)
  }

}
