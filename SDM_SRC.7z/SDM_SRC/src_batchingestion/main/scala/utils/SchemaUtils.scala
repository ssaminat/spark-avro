/*
 * Copyright 2017 Standard Chartered Bank
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package utils

import java.io.ByteArrayOutputStream

import com.fasterxml.jackson.core.{JsonEncoding, JsonGenerator}
import com.fasterxml.jackson.databind.ObjectMapper
import models.SriParams
import models.XmlParser.TableConfig
import org.apache.hadoop.hive.serde2.typeinfo.PrimitiveTypeInfo

object SchemaUtils {

  def getSriTablesSchema(tableConfig: TableConfig, sriParams: SriParams): String = {
    val tableName: String = tableConfig.name
    val columnDelimiter: String = sriParams.fileDelimiter

    val sriOpenHdfsLocation: String = s"""${sriParams.hdfsBaseDir}${sriParams.sriOpenSchema}/$tableName"""
    val sriNonOpenHdfsLocation: String = s"""${sriParams.hdfsBaseDir}${sriParams.sriNonOpenSchema}/$tableName"""
    val verifyTypesHdfsLocation: String = s"""${sriParams.hdfsBaseDir}${sriParams.verifyTypesSchema}/$tableName"""
    val eodTable = createEodTable(sriParams.opsSchema, sriParams.eodTableName, sriParams.hdfsBaseDir + sriParams.opsSchema + "/" + sriParams.eodTableName)
    val hiveColSchemaOrc: String = createHiveSchema(tableConfig)
    val hiveColSchemaAvro: String = createHiveSchema(tableConfig, isAvro = true)

    val sriOpenTable: String = getTableSchema(sriParams.sriOpenSchema, tableName, hiveColSchemaOrc, sriParams.sriOpenPartitionColumn, columnDelimiter, sriOpenHdfsLocation, sriParams.isCdcSource)
    val sriNonOpenTable: String = getTableSchema(sriParams.sriNonOpenSchema, tableName, hiveColSchemaOrc,
      sriParams.sriNonOpenPartitionColumn, columnDelimiter, sriNonOpenHdfsLocation, sriParams.isCdcSource)
    val verifyTypesTables: String = getVerifyTypesTables(sriParams.verifyTypesSchema, tableName, hiveColSchemaAvro,
      sriParams.verifyTypesPartitionColumn, columnDelimiter, verifyTypesHdfsLocation, sriParams.isCdcSource)

    val rowCountsTable: String = getRowCountsTable(sriParams.source, sriParams.country, sriParams.opsSchema, columnDelimiter, sriParams.hdfsBaseDir)
    val invalidTypesTable: String = getInvalidTypesTable(sriParams.source, sriParams.country, sriParams.verifyTypesSchema, sriParams.hdfsBaseDir, sriParams.verifyTypesPartitionColumn)
    val rowHistoryTable: String = getRowHistoryTable(sriParams.source, sriParams.country, sriParams.opsSchema, columnDelimiter, sriParams.hdfsBaseDir)
    (sriOpenTable + sriNonOpenTable + verifyTypesTables + rowCountsTable + rowHistoryTable + invalidTypesTable + eodTable).stripLineEnd.toLowerCase
  }

  private val cdcColSchema = """,c_journaltime string,c_transactionid string,c_operationtype string,c_userid string"""


  def createEodTable(database: String, tableName: String, hdfsLocation: String): String = {
    s"""create schema if not exists $database;
       |drop table if exists $database.$tableName;
       |create external table if not exists $database.$tableName(
       |   source string,country string,markerTime string,previousBusinessDate string
       |   )
       |partitioned by (businessDate string)
       |stored as ORC
       |location '$hdfsLocation';""".stripMargin
  }

  def getTableSchema(database: String, tableName: String, hiveColSchema: String, partitionColumn: String, columnDelimiter: String, hdfsLocation: String, cdcSource: Boolean): String = {
    val cdcColumn = if (cdcSource) cdcColSchema else ""
    s"""create schema if not exists $database;
       |drop table if exists $database.$tableName;
       |create external table if not exists $database.$tableName(
       |   ROWID string
       |   ,s_startdt string,s_starttime string,s_enddt string,s_endtime string,s_deleted_flag string
       |   $cdcColumn$hiveColSchema
       |   )
       |partitioned by ($partitionColumn string)
       |stored as ORC
       |location '$hdfsLocation';""".stripMargin
  }

  //Shall be ported post Avrov1.8.x upgrade
  val toAvroType: String => String = typee => typee match {
    case "BOOLEAN" | "SHORT" => "boolean"
    case "INT" => "int"
    case "LONG" => "long"
    case "FLOAT" => "float"
    case x if List("DECIMAL", "DOUBLE").exists(typee.contains) => "double"
    case x if List("CHAR", "VARCHAR", "STRING", "DATE", "TIMESTAMP").exists(typee.contains) => "string"
    case _ => throw new IllegalArgumentException(s"Invalid type: $typee")
  }

  def createHiveSchema(tableConfig: TableConfig, isAvro: Boolean = false): String = {
    val columns: Array[String] = tableConfig.colSchema.split("\\^")
    columns.map {
      col =>
        val strings = col.split(" ")
        val drop = strings.exists(_.equalsIgnoreCase("DROP"))

        drop match {
          case true => ""
          case false if !isAvro => "," + strings(0) + " " + strings(1)
          case false if isAvro => "," + strings(0) + " " + toAvroType(strings(1))
        }

    }.foldRight("") { (x, y) => x + y }
  }

  def getRowCountsTable(source: String, country: String, opsSchemaName: String, columnDelimiter: String, hdfsRootDir: String): String = {
    val rowCountsTable: String = s"""${source}_${country}_rowcounts"""
    s"""create schema if not exists $opsSchemaName;
       |drop table if exists ${opsSchemaName}.$rowCountsTable;
       |create external table if not exists ${opsSchemaName}.${rowCountsTable}(
       |   schemaname string COMMENT 'schema (or database)',
       |   tablename string COMMENT 'physical table that is the source of rowcount computation',
       |   rowcount bigint,
       |   functionaltable string COMMENT 'logical table whose data is embedded in the physical table and that forms the granularity of rowcounts',
       |   asof string COMMENT 'date timestamp at which the row count entry was made',
       |   comment string COMMENT 'processing step that populated this row',
       |   attempt_id string COMMENT 'job attempt that executed this step'
       |   )
       |partitioned by (rcds string)
       |stored as ORC
       |location '$hdfsRootDir$opsSchemaName/$rowCountsTable';""".stripMargin
  }

  def getRowHistoryTable(source: String, country: String, opsSchemaName: String, columnDelimiter: String, hdfsRootDir: String): String = {
    val rowHistoryTable: String = s"""${source}_${country}_rowhistory"""
    s"""create schema if not exists $opsSchemaName;
       |drop table if exists ${opsSchemaName}.$rowHistoryTable;
       |CREATE EXTERNAL TABLE ${opsSchemaName}.${rowHistoryTable}(
       |   ROWID string,
       |   FILENAME string
       |)
       | partitioned by (vds string)
       |STORED as AVRO
       |location '$hdfsRootDir$opsSchemaName/$rowHistoryTable';""".stripMargin
  }

  def getVerifyTypesTables(database: String, tableName: String, hiveColSchema: String, partitionColumn: String, columnDelimiter: String,
                           hdfsLocation: String, cdcSource: Boolean): String = {
    val cdcColumn = if (cdcSource) {
      cdcColSchema
    } else {
      ""
    }
    s"""create schema if not exists $database;
       |drop table if exists ${database}.${tableName};
       |create external table if not exists ${database}.${tableName}(
       |   ROWID string, FILENAME string
       |   $cdcColumn$hiveColSchema
       |   )
       |partitioned by ($partitionColumn string)
       |stored as AVRO
       |location '$hdfsLocation';""".stripMargin
  }

  def getInvalidTypesTable(source: String, country: String, storageSchemaName: String, hdfsRootDir: String, partitionColumn: String): String = {

    val invalidTypesTable: String = s"""${source}_${country}_invalidtypes"""
    s"""
       |create schema if not exists $storageSchemaName;
       |drop table if exists ${storageSchemaName}.${invalidTypesTable};
       |create external table if not exists ${storageSchemaName}.${invalidTypesTable}(
       |      source string,country string,tablename string,rowid string,data string,errormsg string, partitioncolumn string, ts string
       |  )
       |  partitioned by ($partitionColumn string)
       |  stored as orc
       |  location '$hdfsRootDir$storageSchemaName/$invalidTypesTable';""".stripMargin

  }

}
