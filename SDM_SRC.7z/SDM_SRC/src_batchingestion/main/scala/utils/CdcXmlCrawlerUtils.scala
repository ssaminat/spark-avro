/*
 * Copyright 2017 Standard Chartered Bank
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package utils

import java.io.{BufferedInputStream, ByteArrayInputStream, File, PrintWriter}
import java.nio.file
import java.nio.file.{FileSystem, Files}
import java.nio.file.StandardOpenOption._

import models.XmlParser._
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.Path
import org.apache.hadoop.io.IOUtils

import scala.collection.immutable.Seq
import scala.io.Source
import scala.xml.{Elem, NodeSeq}

object CdcXmlCrawlerUtils {

  def main(args: Array[String]) {
    val Array(cdcXmlFileName, keyColFileName, sourceTypeFileName, transRulesFileName, tableConfigFileName) = args
    writeConfigurationFile(cdcXmlFileName, keyColFileName, sourceTypeFileName, transRulesFileName, tableConfigFileName)
  }

  def writeConfigurationFile(cdcXmlFileName: String, keyColFileName: String, sourceTypeFileName: String, transRulesFileName: String, tableConfigFileName: String): file.Path = {
    val localFs: FileSystem = java.nio.file.FileSystems.getDefault
    val configXmlFile = localFs.getPath(tableConfigFileName)

    val configuration = cdcCrawler(cdcXmlFileName, keyColFileName, sourceTypeFileName, transRulesFileName)
    Files.write(configXmlFile, configuration.toString.getBytes, CREATE, APPEND)
  }

  def writeHdfsConfigurationFile(cdcXmlFileName: String, keyColFileName: String, sourceTypeFileName: String, transRulesFileName: String, tableConfigFileName: String): Unit = {
    val configuration = cdcCrawler(cdcXmlFileName, keyColFileName, sourceTypeFileName, transRulesFileName)
    val fs: org.apache.hadoop.fs.FileSystem = FileSystemUtils.fetchFileSystem
    val in = new BufferedInputStream(new ByteArrayInputStream(configuration.toString.getBytes))
    val os = fs.create(new Path(tableConfigFileName))
    IOUtils.copyBytes(in, os, new Configuration())
  }

  def cdcCrawler(cdcXmlFileName: String, keyColFileName: String, sourceTypeFileName: String, transRulesFileName: String): CdcConfiguration = {

    val cdcXml: Elem = xml.XML.loadFile(new File(cdcXmlFileName))
    val tableMappings: NodeSeq = cdcXml \\ "TableMapping"

    val keyColFile: List[String] = Source.fromFile(new File(keyColFileName)).getLines().filter(!_.isEmpty).toList
    val keyColList: List[TableKeyColInfo] = keyColFile.map(_.split("->")).map(x => TableKeyColInfo(x(0), x(1).trim))

    val tableTypeFile: List[String] = Source.fromFile(new File(sourceTypeFileName)).getLines().filter(!_.isEmpty).toList
    val sourceTypeList: List[TableSourceInfo] = tableTypeFile.map(_.split("->")).map(x => TableSourceInfo(x(0), x(1).trim))

    val transColFile = Source.fromFile(new File(transRulesFileName)).getLines().filter(!_.isEmpty).toList
    val transColList: List[TableTransformationRule] =
      if (transColFile.nonEmpty) {
        transColFile.map(_.split("->")).map(x => TableTransformationRule(x(0),
          x(1).split("\\|").map(ColTransformationRule(_)).toList))
      }
      else List()

    val properties: Seq[Property] = tableMappings.flatMap {
      tableMap => {
        val tableName: String = XmlParserUtils.getXmlAttribute(tableMap, "sourceTableName").toString()
        val sourceColumns = tableMap \\ "SourceColumn"

        val rulesList: List[ColTransformationRule] = if (transColList.nonEmpty) transColList.filter(_.tableName.equals(tableName)).head.rulesList else List()

        val keyPrefix = Constants.PREFIX_CONFIG_EDMHDPIF_TABLE + tableName
        val colSchema = sourceColumns.map(sourceCol => XmlParserUtils.getColumn(sourceCol, tableName, rulesList)).mkString("^")

        Seq(Property(keyPrefix + Constants.SUFFIX_CONFIG_COLSCHEMA, colSchema),
          Property(keyPrefix + Constants.SUFFIX_CONFIG_SOURCETYPE, sourceTypeList.filter(_.tableName.equals(tableName)).head.typee),
          Property(keyPrefix + Constants.SUFFIX_CONFIG_KEYCOLS, keyColList.filter(_.tableName.equals(tableName)).head.keyCols))
      }
    }
    CdcConfiguration(properties.toList)
  }
}
