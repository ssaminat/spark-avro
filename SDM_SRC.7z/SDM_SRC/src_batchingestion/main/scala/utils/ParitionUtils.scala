/*
 * Copyright 2017 Standard Chartered Bank
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package utils

import org.joda.time._

object ParitionUtils {

  import utils.Constants._

  type Partition = String
  type Format = String
  type TimeRange = String
  type RecursionLimit = Int

  case class PartitionInformation(partition: Partition, format: Format, timeRange: TimeRange, limit: RecursionLimit)

  val calendarDifference: String => String => DateTime => DateTime = frequency => period => cal => frequency match {
    case "minutes" => cal.minusMinutes(period.toInt)
    case "hours" => cal.minusHours(period.toInt)
    case "days" => cal.minusDays(period.toInt)
    case "months" => cal.minusMonths(period.toInt)
    case _ => throw new IllegalArgumentException(s"period $frequency was expected to be in minutes or hours or days or months")
  }

  def getPreviousBusinessDatePartition(input: String, partitionFormat: String, deltaa: String): String = {
    val Array(frequency, period) = deltaa.replaceAll("[(|)]", " ").split(" ")
    val parsedDate: DateTime = formatter(partitionFormat) parseDateTime input
    formatter(partitionFormat) print calendarDifference(frequency)(period)(parsedDate)
  }

  val allPartitions: PartitionInformation => List[String] = {
    case PartitionInformation(_, _, _, 0) => Nil
    case PartitionInformation(partition, format, timeRange, limit) => getPreviousBusinessDatePartition(partition, format,
      timeRange) :: allPartitions(PartitionInformation(getPreviousBusinessDatePartition(partition, format, timeRange), format, timeRange, limit - 1))
  }
}

