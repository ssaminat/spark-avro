package tests.poc

import models.XmlParser.TableConfig
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.FileSystem
import org.scalatest.{FlatSpec, Matchers}
import utils.FileSystemUtils

class XmlParserForTableConfig extends FlatSpec with Matchers {

  "ParseASampleXmlToTableConfigs" should "parse all correctly" in {

    val fs = FileSystemUtils.fetchFileSystem

    val configs: List[TableConfig] = models.XmlParser.parseXmlConfig("sampleconfig/gps_all_tables_config.xml", fs)

    assert(configs.size == 10)

    val tableNames: Array[String] = ("gps_all_tl_eod_marker,gps_all_tl_pymt_batch_trk," +
      "gps_all_ds_bank_ref,gps_all_tl_pymt_batch,gps_all_tl_pymt_details_trk," +
      "gps_all_tl_pymt_details_merger_addl,gps_all_tl_sys_parm,gps_all_tl_rpt_sts_recon,gps_all_tl_pymt_details,gps_all_ds_operating_accts").split(",")

    configs.foreach(x => assert(tableNames.contains(x.name)))


  }

}
