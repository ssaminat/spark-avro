package tests.poc.integration

import java.io.File

import models.SriParams
import models.XmlParser.parseXmlConfig
import org.apache.commons.io.FileUtils
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.FileSystem
import org.apache.spark.SparkContext
import org.apache.spark.sql.hive.HiveContext
import org.scalatest.{FlatSpec, Matchers}
import processor.Sri.processSri
import tests.poc.fixtures.SparkContextFixture
import utils.SchemaUtils
import utils.SriUtils.getParamConf
// FIX the input avro file to contain vds column as well.
class AvroReaderTest extends FlatSpec with Matchers with SparkContextFixture {

  "Read Avro files for VtypeInputs" should "read" ignore withSparkContext {
    (sc: SparkContext, sqlContext: HiveContext) =>
      val conf = new Configuration()
      val fs = FileSystem.get(conf)
      val configuration = getParamConf(fs, "src/test/resources/avrotest/param.xml")
      configuration.reloadConfiguration()
      configuration.set("hdfsDataParentDir", new File(configuration.get("hdfsDataParentDir")).getAbsolutePath.replaceAll("\\\\", "/"))
      FileUtils.deleteDirectory(new File(configuration.get("hdfsDataParentDir")))

      val params = SriParams(configuration, "2017_07_17_06", "2017-07-17", "fulldump", "2017-07-17 06:45:47", "2017_07_16_06")

      val tableConfigs = parseXmlConfig(params.tableConfigXml, fs).filter(_.name.equals("ecddp_all_COPI_FATCA_STATUS_INFO_CRS"))
      tableConfigs.foreach {
        tableConfig =>
          SchemaUtils.getSriTablesSchema(tableConfig, params)
            .split(";")
            .filterNot(_.startsWith("drop"))
            .foreach(sqlContext.sql)
      }
      FileUtils.copyFileToDirectory(new File("src/test/resources/avrotest/COPI_FATCA_STATUS_INFO_CRS.D2017198.T064149830.R011446.avro"),
        new File(params.getVerifyTypesPartitionPath("ecddp_all_COPI_FATCA_STATUS_INFO_CRS", "2017_07_17_05") + "/"))
      processSri(params, fs, tableConfigs, new Configuration())(sc, sqlContext, "com.databricks.spark.avro")

      sqlContext.sql("select count(*) from " + params.sriOpenSchema + "." + "ecddp_all_COPI_FATCA_STATUS_INFO_CRS" + " where ods='2017-07-17'").first().getLong(0) should be(11446)
      sqlContext.sql("select * from " + params.sriOpenSchema + "." + "ecddp_all_COPI_FATCA_STATUS_INFO_CRS" + " where ods='2017-07-17'").head().mkString("|")
      params
  }
}
