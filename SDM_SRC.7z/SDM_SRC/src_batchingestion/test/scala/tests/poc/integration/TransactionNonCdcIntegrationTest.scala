package tests.poc.integration

import java.io.File
import java.util.UUID

import models.SriParams
import models.XmlParser.TableConfig
import org.apache.commons.io.FileUtils
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.FileSystem
import org.apache.spark.SparkContext
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.hive.HiveContext
import org.scalatest.{FlatSpec, Matchers}
import processor.Sri
import testUtils.DataHelpers._
import tests.poc.fixtures.SparkContextFixture
import utils.{FileSystemUtils, SchemaUtils, SriUtils}
import testUtils.DataHelpers._

class TransactionNonCdcIntegrationTest extends FlatSpec with Matchers with SparkContextFixture {

  "TxnNonCdcDataSriTest" should "createSriOpen_NonOpen" in withSparkContext {
    (sc: SparkContext, sqlContext: HiveContext) =>
      val id = UUID.randomUUID().toString.substring(1, 5)
      val base = "target/batchIngestion/" + id
      val tableName = "gps_all_TxnNonCdcDataSriTest"
      prepareSampleNonCDCData(sc, sqlContext, base, tableName)
      val tableDictionary: List[TableConfig] = List(TableConfig(tableName, "txn", "SYSTEMID",
        "SYSTEMID VARCHAR(2) NOT NULL DEFAULT 'AB'^CURRENCYVAL VARCHAR(4)^CURRENTDATE VARCHAR(10)^DROPPEDCOL VARCHAR(8)", null, "", ""))
      val eodMarker = "2017-02-01 10:10:00"
      val businessDay = "2017-01-01 02:10:00"
      val (partition: String, businessDate: String) = SriUtils.getBusinessDayPartition(businessDay).get

      val sriParams: SriParams = SriParams(partition, businessDate, eodMarker, "batch", base, "txnNonCdcDataSriTest")
      val fs: FileSystem = FileSystemUtils.fetchFileSystem
      val schema: String = SchemaUtils.getSriTablesSchema(tableDictionary.head, sriParams)
      schema.split(";").foreach(sqlContext.sql)
      Sri.processSri(sriParams, fs, tableDictionary,new Configuration())(sc, sqlContext,"orc")
      val sqlSriOpen1: DataFrame = sqlContext.sql("select count(*) from " + sriParams.sriOpenSchema + "." + tableName + " where ods='2017-01-01'")
      assert(sqlSriOpen1.take(1).map(_.getLong(0)).head == 9)

      val eodMarker2 = "2017-02-02 10:10:00"
      val businessDay2 = "2017-01-02 02:10:00"

      val (partition2: String, businessDate2: String) = SriUtils.getBusinessDayPartition(businessDay2).get

      val sriParams2: SriParams = SriParams(partition2, businessDate2, eodMarker2, "batch", base, "txnNonCdcDataSriTest")

      Sri.processSri(sriParams2, fs, tableDictionary,new Configuration())(sc, sqlContext,"orc")
      val sqlSriOpen2: DataFrame = sqlContext.sql("select count(*) from " + sriParams.sriOpenSchema + "." + tableName + " where ods='2017-01-02'")
      assert(sqlSriOpen2.take(1).map(_.getLong(0)).head == 16)
      sriParams
  }


}