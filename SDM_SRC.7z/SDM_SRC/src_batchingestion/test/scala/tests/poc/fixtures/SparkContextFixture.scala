package tests.poc.fixtures

import java.util.UUID

import models.SriParams
import org.apache.spark.SparkContext
import org.apache.spark.sql.hive.HiveContext
import testUtils.DataHelpers._

trait SparkContextFixture {
  def withSparkContext(testCode: ((SparkContext, HiveContext) => SriParams)): Unit = {

    try {
      conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      conf.set("spark.kryo.registrationRequired", "true")
      conf.set("spark.sql.warehouse.dir", "target/" + UUID.randomUUID().toString.substring(5))
      val params: SriParams = testCode(sc, sqlContext)
    }
  }

}
