package utils

import models.SriParams
import models.XmlParser.TableConfig
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.scalatest.{FlatSpec, Matchers}

class SchemaUtilsTest extends FlatSpec with Matchers {

  "createCdcTable" should "return Schema with Cdc columns" ignore  {
    val tableConfig: TableConfig = TableConfig("table1", "delta", "SYSTEMID",
      "SYSTEMID VARCHAR(2) NOT NULL DEFAULT 'AB'^CURRENCYVAL VARCHAR(4) DROP^CURRENTDATE VARCHAR(10)^DROPPEDCOL VARCHAR(8)", null, "", "")
    val sriParams: SriParams = SriParams("", "", "", "cdc")

    val table: String = SchemaUtils.getSriTablesSchema(tableConfig, sriParams).stripLineEnd
    assert(table.split(";").length == 12)

    val hdfsRoot = sriParams.hdfsBaseDir

    val margin: String =
      s"""create schema if not exists gps_sri_open;
         |use gps_sri_open;
         |drop table if exists gps_sri_open.gps_all_table1;
         |create external table if not exists gps_sri_open.gps_all_table1(
         |   rowid string
         |   ,s_startdt string,s_starttime string,s_enddt string,s_endtime string,s_deleted_flag string
         |   ,c_journaltime string,c_transactionid string,c_operationtype string,c_userid string,SYSTEMID VARCHAR(2),CURRENTDATE VARCHAR(10),DROPPEDCOL VARCHAR(8)
         |   )
         |partitioned by (ods string)
         |row format delimited fields terminated by '\u0001'
         |stored as ORC
         |location '${hdfsRoot}gps_sri_open/gps_all_table1';create schema if not exists gps_sri_nonopen;
         |use gps_sri_nonopen;
         |drop table if exists gps_sri_nonopen.gps_all_table1;
         |create external table if not exists gps_sri_nonopen.gps_all_table1(
         |   rowid string
         |   ,s_startdt string,s_starttime string,s_enddt string,s_endtime string,s_deleted_flag string
         |   ,c_journaltime string,c_transactionid string,c_operationtype string,c_userid string,SYSTEMID VARCHAR(2),CURRENTDATE VARCHAR(10),DROPPEDCOL VARCHAR(8)
         |   )
         |partitioned by (nds string)
         |row format delimited fields terminated by '\u0001'
         |stored as ORC
         |location '${hdfsRoot}gps_sri_nonopen/gps_all_table1';
         |create schema if not exists gps_storage;
         |use gps_storage;
         |drop table if exists gps_all_table1_verifytypes;
         |create external table if not exists gps_all_table1_verifytypes(
         |   rowid string
         |   ,c_journaltime string,c_transactionid string,c_operationtype string,c_userid string,SYSTEMID VARCHAR(2),CURRENTDATE VARCHAR(10),DROPPEDCOL VARCHAR(8)
         |   )
         |partitioned by (vds string)
         |row format delimited fields terminated by '\u0001'
         |stored as ORC
         |location '${hdfsRoot}gps_storage/gps_all_table1_verifytypes';create schema if not exists gps_ops;
         |use gps_ops;
         |drop table if exists gps_all_rowcounts;
         |create external table if not exists gps_ops.gps_all_rowcounts(
         |   schemaname string COMMENT 'schema (or database)',
         |   tablename string COMMENT 'physical table that is the source of rowcount computation',
         |   rowcount bigint,
         |   functionaltable string COMMENT 'logical table whose data is embedded in the physical table and that forms the granularity of rowcounts',
         |   asof string COMMENT 'date timestamp at which the row count entry was made',
         |   comment string COMMENT 'processing step that populated this row',
         |   attempt_id string COMMENT 'job attempt that executed this step'
         |   )
         |partitioned by (rcds string)
         |row format delimited fields terminated by '\u0001'
         |stored as ORC
         |location '${hdfsRoot}gps_ops/gps_all_rowcounts';
         | """.stripMargin

    margin.split(";").zip(table.split(";")).foreach {
      x =>
        x._1.trim should be(x._2.trim)
    }
  }


  "createNonCdcTable" should "return Schema without Cdc columns" ignore {
    val tableConfig: TableConfig = TableConfig("gps_all_table1", "delta", "SYSTEMID",
      "SYSTEMID VARCHAR(2) NOT NULL DEFAULT 'AB'^CURRENCYVAL VARCHAR(4) DROP^CURRENTDATE VARCHAR(10)^DROPPEDCOL VARCHAR(8)", null, "", "")
    val sriParams: SriParams = SriParams("", "", "", "batch")

    val table: String = SchemaUtils.getSriTablesSchema(tableConfig, sriParams).stripLineEnd
    assert(table.split(";").length == 12)

    val hdfsRoot = sriParams.hdfsBaseDir

    val margin: String =
      s"""create schema if not exists gps_sri_open;
         |use gps_sri_open;
         |drop table if exists gps_sri_open.gps_all_table1;
         |create external table if not exists gps_sri_open.gps_all_table1(
         |   rowid string
         |   ,s_startdt string,s_starttime string,s_enddt string,s_endtime string,s_deleted_flag string
         |   ,SYSTEMID VARCHAR(2),CURRENTDATE VARCHAR(10),DROPPEDCOL VARCHAR(8)
         |   )
         |partitioned by (ods string)
         |row format delimited fields terminated by '\u0001'
         |stored as ORC
         |location '${hdfsRoot}gps_sri_open/gps_all_table1';create schema if not exists gps_sri_nonopen;
         |use gps_sri_nonopen;
         |drop table if exists gps_sri_nonopen.gps_all_table1;
         |create external table if not exists gps_sri_nonopen.gps_all_table1(
         |   rowid string
         |   ,s_startdt string,s_starttime string,s_enddt string,s_endtime string,s_deleted_flag string
         |   ,SYSTEMID VARCHAR(2),CURRENTDATE VARCHAR(10),DROPPEDCOL VARCHAR(8)
         |   )
         |partitioned by (nds string)
         |row format delimited fields terminated by '\u0001'
         |stored as ORC
         |location '${hdfsRoot}gps_sri_nonopen/gps_all_table1';
         |create schema if not exists gps_storage;
         |use gps_storage;
         |drop table if exists gps_all_table1_verifytypes;
         |create external table if not exists gps_all_table1_verifytypes(
         |   rowid string
         |   ,SYSTEMID VARCHAR(2),CURRENTDATE VARCHAR(10),DROPPEDCOL VARCHAR(8)
         |   )
         |partitioned by (vds string)
         |row format delimited fields terminated by '\u0001'
         |stored as ORC
         |location '${hdfsRoot}gps_storage/gps_all_table1_verifytypes';create schema if not exists gps_ops;
         |use gps_ops;
         |drop table if exists gps_all_rowcounts;
         |create external table if not exists gps_ops.gps_all_rowcounts(
         |   schemaname string COMMENT 'schema (or database)',
         |   tablename string COMMENT 'physical table that is the source of rowcount computation',
         |   rowcount bigint,
         |   functionaltable string COMMENT 'logical table whose data is embedded in the physical table and that forms the granularity of rowcounts',
         |   asof string COMMENT 'date timestamp at which the row count entry was made',
         |   comment string COMMENT 'processing step that populated this row',
         |   attempt_id string COMMENT 'job attempt that executed this step'
         |   )
         |partitioned by (rcds string)
         |stored as ORC
         |location '${hdfsRoot}gps_ops/gps_all_rowcounts';
         | """.stripMargin

    margin.split(";").zip(table.split(";")).foreach {
      x =>
        x._1.trim should be(x._2.trim)
    }
  }

}
