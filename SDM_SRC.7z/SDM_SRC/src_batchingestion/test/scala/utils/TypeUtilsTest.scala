package utils

import models.XmlParser
import models.XmlParser.TableConfig
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.FileSystem
import org.apache.spark.sql.Row
import org.scalatest.{FlatSpec, Matchers}

class TypeUtilsTest extends FlatSpec with Matchers {

  val fs: FileSystem = FileSystemUtils.fetchFileSystem


  "TypeTransformationOfSriOutputToOrcRowsWithTableStructs" should "MapItCorrectlyInTypes" in {

    val input: String = "attempt_1486653646012_6466_m_000003_0_1|ST_DT|ST_ST|END_DT|END_TM|DEL_FLG|" +
      "2017-02-18 22:08:49.000049|0|I|NOT SET   |2017-02-18 00:00:00|2017-02-19 00:00:00|2017-02-18 14:59:35|IN"
    val delimiter = "|"
    val tableDictionary: List[TableConfig] = models.XmlParser.parseXmlConfig("sampleconfig/gps_all_tables_config.xml", fs)
    XmlParser.fetchColumnConfig(tableDictionary.filter(x => "gps_all_tl_pymt_batch_trk".equals(x.name)).head)
    val tableName: String = "gps_all_tl_eod_marker"
    val data: Row = TypeUtils.extractRowFromSriOutputData(tableDictionary.filter(_.name.equals(tableName)).head, input.replace('|', '\u0001'), "\u0001", "ods", true)
    assert(data.size == 14)

  }
  "TypeTransformationOfSriOutputToOrcRowsWithTableStructsForAReallyLongTable" should "MapItCorrectlyInTypesForLongOnes" in {

    val input: String = "attempt_1486653646012_6466_m_000003_0_1|ST_DT|ST_ST|END_DT|END_TM" +
      "|DEL_FLG|2017-02-18 22:04:02.000002|0|I|NOT SET   |MY00140|R4017148|AE|DXB|XTT|ON|95|D0281781" +
      "|249|  |200001099512IQ01|2012-11-06 00:00:00|2012-11-08 00:00:00|AE|DXB|0108966500501" +
      "|USD|121.59|2012-11-07 00:00:00|MAHIR RIAD ABDUL SAHIB LU'AIBI| " +
      "|MAJNOON OIL FIELD, AL NASHWA DISTRI|BASRAH IRAQ|BASRAH IRAQ|Testaddr4|MAHIR RIAD ABDUL SAHIB LU AIBI|MAJNOON OIL FIELD, AL NASHWA DISTRI|BASRAH IRAQ| | |2012-11-14 07:51:25|BABIIQBAXXX" +
      "| | | | |N|658922|0001018295/OCT BONUS PAY/BONUS/1900000822| |0001018295/OCT BONUS PAY/BONUS/1900000822| |0| |  |             | ||          | |0|0|   " +
      "| |0|0|0| |D|6540496|1134.999961||| |4|IQD|IQD|138000|138000|138000|0|138000|N|0|0|C|C|N| " +
      "|BABIIQBAXXX/BANK OF BAGHDAD/AL DHAHIA|  | |M|C|N|   | || |1291687|200001099512IQ01" +
      "|Transaction Accepted in STSTPS|1|2012-11-06 18:06:51| |508944|508944|508944|1|S|||C|0|STS_APP| | ||N|0|0| |N| |                  |N|H2H|SCB279491|0|N| |N|0|0|0| |0| " +
      "|0| |0| |0| |0| |0| |0| |0| |0| |0| |0| |0| |0| |0| | ||N|N|658922|||0|N| | |N| | | | | | |  | | | " +
      "| | | | | | | | |N| |N| | |Narr| | | |0001018295 OCT BONUS PAY BONUS 1900000822| | | | | | | | | | | " +
      "| | | | | |MY00140|D0281781|R4017148|XTT| | | | | | |AE|DXB|0108966500501| |AL DHAHIA| | " +
      "|Shell Iraq Pet Dev (SCB)|0108966500501|Shell Iraq Pet Dev (SCB)|Convention Tower| | |REM| | | | " +
      "|Shell Iraq Pet Dev (SCB)|Convention Tower| | |||  ||||||| |D|C|Y|K|||||0|0|0|" +
      "|AOC1000475AEDXBMY00140R4017148XC|2012-11-08 00:00:00|||||||| |N||||||||||T|XC108539|SCBLGB2LWEB||||X| |D||D|SCBLAEADXXX||240827|C|Y|AE|DXB" +
      "|US|NY ||||||||||GMY00140|USD|21690039902|5209449062201|3582" +
      "088678001|3582022128001|CCS|2012-11-08 00:00:00|||||||2012-11-08 00:00:00|STS|CCS|IN01904|NA|FULL|N||||||||||||||" +
      "||||||||"
    val delimiter = "|"
    val tableDictionary: List[TableConfig] = models.XmlParser.parseXmlConfig("sampleconfig/gps_all_tables_config.xml", fs)
    val tableName: String = "gps_all_tl_pymt_details"
    val data: Row = TypeUtils.extractRowFromSriOutputData(tableDictionary.filter(_.name.equals(tableName)).head, input.replace('|', '\u0001'), "\u0001", "ods", true)
    assert(data.size == 366)

  }
}
