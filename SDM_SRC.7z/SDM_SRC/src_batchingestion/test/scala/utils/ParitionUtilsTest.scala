package utils

import models.ParameterUtils
import org.scalatest.{FlatSpec, Matchers}
import utils.Constants.`verify types partition format`
import utils.ParitionUtils.PartitionInformation

class ParitionUtilsTest extends FlatSpec with Matchers {

  "TestPartitionUtilPreviousPartiton" should "fetchCorrectPreviousPartitionInSoManyCalls" in {

    assert(ParitionUtils.getPreviousBusinessDatePartition("2017_02_18", "yyyy_MM_dd", "days(1)").equals("2017_02_17"),
      " Previous Partition Was successfully fetched for daily ones")
    assert(utils.ParitionUtils.allPartitions(PartitionInformation(ParameterUtils.getVerifyTypePartitionFromBusinessDateFormat("2017-01-01 10:33:33"),
      `verify types partition format`, "hours(1)", 1)).equals(List("2017_01_01_09")))
    assert(ParitionUtils.getPreviousBusinessDatePartition("2017_02_18", "yyyy_MM_dd", "days(1)").equals("2017_02_17"),
      " Previous Partition Was successfully fetched for daily ones")
    assert(ParitionUtils.getPreviousBusinessDatePartition("2017_02_17_12", "yyyy_MM_dd_HH", "hours(1)").equals("2017_02_17_11"),
      " Previous Partition Was successfully fetched for hourly ones ")
    assert(ParitionUtils.getPreviousBusinessDatePartition("2017_02_17_22_30", "yyyy_MM_dd_HH_mm", "minutes(30)").equals("2017_02_17_22_00"),
      " Previous Partition Was successfully fetched for monthly ones")
  }
}
