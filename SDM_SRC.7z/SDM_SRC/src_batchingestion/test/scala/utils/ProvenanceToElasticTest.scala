package utils

import models.SriParams
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.Path
import org.scalatest.{FlatSpec, Matchers}
import tests.poc.fixtures.SparkContextFixture
import utils.ProvenanceUtils._

class ProvenanceToElasticTest extends FlatSpec with Matchers with SparkContextFixture {

  val paramConf: Configuration = new Configuration()
  paramConf.addResource(new Path("sampleconfig/param.xml"))

  "provenance_info_json" should "produce json string given job details" in withSparkContext {
    (sc, cntx) =>
      val res = provenance_info_json(sc.applicationAttemptId.getOrElse("testAttemptId"), "2017-03-18", "runType",
        "ebbs", "india")
      val expected = """{"SparkJob-AttemptID":"testAttemptId", "BusinessDay":"2017-03-18","RunType":"runType", "Source":"ebbs","Country":"india"}"""
      assert(res == expected)
      SriParams("", "", "", "batch")
  }

  "get Connection function " should "return URL for connection to elastic search" in withSparkContext {
    (sc, cntx) =>
      assert(getElasticSearchConnection(paramConf) == "http://localhost:9200/sparkJobInfo/metatable")
      SriParams("", "", "", "batch")
  }


}
