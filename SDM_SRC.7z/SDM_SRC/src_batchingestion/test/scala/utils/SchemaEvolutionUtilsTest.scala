package utils

import org.scalatest.{FlatSpec, Matchers}
import utils.SchemaEvolutionUtils.SchemaCompare

class SchemaEvolutionUtilsTest extends FlatSpec with Matchers {

  "NewColumnAddedAtMiddle1" should "returnADD_between" in {
    val list1 = List("column1", "column2", "column3", "column4")
    val list2 = List("column1", "column3", "column4")
    val schema = SchemaEvolutionUtils.compareSchema(list1, list2).head
    assert(schema._1.compareTo(SchemaCompare.ADD_BETWEEN) == 0)
    assert(schema._2 == 1)
  }

  "NewColumnAddedAtMiddle2" should "returnADD_between" in {
    val list1 = List("column1", "column2", "column3", "column4")
    val list2 = List("column1", "column2", "column4")
    val schema = SchemaEvolutionUtils.compareSchema(list1, list2).head
    assert(schema._1.compareTo(SchemaCompare.ADD_BETWEEN) == 0)
    assert(schema._2 == 2)
  }

  "NewColumnAddedAtStart" should "returnADD_between" in {
    val list1 = List("column1", "column2", "column3", "column4")
    val list2 = List("column2", "column3", "column4")
    val schema = SchemaEvolutionUtils.compareSchema(list1, list2).head
    assert(schema._1.compareTo(SchemaCompare.ADD_BETWEEN) == 0)
    assert(schema._2 == 0)
  }

  "NewColumnAddedAtEnd" should "returnADD_end" in {
    val list1 = List("column1", "column2", "column3", "column4")
    val list2 = List("column1", "column2", "column3")
    val schema = SchemaEvolutionUtils.compareSchema(list1, list2).head
    assert(schema._1.compareTo(SchemaCompare.ADD_END) == 0)
    assert(schema._2 == 3)
  }

  "ColumnDeleteAtMiddle1" should "returnDELETE_between" in {
    val list1 = List("column1", "column2", "column4")
    val list2 = List("column1", "column2", "column3", "column4")
    val schema = SchemaEvolutionUtils.compareSchema(list1, list2).head
    assert(schema._1.compareTo(SchemaCompare.DELETE_BETWEEN) == 0)
    assert(schema._2 == 2)
  }

  "ColumnDeleteAtMiddle2" should "returnDELETE_between" in {
    val list1 = List("column1", "column3", "column4")
    val list2 = List("column1", "column2", "column3", "column4")
    val schema = SchemaEvolutionUtils.compareSchema(list1, list2).head
    assert(schema._1.compareTo(SchemaCompare.DELETE_BETWEEN) == 0)
    assert(schema._2 == 1)
  }

  "ColumnDeleteAtStart" should "returnDELETE_between" in {
    val list1 = List("column2", "column3", "column4")
    val list2 = List("column1", "column2", "column3", "column4")
    val schema = SchemaEvolutionUtils.compareSchema(list1, list2).head
    assert(schema._1.compareTo(SchemaCompare.DELETE_BETWEEN) == 0)
    assert(schema._2 == 0)
  }

  "ColumnDeleteAtEnd" should "returnDELETE_end" in {
    val list1 = List("column1", "column2", "column3")
    val list2 = List("column1", "column2", "column3", "column4")
    val schema = SchemaEvolutionUtils.compareSchema(list1, list2).head
    assert(schema._1.compareTo(SchemaCompare.DELETE_END) == 0)
    assert(schema._2 == 3)
  }

  "NoChange" should "returnNo_change" in {
    val list1 = List("column1", "column2", "column3", "column4")
    val list2 = List("column1", "column2", "column3", "column4")
    val schema = SchemaEvolutionUtils.compareSchema(list1, list2).head
    assert(schema._1.compareTo(SchemaCompare.NO_CHANGE) == 0)
    assert(schema._2 == -1)
  }

  "MultipleNewColumnAddedAtMiddle" should "returnADD_between" in {
    val list1 = List("column1", "column2", "column3", "column4", "column5", "column6", "column7")
    val list2 = List("column1", "column2", "column7")
    val schema = SchemaEvolutionUtils.compareSchema(list1, list2)
    assert(schema.length == 4)
    assert(schema.filterNot(_._1.compareTo(SchemaCompare.ADD_BETWEEN) == 0).length == 0)
    assert(schema.map(_._2).equals(List(2, 3, 4, 5)))
  }

  "MultipleNewColumnAddedAtEnd" should "returnADD_end" in {
    val list1 = List("column1", "column2", "column3", "column4", "column5", "column6", "column7")
    val list2 = List("column1", "column2")
    val schema = SchemaEvolutionUtils.compareSchema(list1, list2)
    assert(schema.length == 5)
    assert(schema.filterNot(_._1.compareTo(SchemaCompare.ADD_END) == 0).length == 0)
    assert(schema.map(_._2).equals(List(2, 3, 4, 5, 6)))
  }

  "MultipleNewColumnAddedAtStart" should "returnADD_between" in {
    val list1 = List("column1", "column2", "column3", "column4", "column5", "column6", "column7")
    val list2 = List("column7")
    val schema = SchemaEvolutionUtils.compareSchema(list1, list2)
    assert(schema.length == 6)
    assert(schema.filterNot(_._1.compareTo(SchemaCompare.ADD_BETWEEN) == 0).length == 0)
    assert(schema.map(_._2).equals(List(0, 1, 2, 3, 4, 5)))
  }

  "MultipleColumnDeleteAtMiddle" should "returnDELETE_between" in {
    val list1 = List("column1", "column2", "column7")
    val list2 = List("column1", "column2", "column3", "column4", "column5", "column6", "column7")
    val schema = SchemaEvolutionUtils.compareSchema(list1, list2)
    assert(schema.length == 4)
    assert(schema.filterNot(_._1.compareTo(SchemaCompare.DELETE_BETWEEN) == 0).length == 0)
    assert(schema.map(_._2).equals(List(2, 3, 4, 5)))
  }

  "MultipleColumnDeleteAtEnd" should "returnDELETE_end" in {
    val list1 = List("column1", "column2")
    val list2 = List("column1", "column2", "column3", "column4", "column5", "column6", "column7")
    val schema = SchemaEvolutionUtils.compareSchema(list1, list2)
    assert(schema.length == 5)
    assert(schema.filterNot(_._1.compareTo(SchemaCompare.DELETE_END) == 0).length == 0)
    assert(schema.map(_._2).equals(List(2, 3, 4, 5, 6)))
  }

  "MultipleColumnDeleteAtStart" should "returnDELETE_between" in {
    val list1 = List("column7")
    val list2 = List("column1", "column2", "column3", "column4", "column5", "column6", "column7")
    val schema = SchemaEvolutionUtils.compareSchema(list1, list2)
    assert(schema.length == 6)
    assert(schema.filterNot(_._1.compareTo(SchemaCompare.DELETE_BETWEEN) == 0).length == 0)
    assert(schema.map(_._2).equals(List(0, 1, 2, 3, 4, 5)))
  }

  "deleteAndAdd" should "returnDELETE_Add" in {
    val list1 = List("column1")
    val list2 = List("column2")
    val schema = SchemaEvolutionUtils.compareSchema(list1, list2)
    assert(schema.length == 2)
    assert(schema.count(_._1.compareTo(SchemaCompare.DELETE_END) == 0) == 1)
    assert(schema.count(_._1.compareTo(SchemaCompare.ADD_END) == 0) == 1)
    assert(schema.map(_._2).equals(List(0, 0)))
  }

  "deleteAndAdd2" should "returnDELETE_Add" in {
    val list1 = List("column1", "column2", "column4")
    val list2 = List("column1", "column3", "column4")
    val schema = SchemaEvolutionUtils.compareSchema(list1, list2)
    assert(schema.length == 2)
    assert(schema.count(_._1.compareTo(SchemaCompare.DELETE_END) == 0) == 1)
    assert(schema.count(_._1.compareTo(SchemaCompare.ADD_END) == 0) == 1)
    assert(schema.map(_._2).equals(List(1, 1)))
  }

  "deleteAndAdd3" should "returnDELETE_Add" in {
    val list1 = List("column2", "column4")
    val list2 = List("column3", "column4")
    val schema = SchemaEvolutionUtils.compareSchema(list1, list2)
    assert(schema.length == 2)
    assert(schema.count(_._1.compareTo(SchemaCompare.DELETE_END) == 0) == 1)
    assert(schema.count(_._1.compareTo(SchemaCompare.ADD_END) == 0) == 1)
    assert(schema.map(_._2).equals(List(0, 0)))
  }

  "deleteAndAdd4" should "returnDELETE_Add" in {
    val list1 = List("column1", "column2", "column3", "column5")
    val list2 = List("column1", "column3", "column4", "column5")
    val schema = SchemaEvolutionUtils.compareSchema(list1, list2)
    assert(schema.length == 2)
    assert(schema.count(_._1.compareTo(SchemaCompare.DELETE_BETWEEN) == 0) == 1)
    assert(schema.count(_._1.compareTo(SchemaCompare.ADD_BETWEEN) == 0) == 1)
    assert(schema.map(_._2).equals(List(1, 2)))
  }

  "deleteAndAdd5" should "returnDELETE_Add" in {
    val list1 = List("column1", "column2", "column3", "column4", "column5", "column6", "column7")
    val list2 = List("column1", "column2", "column8")
    val schema = SchemaEvolutionUtils.compareSchema(list1, list2)
    assert(schema.length == 6)
    assert(schema.count(_._1.compareTo(SchemaCompare.DELETE_END) == 0) == 1)
    assert(schema.count(_._1.compareTo(SchemaCompare.ADD_END) == 0) == 5)
    assert(schema.map(_._2).equals(List(2, 2, 3, 4, 5, 6)))
  }

}
