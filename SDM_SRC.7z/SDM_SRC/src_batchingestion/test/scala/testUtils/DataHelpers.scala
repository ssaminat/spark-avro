package testUtils

import java.io.File

import models.SriParams
import models.XmlParser.TableConfig
import org.apache.commons.io.FileUtils
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.{SparkConf, SparkContext}
import utils.FileSystemUtils

object DataHelpers {


  System.setProperty("hive.exec.staging", "tmp/hive/staging")
  System.setProperty("hive.exec.scratchdir", "tmp/hive/staging")

  val conf = new SparkConf().setAppName("ScudeePocSparkTableLevelFixture").setMaster("local[1]")
  val sc = new SparkContext(conf)
  val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)

  case class Table2(rowId: String, filename: String, vds: String, SYSTEMID: String, CURRENCYVAL: String, OPTYPE: String, DROPPEDCOL: String)

  case class Table1(rowId: String, filename: String, vds: String, vds1: String, journalTS: String, transactionId: String, operationType: String,
                    userId: String, SYSTEMID: String, CURRENCYVAL: String, CURRENTDATE: String,
                    DROPPEDCOL: String)

  def prepareSampleNonCDCData: (SparkContext, HiveContext, String, String) => SriParams = {


    (sc: SparkContext, sqlContext: HiveContext, base: String, tableName: String) =>
      val tableDictionary: List[TableConfig] = List(TableConfig(tableName, "delta", "SYSTEMID",
        "SYSTEMID VARCHAR(2) NOT NULL DEFAULT 'AB'^CURRENCYVAL VARCHAR(4)^OPTYPE VARCHAR(1)^DROPPEDCOL VARCHAR(8)", null, "", ""))
      val sriParams: SriParams = SriParams("", "", "", "batch", base)

      val verifyTypesBaseDir: String = sriParams.getVerifyTypesPath(tableDictionary.head.name)


      val table1P1: Seq[Table2] = Seq(
        Table2("attempt_0001", "FNAME", "2017_01_01_01", "01", "CVAL", "I", "12345678"),
        Table2("attempt_0002", "FNAME", "2017_01_01_01", "02", "CVAL", "I", "12345678"),
        Table2("attempt_0003", "FNAME", "2017_01_01_01", "03", "CVAL", "I", "12345678"),
        Table2("attempt_0004", "FNAME", "2017_01_01_01", "03", "CVAL", "I", "12345678"),
        Table2("attempt_0005", "FNAME", "2017_01_01_01", "04", "CVAL", "I", "12345678")
      ) ++ Seq(
        Table2("attempt_0011", "FNAME", "2017_01_01_02", "01", "CVL", "A", "12345678")
        ,
        Table2("attempt_0012", "FNAME", "2017_01_01_02", "02", "CVAL", "A", "1234567"),
        Table2("attempt_0013", "FNAME", "2017_01_01_02", "04", "CVAL", "D", "12345678")
        ,
        Table2("attempt_0014", "FNAME", "2017_01_01_02", "03", "CVAL", "I", "12345678")
      ) ++ Seq(
        Table2("attempt_0101", "FNAME", "2017_01_02_01", "11", "CVAL", "I", "12345678"),
        Table2("attempt_0102", "FNAME", "2017_01_02_01", "12", "CVAL", "I", "12345678"),
        Table2("attempt_0103", "FNAME", "2017_01_02_01", "13", "CVAL", "I", "12345678"),
        Table2("attempt_0104", "FNAME", "2017_01_02_01", "13", "CVAL", "D", "12345678")
      ) ++ Seq(
        Table2("attempt_0111", "FNAME", "2017_01_02_02", "01", "CVL", "D", "12345678"),
        Table2("attempt_0112", "FNAME", "2017_01_02_02", "11", "CVL", "A", "12345678"),
        Table2("attempt_0113", "FNAME", "2017_01_02_02", "12", "CVAL", "A", "1234567")
      )


      sqlContext.createDataFrame(sc.parallelize(table1P1)).write.format("orc").partitionBy("vds").save(verifyTypesBaseDir)


      val fs: FileSystem = FileSystemUtils.fetchFileSystem


      fs.listStatus(new Path(verifyTypesBaseDir)).foreach {
        partition =>
          fs.listStatus(partition.getPath).filter(_.getPath.getName.startsWith("part-r-")).foreach {
            file =>
              val newPath: String = partition.getPath.toString + "/" + tableName.split('_').drop(2).mkString("_") + ".D0" + file.getPath.getName
              val oldPath: String = partition.getPath.toString + "/" + file.getPath.getName

              fs.rename(new Path(oldPath), new Path(newPath))
          }
      }
      sriParams
  }

  def prepareSampleCDCData: (SparkContext, HiveContext, String, String) => SriParams = {
    (sc: SparkContext, sqlContext: HiveContext, base: String, tableName: String) =>
      val tableDictionary: List[TableConfig] = List(TableConfig(tableName, "delta", "SYSTEMID",
        "SYSTEMID VARCHAR(2) NOT NULL DEFAULT 'AB'^CURRENCYVAL VARCHAR(4)^CURRENTDATE VARCHAR(10)^DROPPEDCOL VARCHAR(8)", null, "", ""))
      val sriParams: SriParams = SriParams("", "", "", "cdc", base)

      val verifyTypesBaseDir: String = sriParams.getVerifyTypesPath(tableDictionary.head.name)

      val table1P1: Seq[Table1] = Seq(
        Table1("attempt_0001", "FNAME", "2017_01_01_01", "2017_01_01_01", "2017-01-01 00:00:15.000000", "trid", "I", "user", "01", "CVAL", "2015-01-01", "12345678"),
        Table1("attempt_0002", "FNAME", "2017_01_01_01", "2017_01_01_01", "2017-01-01 00:01:15.000000", "trid", "I", "user", "02", "CVAL", "2015-01-01", "12345678"),
        Table1("attempt_0003", "FNAME", "2017_01_01_01", "2017_01_01_01", "2017-01-01 00:02:15.000000", "trid", "I", "user", "03", "CVAL", "2015-01-01", "12345678"),
        Table1("attempt_0004", "FNAME", "2017_01_01_01", "2017_01_01_01", "2017-01-01 00:03:15.000000", "trid", "I", "user", "04", "CVAL", "2015-01-01", "12345678"),
        Table1("attempt_0005", "FNAME", "2017_01_01_01", "2017_01_01_01", "2017-01-01 00:03:15.000000", "trid", "I", "user", "04", "CVAL", "2015-01-01", "12345678"),
        Table1("attempt_0006", "FNAME", "2017_01_01_01", "2017_01_01_01", "2017-01-01 00:03:16.000000", "trid", "I", "user", "04", "CVAL", "2015-01-01", "12345678"),
        Table1("attempt_0007", "FNAME", "2017_01_01_01", "2017_01_01_01", "2017-01-01 00:03:15.000000", "trid", "I", "user", "44", "CVAL", "2015-01-01", "12345678")
      ) ++ Seq(
        Table1("attempt_0011", "FNAME", "2017_01_01_02", "2017_01_01_02", "2017-01-01 01:01:15.000000", "trid", "B", "user", "01", "CVAL", "2015-01-01", "12345678"),
        Table1("attempt_0012", "FNAME", "2017_01_01_02", "2017_01_01_02", "2017-01-01 01:01:15.000000", "trid", "A", "user", "01", "CVL", "2015-01-01", "12345678"),
        Table1("attempt_0013", "FNAME", "2017_01_01_02", "2017_01_01_02", "2017-01-01 01:02:15.000000", "trid", "B", "user", "03", "CVAL", "2015-01-01", "12345678"),
        Table1("attempt_0014", "FNAME", "2017_01_01_02", "2017_01_01_02", "2017-01-01 01:02:15.000000", "trid", "A", "user", "03", "CAL", "2015-01-01", "12345678"),
        Table1("attempt_0015", "FNAME", "2017_01_01_02", "2017_01_01_02", "2017-01-01 01:03:15.000000", "trid", "B", "user", "02", "CVAL", "2015-01-01", "12345678"),
        Table1("attempt_0016", "FNAME", "2017_01_01_02", "2017_01_01_02", "2017-01-01 01:03:15.000000", "trid", "A", "user", "02", "CVAL", "2015-01-01", "1234567"),
        Table1("attempt_0017", "FNAME", "2017_01_01_01", "2017_01_01_01", "2017-01-01 00:03:15.000000", "trid", "D", "user", "44", "CVAL", "2015-01-01", "12345678")
      ) ++ Seq(
        Table1("attempt_0101", "FNAME", "2017_01_02_01", "2017_01_02_01", "2017-01-02 00:00:15.000000", "trid", "I", "user", "11", "CVAL", "2015-01-01", "12345678"),
        Table1("attempt_0102", "FNAME", "2017_01_02_01", "2017_01_02_01", "2017-01-02 00:01:15.000000", "trid", "I", "user", "12", "CVAL", "2015-01-01", "12345678"),
        Table1("attempt_0103", "FNAME", "2017_01_02_01", "2017_01_02_01", "2017-01-02 00:02:15.000000", "trid", "I", "user", "13", "CVAL", "2015-01-01", "12345678"),
        Table1("attempt_0104", "FNAME", "2017_01_02_01", "2017_01_02_01", "2017-01-02 00:03:15.000000", "trid", "I", "user", "14", "CVAL", "2015-01-01", "12345678")
      ) ++ Seq(
        Table1("attempt_0111", "FNAME", "2017_01_02_02", "2017_01_02_02", "2017-01-02 01:00:15.000000", "trid", "B", "user", "11", "CVAL", "2015-01-01", "12345678"),
        Table1("attempt_0112", "FNAME", "2017_01_02_02", "2017_01_02_02", "2017-01-02 01:01:15.000000", "trid", "A", "user", "11", "CVL", "2015-01-01", "12345678"),
        Table1("attempt_0113", "FNAME", "2017_01_02_02", "2017_01_02_02", "2017-01-02 01:02:15.000000", "trid", "B", "user", "13", "CVAL", "2015-01-01", "12345678"),
        Table1("attempt_0114", "FNAME", "2017_01_02_02", "2017_01_02_02", "2017-01-02 01:03:15.000000", "trid", "A", "user", "13", "CAL", "2015-01-01", "12345678"),
        Table1("attempt_0115", "FNAME", "2017_01_02_02", "2017_01_02_02", "2017-01-02 01:03:15.000000", "trid", "B", "user", "12", "CVAL", "2015-01-01", "12345678"),
        Table1("attempt_0116", "FNAME", "2017_01_02_02", "2017_01_02_02", "2017-01-02 01:03:15.000000", "trid", "A", "user", "12", "CVAL", "2015-01-01", "1234567")
      )

      sqlContext.createDataFrame(sc.parallelize(table1P1)).write.format("orc").partitionBy("vds").save(verifyTypesBaseDir)

      val fs: FileSystem = FileSystemUtils.fetchFileSystem


      fs.listStatus(new Path(verifyTypesBaseDir)).foreach {
        partition =>
          fs.listStatus(partition.getPath).filter(_.getPath.getName.startsWith("part-r-")).foreach {
            file =>
              val newPath: String = partition.getPath.toString + "/" + tableName.split('_').drop(2).mkString("_") + ".D0" + file.getPath.getName
              val oldPath: String = partition.getPath.toString + "/" + file.getPath.getName

              fs.rename(new Path(oldPath), new Path(newPath))
          }
      }

      sriParams
  }
}



