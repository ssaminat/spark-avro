package props

import com.fortysevendeg.scalacheck.datetime.GenDateTime.genDateTimeWithinRange
import com.fortysevendeg.scalacheck.datetime.instances.joda._
import com.fortysevendeg.scalacheck.datetime.joda.ArbitraryJoda._
import org.joda.time.{DateTime, Days, Period}
import org.scalatest.prop.PropertyChecks
import org.scalatest.{FlatSpec, Matchers}
import utils.Constants._
import utils.SriUtils

class SriUtilsSpecs extends FlatSpec with Matchers with PropertyChecks {
  val from = new DateTime(2016, 1, 1, 0, 0)
  val range = Period.years(1)

  "Get Business Date" should "work" in {
    forAll {
      dt: DateTime =>
        SriUtils.getBusinessDayPartition(formatter(`business date format`) print dt) should be(Some((formatter(`verify types partition format`) print dt,
          formatter(`sri partititon format`) print dt)))
    }
  }

  "Get Previous Partition" should "be positive" in {
    forAll(genDateTimeWithinRange(from, range), genDateTimeWithinRange(from, range)) {
      (dt1: DateTime, dt2: DateTime) =>
        whenever(dt1.getMillis < dt2.getMillis) {
         // Days.daysBetween(formatter(`sri partititon format`) print dt2, formatter(`sri partititon format`) print dt1).getDays should be > 0
        }
    }
  }


}
