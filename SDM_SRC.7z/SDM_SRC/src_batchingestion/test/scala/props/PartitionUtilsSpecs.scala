package props

import utils.Constants._
import org.scalatest.{FlatSpec, Matchers}
import org.scalatest.prop.PropertyChecks
import com.fortysevendeg.scalacheck.datetime.GenDateTime.genDateTimeWithinRange
import com.fortysevendeg.scalacheck.datetime.instances.joda._
import com.fortysevendeg.scalacheck.datetime.joda.ArbitraryJoda._
import org.joda.time.{DateTime, Period}
import org.scalatest.prop.PropertyChecks
import org.scalatest.{FlatSpec, Matchers}

class PartitionUtilsSpecs extends FlatSpec with Matchers with PropertyChecks {
  val from = new DateTime(2016, 1, 1, 0, 0)
  val range = Period.years(1)

  "Get Previous Business Partition" should "return previous partition " in {
    forAll(genDateTimeWithinRange(from, range)) {
      date: DateTime =>
        utils.ParitionUtils.getPreviousBusinessDatePartition(formatter(`verify types partition format`) print date,
          `verify types partition format`, `verify types frequency`) should be(formatter(`verify types partition format`) print date.minusHours(1))
    }
  }

}
