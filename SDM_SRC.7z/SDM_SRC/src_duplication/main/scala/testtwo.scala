import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.catalyst.plans.Inner
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

object testtwo {
  case class test1(JT: String, OT: String, PK1: String,PK2: Int,col: String)
  def main(args: Array[String]): Unit = {
    println("hi")
    val sparkConf=new SparkConf().setAppName("test").setMaster("local[*]").set("spark.sql.crossJoin.enabled","true")
    val sc=new SparkContext(sparkConf)
    val sqlContext=new SQLContext(sc)
    import sqlContext.implicits._
    val df = sc.parallelize(Seq(test1("121", "I", "Siva", 23, "cc"), test1("122", "B", "Siva", 23, "ccc"), test1("123", "A", "Siva", 23, "ccc"), test1("124", "I", "Siva", 23, "ccc"), test1("121", "I", "gopi", 23, "cc"), test1("121", "I", "sami", 23, "cc"), test1("122", "I", "sami", 23, "ccr"), test1("121", "A", "venky", 23, "cc"), test1("122", "I", "venky", 23, "ccd"), test1("121", "I", "kart", 23, "cc"), test1("122", "I", "kart", 23, "cc"), test1("123", "I", "kart", 23, "ccc"), test1("123", "I", "kart", 23, "ccc"), test1("124", "D", "kart", 23, "ccc"), test1("125", "I", "kart", 23, "cc"), test1("126", "I", "kart", 23, "ccd"), test1("121", "I", "vj", 23, "ccc"), test1("122", "B", "vj", 23, "ccc"), test1("123", "A", "vj", 23, "ccc"), test1("121", "I", "nandi", 23, "cc"), test1("121", "I", "nandi", 23, "ccc"), test1("122", "B", "nandi", 23, "ccc"), test1("123", "A", "nandi", 23, "ccc"), test1("124", "B", "nandi", 23, "ccc"), test1("125", "A", "nandi", 23, "ccc"))).toDF()
    df.registerTempTable("test")
    //df.show()
    // val dd=sqlContext.sql("select * from test").show()
    val wspec2=Window.partitionBy("PK1","PK2").orderBy(desc("JT"))
    val wspec3=Window.partitionBy("PK1","PK2")
   //val df1=df.withColumn("rank",row_number().over(wspec2)).withColumn("count",count("*").over(wspec3))

    val df1=sqlContext.sql("select JT,OT,PK1,PK2,col,ROW_NUMBER() over(partition by PK1,PK2 order by JT desc)as rank,count(*) over(partition by PK1,PK2)as count from test")
   val dfrank1=df1.where("rank=1")
    //df1.show()
    dfrank1.registerTempTable("temprank1")
    println("juuu")
    val dq=df1.where("count >1")
     // dq.registerTempTable("test1")
    val ddrank1I=dq.where("rank=1").where("OT='I'")
    val columnWithCDCSeq=Seq("PK1","PK2")
    val colnames=dq.columns
    val qq=dq.join(ddrank1I,columnWithCDCSeq,"Inner").select(dq("PK1"),dq("PK2"),dq("JT"),dq("OT"),dq("col"),dq("rank"),dq("count"))
    //,"PK2","JT","OT","col","rank"
   //val qq=dq.join(ddrank1I,columnWithCDCSeq,"Inner").select(colnames.head,colnames.tail:_*)
   //qq.show()
    qq.registerTempTable("test1")
   // val wspec1=Window.xx  partitionBy("PK1","PK2","col").orderBy(desc("JT"))
//val df3=dq.withColumn("denseRank",rank().over(wspec1))
   // val columnWithCDCSeq=Seq("PK1","PK2")
    val df3=sqlContext.sql("select JT,OT,PK1,PK2,col,rank,count, ROW_NUMBER() over (partition by PK1,PK2,col order by JT desc) as denseRank from test1 ")
    //df3.show()
    val df4=df3.where("rank <>1").where("denseRank =1").where("OT<>'D'").where("OT<>'A'")
    df4.registerTempTable("test1")
    val withactualrank=sqlContext.sql("select a.JT,a.OT,a.PK1,a.PK2,a.col,a.rank,a.count,b.JT as latestJT from test1 a left join temprank1 b on a.PK1=b.PK1 and a.PK2=b.PK2")
    withactualrank.show()
    //val df3=sqlContext.sql("select JT,OT,PK1,PK2,col,rank,count,latestJT, rank() over (partition by PK1,PK2,col order by JT desc) as denseRank from test2 ")
   // val df3=sqlContext.sql("select JT,OT,PK1,PK2,col,rank,count,latestJT, rank() over (partition by PK1,PK2,col order by JT desc) as denseRank from temp1 ")
    //df3.show()
    //val df4=df3.where("rank <>1").where("denseRank =1").where("OT<>'D'").where("OT<>'A'")
    //df4.show()
   // df4.registerTempTable("temptablewithD")

  }
}
