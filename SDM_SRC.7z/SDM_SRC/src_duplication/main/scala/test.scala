/*
import org.apache.spark.sql.SQLContext
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.sql.functions.rank
import org.apache.spark.sql.expressions.Window

object test {
  case class test1(JT: String, OT: String, PK1: String,PK2: Int)
  def main(args: Array[String]): Unit = {
    println("hi")
    val sparkConf=new SparkConf().setAppName("test").setMaster("local[*]")
    val sc=new SparkContext(sparkConf)
    val sqlContext=new SQLContext(sc)
    import sqlContext.implicits._
    val df=sc.parallelize(Seq((test1("121","I","Siva",23)),(test1("122","B","Siva",23)),(test1("123","A","Siva",23)),(test1("124","I","Siva",23)),(test1("121","I","gopi",23)),(test1("121","I","sami",23)),(test1("122","I","sami",23)),(test1("121","A","venky",23)),(test1("122","I","venky",23)))).toDF()
    val w = Window.partitionBy("PK1","PK2").orderBy("JT")
    val df1=df.withColumn("rank",rank().over(w)).withColumn("count",
    df1.show()
    val OT1=df1.where("rank=1").select("OT").collect()
    OT1.foreach(x=>{
      if(x.equals("I"))
        {
println("acho")
        }

    })



//df.select(Col("JT"),("OT"),$("PK1"),$("PK2"),rank.over(w).alias(ranking)).show
    println("before show")
    df1.show()
    //df.foreach(x=>println(x))
//val dd=seq("","","",23)


  }
}
*/
