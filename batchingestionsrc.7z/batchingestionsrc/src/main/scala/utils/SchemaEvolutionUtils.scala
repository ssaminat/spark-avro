/*
 * Copyright 2017 Standard Chartered Bank
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package utils

import models.SriParams
import models.XmlParser.TableConfig
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.FileSystem

import scala.collection.immutable.Seq

object SchemaEvolutionUtils {

  def schemaEvolution(cdcXmlFileName: String, keyColFileName: String, sourceTypeFileName: String,
                      transRulesFileName: String, tableConfigFileName: String, sriParams: SriParams): List[(TableConfig, List[(utils.SchemaEvolutionUtils.SchemaCompare.Value, Int)])] = {
    CdcXmlCrawlerUtils.writeHdfsConfigurationFile(cdcXmlFileName, keyColFileName,
      sourceTypeFileName, transRulesFileName, tableConfigFileName)

    val fs = FileSystemUtils.fetchFileSystem

    val oldTableConfigs: List[TableConfig] = models.XmlParser.parseXmlConfig(sriParams.tableConfigXml, fs)
    val newTableConfigs: List[TableConfig] = models.XmlParser.parseXmlConfig(tableConfigFileName, fs)

    val schemaCompare = oldTableConfigs.zip(newTableConfigs).map {
      tableConfig =>
        val oldColumnList = tableConfig._1.colSchema.split("\\^").map(_.trim).map(_.split(" ")(0)).toList
        val newColumnList = tableConfig._2.colSchema.split("\\^").map(_.trim).map(_.split(" ")(0)).toList

        val schema = compareSchema(newColumnList, oldColumnList)
        (tableConfig._2, schema)
    }

    schemaCompare
  }

  def compareSchema(newColumnList: List[String], oldColumnList: List[String]): List[(SchemaCompare.Value, Int)] = {

    val i = 0
    val j = 0
    val max = Math.max(newColumnList.length, oldColumnList.length)

    val toList = compareColumnList(i, j, newColumnList, oldColumnList, max).toList
    if (toList.isEmpty) List((SchemaCompare.NO_CHANGE, -1)) else toList
  }

  def compareColumnList(i: Int, j: Int, newColumnList: List[String], oldColumnList: List[String], max: Int): Seq[(SchemaCompare.Value, Int)] = {

    def compareColumns(x: Int, iStart: Int, jStart: Int): (Int, Int, Seq[(SchemaCompare.Value, Int)]) = {
      if (x == max) {
        (i + 1, j + 1, Seq((SchemaCompare.DELETE_END, jStart), (SchemaCompare.ADD_END, iStart)))
      } else if (i + x < newColumnList.length && newColumnList(i + x) == oldColumnList(j)) {
        (i + x, j, (0 until x).map(idx => (SchemaCompare.ADD_BETWEEN, i + idx)))
      } else if (j + x < oldColumnList.length && newColumnList(i) == oldColumnList(j + x)) {
        (i, j + x, (0 until x).map(idx => (SchemaCompare.DELETE_BETWEEN, j + idx)))
      } else {
        compareColumns(x + 1, iStart: Int, jStart: Int)
      }
    }


    if (i < newColumnList.length || j < oldColumnList.length) {
      if (i == newColumnList.length) {
        (j until oldColumnList.length).map((SchemaCompare.DELETE_END, _)) ++ compareColumnList(i, oldColumnList.length, newColumnList, oldColumnList, max)
      } else if (j == oldColumnList.length) {
        (i until newColumnList.length).map((SchemaCompare.ADD_END, _)) ++ compareColumnList(newColumnList.length, j, newColumnList, oldColumnList, max)
      } else if (newColumnList(i).equals(oldColumnList(j))) {
        compareColumnList(i + 1, j + 1, newColumnList, oldColumnList, max)
      } else {
        val loopResult = compareColumns(1, i, j)
        loopResult._3 ++ compareColumnList(loopResult._1, loopResult._2, newColumnList, oldColumnList, max)
      }
    } else {
      Seq()
    }
  }


  object SchemaCompare extends Enumeration {
    val ADD_END, ADD_BETWEEN, DELETE_END, DELETE_BETWEEN, NO_CHANGE = Value
  }

}
