/*
 * Copyright 2017 Standard Chartered Bank
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package utils

import models.XmlParser.ColTransformationRule

import scala.collection.immutable.Seq
import scala.xml.Node

object XmlParserUtils {

  def getColumn(sourceCol: Node, tableName: String, rulesList: List[ColTransformationRule]): String = {
    val columnName: String = getXmlAttribute(sourceCol, "columnName").toString()
    val dataType: String = getXmlAttribute(sourceCol, "dataType").toString()

    val nullable: Boolean = getXmlAttribute(sourceCol, "nullable").toString().toBoolean
    val length: String = getXmlAttribute(sourceCol, "length").toString()
    val scale: String = getXmlAttribute(sourceCol, "scale").toString()

    val scaled: String = if (dataType.equals("NUMBER")) scale else ""
    val hiveDataType = getHiveDataType(dataType, length, scaled)

    val colRule: List[ColTransformationRule] = if (rulesList.nonEmpty) rulesList.filter(_.columnName.equals(columnName)) else List()
    val rules: String = if (colRule.nonEmpty) " " + colRule.head.rules else ""

    columnName + " " + hiveDataType + (if (nullable) " NOT NULL" else "") + rules
  }

  def getXmlAttribute(sourceCol: Node, attributeName: String): Seq[Node] = {
    sourceCol.attribute(attributeName).getOrElse(Seq.empty[Node])
  }

  def getHiveDataType(dataType: String, length: String, scale: String): String = {
    dataType match {
      case "CHAR" | "VARCHAR" | "VARCHAR2" | "NVARCHAR" | "NVARCHAR2" => "VARCHAR(" + length + ")"
      case "NUMBER" => "DECIMAL(" + length + "," + scale + ")"
      case _ => dataType
    }
  }

}
