package utils

import org.apache.spark.Accumulator
import org.apache.spark.rdd.RDD

object AccumulatorUtils {
  /**
    * Generic utility to accumulate for a given RDD and accumulator
    */
  def `increment accumulator for an RDD`[T]: RDD[T] => Accumulator[Long] => RDD[T] = { rdd => acc => rdd.foreach { x => acc += 1 }; rdd }

}
