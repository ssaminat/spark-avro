/*
 * Copyright 2017 Standard Chartered Bank
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package utils

import java.sql.Timestamp
import implicits.Implicits._
import models.XmlParser
import models.XmlParser.{TableConfig, ColumnConfigSparkDF, ColumnConfig}
import org.apache.commons.lang.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.sql.Row
import org.apache.spark.sql.types._

import scala.collection.mutable
import scala.collection.mutable.ListBuffer
import scala.util.Try
import scala.util.matching.Regex

object TypeUtils {
  val logger = Logger.getLogger(TypeUtils.getClass)
  private val _nopes: PartialFunction[String, Boolean] = {
    case _ => false
  }
  private val _isString: PartialFunction[String, Boolean] = {
    case str: String if str.startsWith("VARCHAR") => true
    case str: String if str.startsWith("NVARCHAR") => true
    case str: String if str.startsWith("STRING") => true
  }

  private val _isDecimal: PartialFunction[String, Boolean] = {
    case str: String if str.startsWith("DECIMAL") => true
  }

  private val _isDouble: PartialFunction[String, Boolean] = {
    case str: String if str.startsWith("DOUBLE") => true
  }

  private val _isFloat: PartialFunction[String, Boolean] = {
    case str: String if str.startsWith("FLOAT") => true
  }

  private val _isIntegral: PartialFunction[String, Boolean] = {
    case str: String if str.startsWith("SMALLINT") => true
    case str: String if str.startsWith("TINYINT") => true
    case str: String if str.startsWith("INT") => true
  }

  private val _isLong: PartialFunction[String, Boolean] = {
    case str: String if str.startsWith("BIGINT") => true
    case str: String if str.startsWith("LONG") => true
  }

  private val _isBoolean: PartialFunction[String, Boolean] = {
    case str: String if str.startsWith("BOOLEAN") => true
  }
  private val _isTimeStamp: PartialFunction[String, Boolean] = {
    case str: String if str.startsWith("TIMESTAMP") => true
  }
  private val _isDate: PartialFunction[String, Boolean] = {
    case str: String if str.startsWith("DATE") => true
  }
  private val scalePrecPattern: Regex = ".*\\((.*),(.*)\\)".r

  val parseScaleAndPrecision: String => (String, String) = {
    case scalePrecPattern(scale, prec) => (scale, prec)
  }


  val isString = _isString.orElse(_nopes)
  val isDecimal = _isDecimal.orElse(_nopes)
  val isDouble = _isDouble.orElse(_nopes)
  val isFloat = _isFloat.orElse(_nopes)
  val isLong = _isLong.orElse(_nopes)
  val isBoolean = _isBoolean.orElse(_nopes)
  val isTimeStamp = _isTimeStamp.orElse(_nopes)
  val isDate = _isDate.orElse(_nopes)
  val isIntegral = _isIntegral.orElse(_nopes)


  val transformColumnConfig: ColumnConfig => ColumnConfigSparkDF = {
    case ColumnConfig(name, typee) if isString(typee) => ColumnConfigSparkDF(name, StringType)
    case ColumnConfig(name, typee) if isDate(typee) => ColumnConfigSparkDF(name, DateType)
    case ColumnConfig(name, typee) if isTimeStamp(typee) => ColumnConfigSparkDF(name, TimestampType)
    case ColumnConfig(name, typee) if isDecimal(typee) =>
      ColumnConfigSparkDF(name, DataTypes.createDecimalType(parseScaleAndPrecision(typee)._1.toInt, parseScaleAndPrecision(typee)._2.toInt))
    case ColumnConfig(name, typee) if isFloat(typee) => ColumnConfigSparkDF(name, FloatType)
    case ColumnConfig(name, typee) if isIntegral(typee) => ColumnConfigSparkDF(name, IntegerType)
    case ColumnConfig(name, typee) if isBoolean(typee) => ColumnConfigSparkDF(name, BooleanType)
    case ColumnConfig(name, typee) if isDouble(typee) => ColumnConfigSparkDF(name, DoubleType)
  }
  val transformColumnConfigAvro: ColumnConfig => ColumnConfigSparkDF = {
    case ColumnConfig(name, typee) if isString(typee) => ColumnConfigSparkDF(name, StringType)
    case ColumnConfig(name, typee) if isDate(typee) => ColumnConfigSparkDF(name, StringType)
    case ColumnConfig(name, typee) if isTimeStamp(typee) => ColumnConfigSparkDF(name, StringType)
    case ColumnConfig(name, typee) if isDecimal(typee) => ColumnConfigSparkDF(name, DoubleType)
    case ColumnConfig(name, typee) if isFloat(typee) => ColumnConfigSparkDF(name, StringType)
    case ColumnConfig(name, typee) if isIntegral(typee) => ColumnConfigSparkDF(name, StringType)
    case ColumnConfig(name, typee) if isBoolean(typee) => ColumnConfigSparkDF(name, BooleanType)
    case ColumnConfig(name, typee) if isDouble(typee) => ColumnConfigSparkDF(name, DoubleType)
  }

  /**
    * Transform string types to base Orc Types folding over the table config as well as the
    * input data as a string array
    *
    * @param str
    * @param table
    * @return
    */
  // FIXME Change to functional
  def transformerToBaseType(str: Seq[String], table: List[ColumnConfigSparkDF]): List[Any] = {
    var colIndx = -1
    val list: ListBuffer[Any] = new ListBuffer[Any]
    if (table.length < str.length) {
      logger.error("<<PARSING_ERROR>> as table has " + table.length + " columns only while input was " + str.mkString("##"))
    }
    str.foreach {
      value =>
        colIndx = colIndx + 1
        list.append(table(colIndx).typee match {
          case TimestampType =>
            if (StringUtils.isEmpty(value)) new Timestamp(0) else Timestamp.valueOf(value)
          case v if v.isInstanceOf[DecimalType] =>
            Try(BigDecimal(if (StringUtils.isBlank(value) || "null".equals(value)) {
              "0"
            } else value)).getOrElse(throw new Exception(" Failed converting column value " + value + " to " + v + " of name " + table(colIndx).name + " with index " + colIndx + " for " + str.toString() + " with column types as " + table.toString()))
          case v@FloatType =>
            Try(java.lang.Float.parseFloat(if (StringUtils.isBlank(value)) {
              "0"
            } else value)).getOrElse(throw new Exception(" Failed converting column value " + value + " to " + v + " of name " + table(colIndx).name + " with index " + colIndx + " for " + str.toString() + " with column types as " + table.toString()))
          case v: DateType => if (StringUtils.isEmpty(value)) null else new java.sql.Date(Constants.`journal time format_avro`.parse(value).getTime)
          case _ => if (StringUtils.isEmpty(value)) value else String.valueOf(value)
        })

    }
    list.toList
  }

  val transformStructFieldsAvro: TableConfig => Seq[StructField] = {
    case tblConfig@TableConfig(name, source, keyCOls, colSchema, reconQuery, deleteIndex, deleteValue) =>
      XmlParser.fetchColumnConfig(tblConfig).map(transformColumnConfigAvro.andThen({ x => StructField(x.name, x.typee) }))
  }
  val transformStructFields: TableConfig => Seq[StructField] = {
    case tblConfig@TableConfig(name, source, keyCOls, colSchema, reconQuery, deleteIndex, deleteValue) =>
      XmlParser.fetchColumnConfig(tblConfig).map(transformColumnConfig.andThen({ x => StructField(x.name, x.typee) }))
  }

  def extractRowFromSriOutputData(tableConfig: TableConfig, x: String, fileDelimiter: String, partitionColumn: String, cdcSource: Boolean): Row = {
    val datumInString: mutable.WrappedArray[String] = x.split(fileDelimiter, -1)
    val n = SriUtils.getSriFirstDataColumnPosition(cdcSource)
    // this is to ignore the second last column , which would be vds value and make the last column as ods column
    val columns = datumInString.drop(n)
    val converted: List[Any] = TypeUtils.transformerToBaseType(columns,
      (XmlParser.fetchColumnConfig(tableConfig) ++ Seq(ColumnConfig(partitionColumn, "STRING"))).map(TypeUtils.transformColumnConfig))
    Row.fromSeq(datumInString.take(n).zipWithIndex.filter(_._2 != 6).map(_._1) ++ converted)
  }

}
