/*
 * Copyright 2017 Standard Chartered Bank
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package processor

import models.Misc.PackedInputs
import models.XmlParser.TableConfig
import models.{SriAccumulators, SriParams}
import org.apache.commons.lang3
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.catalyst.util.StringUtils
import org.apache.spark.sql.hive.HiveContext
import utils.SriUtils._
import utils.TypeUtils._

object SriProcessor {

  def sriOpenReducer(sriParams: SriParams, sqlContext: HiveContext, tableConfig: TableConfig, MapperOutputs: RDD[(String, String)], sriAccumulators: SriAccumulators): Unit = {
    val tableSchema = fetchSriStructure(tableConfig)(sriParams.sriOpenPartitionColumn)(sriParams.isCdcSource)
    val tableNameWithPrefix: String = tableConfig.name

    val sriOpenOutput = if (tableConfig.isDeltaSource) {
      MapperOutputs
        .reduceByKey(compareOpenRows(_)(_)(sriParams.fileDelimiter)(sriParams.isCdcSource))
        .filter(x => !`if D records`(x._2)(sriParams))
        .map(_._2)
        .map(extractRowFromSriOutputData(tableConfig, _, sriParams.fileDelimiter, sriParams.sriOpenPartitionColumn, sriParams.isCdcSource))
    } else {
      MapperOutputs.map(_._2)
        .map(x => extractRowFromSriOutputData(tableConfig, x,
          sriParams.fileDelimiter, sriParams.sriOpenPartitionColumn,
          sriParams.isCdcSource))
    }

    sriAccumulators.sriOpen += sriOpenOutput.count()

    sqlContext.createDataFrame(sriOpenOutput, tableSchema)
      .write
      .option("orc.compress", "SNAPPY")
      .option("orc.stripe.size", "104857")
      .option("orc.compress.size", "8000")
      .format("orc")
      .partitionBy(sriParams.sriOpenPartitionColumn)
      .save(sriParams.getSriOpenTmpPath(tableNameWithPrefix))

    moveHdfsFiles(sriParams.getSriOpenTmpPath(tableNameWithPrefix), sriParams.getSriOpenPath(tableNameWithPrefix), sqlContext)
  }

  def sriNonOpenReducer(packedInputs: PackedInputs, verifyTypesRdd: RDD[(String, String)])(implicit sc: SparkContext, sqlContext: SQLContext): Unit = {
    import packedInputs._
    val tableSchema = fetchSriStructure(tableConfig)(sriParams.sriNonOpenPartitionColumn)(sriParams.isCdcSource)
    val tableNameWithPrefix: String = tableConfig.name

    val sriNonOpenOutput = verifyTypesRdd
      .reduceByKey(compareNonOpenRows(_, _, sriParams))
      .map(_._2)
      .filter(`if EndDate exists`(_)(sriParams.fileDelimiter))
      .map(extractRowFromSriOutputData(tableConfig, _, sriParams.fileDelimiter, sriParams.sriNonOpenPartitionColumn, sriParams.isCdcSource))

    sriAccumulators.sriNonOpen += sriNonOpenOutput.count()

    sqlContext.createDataFrame(sriNonOpenOutput, tableSchema).write.format("orc").partitionBy(sriParams.sriNonOpenPartitionColumn).save(sriParams.getSriNonOpenTmpPath(tableConfig.name))
    moveHdfsFiles(sriParams.getSriNonOpenTmpPath(tableNameWithPrefix), sriParams.getSriNonOpenPath(tableNameWithPrefix), sqlContext)
  }

}
