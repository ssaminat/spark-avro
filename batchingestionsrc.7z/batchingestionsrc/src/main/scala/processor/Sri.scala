/*
 * Copyright 2017 Standard Chartered Bank
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package processor

import java.io.{BufferedInputStream, PrintWriter}
import java.math

import models.Exceptions.{TableProcessingFailureException, TableSriNonOpenGenerationException, TableSriOpenGenerationException}
import models.Misc._
import models.XmlParser.{TableConfig, parseXmlConfig}
import models.{RowCounts, SriAccumulators, SriParams}
import org.apache.commons.lang3.StringUtils
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.{SparkConf, SparkContext}
import utils.SriUtils._
import utils.{Constants, FileSystemUtils, SchemaUtils}

import scala.collection.parallel.immutable.ParSeq
import scala.util.{Failure, Success, Try}
import utils.EodUtils._

object Sri {

  val logger: Logger = Logger.getLogger(Sri.getClass)

  def main(args: Array[String]) {
    val nArgs = 5
    if (args.length == 2) {
      logger.info("## dev mode ## :: shall be creating schema and will not delete anything ")
      val conf = new SparkConf().setAppName("SriProcess##DevMode##")
      val sc = new SparkContext(conf)
      val sqlContext = new HiveContext(sc)

      val fs: FileSystem = FileSystemUtils.fetchFileSystem
      val paramConf: Configuration = getParamConf(fs, args(1))

      val sriParams: SriParams = SriParams(paramConf, "dummy", "2017-01-01 00:00:00", "fulldump", "2016-12-31 23:59:59", "")
      val tableConfigs = parseXmlConfig(sriParams.tableConfigXml, fs)
      tableConfigs.foreach { con =>
        SchemaUtils.getSriTablesSchema(con, sriParams).split(";", -1)
          .filter(x => StringUtils.isNotEmpty(x.trim)).foreach(sqlContext.sql)
      }

    }
    else if (args.length != nArgs) {
      logger.error("Usage : Sri <eod Marker> <business Day> <parameter xml hdfs path> <fulldump|incremental> <last-verifytypes-partition>")
      sys.error("Usage : Sri <eod Marker> <business Day> <parameter xml hdfs path> <fulldump|incremental> <last-verifytypes-partition>")
      System.exit(1)
    } else {

      logger.info("Spark Driver arguments - " + args.mkString(" | "))
      val Array(eodMarker, submitTime, paramPath, runType, lastVerifyTypesPart) = args

      // TODO: get rerun table names
      val rerunTables = List() //if (args.length == 4) args(3).split(",", -1).toList else List()

      val (partition: String, businessDate: String) = getBusinessDayPartition(submitTime)
        .getOrElse(new Exception(" Business date and partition format were incorrectly specified!"))

      val fs: FileSystem = FileSystemUtils.fetchFileSystem
      val paramConf: Configuration = getParamConf(fs, paramPath)
      val format = paramConf.get("inputFormat", "orc")
      val sriParams: SriParams = SriParams(paramConf, partition, businessDate, runType, eodMarker, lastVerifyTypesPart)

      val tableConfigs = parseXmlConfig(sriParams.tableConfigXml, fs)
      val tableDictionary = if (rerunTables.isEmpty) tableConfigs else tableConfigs.filter(x => rerunTables.contains(x.name))


      val conf = new SparkConf().setAppName("SriProcess").setMaster("local")
      conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      conf.set("spark.kryo.registrationRequired", "true")
      conf.registerKryoClasses(
        Array(
          classOf[scala.collection.mutable.WrappedArray.ofRef[_]],
          classOf[models.RowCounts],
          classOf[Array[models.RowCounts]],
          classOf[SriParams],
          classOf[Array[org.apache.spark.sql.Row]],
          classOf[SriAccumulators],
          Class.forName("com.databricks.spark.avro.DefaultSource$SerializableConfiguration"),
          Class.forName("scala.reflect.ClassTag$$anon$1"), // this is needed due to SPARK-6497, a spark bug unsolved for sometime
          Class.forName("java.lang.Class"), // this is needed due to SPARK-6497, a spark bug unsolved for sometime
          classOf[models.Misc.NormalizedRowForm],
          classOf[Array[models.Misc.NormalizedRowForm]],
          classOf[models.Misc.GroupedNormalForm],
          classOf[models.Misc.PackedInputs],
          classOf[models.Misc.VerifyTypesInputModel],
          classOf[Array[org.apache.spark.sql.catalyst.InternalRow]],
          classOf[org.apache.spark.sql.catalyst.expressions.UnsafeRow]
        )
      )
      implicit val sc = new SparkContext(conf)
      implicit val sqlContext = new HiveContext(sc)

      try {
        val makerLocation = paramConf.get("edmhdpif.config.prev.bday.marker.location")
        val previousBusinessDate = FileSystemUtils.readHDFSFile(new Path(makerLocation))(fs)
        processSri(sriParams, fs, tableDictionary, paramConf)(sc, sqlContext, format)
        if (sriParams.reconTableName.nonEmpty) {
          recon(sriParams, tableDictionary, fs, paramConf)
        }
        writeEodTableAndMarker(fs, paramConf, sriParams, sqlContext, makerLocation, previousBusinessDate.getOrElse("BOOTSTRAP"))
      }
      catch {
        case e: Exception => logger.error("Process SRI encountered error: ", e)
      }
      finally {
        //putProvenanceInfoToElastic(sc, businessDate, runType, paramConf)
      }
    }
  }


  def processSri(sriParams: SriParams, fs: FileSystem, tableDictionary: List[TableConfig], paramConf: Configuration)(implicit sc: SparkContext, sqlContext: HiveContext, inputFormat: String): Unit = {
    fs.mkdirs(new Path(sriParams.hdfsTmpDir))
    fs.deleteOnExit(new Path(sriParams.hdfsTmpDir))
    val markers = parseEodMarkerForTable(sc, sqlContext, sriParams, paramConf, inputFormat)
    val rowCounts: ParSeq[RowCounts] = tableDictionary.filterNot(_.name.isEmpty).par.flatMap {
      tableConfig =>
        val result = Try {
          val sriAccumulators: SriAccumulators = SriAccumulators(sc)
          val marker = markers.filter(x => tableConfig.name.equals(x.tableName)).map(_.marker).headOption
          val paramConfig = SriParams.clone(sriParams)(marker.getOrElse(sriParams.eodMarker))
          val (prevPartitionEarlyPath: String, prevPartitionLatePath: String, verifyTypesPathList: List[String], sriOpenPrevPartitionPath: String) =
            getInputFiles(paramConfig, fs, tableConfig)`
          if (verifyTypesPathList.nonEmpty) {
            logger.info("Processing table - " + tableConfig.name)
            val packedInput = PackedInputs(VerifyTypesInputModel(verifyTypesPathList,
              sriOpenPrevPartitionPath, prevPartitionEarlyPath, prevPartitionLatePath), paramConfig, tableConfig, sriAccumulators, inputFormat)
            val verifyTypesRddd: NormalizedRowFormWriterRDD = VerifyTypesProcessor.fetchVerifyTypes(packedInput)(sc, sqlContext)
            val (logs, verifyTypesRddM) = verifyTypesRddd.run
            logs.foreach(x => logger.info("******** " + x))
            val verifyTypesRdd = verifyTypesRddM.map(_.toTuple)
            //Process Non-Open if Delta
            if (tableConfig.isDeltaSource) {
              SriProcessor.sriNonOpenReducer(packedInput, verifyTypesRdd)
            }
            //Process Open
            SriProcessor.sriOpenReducer(paramConfig, sqlContext, tableConfig, verifyTypesRdd, sriAccumulators)
            val tableRowCount: Seq[RowCounts] = sriAccumulators.getRowCount(paramConfig, tableConfig, sc.applicationAttemptId.getOrElse("attemptIdNotFound"))
            tableRowCount.foreach(x => logger.info("Table " + tableConfig.name + " RowCount Record" + x.toString))
            tableRowCount
          } else {
            logger.warn(" No input verify types were found for " + tableConfig.name)
            Seq()
          }
        }
        result match {
          case Success(res) =>
            fs.createNewFile(new Path(paramConf.get("status_file_location", "target/") + "/" + sriParams.businessDate + "_COMPLETED_PROCESSING_TABLE_" + tableConfig.name))
            res
          case Failure(ex) => logger.error(s" Exception processing ${
            tableConfig.name
          } for ${
            sriParams.toString
          } " +
            ex.getMessage)
            ex.printStackTrace()
            fs.createNewFile(new Path(paramConf.get("status_file_location", "target/") + "/" + sriParams.businessDate + "_ERROR_PROCESSING_TABLE_" + tableConfig.name))
            Seq()
        }
    }
    writeRowCounts(sriParams, rowCounts)(sc, sqlContext)
  }

  def writeRowCounts(sriParams: SriParams, rowCounts: ParSeq[RowCounts])(implicit sc: SparkContext, sqlContext: HiveContext): Unit = {
    val rowCountsRDD: RDD[RowCounts] = sc.parallelize(rowCounts.toList, 1)
    val rowCountTableName: String = sriParams.source + "_" + sriParams.country + "_rowcounts"
    sqlContext.createDataFrame(rowCountsRDD)
      .write.format("orc")
      .partitionBy("rcds")
      .save(sriParams.hdfsTmpDir + "/" + sriParams.opsSchema + "/" + rowCountTableName)
    moveHdfsFiles(sriParams.hdfsTmpDir + "/" + sriParams.opsSchema + "/" + rowCountTableName, sriParams.hdfsBaseDir +
      sriParams.opsSchema + "/" + rowCountTableName, sqlContext, deletePreviousFiles = false)
  }

  def recon(sriParams: SriParams, tableDictionary: List[TableConfig], fs: FileSystem, paramConf: Configuration)(implicit sqlContext: HiveContext): Unit = {
    val reconTablePath: String = sriParams.getSriOpenPartitionPath(sriParams.reconTableName, sriParams.businessDate)
    val load: DataFrame = sqlContext.read.format("orc").load(reconTablePath)
    val srcReconValues: Array[(String, math.BigDecimal)] = load.rdd.map {
      x => (x.getString(sriParams.reconTableNameColumn), x.getDecimal(sriParams.reconCountColumn))
    }.collect()
    val reconTableConfig: List[TableConfig] = tableDictionary.filterNot(_.name.isEmpty).filterNot(_.reconQuery.isEmpty)

    if (reconTableConfig.nonEmpty) {
      val reconResult: ParSeq[Option[Recon]] = reconTableConfig.par.map {
        tableConfig =>
          Try {
            val query = tableConfig.reconQuery.split(";", -1)
            query.dropRight(1).foreach(sqlContext.sql)
            val sql: DataFrame = sqlContext.sql(query.last)
            val reconValue = sql.take(1).map(x => x.getLong(0)).head
            val srcRecon = srcReconValues.filter(_._1.equals(tableConfig.name)).head._2
            val reconValueBig: BigDecimal = BigDecimal.apply(reconValue)
            val compare: Int = srcRecon.compareTo(reconValueBig.bigDecimal)
            logger.info(tableConfig.name + " -> " + reconValue + " : " + srcRecon + " : compare " + compare)
            Some(Recon(srcRecon.longValue(), tableConfig.name, reconValueBig.longValue(), compare == 0, sriParams.businessDate))
          } match {
            case Success(recon) =>
              fs.createNewFile(new Path(paramConf.get("status_file_location") + "/" + sriParams.businessDate + "_COMPLETED_RECON_TABLE_" + tableConfig.name))
              recon
            case Failure(ex) =>
              fs.createNewFile(new Path(paramConf.get("status_file_location") + "/" + sriParams.businessDate + "_ERROR_RECON_TABLE_" + tableConfig.name))
              logger.error(ex.getMessage + " was encountered trying to reconcile ")
              ex.printStackTrace()
              None
          }
      }
      val list: List[Recon] = reconResult.filter(_.isDefined).map(_.get).toList
      if (list.nonEmpty) {
        sqlContext.createDataFrame(sqlContext.sparkContext
          .parallelize(list)).write.format("orc").partitionBy("batch").save(paramConf.get("recon_table_dir"))
      }
    }
  }

}
