/*
 * Copyright 2017 Standard Chartered Bank
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package processor

import cats.implicits._
import models.Misc._
import org.apache.log4j.Logger
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{Row, SQLContext}
import provenance.Ops._
import utils.VerifyTypeUtils._
import utils.AccumulatorUtils._
import utils.SriUtils._
import utils.DeltaSourceUtils._

object VerifyTypesProcessor {


  val logger: Logger = Logger.getLogger(VerifyTypesProcessor.getClass)

  /**
    *
    * DONE load verify types inputs from paths as orc/avro as rdd
    * DONE split that into after or before EOD and accordingly increment the accumulator for verify types
    * DONE remove duplicates from delta and accumulate the counts aptly
    * DONE normalize the RDD output into normal form for SRI calculations
    * DONE if delta table and previous sri open exists, join that inputs as well
    * DONE check if delta table , if so group by primary key defined for it.If no PKey defined, throw an error/exception message
    * DONE return the normalized output as a writer with an RDD
    *
    * @param packedInputs
    * @return
    */
  def fetchVerifyTypes(packedInputs: PackedInputs)(implicit sc: SparkContext, sqlContext: SQLContext): (NormalizedRowFormWriterRDD) = {
    import packedInputs._

    val deleteIndex = `fetch delete index`(packedInputs)

    for {
      storageEvents <- `load storage inputs into rows`(sc)(sqlContext)(packedInputs)
      formattedEvents <- s"Formatting storage events for ${tableConfig.name} into KVP" ~>
        `lifted Storage Event Key-Value-Pair Formatter`(packedInputs)(deleteIndex)(storageEvents)
      previousSriOpen <- s"Loading SRI Open from previous business day,if required, for ${tableConfig.name}" ~>
        readPreviouoSriOpen(sc)(sqlContext)(packedInputs)
      normalizedSriOpen <- s"Formatting prev sri open events , if required for ${tableConfig.name}" ~>
        previousSriOpen.map(normalizePrevSriOpen(packedInputs))
      completeStorageInputs <- s"Combining storage inputs with sri open inputs" ~>
        formattedEvents.union(normalizedSriOpen)
      keyGroupedForm <- s"Grouping storage events by key ${tableConfig.name}" ~>
        groupByKeyForTables(completeStorageInputs)(packedInputs)
      keyValidatedGroupForm <- s"Primary Key Validation for ${tableConfig.name}" ~>
        keyGroupedForm.map(primaryKeyValidation(packedInputs)(_))
      bRecordsDroppedGroupForms <- s"Counting B Records for ${tableConfig.name}" ~>
        `increment accumulator for an RDD`(keyValidatedGroupForm.map(`filter Group record B`(_)(packedInputs)).flatMap(_.value))(sriAccumulators.bDrops)
      nonBRecordsGroupForm <- s"Fetching non B records for storage inputs of ${tableConfig.name}" ~>
        keyValidatedGroupForm.map(`remove Group record B`(_)(packedInputs))
      unduplicatedResult <- s"UnDuplicating and Counting ,if required for ${tableConfig.name}" ~>
        extractDuplicates( nonBRecordsGroupForm,packedInputs)
    } yield unduplicatedResult
  }


  def extractDuplicates(storageEvents: RDD[GroupedNormalForm], packedInputs: PackedInputs): RDD[NormalizedRowForm] = {
    import packedInputs._
    if (packedInputs.tableConfig.isDeltaSource)
      DeltaProcessor.removeDuplicates(packedInputs, storageEvents)
    else
      storageEvents.flatMap {
        x =>
          x.value.map {
            y => normalize(x.key, y)
          }
      }

  }

  val `load storage inputs into rows`: SparkContext => SQLContext => PackedInputs => RowWriterRDD = sc => sqlContext => {
    packedInput =>
      import packedInput._
      for {

        storageInputs <- s"Loading storage inputs for ${tableConfig.name}" ~>
          `load storage inputs into RDD`(sc)(sqlContext)(packedInput)
        earlyStorageInputs <- s"Loading Early storage inputs for ${tableConfig.name}" ~>
          `load early storage inputs into RDD`(sc)(sqlContext)(packedInput)
        lateStorageInputs <- s"Loading Late storage inputs for ${tableConfig.name}" ~>
          `load late storage inputs into RDD`(sc)(sqlContext)(packedInput)
        accumulatedStorage <- s"Accumulating storage ${tableConfig.name}" ~>
          `increment accumulator for an RDD`(storageInputs.union(earlyStorageInputs).union(lateStorageInputs))(sriAccumulators.verifyTypes)
        earlyStorageEvents <- earlyArrival(sc)(packedInput)(accumulatedStorage)
        lateStorageEvents <- lateArrival(sc)(packedInput)(accumulatedStorage)
        accumulatedEarlyStorageEvents <- s"Accumulating early events for ${tableConfig.name}" ~>
          `increment accumulator for an RDD`(earlyStorageEvents)(sriAccumulators.earlyArrival)
        parkedEarlyEvents <- s"Parking Early Events for ${tableConfig.name}" ~>
          `park early events onto storage`(sc)(sqlContext)(accumulatedEarlyStorageEvents)(packedInput)

      } yield lateStorageEvents
  }


}


