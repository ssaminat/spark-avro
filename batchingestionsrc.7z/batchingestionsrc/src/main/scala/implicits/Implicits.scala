package implicits

import java.text.SimpleDateFormat

object Implicits {
  implicit val strToDateFormat: String => SimpleDateFormat = new SimpleDateFormat(_)

}
