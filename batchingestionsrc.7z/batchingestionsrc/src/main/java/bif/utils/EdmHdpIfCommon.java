/*
 * Copyright 2017 Standard Chartered Bank
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package bif.utils;


import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.log4j.Logger;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;

public class EdmHdpIfCommon {
    private static final Logger logger = Logger.getLogger(EdmHdpIfCommon.class);

    private final static String UNIX_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
    private static SimpleDateFormat unixTimeFormat = new SimpleDateFormat(UNIX_TIME_FORMAT);

    /**
     * Gets the current time in Unix format
     *
     * @return The current time in Unix format.
     */
    public static String getUnixTime() {
        // synchronized because DateFormat is unsafe for multithreaded use
        synchronized (unixTimeFormat) {
            return unixTimeFormat.format(Calendar.getInstance().getTime());
        }
    }

    /**
     * Get the date part of a string representing a partition.
     *
     * @param partitionstr
     *            The partition string.
     * @return The date part of the partition.
     */
    public static String getPartitionDate(String partitionstr) {
        if (partitionstr == null) {
            return null;
        }
        String partition = getPartition(partitionstr);
        if (partition.contains("=")) {
            partition = partition.substring(partition.indexOf('=') + 1).trim();
        }
        return partition;
    }

    /**
     * Get the date, as YYYY-MM-DD, of a string representing a partition.
     *
     * @param partitionstr
     *            The partition string.
     * @return The date part of the partition.
     */
    public static String getPartitionDateForSeqFiles(String partitionstr) {
        if (partitionstr == null) {
            return null;
        }
        String partition = getPartitionDate(partitionstr).trim();
        if (partition.length() >= 10) {
            partition = partition.substring(0, 10); // Only date
        } else if (partition.length() >= 7) { // Year and month only
            partition = partition.substring(0, 7) + "_01";
        } else if (partition.length() >= 4) { // Year only
            partition = partition.substring(0, 4) + "_01_01";
        } else {
            return null;
        }
        return partition;
    }

    public static String getPartitionDateForORC(String partitionstr) {

        return getPartitionDateForSeqFiles(partitionstr).replaceAll("_", "-");
    }

    /**
     * Clean the partition string from any symbols.
     *
     * @param partitionstr
     *            The partition string.
     * @return The partition string, clean from symbols, like () or ''.
     */
    public static String getPartition(String partitionstr) {
        if (partitionstr == null) {
            return null;
        }
        String partition = partitionstr.trim();
        if (partition.startsWith("(") && partition.endsWith(")")) {
            partition = partition.substring(1, partition.length() - 1);
        }
        partition = partition.replace("'", "");
        return partition;
    }

    /**
     * Get files with exact name, from a path using filters.
     *
     * @param fileSystem
     *            The file system where look for the path.
     * @param parentPath
     *            The path.
     * @param name
     *            Name to filter files with.
     * @return The list of files in parentPath starting by name.
     * @throws IOException
     */
    public static FileStatus[] getFilteredFilesByName(final FileSystem fileSystem, final Path parentPath,
                                                      final String name) throws IOException {
        try {
            FileStatus[] fileList = fileSystem.listStatus(parentPath, new PathFilter() {
                @Override
                public boolean accept(Path path) {
                    if (name == null) {
                        return true;
                    }
                    return path.getName().startsWith(name);
                }
            });
            if (fileList == null) {
                fileList = new FileStatus[] {};
            }
            return fileList;
        } catch (FileNotFoundException e) {
            logger.warn("Ignoring path " + parentPath + ": " + e.getMessage());
            return new FileStatus[] {};
        }
    }

    /**
     * Delete a path. If the provided path is a directory, delete it
     * recursively. If it's a file, delete the files starting with the file
     * name.
     *
     * @param deletePathStr
     *            Path to delete
     * @param fileSystem
     *            Indicates if it's expected to be a directory or not.
     * @throws IOException
     */
    public static void deletePath(FileSystem fileSystem, final String deletePathStr) throws IOException {
        // If exists and it's a directory, delete
        boolean directory = deletePathStr.endsWith("/");
        Path deletePath = new Path(deletePathStr);
        if (directory || (fileSystem.exists(deletePath) && fileSystem.isDirectory(deletePath))) {
            if (fileSystem.exists(deletePath)) {
                // Check minimum levels of directory, to avoid deletion of
                // parent directories if parameters are incorrect or not set
                if (deletePath.toString().split("/").length < 4) {
                    logger.error("Skipping unsafe delete of directory, please check parameters: " + deletePath);
                } else {
                    fileSystem.delete(deletePath, true);
                    logger.info("Deleted directory: " + deletePath);
                }
            }
        } else {
            Path parentPath = deletePath.getParent();
            if (fileSystem.exists(parentPath) && fileSystem.isDirectory(parentPath)) {
                // Look for the files matching deletePath
                FileStatus[] fileStatus = getFilteredFilesByName(fileSystem, parentPath, deletePath.getName());
                for (FileStatus file : fileStatus) {
                    fileSystem.delete(file.getPath(), true);
                    logger.info("Deleted  file: " + file.getPath());
                }
            }
        }
    }

    /**
     * Check for required parameters, throws an exception if some of the
     * required parameters are missing.
     *
     * @param conf
     * @param parameters
     * @throws RuntimeException
     */
    public static void checkRequiredParameters(Configuration conf, String[] parameters) throws RuntimeException {
        ArrayList<String> missingParams = new ArrayList<String>();
        for (String param : parameters) {
            if (conf.get(param) == null) {
                missingParams.add(param);
            }
        }
        if (!missingParams.isEmpty()) {
            StringBuilder error = new StringBuilder("Required parameters not set: ");
            for (String param : missingParams) {
                error.append("\n").append(param);
            }
            throw new RuntimeException(error.toString());
        }

    }

    /**
     * Create a directory. If the path already exists, delete it.
     *
     * @param fileSystem
     *            Filesystem in which to create
     * @param dirStr
     *            Directory to create.
     * @throws IOException
     */
    public static void createDirectory(FileSystem fileSystem, final String dirStr) throws IOException {
        Path dirPath = new Path(dirStr);
        if (fileSystem.exists(dirPath)) {
            logger.info(dirStr + " exists; so deleting it");
            fileSystem.delete(dirPath, false);
        }
        fileSystem.mkdirs(dirPath);
    }

    public static String getTableNameFromContext(Context context) {
        Path filePath = null;
        String fileName = context.getConfiguration().get("map.input.file");

        if (fileName == null) {
            FileSplit fileSplit = null;
            InputSplit split = context.getInputSplit();
            Class<? extends InputSplit> splitClass = split.getClass();

            if (FileSplit.class.isAssignableFrom(splitClass)) {
                fileSplit = (FileSplit) split;
            } else if ("org.apache.hadoop.mapreduce.lib.input.TaggedInputSplit".equals(splitClass.getName())) {
                // begin reflection hackery...
                try {
                    Method getInputSplitMethod = splitClass.getDeclaredMethod("getInputSplit");
                    getInputSplitMethod.setAccessible(true);
                    fileSplit = (FileSplit) getInputSplitMethod.invoke(split);
                } catch (Exception e) {
                    // wrap and re-throw error
                    throw new RuntimeException("Error trying to get table name from file: " + e);
                }
                // end reflection hackery
            }
            if (fileSplit == null) {
                throw new RuntimeException("Could not find input file");
            }
            filePath = fileSplit.getPath();
        } else {
            filePath = new Path(fileName);
        }

        return filePath.getParent().getParent().getName();
    }

    public static String[] getinputFilesWithoutInputFormat(String[] inputFilesWithInputFormat){
        String[] inputFiles = new String[inputFilesWithInputFormat.length];
        int i = 0;
        for(String file: inputFilesWithInputFormat){
            inputFiles[i++] = file.split(";")[0];
        }
        return inputFiles;
    }


    /**
     * Calculates the ideal number of reducers, based on the number of input
     * blocks and number of tables
     *
     * @param conf
     * @param sri
     * @return
     */
    public static int calculateNumberOfReducers(Configuration conf, boolean sri) {

        //Get input files
        String inputs = conf.get(MultipleInputs.DIR_FORMATS);
        if (inputs == null) {

            logger.warn("No input files found.");
            return 1;
        }
        // Get cluster block size
        // Input files comes in the following format:
        // file1;InputFormat1,file2;InputFormat2....
        String[] inputFilesWithInputFormat = inputs.split(",");
        String[] inputFiles = getinputFilesWithoutInputFormat(inputFilesWithInputFormat);

        // Calculate the size for all the inputs
        double numOfBlocks = getNumberOfBlocksForInputFiles(conf, inputFiles);
        int numOfTables = getNumberOfTablesFromInputFiles(conf, inputFiles);
        logger.info("Number of tables: " + numOfTables + "\nNumber of blocks:" + numOfBlocks);

        Integer calculatedReducers = 1;
        if (sri || numOfBlocks < numOfTables) {
            calculatedReducers = (int) Math.max(numOfBlocks, 1); // Never return 0
        } else {
            // If not SRI, never return more than number of tables
            calculatedReducers = Math.max(numOfTables, 1);
        }
        Integer maxReducers = 0;
        try {
            maxReducers = Integer.parseInt(conf.get("edmhdpif.maxreducers", "0").trim());
        } catch (NumberFormatException e) {
            logger.warn("Property 'edmhdpif.maxreducers' not set.");
        }
        if (maxReducers > 0) {
            return Math.min(calculatedReducers, maxReducers);
        }
        return calculatedReducers;
    }

    public static int getNumberOfTablesFromInputFiles(Configuration conf, String[] inputFiles){

        HashSet<String> tableNames = new HashSet<>();
        try{
            FileSystem fs = FileSystem.get(conf);
            for (String f : inputFiles){

                Path currentPath = new Path(f);
                if (fs.isFile(currentPath))
                    tableNames.add(cleanTableName(currentPath.getName()));
                else
                {
                    RemoteIterator<LocatedFileStatus> filesIterator = fs.listFiles(currentPath, true);
                    while(filesIterator.hasNext())
                        tableNames.add(filesIterator.next().getPath().getName());
                }
            }
            return tableNames.size();
        }catch(IOException e){
            logger.error("Error retrieving table names from input files. Message: "+e.getMessage());
            return 0;
        }
    }

    public static double getNumberOfBlocksForInputFiles(Configuration conf, String[] inputFiles) {

        long clusterBlockSize = conf.getInt("dfs.blocksize", 134217728);
        double blocks = 0;
        try {
            FileSystem fs = FileSystem.get(conf);
            for (String f : inputFiles) {
                FileStatus fileStatus = fs.getFileStatus(new Path(f.split(";")[0]));
                if (fileStatus.isDirectory()) {
                    RemoteIterator<LocatedFileStatus> filesInDir = fs.listFiles(fileStatus.getPath(), true);
                    while (filesInDir.hasNext()) {
                        LocatedFileStatus fileinDir = filesInDir.next();
                        logger.info("File: " + fileinDir.getPath() + " Len: " + fileinDir.getLen() + " Blocksize: "
                                + fileinDir.getBlockSize());
                        long blockDiv=(fileinDir.getBlockSize() > 0 ? fileinDir.getBlockSize() : clusterBlockSize);
                        blocks +=((float) fileinDir.getLen())/blockDiv;
                    }
                } else {
                    logger.info("File: " + fileStatus.getPath() + " Len: " + fileStatus.getLen() + " Blocksize: "
                            + fileStatus.getBlockSize());
                    blocks += ((float) fileStatus.getLen()) / Math.max(fileStatus.getBlockSize(), 1);
                }
            }
        } catch (Exception e) {
            logger.error("Error calculating number of reducers: " + e.getMessage());
            return 0;
        }
        return blocks;
    }

    /**
     * Get table name from file name.
     *
     * If the table comes from an intermediate step, the filename is in the form
     * of table-r-0000.
     *
     * If the table comes at the input, the file name is in the form of
     * table.xxxx
     *
     * @param name
     * @return
     */
    private static String cleanTableName(String name) {
        if (name.contains("-r-")) {
            return name.substring(0, name.indexOf("-r-"));
        }
        if (name.contains(".")) {
            return name.substring(0, name.indexOf('.'));
        }
        return name;
    }

}
