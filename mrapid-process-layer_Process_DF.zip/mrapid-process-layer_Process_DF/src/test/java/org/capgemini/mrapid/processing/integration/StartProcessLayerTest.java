package org.capgemini.mrapid.processing.integration;

import org.capgemini.mrapid.processing.exception.ProcessException;
import org.easymock.EasyMockSupport;
import org.junit.Ignore;
import org.junit.Test;
@Ignore
public class StartProcessLayerTest extends EasyMockSupport {
@Test
public void start_process() throws ProcessException{
	String SourceSystem="DOTOPAL";
	String country="DOTOPAL";
	String partitian="10-04-1991";
	String fullbase="N";
	String[] hdfInputs=new String[]{SourceSystem,country,partitian,fullbase};
	StartProcessLayer.main(hdfInputs);
}

}
