package org.capgemini.mrapid.processing.util;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.spark.sql.Row;
import org.capgemini.mrapid.processing.exception.ProcessException;

/**
 * This class is used to create a group of primary keys with comma separator and
 * creates query structure containing ProcessWithAllRecords (table containing
 * all the records) and ProcessWithPrimaryKey ( table containing all the primary
 * keys and max column )class.
 * 
 * @author ikumarav
 *
 */
public class ProcessPrimaryKeyUtil {
	final static Logger logger = Logger.getLogger(ProcessPrimaryKeyUtil.class);

	/**
	 * This method is used to form the primary keys with comma separator.
	 * 
	 * @param primaryKeyList
	 *            : list of primary Key
	 * @return String: Primary key with comma separator.
	 * @throws ProcessException
	 */
	public String getPrimaryKeyWithCommaSeperator(List<String> primaryListWithComma) throws ProcessException {
		logger.info("inside the getPrimaryKeyWithCommaSeperator() method");
		StringBuilder builder = new StringBuilder();
		String primaryKeysJoin = null;
		int count = 0;
		if (primaryListWithComma.size()!=0) {
			for (String primaryKey : primaryListWithComma) {
				if (count == primaryListWithComma.size() - 1) {
					builder.append("`" + primaryKey + "`");
				} else {
					builder.append("`" + primaryKey + "`");
					builder.append(",");
				}
				count++;
			}
			primaryKeysJoin = builder.toString();

		}
		return primaryKeysJoin;
	}
	
	public static List<String> convertIterableToList(Iterable<String> primaryKeyList){
		List<String> list = new ArrayList<String>();
		for (String column : primaryKeyList) {
			list.add(column);
		}
		logger.info("list is "+list.toString());
		return list;
	}
	
	/**
	 * This method is used to form the primary keys with combination of a. and
	 * b. a is a alias name for temporary table ProcessWithAllRecords. b is a
	 * alias name for temporary table ProcessWithPrimaryKey.
	 * 
	 * @param primaryKeyList
	 *            : list of primary Key
	 * @return String: Primary key with a. and b.
	 */
	public String getPrimaryKeys(List<String> primaryListWithComma)
			throws ProcessException {
		logger.info("inside the getPrimaryKeys() method");
		StringBuilder builder1 = new StringBuilder();
		String primaryKeysJoins = "";
		int count = 0;
		if (primaryListWithComma.size() != 0) {
			for (String primaryKey : primaryListWithComma) {
				if (count == primaryListWithComma.size() - 1) {
					builder1.append("nvl(a." + "`" + primaryKey + "`"+",'1')"
							+ "=nvl(b." + "`" + primaryKey + "`"+",'1')");
				} else {
					builder1.append("nvl(a." + "`" + primaryKey + "`"+",'1')"
							+ "=nvl(b." + "`" + primaryKey + "`"+",'1')");
					builder1.append(" and ");
				}
				count++;
			}
			primaryKeysJoins = builder1.toString();

		}
		return primaryKeysJoins;
	}
	
	public static String getPrimaryKeysWithAliasSeperator(List<String> primaryKeyList, String aliasName)
			throws ProcessException {
		logger.info("inside the getPrimaryKeysWithAliasSeperator() method");
		StringBuilder builder1 = new StringBuilder();
		String primaryKeysJoins = "";
		int count = 0;
		if (primaryKeyList.size() != 0) {
			for (String primaryKey : primaryKeyList) {
				if (count == primaryKeyList.size() - 1) {
					builder1.append(aliasName+"." + "`" + primaryKey + "`");
				} else {
					builder1.append(aliasName+"." + "`" + primaryKey + "`");
					builder1.append(",");
				}
				count++;
			}
			primaryKeysJoins = builder1.toString();

		}
		return primaryKeysJoins;
	}
	
}
