package org.capgemini.mrapid.processing.sourcetype.impl;

import static org.capgemini.mrapid.processing.util.Constants.MASTER;

import org.apache.log4j.Logger;

/**
 * This class is used to process the I,A,B and D records. <br/>
 * This class extends AbstractSourceTypeProcessor class and use the base class
 * method. <br/>
 * 
 * @author ikumarav
 *
 */
@SuppressWarnings("serial")
public class IncrementalTypeProcessor extends AbstractSourceTypeProcessor {

	final Logger logger = Logger.getLogger(this.getClass());

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.capgemini.mrapid.processing.sourcetype.impl.AbstractSourceTypeProcessor
	 * #sourceTypeProcess(java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String)
	 * 
	 * <br/>
	 */

	public String getType() {
		return MASTER;
	}

}
