package org.capgemini.mrapid.processing.recon.impl;

import static org.capgemini.mrapid.processing.util.Constants.DOT;
import static org.capgemini.mrapid.processing.util.Constants.FAILURE;
import static org.capgemini.mrapid.processing.util.Constants.NFD;
import static org.capgemini.mrapid.processing.util.Constants.RECONCILIATION;
import static org.capgemini.mrapid.processing.util.Constants.SCB_ALL_TAB;
import static org.capgemini.mrapid.processing.util.Constants.UNDERSCORE;
import static org.capgemini.mrapid.processing.util.Constants.UNIONALL;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.hive.HiveContext;
import org.capgemini.mrapid.processing.exception.ProcessException;
import org.capgemini.mrapid.processing.exception.QueryException;
import org.capgemini.mrapid.processing.metadata.MetaDataProcessor;
import org.capgemini.mrapid.processing.rowcounts.RowCounts;
import org.capgemini.mrapid.processing.sparksql.QueryExecutor;
import org.capgemini.mrapid.processing.util.CommonUtil;

/**
 * EodReconProcessorMain is the mail class to differentiate master and
 * transaction reconciliation and it will call respective implementation.<br/>
 * Implementation Logic: <br/>
 * EOD_RECON must have an entry for all the Table for respective source system
 * 1. if
 * 
 * @author suresh
 *
 */
public class EodReconProcessorMain {
	final static Logger logger = Logger.getLogger(EodReconProcessorMain.class);
	HiveContext hiveCtx;
	SparkConf prop;
	JavaSparkContext jsCtx;
	RowCounts rowCount = new RowCounts();
	public EodReconProcessorMain() {
		prop = new SparkConf().setAppName("SPARK");
		jsCtx = new JavaSparkContext(prop);
		hiveCtx = new HiveContext(jsCtx.sc());
	}

	public EodReconProcessorMain(HiveContext hiveCtx, JavaSparkContext jsCtx,
			SparkConf prop) {
		this.hiveCtx = hiveCtx;
		this.jsCtx = jsCtx;
		this.prop = prop;
	}

	/**
	 * 
	 * @param hdfInputs
	 * @throws QueryException
	 */
	public static void main(String[] args) throws QueryException,
			ProcessException {

		logger.info("inside the EodReconProcessorMain main() method");
		EodReconProcessorMain eodReconProcessorMain = new EodReconProcessorMain();

		eodReconProcessorMain.processRecon(args);
	}

	public void processRecon(String[] hdfInputs) {
		logger.info("inside the processRecon() method");
		String sourceName = hdfInputs[0];
		String countryCode = hdfInputs[1];
		String partitionDate = hdfInputs[2];
		boolean status = false;
		List<String> metaDataForRecon = new ArrayList<String>();

		MetaDataProcessor metaDataProcessor = new MetaDataProcessor();
		AbstractEodReconProcessor abstractEodReconProcessor = new EodReconDeltaProcessorImpl();
		QueryExecutor processingQuery = new QueryExecutor(sourceName,
				countryCode, partitionDate);
		String commonDatabase = prop.get("spark.commonDatabase");
		List<Row> reconTable = abstractEodReconProcessor.getReconciliation(
				sourceName, countryCode, partitionDate, hiveCtx, prop,
				metaDataForRecon);
		Map<String, String> recon_dataForDelta = new HashMap<String, String>();
		Map<String, String> recon_dataForTransaction = new HashMap<String, String>();
		List<Row> eodDate = new ArrayList<Row>();
		String finalQueryForReconMetadata = "";
		String Date = "";
		String startDate = "";

		try {
			eodDate = processingQuery.getEodDate(countryCode, partitionDate,
					hiveCtx, prop);

			if (eodDate.size() > 0 && eodDate.get(0).get(0) != null) {
				if ((Date = eodDate.get(0).get(0).toString()).contains(":")) {
					startDate = Date.split(" ")[0];
				} else {
					startDate = eodDate.get(0).get(0).toString();
				}
			}

			for (Row row : reconTable) {
				if (row.get(3) == null
						|| row.get(3).toString().trim().length() == 0) {
					if (row.get(0) != null && row.get(2) != null) {
						recon_dataForDelta.put(row.get(0).toString(), row
								.get(2).toString()
								+ "/"
								+ ((row.get(4) != null) ? row.get(4).toString()
										: "")
								+ "/"
								+ ((row.get(5) != null) ? row.get(5).toString()
										: ""));

					}
				} else {
					if (row.get(0) != null && row.get(1) != null
							&& row.get(2) != null && row.get(3) != null)
						recon_dataForTransaction.put(row.get(0).toString(), row
								.get(1).toString()
								+ "/"
								+ row.get(2).toString()
								+ "/"
								+ row.get(3).toString()
								+ "/"
								+ ((row.get(4) != null) ? row.get(4).toString()
										: "")
								+ "/"
								+ ((row.get(5) != null) ? row.get(5).toString()
										: ""));

				}
			}
			if (!recon_dataForDelta.isEmpty()) {
				logger.info("Delta Recon implementations started");
				EodReconDeltaProcessorImpl eodReconDeltaProcessorImpl = new EodReconDeltaProcessorImpl();
				status = eodReconDeltaProcessorImpl.reconcile(sourceName,
						countryCode, partitionDate, recon_dataForDelta,
						startDate, hiveCtx, prop, metaDataForRecon);

			}
			if (!recon_dataForTransaction.isEmpty()) {
				logger.info("Transaction Recon implementations started");
				EodReconTransactionProcessorImpl eodReconTransactionProcessorImpl = new EodReconTransactionProcessorImpl();

				status = eodReconTransactionProcessorImpl.reconcile(sourceName,
						countryCode, partitionDate, recon_dataForTransaction,
						startDate, hiveCtx, prop, metaDataForRecon);

			}

		} catch (QueryException queryException) {
			logger.error(queryException.getMessage());
			CommonUtil commonUtil = new CommonUtil();
			metaDataForRecon.add(metaDataProcessor.processMetaData(sourceName,
					countryCode, partitionDate, recon_dataForDelta.toString(),
					FAILURE, queryException.getMessage(), RECONCILIATION,
					"RECON", hiveCtx, prop));
			String description = "Due to " + queryException.getMessage()
					+ RECONCILIATION + " is " + FAILURE;
			commonUtil.createFileForRemedy(sourceName, countryCode,
					partitionDate, NFD, "202", description, "RECON", prop);
		} catch (Exception exception) {
			logger.error(exception.getMessage());
			CommonUtil commonUtil = new CommonUtil();
			metaDataForRecon.add(metaDataProcessor.processMetaData(sourceName,
					countryCode, partitionDate, null, FAILURE,
					exception.getMessage(), RECONCILIATION, RECONCILIATION,
					hiveCtx, prop));
			String description = "Due to " + exception.getMessage()
					+ RECONCILIATION + " is " + FAILURE;
			commonUtil.createFileForRemedy(sourceName, countryCode,
					partitionDate, NFD, "202", description, RECONCILIATION,
					prop);
			if (exception instanceof RuntimeException) {
				System.exit(0);
			}
		}
		for (String metaData : metaDataForRecon) {
			if (metaDataForRecon.size() == 1) {
				finalQueryForReconMetadata = finalQueryForReconMetadata
						+ metaData + " from " + commonDatabase + DOT
						+ sourceName + UNDERSCORE + SCB_ALL_TAB + " limit 1";
			} else {
				finalQueryForReconMetadata = finalQueryForReconMetadata
						+ metaData + UNIONALL;
			}
		}
		if (!metaDataForRecon.isEmpty()) {
			if (finalQueryForReconMetadata.trim().endsWith(UNIONALL.trim())) {
				finalQueryForReconMetadata = finalQueryForReconMetadata
						.substring(0, finalQueryForReconMetadata.length() - 10);
			}
		}
		if (!finalQueryForReconMetadata.isEmpty()) {
			metaDataProcessor.insertMetaData(sourceName, countryCode,
					partitionDate, RECONCILIATION, RECONCILIATION, hiveCtx,
					prop, finalQueryForReconMetadata);
		} else {
			logger.info("Process metadata entry missing for Reconciliation");
		}
	}

	public boolean processReconForReRun(String[] hdfInputs,
			List<Row> partitionDates) {
		boolean status = false;
		logger.info("inside the processReRunRecon() method");
		String commonDatabase = prop.get("spark.commonDatabase");
		String sourceName = hdfInputs[0];
		String countryCode = hdfInputs[1];
		String tableName = hdfInputs[2].toLowerCase();
		List<String> tableList = new ArrayList<String>();
		List<String> metaDataForRecon = new ArrayList<String>();
		MetaDataProcessor metaDataProcessor = new MetaDataProcessor();
		String finalQueryForReconMetadata="";
		tableList.add(tableName);
		for (Row partitionRowDate : partitionDates) {

			String partitionDate = partitionRowDate.get(0).toString();
			;
			AbstractEodReconProcessor abstractEodReconProcessor = new EodReconDeltaProcessorImpl();
			QueryExecutor processingQuery = new QueryExecutor(sourceName,
					countryCode, partitionDate);

			List<Row> reconTable = abstractEodReconProcessor
					.getReconciliationForReRun(sourceName, countryCode,
							tableName, partitionDate, hiveCtx, prop);


			Map<String, String> recon_dataForDelta = new HashMap<String, String>();
			Map<String, String> recon_dataForTransaction = new HashMap<String, String>();
			List<Row> eodDate = new ArrayList<Row>();

			String Date = "";
			String startDate = "";

			try {
				eodDate = processingQuery.getEodDate(countryCode,
						partitionDate, hiveCtx, prop);

				if (eodDate.size() > 0 && eodDate.get(0).get(0) != null) {
					if ((Date = eodDate.get(0).get(0).toString()).contains(":")) {
						startDate = Date.split(" ")[0];
					} else {
						startDate = eodDate.get(0).get(0).toString();
					}
				}

				for (Row row : reconTable) {
					if (row.get(3) == null
							|| row.get(3).toString().trim().length() == 0) {
						if (row.get(0) != null && row.get(2) != null) {
							recon_dataForDelta.put(row.get(0).toString(),
									row.get(2).toString()
											+ "/"
											+ ((row.get(4) != null) ? row
													.get(4).toString() : "")
											+ "/"
											+ ((row.get(5) != null) ? row
													.get(5).toString() : ""));

						}
					} else {
						if (row.get(0) != null && row.get(1) != null
								&& row.get(2) != null && row.get(3) != null)
							recon_dataForTransaction.put(row.get(0).toString(),
									row.get(1).toString()
											+ "/"
											+ row.get(2).toString()
											+ "/"
											+ row.get(3).toString()
											+ "/"
											+ ((row.get(4) != null) ? row
													.get(4).toString() : "")
											+ "/"
											+ ((row.get(5) != null) ? row
													.get(5).toString() : ""));

					}
				}
				if (!recon_dataForDelta.isEmpty()) {
					logger.info("Delta Recon implementations started");
					EodReconDeltaProcessorImpl eodReconDeltaProcessorImpl = new EodReconDeltaProcessorImpl();
					status = eodReconDeltaProcessorImpl.reconcile(sourceName,
							countryCode, partitionDate, recon_dataForDelta,
							startDate, hiveCtx, prop, metaDataForRecon);

				}
				if (!recon_dataForTransaction.isEmpty()) {
					logger.info("Transaction Recon implementations started");
					EodReconTransactionProcessorImpl eodReconTransactionProcessorImpl = new EodReconTransactionProcessorImpl();

					status = eodReconTransactionProcessorImpl.reconcile(
							sourceName, countryCode, partitionDate,
							recon_dataForTransaction, startDate, hiveCtx, prop,
							metaDataForRecon);

				}
				this.rowCount.rowCount(sourceName, countryCode, partitionDate,
						tableList, false, hiveCtx, prop);
				
			} catch (QueryException queryException) {
				logger.error(queryException.getMessage());
				CommonUtil commonUtil = new CommonUtil();
				metaDataForRecon.add(metaDataProcessor.processMetaData(
						sourceName, countryCode, partitionDate,
						recon_dataForDelta.toString(), FAILURE,
						queryException.getMessage(), RECONCILIATION,
						"RERUN_RECON", hiveCtx, prop));
				String description = "Due to " + queryException.getMessage()
						+ RECONCILIATION + " is " + FAILURE;
				commonUtil.createFileForRemedy(sourceName, countryCode,
						partitionDate, NFD, "202", description, "RERUN_RECON", prop);
			} catch (Exception exception) {
				logger.error(exception.getMessage());
				CommonUtil commonUtil = new CommonUtil();
				metaDataForRecon.add(metaDataProcessor.processMetaData(
						sourceName, countryCode, partitionDate, null, FAILURE,
						exception.getMessage(), RECONCILIATION, "RERUN_RECON",
						hiveCtx, prop));
				String description = "Due to " + exception.getMessage()
						+ RECONCILIATION + " is " + FAILURE;
				commonUtil.createFileForRemedy(sourceName, countryCode,
						partitionDate, NFD, "202", description, RECONCILIATION,
						prop);
				if (exception instanceof RuntimeException) {
					System.exit(0);
				}
			}
		
		for (String metaData : metaDataForRecon) {
			if (metaDataForRecon.size() == 1) {
				finalQueryForReconMetadata = finalQueryForReconMetadata
						+ metaData + " from " + commonDatabase + DOT
						+ sourceName + UNDERSCORE + SCB_ALL_TAB + " limit 1";
			} else {
				finalQueryForReconMetadata = finalQueryForReconMetadata
						+ metaData + UNIONALL;
			}
		}
		if (!metaDataForRecon.isEmpty()) {
			if (finalQueryForReconMetadata.trim().endsWith(UNIONALL.trim())) {
				finalQueryForReconMetadata = finalQueryForReconMetadata
						.substring(0, finalQueryForReconMetadata.length() - 10);
			}
		}
		if (!finalQueryForReconMetadata.isEmpty()) {
			metaDataProcessor.insertMetaData(sourceName, countryCode,
					partitionDate, RECONCILIATION, "RERUN_RECON", hiveCtx,
					prop, finalQueryForReconMetadata);
		} else {
			logger.info("Process metadata entry missing for Reconciliation");
		}
		}
		return status;
	}
}