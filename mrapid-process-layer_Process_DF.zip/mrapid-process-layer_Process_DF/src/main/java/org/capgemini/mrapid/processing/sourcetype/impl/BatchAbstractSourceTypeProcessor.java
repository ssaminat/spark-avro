package org.capgemini.mrapid.processing.sourcetype.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.hive.HiveContext;
import org.capgemini.mrapid.processing.api.BatchSourceTypeProcessor;
import org.capgemini.mrapid.processing.api.SourceTypeProcessor;
import org.capgemini.mrapid.processing.exception.ProcessException;
import org.capgemini.mrapid.processing.metadata.MetaDataProcessor;
import org.capgemini.mrapid.processing.sparksql.QueryExecutor;
import org.capgemini.mrapid.processing.util.CommonUtil;
import org.capgemini.mrapid.processing.util.ProcessPrimaryKeyUtil;

import static org.apache.spark.sql.functions.col;
import static org.apache.spark.sql.functions.max;
import static org.capgemini.mrapid.processing.util.Constants.AVRO;
import static org.capgemini.mrapid.processing.util.Constants.FAILURE;
import static org.capgemini.mrapid.processing.util.Constants.FORWARD_SLASH;
import static org.capgemini.mrapid.processing.util.Constants.NFD;
import static org.capgemini.mrapid.processing.util.Constants.PART_ODS;
import static org.capgemini.mrapid.processing.util.Constants.EQUAL_SIGN;
import static org.capgemini.mrapid.processing.util.Constants.COMMA;
import static org.capgemini.mrapid.processing.util.Constants.C_JOURNALTIME;
import static org.capgemini.mrapid.processing.util.Constants.END_DATE;
import static org.capgemini.mrapid.processing.util.Constants.END_DATETIME;
import static org.capgemini.mrapid.processing.util.Constants.PROCESS_BUILD;
import static org.capgemini.mrapid.processing.util.Constants.PROCESS_LAYER;
import static org.capgemini.mrapid.processing.util.Constants.R202;
import static org.capgemini.mrapid.processing.util.Constants.UNDERSCORE;
import static org.capgemini.mrapid.processing.util.Constants.DOT;

public abstract class BatchAbstractSourceTypeProcessor implements
		BatchSourceTypeProcessor {
	final Logger logger = Logger.getLogger(this.getClass());

	public boolean batchSourceTypeProcess(String sourceName, String tableName,
			String countryCode, String partitionDate, String sourceType,
			List<Row> CurrentAndpreviuosDayPartitions, List<Row> eodAndNextEod,
			List<Row> eod_marker, HiveContext hiveContext, SparkConf prop,
			Broadcast<Map<String, Iterable<String>>> columns,
			Broadcast<Map<String, Iterable<String>>> primaryColumns,
			List<String> metaDataList) {
		logger.info("Inside the AbstractSourceTypeProcessor class sourceTypeProcess() method");
		BatchSourceTypeProcessor sourceTypeProcessor = null;
		if (this instanceof BatchIncrementalTypeProcessor) {
			sourceTypeProcessor = (BatchIncrementalTypeProcessor) this;
		} else if (this instanceof BatchTransactionTypeProcessor) {
			sourceTypeProcessor = (BatchTransactionTypeProcessor) this;
		}

		CommonUtil commonUtil = new CommonUtil();
		QueryExecutor queryExecutor = new QueryExecutor(sourceName,
				countryCode, partitionDate);
		MetaDataProcessor metaDataProcessor = new MetaDataProcessor();
		ProcessPrimaryKeyUtil primaryKey = new ProcessPrimaryKeyUtil();

		String startDate = "";
		String Date = "";
		String query = "";
		String columnJoins = "";
		String columnsForDuplicate = null;
		String primaryKeyWithCommaSeperator = null;
		String primaryKeysJoins = null;
		String columnNamesWithCol =null;
		String columnsWithCommaSeperator = null;
		String columnsWithCommaSeperatorForNoPrimaryKey = "";
		String primaryKeysColumn = null;
		String fromTimezone = prop.get("spark.fromJournalTimeTimeZone");
		String toTimezone = prop.get("spark.toJournalTimeTimeZone");
		String tableNameWithoutCountry = tableName;
		String filePath = prop.get("spark.filePath");
		String stagingDatabase = prop.get("spark.stagingDatabase");
		String processedDatabase = prop.get("spark.processedDatabase");
		List<String> primaryKeyList = new ArrayList<String>();
		List<String> columnListWithoutDataType = new ArrayList<String>();
		boolean status = true;
		try {
			Iterable<String> columnList = columns.value().get(
					tableNameWithoutCountry.toUpperCase());
			logger.info("columnList in query" + columnList);

			columnListWithoutDataType = CommonUtil
					.getColumnListWithoutDataType(columnList);
			columnJoins = CommonUtil
					.getColumnListForJoins(columnListWithoutDataType);
			logger.info("columnJoins " + columnJoins);
			columnsWithCommaSeperator = CommonUtil
					.getColumnsWithCommaSeperator(columnListWithoutDataType);
			columnsWithCommaSeperatorForNoPrimaryKey = CommonUtil
					.getColumnsWithCommaSeperatorNoPrimaryKey(columnListWithoutDataType);
			columnsForDuplicate = CommonUtil
					.getColumnListForDuplicate(columnListWithoutDataType);
			Iterable<String> primaryColumnsList = primaryColumns.value().get(
					tableNameWithoutCountry.toUpperCase());
			primaryKeyList = ProcessPrimaryKeyUtil
					.convertIterableToList(primaryColumnsList);
			primaryKeysColumn = CommonUtil
					.getColumnsWithCommaSeperatorFornoPK(columnsWithCommaSeperator);

			primaryKeyWithCommaSeperator = primaryKey
					.getPrimaryKeyWithCommaSeperator(primaryKeyList);

			primaryKeysJoins = primaryKey.getPrimaryKeys(primaryKeyList);
			//change below thing as per NBP(chk the source col list)
			columnNamesWithCol =CommonUtil.getColumnWithCol(columnListWithoutDataType);
			DataFrame dataframeAvro = hiveContext
					.read()
					.format(AVRO)
					.load(filePath + FORWARD_SLASH + stagingDatabase
							+ FORWARD_SLASH + countryCode + FORWARD_SLASH
							+ tableName + FORWARD_SLASH + PART_ODS + EQUAL_SIGN
							+ partitionDate + "/*");

			DataFrame dataframeOrc = hiveContext
					.read()
					.format("orc")
					.load(filePath + FORWARD_SLASH + stagingDatabase
							+ FORWARD_SLASH + countryCode + FORWARD_SLASH
							+ tableName + FORWARD_SLASH + PART_ODS + EQUAL_SIGN
							+ partitionDate + "/*");

/*			String pk1 = "msgtype";
			String pk2 = "c_userid";
			String pk3 = "c_userid1";
			String pk4 = "c_userid1";
			String pk5 = "c_userid1";*/
			DataFrame records = dataframeAvro.unionAll(dataframeOrc);
			String rundate="run_date";
			DataFrame maxDF;
			DataFrame df3 = null;
			DataFrame recordstemp=records.as("t");
			DataFrame maxDFtemp;

			// DataFrame
			// df2=dataframe.groupBy(mt,ui).agg(max("c_journaltime").as("c_journaltime"));

			//maxDFtemp.col(rundate).equalTo(recordstemp.col(rundate))).and
			switch (primaryKeyList.size()) {
			case 1:
				maxDF = recordstemp.groupBy(primaryKeyList.get(0)).agg(max(rundate).as("run_date"));
				maxDFtemp=maxDF.as("t1");
				df3=recordstemp.join(maxDFtemp,( maxDFtemp.col(primaryKeyList.get(0)).equalTo(recordstemp.col(primaryKeyList.get(0)))));
				break;
			case 2:
				maxDF = recordstemp.groupBy(primaryKeyList.get(0),primaryKeyList.get(1)).agg(max(rundate).as("run_date"));
				 maxDFtemp=maxDF.as("t1");
				df3=recordstemp.join(maxDFtemp,( maxDFtemp.col(primaryKeyList.get(0)).equalTo(recordstemp.col(primaryKeyList.get(0)))).and(maxDFtemp.col(primaryKeyList.get(1)).equalTo(recordstemp.col(primaryKeyList.get(1)))));
				break;
			case 3:
				maxDF = recordstemp.groupBy(primaryKeyList.get(0),primaryKeyList.get(1),primaryKeyList.get(2)).agg(max(rundate).as("run_date"));
				maxDFtemp=maxDF.as("t1");
				df3=recordstemp.join(maxDFtemp,( maxDFtemp.col(primaryKeyList.get(0)).equalTo(recordstemp.col(primaryKeyList.get(0)))).and(maxDFtemp.col(primaryKeyList.get(1)).equalTo(recordstemp.col(primaryKeyList.get(1)))).and(maxDFtemp.col(primaryKeyList.get(2)).equalTo(recordstemp.col(primaryKeyList.get(2)))));
				break;
			case 4:
				maxDF = recordstemp.groupBy(primaryKeyList.get(0),primaryKeyList.get(1),primaryKeyList.get(2),primaryKeyList.get(3)).agg(max(rundate).as("run_date"));
				maxDFtemp=maxDF.as("t1");
				df3=recordstemp.join(maxDFtemp,( maxDFtemp.col(primaryKeyList.get(0)).equalTo(recordstemp.col(primaryKeyList.get(0)))).and(maxDFtemp.col(primaryKeyList.get(1)).equalTo(recordstemp.col(primaryKeyList.get(1)))).and(maxDFtemp.col(primaryKeyList.get(2)).equalTo(recordstemp.col(primaryKeyList.get(2)))).and(maxDFtemp.col(primaryKeyList.get(3)).equalTo(recordstemp.col(primaryKeyList.get(3)))));
				break;
			case 5:
				maxDF = recordstemp.groupBy(primaryKeyList.get(0),primaryKeyList.get(1),primaryKeyList.get(2),primaryKeyList.get(3),primaryKeyList.get(4)).agg(max(rundate).as("run_date"));
				maxDFtemp=maxDF.as("t1");
				df3=recordstemp.join(maxDFtemp,( maxDFtemp.col(primaryKeyList.get(0)).equalTo(recordstemp.col(primaryKeyList.get(0)))).and(maxDFtemp.col(primaryKeyList.get(1)).equalTo(recordstemp.col(primaryKeyList.get(1)))).and(maxDFtemp.col(primaryKeyList.get(2)).equalTo(recordstemp.col(primaryKeyList.get(2)))).and(maxDFtemp.col(primaryKeyList.get(3)).equalTo(recordstemp.col(primaryKeyList.get(3)))).and(maxDFtemp.col(primaryKeyList.get(4)).equalTo(recordstemp.col(primaryKeyList.get(4)))));
				break;

			}
			//DataFrame df4=df3.select(col("t.rowid"),col("t.msgtype"),col("t.rowid"),col("t.msgtype"),col("t.c_journaltime"),col("t.c_transactionid"),col("t.c_operationtype"),col("t.c_userid"),col("t.prdcd"),col("t.starttime"));
			//DataFrame df4=df3.selectExpr(columnNamesWithCol);
			DataFrame df4=df3.select(columnNamesWithCol);
			DataFrame recordsWithoutX=df4.where("c_operationtype<>'X'");
			recordsWithoutX.registerTempTable("processedRecordsTemp");
			
			query = " select a." + "`" + "rowid" + "`" + ", " + "'" + startDate
					+ "'" + COMMA + "from_utc_timestamp(to_utc_timestamp("
					+ "a." + C_JOURNALTIME + "," + "\"" + fromTimezone + "\""
					+ ")," + "\"" + toTimezone + "\"" + ")" + COMMA + "\""
					+ END_DATE + "\"" + COMMA + "\"" + END_DATETIME + "\""
					+ COMMA + columnJoins + " from " + "processedRecordsTemp a" ;
			String ORCPath = filePath + FORWARD_SLASH + processedDatabase
					+ FORWARD_SLASH + countryCode + FORWARD_SLASH + tableName
					+ FORWARD_SLASH + PART_ODS + EQUAL_SIGN + partitionDate;
			CommonUtil.deletePreviousPath(ORCPath);
			
			String finalQuery = "INSERT INTO " + processedDatabase + DOT
					+ tableName + " PARTITION(" + PART_ODS + "='"
					+ (startDate.equals("") ? partitionDate : startDate) + "')"
					+ query;
			QueryExecutor.getDataFrameFromQuery(hiveContext, finalQuery);
			//recordsWithoutX.withColumn(colName, col);
			/*
			 * if(primaryKeyList.size()==1) { DataFrame
			 * df2=records.groupBy(pk1).agg(max("run_date").as("run_date")); }
			 * else if(primaryKeyList.size()==2) { DataFrame
			 * df2=records.groupBy(pk1,pk2).agg(max("run_date").as("run_date"));
			 * } else if(primaryKeyList.size()==3) { DataFrame
			 * df2=records.groupBy
			 * (pk1,pk2,pk3).agg(max("run_date").as("run_date")); } else
			 * if(primaryKeyList.size()==4) { DataFrame
			 * df2=records.groupBy(pk1,pk2
			 * ,pk3,pk4).agg(max("run_date").as("run_date")); }
			 */

		} catch (Exception exception) {
			status = false;
			metaDataList.add(metaDataProcessor.processMetaData(sourceName, countryCode,
					partitionDate, tableName, FAILURE, exception.getMessage(),
					PROCESS_LAYER, sourceTypeProcessor.getType(), hiveContext,
					prop));
			String description = "Due to " + exception.getMessage()
					+ sourceTypeProcessor.getType() + "table " + tableName
					+ " is " + FAILURE;
			commonUtil
					.createFileForRemedy(sourceName, countryCode,
							partitionDate, NFD, R202, description,
							PROCESS_BUILD, prop);
			if (exception instanceof RuntimeException) {
				System.exit(0);
			}

		}
		
		hiveContext.dropTempTable("processedRecordsTemp");		
		return status;
	}

}
