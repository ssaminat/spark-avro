package org.capgemini.mrapid.processing.recon.impl;

import static org.capgemini.mrapid.processing.util.Constants.COMMA;
import static org.capgemini.mrapid.processing.util.Constants.DOT;
import static org.capgemini.mrapid.processing.util.Constants.EMPTY_STRING;
import static org.capgemini.mrapid.processing.util.Constants.FAILURE;
import static org.capgemini.mrapid.processing.util.Constants.NFD;
import static org.capgemini.mrapid.processing.util.Constants.PART_ODS;
import static org.capgemini.mrapid.processing.util.Constants.RECONCILIATION;
import static org.capgemini.mrapid.processing.util.Constants.RECON_BUILD;
import static org.capgemini.mrapid.processing.util.Constants.RECON_DELTA;
import static org.capgemini.mrapid.processing.util.Constants.RECON_REPORT;
import static org.capgemini.mrapid.processing.util.Constants.RECON_TRANSACTION;
import static org.capgemini.mrapid.processing.util.Constants.RUNTYPE;
import static org.capgemini.mrapid.processing.util.Constants.SCB_ALL_TAB;
import static org.capgemini.mrapid.processing.util.Constants.SUCESS;
import static org.capgemini.mrapid.processing.util.Constants.UNDERSCORE;
import static org.capgemini.mrapid.processing.util.Constants.UNIONALL;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.sql.hive.HiveContext;
import org.capgemini.mrapid.processing.exception.ProcessException;
import org.capgemini.mrapid.processing.exception.QueryException;
import org.capgemini.mrapid.processing.metadata.MetaDataProcessor;
import org.capgemini.mrapid.processing.sparksql.QueryExecutor;
import org.capgemini.mrapid.processing.util.CommonUtil;

/**
 * EodRecon class implements EOD reconciliation for Transaction table based on
 * sourceName, countryCode, partitionDate for each country
 * 
 * @author suresh
 *
 */

public class EodReconTransactionProcessorImpl extends AbstractEodReconProcessor {
	final Logger logger = Logger.getLogger(this.getClass());

	/**
	 * This method is used to call Transaction Reconciliation for Row count,
	 * Checksum
	 * 
	 * @param tableListForTransaction
	 * @param sourceName
	 * @param countryCode
	 * @param partitionDate
	 * @throws QueryException
	 * @throws ProcessException
	 */

	public boolean reconcile(String sourceName, String countryCode,
			String partitionDate, Map<String, String> recon_dataForTransaction,
			String startDate, HiveContext hiveContext, SparkConf prop,
			List<String> metaDataForRecon)
	/* throws QueryException, ProcessException */{

		logger.info("Inside the EodReconTransactionProcessorImpl class ");
		Timestamp time_stamp = new Timestamp(System.currentTimeMillis());
		String commonDatabase = prop.get("spark.commonDatabase");
		Map<String, String> recon_Chk_Dest_count = new HashMap<String, String>();
		int srcChkSum = 0;
		int desChkSum = 0;
		int srcRowCount = 0;
		int desRowCount = 0;
		int src_row_count = 0;
		int dest_recon_count = 0;
		int src_recon_Chksum_count = 0;
		double dest_recon_Chksum_count = 0.0;
		String rowCntStatus = EMPTY_STRING;
		String chkSumStatus = EMPTY_STRING;
		String queryForRowCount = EMPTY_STRING;
		String queryForCheckSum = EMPTY_STRING;
		boolean isSingleRecordChkSum = false;
		boolean isError = true;
		String[] src_recon_chksum_field = null;
		String tableName = "";
		Map<String, String> src_Row_CountMap = new HashMap<String, String>();
		Map<String, String> src_Checksum_CountMap = new HashMap<String, String>();
		QueryExecutor processingQuery = new QueryExecutor(sourceName,
				countryCode, partitionDate);
		MetaDataProcessor metaDataProcessor = new MetaDataProcessor();
		CommonUtil commonUtil = new CommonUtil();
		String queryForProcessMetadata = "";
		String finalQueryForProcessMetadata = "";
		Map<String, String> rowCountForTransaction = new HashMap<String, String>();
		Map<String, String> checksumCountForTransaction = new HashMap<String, String>();
		try {
			if (!recon_dataForTransaction.isEmpty()) {

				String insertQuery = "INSERT INTO " + commonDatabase + DOT
						+ sourceName + UNDERSCORE + RECON_REPORT
						+ " PARTITION(" + PART_ODS + "='"
						+ (startDate.equals("") ? partitionDate : startDate)
						+ "')";
				rowCountForTransaction = processingQuery
						.generateTranReconQuery(sourceName, countryCode,
								partitionDate, recon_dataForTransaction,
								hiveContext, prop);
				logger.info("rowCountForTransaction" + rowCountForTransaction);
				checksumCountForTransaction = processingQuery
						.generateTranReconChkQuery(sourceName, countryCode,
								partitionDate, recon_dataForTransaction,
								hiveContext, prop);
				logger.info("checksumCountForTransaction"
						+ checksumCountForTransaction);
				for (Map.Entry<String, String> reconDataMapEntry : recon_dataForTransaction
						.entrySet()) {

					tableName = reconDataMapEntry.getKey();
					String src_field = reconDataMapEntry.getValue();
					logger.info("Transaction " + tableName
							+ " Row Count is started");

					/*
					 * Transaction Checksum is started
					 */

					String[] src_recon_fields = src_field.split("/");
					if (src_recon_fields.length > 1) {
						if (src_recon_fields[1] != null
								&& !src_recon_fields[1].isEmpty())
							src_row_count = Integer
									.parseInt(src_recon_fields[1]);
						src_Row_CountMap.put(tableName,
								String.valueOf(src_row_count));
						if (rowCountForTransaction.get(tableName) != null
								&& !"".equals(rowCountForTransaction
										.get(tableName))) {
							dest_recon_count = Integer
									.parseInt(rowCountForTransaction
											.get(tableName.toString()));
						}
						if (src_row_count == dest_recon_count) {
							rowCntStatus = SUCESS;
						} else {
							rowCntStatus = FAILURE;
							try {
								commonUtil
										.createFileForRemedy(
												sourceName,
												countryCode,
												partitionDate,
												NFD,
												"264",
												" In Transaction table "
														+ tableName
														+ ",both Source and Destination row count is mismatch",
												RECON_BUILD, prop);
							} catch (Exception exception) {
								logger.error(exception.getMessage());
								metaDataForRecon.add(metaDataProcessor
										.processMetaData(sourceName,
												countryCode, partitionDate,
												recon_dataForTransaction
														.toString(), FAILURE,
												exception.getMessage(),
												RECONCILIATION, RECON_DELTA,
												hiveContext, prop));
							}
						}
					}

					queryForRowCount = queryForRowCount + " select '"
							+ sourceName + "'" + COMMA + "'" + countryCode
							+ "'" + COMMA + "'" + countryCode + "'" + COMMA
							+ "'" + tableName + "'" + COMMA + "'"
							+ src_row_count + "'" + COMMA + "'"
							+ dest_recon_count + "'" + COMMA + "'" + srcChkSum
							+ "'" + COMMA + "'" + desChkSum + "'" + COMMA + "'"
							+ rowCntStatus + "'" + COMMA + "'" + time_stamp
							+ "'" + COMMA + "'" + RUNTYPE + "'";

					if (recon_dataForTransaction.size() == 1) {
						queryForRowCount = queryForRowCount + " from "
								+ commonDatabase + DOT + sourceName
								+ UNDERSCORE + SCB_ALL_TAB + " limit 1";
					}
					queryForRowCount = queryForRowCount + UNIONALL;

					/*
					 * Transaction Checksum is started
					 */
					logger.info("Transaction " + tableName
							+ " CheckSum Count is started");

					String src_Chksum_field = reconDataMapEntry.getValue();
					src_recon_chksum_field = src_Chksum_field.split("/");
					if (src_recon_chksum_field.length >= 4
							&& src_recon_chksum_field[3] != null
							&& !src_recon_chksum_field[3].isEmpty()) {

						if (src_recon_chksum_field != null
								&& src_recon_chksum_field.length >= 5) {
							if (src_recon_chksum_field[4] != null
									&& !src_recon_chksum_field[4].isEmpty())
								src_recon_Chksum_count = Integer
										.parseInt(src_recon_chksum_field[4]);
							src_Checksum_CountMap.put(tableName,
									String.valueOf(src_recon_Chksum_count));
						}

						if (checksumCountForTransaction.get(tableName) != null
								&& !"".equals(checksumCountForTransaction
										.get(tableName))) {
							dest_recon_Chksum_count = Double
									.parseDouble(checksumCountForTransaction
											.get(tableName));
						}

						int destination_Count = (int) Math
								.round(dest_recon_Chksum_count);
						if (src_recon_Chksum_count == destination_Count) {
							chkSumStatus = SUCESS;
						} else {
							chkSumStatus = FAILURE;
						}
						queryForCheckSum = queryForCheckSum + " select '"
								+ sourceName + "'" + COMMA + "'" + countryCode
								+ "'" + COMMA + "'" + countryCode + "'" + COMMA
								+ "'" + tableName + "'" + COMMA + "'"
								+ srcRowCount + "'" + COMMA + "'" + desRowCount
								+ "'" + COMMA + "'" + src_recon_Chksum_count
								+ "'" + COMMA + "'" + dest_recon_Chksum_count
								+ "'" + COMMA + "'" + chkSumStatus + "'"
								+ COMMA + "'" + time_stamp + "'" + COMMA + "'"
								+ RUNTYPE + "'";

						if (recon_Chk_Dest_count.size() == 1) {
							queryForCheckSum = queryForCheckSum + " from "
									+ commonDatabase + DOT + sourceName
									+ UNDERSCORE + SCB_ALL_TAB + " limit 1";
							isSingleRecordChkSum = true;
							break;
						}
						queryForCheckSum = queryForCheckSum + UNIONALL;
					} else {
						logger.info("Transaction Reconciliation checksum is not available for this table :"
								+ reconDataMapEntry.getKey());
					}
					dest_recon_Chksum_count = 0.0;

				}// for close
				if (!queryForRowCount.isEmpty()) {
					queryForRowCount = insertQuery + queryForRowCount;
					queryForRowCount = queryForRowCount.substring(0,
							queryForRowCount.length() - 10);
					logger.info("Executing Query for rowcount"
							+ queryForRowCount);
					QueryExecutor.getDataFrameFromQuery(hiveContext,
							queryForRowCount);
				}

				if (!queryForCheckSum.isEmpty()) {

					queryForCheckSum = insertQuery + queryForCheckSum;
					if (!isSingleRecordChkSum)
						queryForCheckSum = queryForCheckSum.substring(0,
								queryForCheckSum.length() - 10);
					logger.info("Executing Query For CheckSum count"
							+ queryForCheckSum);
					QueryExecutor.getDataFrameFromQuery(hiveContext,
							queryForCheckSum);
				}

			} else {
				logger.info("Transaction Reconciliation is not available for this country");
			}

		} catch (QueryException queryException) {
			logger.error(queryException.getMessage());
			isError = false;
			metaDataForRecon.add(metaDataProcessor.processMetaData(sourceName,
					countryCode, partitionDate,
					recon_dataForTransaction.toString(), FAILURE,
					queryException.getMessage(), RECONCILIATION,
					RECON_TRANSACTION, hiveContext, prop));
			commonUtil.createFileForRemedy(sourceName, countryCode,
					partitionDate, NFD, "263",
					"Due to" + queryException.getMessage()
							+ " transaction recon is failure", RECON_BUILD,
					prop);

		} catch (ProcessException processException) {
			logger.error(processException.getMessage());
			isError = false;
			metaDataForRecon.add(metaDataProcessor.processMetaData(sourceName,
					countryCode, partitionDate,
					recon_dataForTransaction.toString(), FAILURE,
					processException.getMessage(), RECONCILIATION,
					RECON_TRANSACTION, hiveContext, prop));
			commonUtil.createFileForRemedy(sourceName, countryCode,
					partitionDate, NFD, "263",
					"Due to" + processException.getMessage()
							+ " transaction recon is failure", RECON_BUILD,
					prop);

		} catch (Exception exception) {
			logger.error(exception.getMessage());
			isError = false;
			metaDataForRecon.add(metaDataProcessor.processMetaData(sourceName,
					countryCode, partitionDate,
					recon_dataForTransaction.toString(), FAILURE,
					exception.getMessage(), RECONCILIATION, RECON_TRANSACTION,
					hiveContext, prop));
			commonUtil.createFileForRemedy(sourceName, countryCode,
					partitionDate, NFD, "263",
					"Due to" + exception.getMessage()
							+ " transaction recon is failure", RECON_BUILD,
					prop);
			if (exception instanceof RuntimeException) {
				System.exit(0);
			}

		}

		if (isError) {
			for (Map.Entry<String, String> reconDataMapEntry : recon_dataForTransaction
					.entrySet()) {
				tableName = reconDataMapEntry.getKey();
				String description = "EOD RECON for the file " + tableName
						+ " is SUCCESSFUL, RECON_VAL COUNT at source: "
						+ src_Row_CountMap.get(tableName) + ", FILE_COUNT: "
						+ dest_recon_count + ", RECON_VAL CHKSUM: "
						+ src_Checksum_CountMap.get(tableName)
						+ ", FILE CHKSUM: " + dest_recon_Chksum_count;
				queryForProcessMetadata = "SELECT '" + time_stamp + "'" + COMMA
						+ "'" + PART_ODS + "'" + COMMA + "'" + tableName + "'"
						+ COMMA + "'" + SUCESS + "'" + COMMA + "'"
						+ description + "'" + COMMA + "'" + time_stamp + "'"
						+ COMMA + "'" + RECONCILIATION + "'" + COMMA + null
						+ COMMA + "'" + "runtype'" + COMMA + "'"
						+ partitionDate + "'" + COMMA + null;
				if (recon_dataForTransaction.size() == 1) {
					queryForProcessMetadata = queryForProcessMetadata
							+ " from " + commonDatabase + DOT + sourceName
							+ UNDERSCORE + SCB_ALL_TAB + " limit 1";
					finalQueryForProcessMetadata += queryForProcessMetadata;
				} else {
					finalQueryForProcessMetadata += queryForProcessMetadata
							+ UNIONALL;
				}
			}
			if (finalQueryForProcessMetadata.trim().endsWith(UNIONALL.trim())) {
				finalQueryForProcessMetadata = finalQueryForProcessMetadata
						.substring(0,
								finalQueryForProcessMetadata.length() - 10);
			}

		}

		// hiveContext.setConf("spark.sql.hive.convertMetastoreOrc", "false");
		return true;
	}

}