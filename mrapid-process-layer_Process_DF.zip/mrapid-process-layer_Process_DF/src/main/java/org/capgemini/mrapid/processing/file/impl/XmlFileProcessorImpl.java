package org.capgemini.mrapid.processing.file.impl;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.hive.HiveContext;
import org.capgemini.mrapid.processing.api.FileProcessor;
import org.capgemini.mrapid.processing.exception.ProcessException;
import org.capgemini.mrapid.processing.exception.QueryException;

public class XmlFileProcessorImpl implements FileProcessor {

	public boolean process(String[] hdfInputs,HiveContext hiveContext,JavaSparkContext jsCtx,SparkConf prop) throws ProcessException,
			QueryException {
		// TODO Auto-generated method stub
		
		return false;

	}
}
