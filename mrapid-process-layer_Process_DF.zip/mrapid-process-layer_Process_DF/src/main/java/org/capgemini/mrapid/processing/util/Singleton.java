/*package org.capgemini.mrapid.processing.util;

import static org.capgemini.mrapid.processing.util.Constants.SPARKMASTER;
import static org.capgemini.mrapid.processing.util.Constants.EXECUTOR_MEMORY;
import static org.capgemini.mrapid.processing.util.Constants.EXECUTOR_CORES;
import static org.capgemini.mrapid.processing.util.Constants.EXECUTOR_INSTANCES;
import static org.capgemini.mrapid.processing.util.Constants.SHUFFLE_PARTITIONS;
import static org.capgemini.mrapid.processing.util.Constants.YARN_QUEUE;

import java.util.Properties;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.hive.HiveContext;

*//**
 * This class is used to create the singleton objects.
 * 
 * @author nisankar
 *
 *//*
public class Singleton {

	private static final Properties prop = CommonUtil
			.loadPropertiesFile("configuration.properties");

	private static final SparkConf conf = new SparkConf()
			.setMaster(prop.getProperty(SPARKMASTER))
			.set("spark.executor.memory", prop.getProperty(EXECUTOR_MEMORY))
			.set("spark.executor.cores", prop.getProperty(EXECUTOR_CORES))
			.set("spark.executor.instances",
					prop.getProperty(EXECUTOR_INSTANCES))
			.set("spark.sql.shuffle.partitions",
					prop.getProperty(SHUFFLE_PARTITIONS))
			.set("spark.yarn.queue", prop.getProperty(YARN_QUEUE))
			.setAppName("SPARK APP");
	private static SparkConf conf = new SparkConf();
	private static JavaSparkContext jsc = new JavaSparkContext(conf);
	private static HiveContext hc = new HiveContext(jsc.sc());
	public static SparkConf getSparkConf() {
		return conf;
	}

	public static JavaSparkContext getJavaSparkContext() {
		return jsc;
	}

	public static HiveContext getHiveContext() {
		hc.setConf("spark.sql.hive.convertMetastoreOrc", "false");
		return hc;
	}

	public static Properties getProperties() {

		return prop;
	}

}
*/