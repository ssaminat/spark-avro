package org.capgemini.mrapid.processing.recon.impl;

import static org.capgemini.mrapid.processing.util.Constants.COMMA;
import static org.capgemini.mrapid.processing.util.Constants.DOT;
import static org.capgemini.mrapid.processing.util.Constants.EQUAL_SIGN;
import static org.capgemini.mrapid.processing.util.Constants.FAILURE;
import static org.capgemini.mrapid.processing.util.Constants.NFD;
import static org.capgemini.mrapid.processing.util.Constants.PART_ODS;
import static org.capgemini.mrapid.processing.util.Constants.RECONCILIATION;
import static org.capgemini.mrapid.processing.util.Constants.RECON_BUILD;
import static org.capgemini.mrapid.processing.util.Constants.RECON_DELTA;
import static org.capgemini.mrapid.processing.util.Constants.RECON_REPORT;
import static org.capgemini.mrapid.processing.util.Constants.SCB_ALL_TAB;
import static org.capgemini.mrapid.processing.util.Constants.SUCESS;
import static org.capgemini.mrapid.processing.util.Constants.UNDERSCORE;
import static org.capgemini.mrapid.processing.util.Constants.UNIONALL;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.sql.hive.HiveContext;
import org.capgemini.mrapid.processing.exception.QueryException;
import org.capgemini.mrapid.processing.metadata.MetaDataProcessor;
import org.capgemini.mrapid.processing.sparksql.QueryExecutor;
import org.capgemini.mrapid.processing.util.CommonUtil;

/**
 * 
 * EodRecon class implements EOD reconciliation for master table based on
 * sourceName, countryCode, partitionDate for each country
 * 
 * @author nisankar
 *
 */

public class EodReconDeltaProcessorImpl extends AbstractEodReconProcessor {

	final Logger logger = Logger.getLogger(this.getClass());

	boolean isError = false;

	public boolean reconcile(String sourceName, String countryCode,
			String partitionDate, Map<String, String> recon_dataForDelta,
			String startDate, HiveContext hiveContext, SparkConf prop,
			List<String> metaDataForRecon)
	/* throws QueryException, ProcessException */{
		logger.info("Inside the reconcile() method");
		String commonDatabase = prop.get("spark.commonDatabase");
		QueryExecutor processingQuery = new QueryExecutor(sourceName,
				countryCode, partitionDate);
		MetaDataProcessor metaDataProcessor = new MetaDataProcessor();
		CommonUtil commonUtil = new CommonUtil();
		String statusForRowCount = "";
		String statusForChecksumCount = "";
		String[] recon_fields = null;
		int src_row_count = 0;
		double deschksumtot = 0.0;
		int emptySrc_row_count = 0;
		int emptyDest_row_count = 0;
		int emptySrcchksumtot = 0;
		int emptyDeschksumtot = 0;
		int destination_check_count = 0;
		String queryForProcessMetadata = "";
		String finalQueryForProcessMetadata = "";
		String tableName = "";
		String queryForRowCount = "";
		String queryForCheckSumCount = "";
		int dest_row_count = 0;
		boolean isSingleRecordChkSum = false;
		boolean isError = true;
		Map<String, String> src_rowCountMap = new HashMap<String, String>();
		Map<String, String> src_Checksum_Count_Map = new HashMap<String, String>();
		String insertQuery = "INSERT INTO " + commonDatabase + DOT + sourceName
				+ UNDERSCORE + RECON_REPORT + " PARTITION(" + PART_ODS
				+ EQUAL_SIGN + "'"
				+ (startDate.equals("") ? partitionDate : startDate) + "')";
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		try {

			if (!recon_dataForDelta.isEmpty()) {

				Map<String, String> rowCountForDelta = processingQuery
						.generateReconQuery(sourceName, countryCode,
								partitionDate, recon_dataForDelta, hiveContext,
								prop);
				Map<String, String> checksumCountForDelta = processingQuery
						.generateReconchksumQuery(sourceName, countryCode,
								partitionDate, recon_dataForDelta, hiveContext,
								prop);
				Set<String> tableList = recon_dataForDelta.keySet();
				for (Iterator<String> iterator = tableList.iterator(); iterator
						.hasNext();) {
					deschksumtot = 0.0;
					tableName = iterator.next();
					String field = recon_dataForDelta.get(tableName.toString());
					Timestamp time_stamp = new Timestamp(
							System.currentTimeMillis());
					if (field != null) {
						recon_fields = field.split("/");
					}
					if (recon_fields != null) {
						src_row_count = Integer.parseInt(recon_fields[0]);
						src_rowCountMap.put(tableName,
								String.valueOf(src_row_count));
					}
					if (rowCountForDelta.get(tableName) != null
							&& !"".equals(rowCountForDelta.get(tableName)))
						dest_row_count = Integer.parseInt(rowCountForDelta
								.get(tableName));
					if (src_row_count == dest_row_count) {
						statusForRowCount = SUCESS;
					} else {
						statusForRowCount = FAILURE;
					}
					queryForRowCount = queryForRowCount + "select '"
							+ sourceName + "'" + COMMA + "'" + countryCode
							+ "'" + COMMA + "'" + countryCode + "'" + COMMA
							+ "'" + tableName + "'" + COMMA + "'"
							+ src_row_count + "'" + COMMA + "'"
							+ dest_row_count + "'" + COMMA + "'"
							+ emptySrcchksumtot + "'" + COMMA + "'"
							+ emptyDeschksumtot + "'" + COMMA + "'"
							+ statusForRowCount + "'" + COMMA + "'"
							+ time_stamp + "'" + COMMA + "'runtype'";

					if (recon_dataForDelta.size() == 1) {
						queryForRowCount = queryForRowCount + " from "
								+ commonDatabase + DOT + sourceName
								+ UNDERSCORE + SCB_ALL_TAB + " limit 1";
					}
					queryForRowCount = queryForRowCount + UNIONALL;

					String chksumvalues = recon_dataForDelta.get(tableName
							.toString());
					int sourceChecksumtotal = 0;
					String[] Checksumtot = null;
					if (chksumvalues != null)
						Checksumtot = chksumvalues.split("/");
					if (Checksumtot != null && Checksumtot.length >= 3)
						sourceChecksumtotal = Integer.parseInt(Checksumtot[2]);
					src_Checksum_Count_Map.put(tableName,
							String.valueOf(sourceChecksumtotal));
					if (checksumCountForDelta.get(tableName) != null
							&& !"".equals(checksumCountForDelta.get(tableName)))
						deschksumtot = Double.parseDouble(checksumCountForDelta
								.get(tableName));
					destination_check_count = (int) Math.round(deschksumtot);

					if (sourceChecksumtotal == destination_check_count) {
						statusForChecksumCount = SUCESS;
					} else {
						statusForChecksumCount = FAILURE;
						try {
							commonUtil
									.createFileForRemedy(
											sourceName,
											countryCode,
											partitionDate,
											NFD,
											"262",
											"In Master "
													+ tableName
													+ " both Source and Destination Row Count is mismatch",
											RECON_BUILD, prop);
						} catch (Exception exception) {
							logger.error(exception.getMessage());
							metaDataForRecon.add(metaDataProcessor
									.processMetaData(sourceName, countryCode,
											partitionDate,
											recon_dataForDelta.toString(),
											FAILURE, exception.getMessage(),
											RECONCILIATION, RECON_DELTA,
											hiveContext, prop));
						}
					}
					if (checksumCountForDelta.containsKey(tableName)) {
						queryForCheckSumCount = queryForCheckSumCount
								+ "select '" + sourceName + "'" + COMMA + "'"
								+ countryCode + "'" + COMMA + "'" + countryCode
								+ "'" + COMMA + "'" + tableName + "'" + COMMA
								+ "'" + emptySrc_row_count + "'" + COMMA + "'"
								+ emptyDest_row_count + "'" + COMMA + "'"
								+ sourceChecksumtotal + "'" + COMMA + "'"
								+ destination_check_count + "'" + COMMA + "'"
								+ statusForChecksumCount + "'" + COMMA + "'"
								+ time_stamp + "'" + COMMA + "'runtype'";

						if (checksumCountForDelta.size() == 1) {
							queryForCheckSumCount = queryForCheckSumCount
									+ " from " + commonDatabase + DOT
									+ sourceName + UNDERSCORE + SCB_ALL_TAB
									+ " limit 1";
							isSingleRecordChkSum = true;
							break;
						}
						queryForCheckSumCount = queryForCheckSumCount
								+ UNIONALL;
					}

				}// for loop
				if (!queryForRowCount.isEmpty()) {
					queryForRowCount = insertQuery + queryForRowCount;
					queryForRowCount = queryForRowCount.substring(0,
							queryForRowCount.length() - 10);
					logger.info("Executing Query for rowcount"
							+ queryForRowCount);
					QueryExecutor.getDataFrameFromQuery(hiveContext,
							queryForRowCount);

				}
				if (!queryForCheckSumCount.isEmpty()) {

					queryForCheckSumCount = insertQuery + queryForCheckSumCount;
					if (!isSingleRecordChkSum)
						queryForCheckSumCount = queryForCheckSumCount
								.substring(0,
										queryForCheckSumCount.length() - 10);
					logger.info("Executing Query For CheckSum count"
							+ queryForCheckSumCount);
					QueryExecutor.getDataFrameFromQuery(hiveContext,
							queryForCheckSumCount);
				}

			}

			/*
			 * String query = "select " + TABLE_NAME + COMMA + STATUS + " from "
			 * + commonDatabase + DOT + sourceName + UNDERSCORE + RECON_REPORT +
			 * " where " + STATUS + EQUAL_SIGN + "'" + FAILURE + "'";
			 * 
			 * reconRptStsCheck = QueryExecutor.getListFromQuery(hiveContext,
			 * query); for (Row row : reconRptStsCheck) { if
			 * (FAILURE.equalsIgnoreCase(row.get(1).toString())) { try {
			 * commonUtil .createFileForRemedy( sourceName, countryCode,
			 * partitionDate, NFD, "262",
			 * "Both Source and Destination Row Count is mismatch", RECON_BUILD,
			 * prop); } catch (Exception exception) {
			 * logger.error(exception.getMessage());
			 * metaDataForRecon.add(metaDataProcessor.processMetaData(
			 * sourceName, countryCode, partitionDate,
			 * recon_dataForDelta.toString(), FAILURE, exception.getMessage(),
			 * RECONCILIATION, RECON_DELTA, hiveContext, prop)); } }
			 * 
			 * }
			 */

		} catch (QueryException queryException) {
			logger.error(queryException.getMessage());
			isError = false;
			metaDataForRecon.add(metaDataProcessor.processMetaData(sourceName,
					countryCode, partitionDate, recon_dataForDelta.toString(),
					FAILURE, queryException.getMessage(), RECONCILIATION,
					RECON_DELTA, hiveContext, prop));
			commonUtil.createFileForRemedy(sourceName, countryCode,
					partitionDate, NFD, "261",
					"Due to " + queryException.getMessage()
							+ " Delta Recon Count is Failure", RECON_BUILD,
					prop);
			// throw queryException;

		} catch (Exception exception) {
			isError = false;
			logger.error(exception.getMessage());
			metaDataForRecon.add(metaDataProcessor.processMetaData(sourceName,
					countryCode, partitionDate, recon_dataForDelta.toString(),
					FAILURE, exception.getMessage(), RECONCILIATION,
					RECON_DELTA, hiveContext, prop));
			commonUtil.createFileForRemedy(sourceName, countryCode,
					partitionDate, NFD, "261",
					"Due to " + exception.getMessage()
							+ " Delta Recon Count is Failure", RECON_BUILD,
					prop);
			if (exception instanceof RuntimeException) {
				System.exit(0);
			}
		}
		if (isError) {
			for (Map.Entry<String, String> reconDataMapEntry : recon_dataForDelta
					.entrySet()) {
				tableName = reconDataMapEntry.getKey();
				String description = "EOD RECON for the file " + tableName
						+ " is SUCCESSFUL, RECON_VAL COUNT at source: "
						+ src_rowCountMap.get(tableName) + ", FILE_COUNT: "
						+ dest_row_count + ", RECON_VAL CHKSUM: "
						+ src_Checksum_Count_Map.get(tableName)
						+ ", FILE CHKSUM: " + destination_check_count;
				queryForProcessMetadata = "SELECT '" + timestamp + "'" + COMMA
						+ "'" + PART_ODS + "'" + COMMA + "'" + tableName + "'"
						+ COMMA + "'" + SUCESS + "'" + COMMA + "'"
						+ description + "'" + COMMA + "'" + timestamp + COMMA
						+ "'" + RECONCILIATION + "'" + COMMA + null + COMMA
						+ "'" + "runtype'" + COMMA + "'" + partitionDate + "'"
						+ COMMA + null;
				if (recon_dataForDelta.size() == 1) {
					queryForProcessMetadata = queryForProcessMetadata
							+ " from " + commonDatabase + DOT + sourceName
							+ UNDERSCORE + SCB_ALL_TAB + " limit 1";
					finalQueryForProcessMetadata += queryForProcessMetadata;
				} else {
					finalQueryForProcessMetadata = finalQueryForProcessMetadata
							+ queryForProcessMetadata + UNIONALL;
				}
			}
			if (finalQueryForProcessMetadata.trim().endsWith(UNIONALL.trim())) {
				finalQueryForProcessMetadata = finalQueryForProcessMetadata
						.substring(0,
								finalQueryForProcessMetadata.length() - 10);
			}

		}
		return true;

	}
}
