package org.capgemini.mrapid.processing.file.impl;

import static org.capgemini.mrapid.processing.util.Constants.PROCESS_LAYER;
import static org.capgemini.mrapid.processing.util.Constants.SUCESS;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.hive.HiveContext;
import org.capgemini.mrapid.processing.api.BatchSourceTypeProcessor;
import org.capgemini.mrapid.processing.api.FileProcessor;
import org.capgemini.mrapid.processing.api.SourceTypeProcessor;
import org.capgemini.mrapid.processing.exception.ProcessException;
import org.capgemini.mrapid.processing.exception.QueryException;
import org.capgemini.mrapid.processing.factory.BatchSourceTypeProcessorFactory;
import org.capgemini.mrapid.processing.factory.SourceTypeProcessorFactory;
import org.capgemini.mrapid.processing.metadata.MetaDataProcessor;
import org.capgemini.mrapid.processing.rowcounts.RowCounts;
import org.capgemini.mrapid.processing.sparksql.QueryExecutor;
import org.capgemini.mrapid.processing.util.CommonUtil;

/**
 * 
 * This class implements business logic for Batch Implementation. <br/>
 * Batch file format are as follows: H-Header T-Trailer X-Delete. <br/>
 * Implementation Logic: <br/>
 * 1. Get the records from table based on partition date.<br/>
 * 2. Remove the (X)Deleted records from the table.<br/>
 * 3. Save hive tables in ORC format.<br/>
 * Source table name format must be : database.countrycode_tablename. <br/>
 * Destination table name format must be : database.countrycode_tablename_orc. <br/>
 * 
 * @author ikumarav
 */
public class BatchFileProcessorImpl implements FileProcessor {
	final Logger logger = Logger.getLogger(this.getClass());
	public static final String CLASSNAME = "BatchFileProcessorImpl";

	RowCounts rowCount = new RowCounts();
	/*/ *  * (non-Javadoc)
	 * 
	 * @see
	 * org.capgemini.mrapid.processing.api.FileProcessor#process(java.lang.String
	 * [])*/
	 

	public boolean process(String[] hdfInput, HiveContext hiveContext,JavaSparkContext JSC,
			SparkConf prop) throws ProcessException, QueryException {
		SourceTypeProcessorFactory sourceTypeProcessorFactory = new SourceTypeProcessorFactory();
		MetaDataProcessor metaDataProcessor = new MetaDataProcessor();
		Map<String, String> tableNameWithSourceType = null;
		List<String> tableList = new ArrayList<String>();
		Broadcast<Map<String, Iterable<String>>> columns =null;
		Broadcast<Map<String, Iterable<String>>> primaryKeyColumnsMap =null;
		String commonDatabase = prop.get("spark.commonDatabase");
		List<Row> latestPartition = null;
		List<Row> journalTime = null;
		List<Row> eodDate = null;
		boolean fullBase = false;
		boolean status = false;
		List<String> metaDateList = new ArrayList<String>();
		String sourceName = hdfInput[0];
		String countryCode = hdfInput[1];
		String partitionDate = hdfInput[2];
		QueryExecutor processingQuery = new QueryExecutor(sourceName,
				countryCode, partitionDate);
		CommonUtil commonUtil = new CommonUtil();
		BatchSourceTypeProcessorFactory batchSourceTypeProcessorFactory =new BatchSourceTypeProcessorFactory();
		String filePath = prop.get("spark.filePath");
		tableNameWithSourceType=CommonUtil.getTablesListWithSourceType(filePath,commonDatabase,sourceName,countryCode,JSC);
		tableList =new ArrayList<String>(tableNameWithSourceType.keySet());
		eodDate = processingQuery.getEodDate(countryCode, partitionDate,
				hiveContext, prop);
		latestPartition = processingQuery.getLatestPartitions(countryCode,
				hiveContext, prop, partitionDate);
		journalTime = processingQuery.getJournalTime(countryCode,
				latestPartition, hiveContext, prop, partitionDate);
		columns=CommonUtil.getColumnsList(filePath,commonDatabase,sourceName,countryCode,JSC);
		primaryKeyColumnsMap = CommonUtil.getPrimaryColumnsList(JSC);
		String cdc_eod_Marker = prop.get("spark.cdc_eod_marker");
		String cdc_eod_Recon = prop.get("spark.cdc_eod_recon");
		for (String tableName : tableList) {

			logger.info("Getting records from " + tableName);
			if (tableName.equalsIgnoreCase(cdc_eod_Marker) || tableName.equalsIgnoreCase(cdc_eod_Recon)) {
				continue;
				
			}
			BatchSourceTypeProcessor sourceTypeProcessor = batchSourceTypeProcessorFactory
					.createProcessor(tableNameWithSourceType.get(tableName));

			if (sourceTypeProcessor != null)
				status = sourceTypeProcessor.batchSourceTypeProcess(sourceName,
						tableName.toLowerCase(), countryCode, partitionDate,
						tableNameWithSourceType.get(tableName),
						latestPartition, eodDate, journalTime, hiveContext,
						prop, columns,primaryKeyColumnsMap,metaDateList);
			if (status) {
				logger.info("inside for if: ");
				metaDateList.add(metaDataProcessor.processMetaData(sourceName, countryCode,
						partitionDate, tableName, SUCESS,
						sourceTypeProcessor.getType()
								+ " is successfully completed", PROCESS_LAYER,
						sourceTypeProcessor.getType(), hiveContext, prop));
			}
			logger.info("endd");
			status = false;

		}
		if (!tableList.isEmpty()) {
			rowCount.rowCount(sourceName, countryCode, partitionDate,
					tableList, fullBase, hiveContext, prop);
		}
		primaryKeyColumnsMap.unpersist();
		primaryKeyColumnsMap.destroy();
		columns.unpersist();
		columns.destroy();
		return true;
	}
}

