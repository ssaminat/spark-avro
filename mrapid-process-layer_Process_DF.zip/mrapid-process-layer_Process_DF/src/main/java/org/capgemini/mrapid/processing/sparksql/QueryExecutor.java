package org.capgemini.mrapid.processing.sparksql;

import static org.capgemini.mrapid.processing.util.Constants.CDC;
import static org.capgemini.mrapid.processing.util.Constants.COMMA;
import static org.capgemini.mrapid.processing.util.Constants.COUNTRY_NAME;
import static org.capgemini.mrapid.processing.util.Constants.C_JOURNALTIME;
import static org.capgemini.mrapid.processing.util.Constants.DOT;
import static org.capgemini.mrapid.processing.util.Constants.EMPTY_STRING;
import static org.capgemini.mrapid.processing.util.Constants.EOD_DATE;
import static org.capgemini.mrapid.processing.util.Constants.EQUAL_SIGN;
import static org.capgemini.mrapid.processing.util.Constants.FAILURE;
import static org.capgemini.mrapid.processing.util.Constants.FD_NFD;
import static org.capgemini.mrapid.processing.util.Constants.GREATERTHNEQ;
import static org.capgemini.mrapid.processing.util.Constants.LESSTHNEQ;
import static org.capgemini.mrapid.processing.util.Constants.MASTER;
import static org.capgemini.mrapid.processing.util.Constants.NEXT_EOD_DATE;
import static org.capgemini.mrapid.processing.util.Constants.NFD;
import static org.capgemini.mrapid.processing.util.Constants.PART_ODS;
import static org.capgemini.mrapid.processing.util.Constants.PRIMARY_KEY_COULUMN;
import static org.capgemini.mrapid.processing.util.Constants.PROCESS_BUILD;
import static org.capgemini.mrapid.processing.util.Constants.PROCESS_LAYER;
import static org.capgemini.mrapid.processing.util.Constants.RECONCILIATION;
import static org.capgemini.mrapid.processing.util.Constants.RECON_BUILD;
import static org.capgemini.mrapid.processing.util.Constants.RECON_DELTA;
import static org.capgemini.mrapid.processing.util.Constants.RECON_TRANSACTION;
import static org.capgemini.mrapid.processing.util.Constants.SCB_ALL_TAB;
import static org.capgemini.mrapid.processing.util.Constants.SCB_ALL_TAB_COLUMNS;
import static org.capgemini.mrapid.processing.util.Constants.SOURCETYPE;
import static org.capgemini.mrapid.processing.util.Constants.TABLE_NAME;
import static org.capgemini.mrapid.processing.util.Constants.UNDERSCORE;
import static org.capgemini.mrapid.processing.util.Constants.UNIONALL;

import java.sql.Timestamp;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;

import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.hive.HiveContext;
import org.capgemini.mrapid.processing.exception.ProcessException;
import org.capgemini.mrapid.processing.exception.QueryException;
import org.capgemini.mrapid.processing.metadata.MetaDataProcessor;
import org.capgemini.mrapid.processing.util.CommonUtil;

//import org.capgemini.mrapid.processing.util.Singleton;

/**
 * This class is used to execute the hive query.
 * 
 * @author ikumarav
 */
public class QueryExecutor {

	static final Logger logger = Logger.getLogger(QueryExecutor.class);

	Timestamp time_stamp = new Timestamp(System.currentTimeMillis());
	MetaDataProcessor metaDataProcessor = new MetaDataProcessor();
	CommonUtil commonUtil = new CommonUtil();
	private String systemName;
	private String countryCode;

	public QueryExecutor(String systemName, String countryName,
			String partitionName) {
		this.systemName = systemName;
		this.countryCode = countryName;
	}

	public boolean tableRefresh(String tableName, HiveContext hiveContext,
			SparkConf prop) throws QueryException {
		logger.info("Repair table for rerun proces method");
		String snapshotDatabase = prop.get("spark.processedDatabase");
		Boolean refreshStatus = false;
		try {

			tableName = systemName + UNDERSCORE + countryCode + UNDERSCORE
					+ tableName;
			String query = "msck repair table " + snapshotDatabase + DOT
					+ tableName;

			logger.info("Executing Query for getting latest partitions :->"
					+ query);
			getListFromQuery(hiveContext, query);
			refreshStatus = true;

		} catch (Exception e) {
			throw new QueryException(e.getMessage());
		}
		return refreshStatus;

	}

	public List<Row> getAllLatestpartitions(String partitiondate,
			HiveContext hiveContext, SparkConf prop) throws QueryException {
		logger.info("Getting latest partitions for rerun processing method");
		List<Row> partitions = new ArrayList<Row>();
		String commonDatabase = prop.get("spark.commonDatabase");
		String cdc_eod_Marker = prop.get("spark.cdc_eod_marker");
		try {

			String query = "select " + PART_ODS + " from " + commonDatabase
					+ DOT + systemName + UNDERSCORE + countryCode + UNDERSCORE
					+ cdc_eod_Marker + " where " + PART_ODS + GREATERTHNEQ
					+ " '" + partitiondate + "' order by " + PART_ODS + " asc";

			logger.info("Executing Query for getting latest partitions :->"
					+ query);
			partitions = getListFromQuery(hiveContext, query);

		} catch (Exception e) {
			throw new QueryException(e.getMessage());
		}
		return partitions;

	}

	public List<Row> getPartition(String partitiondate,
			HiveContext hiveContext, SparkConf prop) throws QueryException {
		logger.info("Getting partition date for rerun processing method");
		List<Row> partitions = new ArrayList<Row>();
		String commonDatabase = prop.get("spark.commonDatabase");
		String cdc_eod_Marker = prop.get("spark.cdc_eod_marker");
		try {

			String query = "select " + PART_ODS + " from " + commonDatabase
					+ DOT + systemName + UNDERSCORE + countryCode + UNDERSCORE
					+ cdc_eod_Marker + " where " + PART_ODS + EQUAL_SIGN + " '"
					+ partitiondate + "' ";

			logger.info("Executing Query for getting latest partitions :->"
					+ query);
			partitions = getListFromQuery(hiveContext, query);

		} catch (Exception e) {
			throw new QueryException(e.getMessage());
		}
		return partitions;

	}

	public List<Row> getTypeForTable(String tableName, HiveContext hiveContext,
			SparkConf prop) throws QueryException {
		logger.info("Getting sourceType for rerun processing method");
		List<Row> sourceType = new ArrayList<Row>();
		String commonDatabase = prop.get("spark.commonDatabase");
		try {
			String query = "select " + SOURCETYPE + " from " + commonDatabase
					+ DOT + systemName + UNDERSCORE + SCB_ALL_TAB + " where "
					+ COUNTRY_NAME + EQUAL_SIGN + "'"
					+ countryCode.toUpperCase() + "' and table_name"
					+ EQUAL_SIGN + "'" + tableName.toUpperCase() + "'";
			sourceType = getListFromQuery(hiveContext, query);
		} catch (Exception e) {
			throw new QueryException(e.getMessage());
		}
		return sourceType;
	}

	public List<Row> getPreviousDayPartitions(String partitionDate,
			HiveContext hiveContext, SparkConf prop) throws QueryException {
		logger.info("inside the get Previous Day Partitions method");
		List<Row> partitions = new ArrayList<Row>();
		String commonDatabase = prop.get("spark.commonDatabase");
		String cdc_eod_Marker = prop.get("spark.cdc_eod_marker");

		try {
			String query = "select distinct " + PART_ODS + " from "
					+ commonDatabase + DOT + systemName + UNDERSCORE
					+ countryCode + UNDERSCORE + cdc_eod_Marker + " where "
					+ PART_ODS + LESSTHNEQ + " '" + partitionDate
					+ "' order by " + PART_ODS + " desc limit 2";
			logger.info("Executing Query for getting current two partitions:->"
					+ query);
			partitions = getListFromQuery(hiveContext, query);
		} catch (Exception e) {
			throw new QueryException(e.getMessage());
		}
		return partitions;

	}

	/**
	 * This method is used to get the tables with columns.
	 * 
	 * @param columns
	 *            : one or more columns with comma separated
	 * @return List<Row> List of tables.
	 * @throws QueryException
	 */
	public Map<String, String> executeQueryForTableList(String columns,
			String countryName, HiveContext hiveContext, SparkConf prop,
			String partitionDate) throws QueryException {
		logger.info("inside the executeQueryForTableList() method");
		String query = "";
		String commonDatabase = prop.get("spark.commonDatabase");
		Map<String, String> tableNameWithSourceType = new HashMap<String, String>();
		try {

			countryName = countryName.toUpperCase();
			if (columns.length() == 0) {
				query = "select " + TABLE_NAME + " from " + commonDatabase
						+ DOT + systemName + UNDERSCORE + SCB_ALL_TAB
						+ " where " + COUNTRY_NAME + EQUAL_SIGN + "'"
						+ countryName + "'";
			} else {
				query = "select " + TABLE_NAME + "," + columns + " from "
						+ commonDatabase + DOT + systemName + UNDERSCORE
						+ SCB_ALL_TAB + " where " + COUNTRY_NAME + EQUAL_SIGN
						+ "'" + countryName + "'";
			}
			logger.info("Executing Query for getting table list:->" + query);
			List<Row> tableList = new ArrayList<Row>(getListFromQuery(
					hiveContext, query));
			for (Iterator<Row> iterator = tableList.iterator(); iterator
					.hasNext();) {
				Row row = iterator.next();
				tableNameWithSourceType.put(row.get(0).toString(), row.get(1)
						.toString());
			}
		} catch (RuntimeException runTimeException) {
			logger.error(runTimeException.getMessage());
			metaDataProcessor.processMetaData(systemName, countryName,
					partitionDate, null, FAILURE,
					runTimeException.getMessage(), PROCESS_LAYER, CDC,
					hiveContext, prop);
			String description = "Due to " + runTimeException.getMessage()
					+ CDC + " is " + FAILURE;
			commonUtil.createFileForRemedy(systemName, countryName,
					partitionDate, FD_NFD, "202", description, PROCESS_BUILD,
					prop);
			System.exit(0);
		} catch (Exception e) {
			throw new QueryException(e.getMessage());
		}
		return tableNameWithSourceType;
	}

	/**
	 * This method is used to get the list of eod dates.
	 * 
	 * @param countryCode
	 *            : Cannot be null
	 * @param partitionDate
	 *            : Cannot be null
	 * @return List of EodDate
	 * @throws QueryException
	 */

	public List<Row> getEodDate(String countryCode, String partitionDate,
			HiveContext hiveContext, SparkConf prop) throws QueryException,
			ProcessException {
		logger.info("inside the getEodDate() method");
		List<Row> Eod_Date = new ArrayList<Row>();
		String cdc_eod_Marker = prop.get("spark.cdc_eod_marker");
		try {
			String query = "";
			String commonDatabase = prop.get("spark.commonDatabase");
			query = "select " + EOD_DATE + COMMA + NEXT_EOD_DATE + " from "
					+ commonDatabase + DOT + systemName + UNDERSCORE
					+ countryCode + UNDERSCORE + cdc_eod_Marker + " where "
					+ PART_ODS + EQUAL_SIGN + "'" + partitionDate + "'";
			logger.info("Executing Query for getting EOD_DATE and NEXT_EOD_DATE:->"
					+ query);
			Eod_Date = getListFromQuery(hiveContext, query);
			if (Eod_Date == null || Eod_Date.isEmpty()) {
				logger.error("Either Eod_Date or Next_Eod_Date is null");
				throw new ProcessException(
						"Either Eod_Date or Next_Eod_Date is null");

			}

		} catch (RuntimeException runTimeException) {
			logger.error(runTimeException.getMessage());
			metaDataProcessor.processMetaData(systemName, countryCode,
					partitionDate, null, FAILURE,
					runTimeException.getMessage(), PROCESS_LAYER, CDC,
					hiveContext, prop);
			String description = "Due to " + runTimeException.getMessage()
					+ CDC + " is " + FAILURE;
			commonUtil.createFileForRemedy(systemName, countryCode,
					partitionDate, FD_NFD, "202", description, PROCESS_BUILD,
					prop);
			System.exit(0);
		} catch (Exception e) {
			throw new QueryException(e.getMessage());
		}
		return Eod_Date;

	}

	/**
	 * This method is used to get the list of latest partitions.
	 * 
	 * @param countryCode
	 *            : Cannot be null
	 * @return List of latest partition
	 * @throws QueryException
	 */

	public List<Row> getLatestPartitions(String countryCode,
			HiveContext hiveContext, SparkConf prop, String partitionDate)
			throws QueryException {
		logger.info("inside the getLatestPartitions() method");
		List<Row> dt = new ArrayList<Row>();
		String cdc_eod_Marker = prop.get("spark.cdc_eod_marker");

		String query = "";
		String commonDatabase = prop.get("spark.commonDatabase");
		try {
			query = "select distinct " + PART_ODS + " from " + commonDatabase
					+ DOT + systemName + UNDERSCORE + countryCode + UNDERSCORE
					+ cdc_eod_Marker + " order by " + PART_ODS
					+ " desc limit 2";
			logger.info("Executing Query for getting current two partitions:->"
					+ query);
			dt = getListFromQuery(hiveContext, query);
		} catch (RuntimeException runTimeException) {
			logger.error(runTimeException.getMessage());
			metaDataProcessor.processMetaData(systemName, countryCode,
					partitionDate, null, FAILURE,
					runTimeException.getMessage(), PROCESS_LAYER, CDC,
					hiveContext, prop);
			String description = "Due to " + runTimeException.getMessage()
					+ CDC + " is " + FAILURE;
			commonUtil.createFileForRemedy(systemName, countryCode,
					partitionDate, FD_NFD, "202", description, PROCESS_BUILD,
					prop);
			System.exit(0);
		} catch (Exception e) {
			throw new QueryException(e.getMessage());
		}
		return dt;

	}

	/**
	 * This method is used to get the max journal time based on partitions.
	 * 
	 * @param countryCode
	 *            : cannot be null
	 * @param currentAndPrevDaysPartitions
	 *            : Cannot be null
	 * @return List of max journal time
	 * @throws ProcessException
	 * @throws QueryException
	 */

	public List<Row> getJournalTime(String countryCode,
			List<Row> currentAndPrevDaysPartitions, HiveContext hiveContext,
			SparkConf prop, String partitionDate) throws ProcessException,
			QueryException {
		logger.info("inside the getJournalTime() method");
		String cdc_eod_Marker = prop.get("spark.cdc_eod_marker");

		List<Row> eod_marker = new ArrayList<Row>();
		String query = "";
		String commonDatabase = prop.get("spark.commonDatabase");
		try {
			if (currentAndPrevDaysPartitions.size() >= 1) {

				query = "select "
						+ PART_ODS
						+ COMMA
						+ "max("
						+ C_JOURNALTIME
						+ ") from "
						+ commonDatabase
						+ DOT
						+ systemName
						+ UNDERSCORE
						+ countryCode
						+ UNDERSCORE
						+ cdc_eod_Marker
						+ " where "
						+ PART_ODS
						+ " ='"
						+ ((currentAndPrevDaysPartitions.size() == 1) ? (currentAndPrevDaysPartitions
								.get(0).get(0).toString() + "'")
								: (currentAndPrevDaysPartitions.get(0).get(0)
										.toString()
										+ "' or " + PART_ODS + "='" + currentAndPrevDaysPartitions
										.get(1).get(0).toString())
										+ "'") + " group by " + PART_ODS
						+ " order by " + PART_ODS;
				logger.info("Executing Query for getting two journaltime:->"
						+ query);

				eod_marker = hiveContext.sql(query).javaRDD().collect();
				return eod_marker;
			} else {
				throw new ProcessException(
						"Either today partition or previous day partition is not available");
			}
		} catch (RuntimeException runtimeException) {
			logger.error(runtimeException.getMessage());
			metaDataProcessor.processMetaData(systemName, countryCode,
					partitionDate, null, FAILURE,
					runtimeException.getMessage(), PROCESS_LAYER, CDC,
					hiveContext, prop);
			String description = "Due to " + runtimeException.getMessage()
					+ CDC + " is " + FAILURE;
			commonUtil.createFileForRemedy(systemName, countryCode,
					partitionDate, FD_NFD, "202", description, PROCESS_BUILD,
					prop);
			System.exit(0);
		} catch (Exception e) {
			throw new QueryException(e.getMessage());
		}
		return eod_marker;
	}

	/**
	 * This method is used to get the records for CDC Incremental.
	 * 
	 * @param tableName
	 *            : Name of the table
	 * @param countryCode
	 *            : Name of the country
	 * @return DataFrame contains collections of records with I,A,B and D
	 *         combination.
	 * @throws QueryException
	 * @throws ProcessException
	 */

	public DataFrame executeQueryForIncremental(String tableName,
			String countryCode, String partitionDate, String sourceType,
			List<Row> currentAndyesterdayPartitions, List<Row> eodAndNextEod,
			List<Row> eodMarker, String columnJoins, HiveContext hiveContext,
			SparkConf prop) throws QueryException, ProcessException {
		logger.info("inside the executeQueryForIncremental() method");
		CommonUtil commonUtil = new CommonUtil();
		List<Row> list = new ArrayList<Row>();
		DataFrame records = null;
		String query = "";
		String subQuery = "";
		String cdc_eod_Marker = prop.get("spark.cdc_eod_marker");
		String Date = "";
		String nextEodDate = "";
		String eodDate = "";
		String commonDatabase = prop.get("spark.commonDatabase");
		String stagingDatabase = prop.get("spark.stagingDatabase");
		String snapshotDatabase = prop.get("spark.processedDatabase");
		try {
			if (eodAndNextEod.size() > 0 && eodAndNextEod.get(0).get(1) != null
					&& eodAndNextEod.get(0).get(0) != null) {
				nextEodDate = eodAndNextEod.get(0).get(1).toString();
				eodDate = eodAndNextEod.get(0).get(0).toString();
				if ((Date = eodAndNextEod.get(0).get(1).toString())
						.contains(":")) {
					nextEodDate = Date.split(" ")[0];
				}
				if ((Date = eodAndNextEod.get(0).get(0).toString())
						.contains(":")) {
					eodDate = Date.split(" ")[0];
				}
			}

			query = " select a." + "`" + "rowid" + "`" + COMMA + "''"
					+ "as s_startdt" + COMMA + "''" + "as s_starttime" + COMMA
					+ "'' as s_enddt" + COMMA + "'' as s_endtime" + COMMA
					+ columnJoins + " from " + stagingDatabase + DOT
					+ tableName + " a";
			subQuery = " where ("
					+ PART_ODS
					+ " ='"
					+ eodDate
					+ "'"
					+ (((nextEodDate == null) || (nextEodDate.isEmpty())) ? ""
							: " or " + PART_ODS + " ='" + nextEodDate + "'")
					+ ")"
					+ " and "
					+ C_JOURNALTIME
					+ " >= '"
					+ ((eodMarker.size() == 1) ? ("1900-01-01 00:00:00")
							: (eodMarker.get(0).get(1).toString()))
					+ "'"
					+ " and "
					+ C_JOURNALTIME
					+ " <= '"
					+ ((eodMarker.size() == 2) ? (eodMarker.get(1).get(1)
							.toString()) : (eodMarker.get(0).get(1).toString()))
					+ "'";
			query = query + subQuery;
			logger.info("Executing Query for getting data:->" + query);
			records = hiveContext.sql(query);

			if (MASTER.equalsIgnoreCase(sourceType)) {
				String date;
				String previousDate;

				String yesterdayPartition = "select " + EOD_DATE + " from "
						+ commonDatabase + DOT + systemName + UNDERSCORE
						+ countryCode + UNDERSCORE + cdc_eod_Marker + " where "
						+ NEXT_EOD_DATE + EQUAL_SIGN + "'"
						+ eodAndNextEod.get(0).get(0).toString() + "'";
				logger.info("Executing Query for getting yesterday partition from "
						+ tableName + ":->" + yesterdayPartition);
				list = getListFromQuery(hiveContext, yesterdayPartition);
				if (list.size() > 0 && list.get(0).get(0) != null) {

					if ((date = list.get(0).get(0).toString()).contains(":")) {
						previousDate = date.split(" ")[0];
					} else {
						previousDate = list.get(0).get(0).toString();
					}

					String str = "select * from " + snapshotDatabase + DOT
							+ tableName + " where " + PART_ODS + EQUAL_SIGN
							+ "'" + previousDate + "'";
					logger.info("Executing query for joining snapshot and staging"
							+ str);
					DataFrame PreviousDayProcessedData = getDataFrameFromQuery(
							hiveContext, str);

					records = records.unionAll(PreviousDayProcessedData);

				} else {
					commonUtil.createFileForRemedy(systemName, countryCode,
							partitionDate, NFD, "232",
							"Previous Day partition is missing in "
									+ cdc_eod_Marker, PROCESS_BUILD, prop);
				}
				return records;
			}
		} catch (RuntimeException runtimeException) {
			logger.error(runtimeException.getMessage());
			metaDataProcessor.processMetaData(systemName, countryCode,
					partitionDate, null, FAILURE,
					runtimeException.getMessage(), PROCESS_LAYER, CDC,
					hiveContext, prop);
			String description = "Due to " + runtimeException.getMessage()
					+ CDC + " is " + FAILURE;
			commonUtil.createFileForRemedy(systemName, countryCode,
					partitionDate, FD_NFD, "202", description, PROCESS_BUILD,
					prop);
			System.exit(0);
		} catch (Exception e) {
			throw new QueryException(e.getMessage());
		}
		return records;

	}

	/**
	 * 
	 * @param tableName
	 * @return
	 * @throws QueryException
	 */
	public String executeQueryForIncrementalBatchFile(String tableName,
			HiveContext hiveContext, SparkConf prop) throws QueryException {
		logger.info("inside the executeQueryForIncrementalBatchFile() method");
		String commonDatabase = prop.get("spark.commonDatabase");
		String stagingDatabase = prop.get("spark.stagingDatabase");
		String query = "select distinct ods from " + stagingDatabase + DOT
				+ tableName + " order by ods desc limit 2";
		logger.info("Executing Query:->" + query);
		List<Row> dt = new ArrayList<Row>();
		try {
			dt = getListFromQuery(hiveContext, query);
		} catch (Exception e) {
			e.printStackTrace();
		}

		query = "select eod_marker from " + commonDatabase
				+ ".eod_table1 where eds ='" + dt.get(0).get(0).toString()
				+ "' or eds='" + dt.get(1).get(0).toString() + "'";
		logger.info("Executing Query:->" + query);
		List<Row> eod_marker = hiveContext.sql(query).javaRDD().collect();

		query = "select * from " + stagingDatabase + DOT + tableName
				+ " where ods ='" + dt.get(0).get(0).toString() + "' or ods='"
				+ dt.get(1).get(0).toString() + "'";
		String subQuery = " and c_journaltime >= '"
				+ eod_marker.get(0).get(0).toString() + "'"
				+ "and c_journaltime <= '"
				+ eod_marker.get(1).get(0).toString() + "'";
		query = query + subQuery;
		query = query + " where c_operationtype != X";
		logger.info("Executing Query:->" + query);
		return query;
	}

	/**
	 * This method is used to get all the primaryKeys from the table.
	 * 
	 * @param tableName
	 *            : Name of the table
	 * @return List<Row> List of PrimaryKeys for the table.
	 * @throws QueryException
	 */
	public List<Row> executeQueryForPrimaryKey(String tableName,
			String countryName, HiveContext hiveContext, SparkConf prop,
			String partitionDate) throws QueryException {
		logger.info("inside the executeQueryForPrimaryKey() method");
		tableName = tableName.toUpperCase();
		countryName = countryName.toUpperCase();
		List<Row> records = new ArrayList<Row>();
		String commonDatabase = prop.get("spark.commonDatabase");
		try {
			String query = "select column_name from " + commonDatabase + DOT
					+ systemName + UNDERSCORE + SCB_ALL_TAB_COLUMNS + " where "
					+ TABLE_NAME + "='" + tableName + "' and " + COUNTRY_NAME
					+ EQUAL_SIGN + "'" + countryName + "' and "
					+ PRIMARY_KEY_COULUMN + "='Y'";
			logger.info("Executing Query:->" + query);
			records = getListFromQuery(hiveContext, query);
		} catch (RuntimeException runtimeException) {
			logger.error(runtimeException.getMessage());
			metaDataProcessor.processMetaData(systemName, countryName,
					partitionDate, null, FAILURE,
					runtimeException.getMessage(), PROCESS_LAYER, CDC,
					hiveContext, prop);
			String description = "Due to " + runtimeException.getMessage()
					+ CDC + " is " + FAILURE;
			commonUtil.createFileForRemedy(systemName, countryName,
					partitionDate, FD_NFD, "202", description, PROCESS_BUILD,
					prop);
			System.exit(0);
		} catch (Exception e) {
			throw new QueryException(e.getMessage());
		}
		return records;
	}

	/**
	 * This method is used to run the query.
	 * 
	 * @param hiveContext
	 * @param query
	 * @return
	 * @throws QueryException
	 */
	public static DataFrame getDataFrameFromQuery(HiveContext hiveContext,
			String query) throws Exception {
		logger.info("inside the getDataFrameFromQuery() method");

		try {
			DataFrame records = hiveContext.sql(query);
			return records;

		} catch (Exception e) {
			throw e;
		}
	}

	/**
	 * @param hiveContext
	 *            : HiveContext
	 * @param query
	 *            : Query to process
	 * @return : Processed query is converted to List<Row>
	 * @throws QueryException
	 */
	public static List<Row> getListFromQuery(HiveContext hiveContext,
			String query) throws Exception {
		logger.info("Inside the getListFromQuery() method");
		List<Row> records = new ArrayList<Row>();
		DataFrame dataframe;
		try {
			dataframe = hiveContext.sql(query);
			if (dataframe.take(1) != null) {
				records = dataframe.collectAsList();
			}

		} catch (NoSuchElementException noSuchElementException) {
			return records;
		} catch (Exception e) {
			throw e;
		}
		return records;
	}

	/**
	 * This method is used to generate the reconciliation query for the row
	 * count table.
	 * 
	 * @param tableList
	 * @param sourceName
	 * @param countryName
	 * @param partitionDate
	 * @param recon_count
	 * @return
	 */

	public Map<String, String> generateReconQuery(String sourceName,
			String countryName, String partitionDate,
			Map<String, String> recon_dataForDelta, HiveContext hiveContext,
			SparkConf prop) throws QueryException {
		logger.info("inside the generateReconQuery method");

		String partition = " where " + PART_ODS + " = ";
		String finString = "";
		String processedDatabase = prop.get("spark.processedDatabase");

		Set<String> tableList = recon_dataForDelta.keySet();

		Map<String, String> rowCountForDelta = new HashMap<String, String>();
		List<Row> rowCountForDeltaList = new ArrayList<Row>();
		try {
			for (Iterator<String> iterator = tableList.iterator(); iterator
					.hasNext();) {
				String tableName = iterator.next();

				String str = "select " + "\"" + tableName + "\"" + COMMA
						+ "count(1)" + " from ";
				if (iterator.hasNext()) {
					finString += str + processedDatabase + DOT + sourceName
							+ UNDERSCORE + countryName + UNDERSCORE + tableName
							+ partition + "'" + partitionDate + "'" + UNIONALL;
				} else {
					finString += str + processedDatabase + DOT + sourceName
							+ UNDERSCORE + countryName + UNDERSCORE + tableName
							+ partition + "'" + partitionDate + "'";
				}
			}
			logger.info("Executing Query for rowcount:->" + finString);
			rowCountForDeltaList = getListFromQuery(hiveContext, finString);
			for (Row row : rowCountForDeltaList) {
				if (row.get(0) != null && row.get(1) != null) {
					rowCountForDelta.put(row.get(0).toString(), row.get(1)
							.toString());
				}
			}
		} catch (Exception exception) {
			logger.error(exception.getMessage());
			metaDataProcessor.processMetaData(sourceName, countryName,
					partitionDate, recon_dataForDelta.toString(), FAILURE,
					exception.getMessage(), RECONCILIATION, RECON_DELTA,
					hiveContext, prop);
			commonUtil.createFileForRemedy(sourceName, countryName,
					partitionDate, NFD, "202",
					"Due to " + exception.getMessage()
							+ " Delta Recon Count is Failure", RECON_BUILD,
					prop);
			if (exception instanceof RuntimeException) {
				System.exit(0);
			}
			throw new QueryException(exception.getMessage());
		}
		return rowCountForDelta;
	}

	/**
	 * This method is used to generate the reconciliation query for check sum
	 * tables.
	 * 
	 * @param tableName
	 * @param partitionDate
	 * @param filePath
	 * @param countryCode
	 * @param partitionName
	 * @throws QueryException
	 */

	public Map<String, String> generateReconchksumQuery(String sourceName,
			String countryName, String partitionDate,
			Map<String, String> recon_dataForDelta, HiveContext hiveContext,
			SparkConf prop) throws QueryException {
		logger.info("inside the generateReconchksumQuery method");

		String partition = " where " + PART_ODS + " = ";
		String finalString = "";
		Set<String> tableList = recon_dataForDelta.keySet();
		String[] Checksumtot = null;
		boolean isChecksum = false;
		String tableName = "";
		Map<String, String> checksumCountForDelta = new HashMap<String, String>();
		List<Row> checksumCountForDeltaList = new ArrayList<Row>();
		String processedDatabase = prop.get("spark.processedDatabase");
		try {
			for (Iterator<String> iterator = tableList.iterator(); iterator
					.hasNext();) {
				tableName = iterator.next();
				String chksumvalues = recon_dataForDelta.get(tableName
						.toString());
				if (chksumvalues != null)
					Checksumtot = chksumvalues.split("/");

				if (Checksumtot != null && Checksumtot.length >= 2
						&& (!Checksumtot[1].toString().isEmpty())) {
					isChecksum = true;
					String str = "select " + "\"" + tableName + "\"" + COMMA
							+ "sum(" + Checksumtot[1] + ")" + " from ";

					finalString += ((finalString.equals("")) ? "" : UNIONALL)
							+ str + processedDatabase + DOT + sourceName
							+ UNDERSCORE + countryName + UNDERSCORE + tableName
							+ partition + "'" + partitionDate + "'";

				} else {
					logger.info("Reconciliation check sum  is not available for table "
							+ tableName);

				}
			}
			if (isChecksum) {
				logger.info("Executing query for Checksum" + finalString);
				checksumCountForDeltaList = getListFromQuery(hiveContext,
						finalString);
				for (Row row : checksumCountForDeltaList) {
					if (row.get(0) != null) {
						checksumCountForDelta
								.put(row.get(0).toString(),
										(row.get(1) == null) ? null : row
												.get(1).toString());
					}
				}
			}
		} catch (Exception exception) {
			logger.error(exception.getMessage());
			metaDataProcessor.processMetaData(sourceName, countryName,
					partitionDate, recon_dataForDelta.toString(), FAILURE,
					exception.getMessage(), RECONCILIATION, RECON_DELTA,
					hiveContext, prop);
			commonUtil.createFileForRemedy(sourceName, countryName,
					partitionDate, NFD, "202",
					"Due to " + exception.getMessage()
							+ " Delta Recon Count is Failure", RECON_BUILD,
					prop);
			if (exception instanceof RuntimeException) {
				System.exit(0);
			}
			throw new QueryException(exception.getMessage());
		}
		return checksumCountForDelta;
	}

	/**
	 * This method is used to generate the reconciliation count for the
	 * Transaction table.
	 * 
	 * @param tableList
	 * @param sourceName
	 * @param countryName
	 * @param partitionDate
	 * @param recon_count
	 * @return
	 * @throws ProcessException
	 */
	/*
	 * public String generateTranReconQuery(String sourceName, String
	 * countryName, String partitionDate, Map<String, String>
	 * recon_dataForTransaction, HiveContext hiveContext, SparkConf prop) throws
	 * QueryException, ProcessException {
	 * logger.info("inside the generateTranReconQuery method"); String partition
	 * = PART_ODS + " = " + "'" + partitionDate + "'"; String finString = "";
	 * String[] recon_fields = null; Set<String> tableList =
	 * recon_dataForTransaction.keySet(); String processedDatabase =
	 * prop.get("spark.processedDatabase"); try { for (Iterator<String> iterator
	 * = tableList.iterator(); iterator .hasNext();) { String tableName =
	 * iterator.next(); String field = recon_dataForTransaction.get(tableName);
	 * if (field != null) recon_fields = field.split("/"); String rowQuery =
	 * null; try { rowQuery = prop.get("spark." + tableName.toUpperCase() +
	 * "_ROW"); } catch (Exception exception) { // supress } if (rowQuery !=
	 * null && recon_fields != null && recon_fields.length >= 0) { String
	 * formattedquery = MessageFormat.format(rowQuery, tableName,
	 * processedDatabase, sourceName, countryName, partition, recon_fields[0]);
	 * if (iterator.hasNext()) { finString += formattedquery + UNIONALL; } else
	 * { finString += formattedquery; } }
	 * 
	 * } logger.info("Executing query for Recon Query" + finString); } catch
	 * (Exception exception) { logger.error(exception.getMessage());
	 * metaDataProcessor.processMetaData(sourceName, countryName, partitionDate,
	 * recon_dataForTransaction.toString(), FAILURE, exception.getMessage(),
	 * RECONCILIATION, RECON_TRANSACTION, hiveContext, prop);
	 * commonUtil.createFileForRemedy(sourceName, countryName, partitionDate,
	 * NFD, "202", "Due to " + exception.getMessage() +
	 * " Delta Recon Count is Failure", RECON_BUILD, prop); if (exception
	 * instanceof RuntimeException) { System.exit(0); } throw new
	 * QueryException(exception.getMessage()); } return finString; }
	 */

	public Map<String, String> generateTranReconQuery(String sourceName,
			String countryName, String partitionDate,
			Map<String, String> recon_dataForTransaction,
			HiveContext hiveContext, SparkConf prop) throws QueryException,
			ProcessException {
		logger.info("inside the generateTranReconQuery method");
		String partition = PART_ODS + " = " + "'" + partitionDate + "'";
		String finString = "";
		String[] recon_fields = null;
		Set<String> tableList = recon_dataForTransaction.keySet();
		String processedDatabase = prop.get("spark.processedDatabase");
		Map<String, String> rowCountForTransaction = new HashMap<String, String>();
		List<Row> rowCountForTransactionList = new ArrayList<Row>();
		try {
			for (Iterator<String> iterator = tableList.iterator(); iterator
					.hasNext();) {
				String tableName = iterator.next();
				String field = recon_dataForTransaction.get(tableName);
				if (field != null)
					recon_fields = field.split("/");
				String rowQuery = null;
				try {
					rowQuery = prop.get("spark." + tableName.toUpperCase()
							+ "_ROW");
				} catch (Exception exception) {
					// supress
				}
				if (rowQuery != null && recon_fields != null
						&& recon_fields.length >= 0) {
					String formattedquery = MessageFormat.format(rowQuery,
							tableName, processedDatabase, sourceName,
							countryName, partition, recon_fields[0]);
					if (iterator.hasNext()) {
						finString += formattedquery + UNIONALL;
					} else {
						finString += formattedquery;
					}
				}

			}// for close
			logger.info("Executing query for Recon Query" + finString);
			if (!EMPTY_STRING.equals(finString)) {

				if (finString.trim().endsWith(UNIONALL.trim())) {
					finString = finString.substring(0, finString.length() - 10);
				}
				rowCountForTransactionList = getListFromQuery(hiveContext,
						finString);
				for (Row row : rowCountForTransactionList) {
					if (row.get(0) != null && row.get(1) != null) {
						rowCountForTransaction.put(row.get(0).toString(), row
								.get(1).toString());
					}
				}
			}

		} catch (Exception exception) {
			logger.error(exception.getMessage());
			metaDataProcessor.processMetaData(sourceName, countryName,
					partitionDate, recon_dataForTransaction.toString(),
					FAILURE, exception.getMessage(), RECONCILIATION,
					RECON_TRANSACTION, hiveContext, prop);
			commonUtil.createFileForRemedy(sourceName, countryName,
					partitionDate, NFD, "202",
					"Due to " + exception.getMessage()
							+ " Delta Recon Count is Failure", RECON_BUILD,
					prop);
			if (exception instanceof RuntimeException) {
				System.exit(0);
			}
			throw new QueryException(exception.getMessage());
		}
		return rowCountForTransaction;
	}

	/**
	 * This method is used to generate the reconciliation checksum for the
	 * Transaction table.
	 * 
	 * @param tableList
	 * @param sourceName
	 * @param countryName
	 * @param partitionDate
	 * @param recon_count
	 * @return
	 */
	/*
	 * public String generateTranReconChkQuery(String sourceName, String
	 * countryName, String partitionDate, Map<String, String>
	 * recon_dataForTransaction, HiveContext hiveContext, SparkConf prop) throws
	 * QueryException, ProcessException {
	 * logger.info("inside the generateTranReconChkQuery method"); String
	 * partition = PART_ODS + " = " + "'" + partitionDate + "'"; String
	 * finString = ""; String[] recon_chksum_fields = null; Set<String>
	 * tableList = recon_dataForTransaction.keySet(); String processedDatabase =
	 * prop.get("spark.processedDatabase"); try { for (Iterator<String> iterator
	 * = tableList.iterator(); iterator .hasNext();) { String tableName =
	 * iterator.next(); String chksum_field =
	 * recon_dataForTransaction.get(tableName .toString()); String chkquery =
	 * null; try { chkquery = prop.get("spark." + tableName.toUpperCase() +
	 * "_CHK"); } catch (Exception exception) { // supress }
	 * 
	 * if (chksum_field != null) recon_chksum_fields = chksum_field.split("/");
	 * 
	 * if (chkquery != null) { String formattedchkquery =
	 * MessageFormat.format(chkquery, tableName, processedDatabase, sourceName,
	 * countryName, partition, recon_chksum_fields[0]);
	 * 
	 * if (iterator.hasNext()) { finString += formattedchkquery + UNIONALL; }
	 * else { finString += formattedchkquery; } } }
	 * logger.info("Executing query for Recon Query" + finString);
	 * 
	 * } catch (Exception exception) { logger.error(exception.getMessage());
	 * metaDataProcessor.processMetaData(sourceName, countryName, partitionDate,
	 * recon_dataForTransaction.toString(), FAILURE, exception.getMessage(),
	 * RECONCILIATION, RECON_TRANSACTION, hiveContext, prop);
	 * commonUtil.createFileForRemedy(sourceName, countryName, partitionDate,
	 * NFD, "202", "Due to " + exception.getMessage() +
	 * " Delta Recon Count is Failure", RECON_BUILD, prop); if (exception
	 * instanceof RuntimeException) { System.exit(0); } throw new
	 * QueryException(exception.getMessage()); } return finString; }
	 */

	public Map<String, String> generateTranReconChkQuery(String sourceName,
			String countryName, String partitionDate,
			Map<String, String> recon_dataForTransaction,
			HiveContext hiveContext, SparkConf prop) throws QueryException,
			ProcessException {
		logger.info("inside the generateTranReconChkQuery method");
		String partition = PART_ODS + " = " + "'" + partitionDate + "'";
		String finString = "";
		String[] recon_chksum_fields = null;
		Set<String> tableList = recon_dataForTransaction.keySet();
		String processedDatabase = prop.get("spark.processedDatabase");
		boolean isChecksum = false;
		List<Row> checksumCountForTransactionList = new ArrayList<Row>();
		Map<String, String> checksumCountForTransaction = new HashMap<String, String>();
		try {
			for (Iterator<String> iterator = tableList.iterator(); iterator
					.hasNext();) {
				String tableName = iterator.next();
				String chksum_field = recon_dataForTransaction.get(tableName
						.toString());
				String chkquery = null;
				try {
					chkquery = prop.get("spark." + tableName.toUpperCase()
							+ "_CHK");
				} catch (Exception exception) {
					// supress
				}

				if (chksum_field != null)
					recon_chksum_fields = chksum_field.split("/");

				if (chkquery != null) {
					isChecksum = true;
					String formattedchkquery = MessageFormat.format(chkquery,
							tableName, processedDatabase, sourceName,
							countryName, partition, recon_chksum_fields[0]);

					if (iterator.hasNext()) {
						finString += formattedchkquery + UNIONALL;
					} else {
						finString += formattedchkquery;
					}
				}
			}
			logger.info("Executing query for Recon Query" + finString);
			if (isChecksum) {
				logger.info("Executing query for Checksum" + finString);
				if (!EMPTY_STRING.equals(finString)) {

					if (finString.trim().endsWith(UNIONALL.trim())) {
						finString = finString.substring(0,
								finString.length() - 10);
					}
					checksumCountForTransactionList = getListFromQuery(
							hiveContext, finString);
					for (Row row : checksumCountForTransactionList) {
						if (row.get(0) != null && row.get(1) != null) {
							checksumCountForTransaction.put(row.get(0)
									.toString(), row.get(1).toString());
						}
					}
				}
			}
		} catch (Exception exception) {
			logger.error(exception.getMessage());
			metaDataProcessor.processMetaData(sourceName, countryName,
					partitionDate, recon_dataForTransaction.toString(),
					FAILURE, exception.getMessage(), RECONCILIATION,
					RECON_TRANSACTION, hiveContext, prop);
			commonUtil.createFileForRemedy(sourceName, countryName,
					partitionDate, NFD, "202",
					"Due to " + exception.getMessage()
							+ " Delta Recon Count is Failure", RECON_BUILD,
					prop);
			if (exception instanceof RuntimeException) {
				System.exit(0);
			}
			throw new QueryException(exception.getMessage());
		}
		return checksumCountForTransaction;
	}
	/**
	 * This method used to get the invalid 'A' record from invalidType table.
	 * 
	 * @param tableName
	 * @param primaryKeyList
	 * @return
	 */
	/*
	 * public static List<String> getThresholdARecord(String sourceName, String
	 * countryCode, String tableName, String partitionDate, List<Row>
	 * primaryKeyList, SparkConf prop, HiveContext hiveContext, List<Row>
	 * rowIdList) throws QueryException {
	 * 
	 * logger.info("inside the getThresholdARecord() method"); List<Row>
	 * thresholdARecord = new ArrayList<Row>(); String commonDatabase =
	 * prop.get("spark.commonDatabase"); int index = 0; int countForPrimaryKey =
	 * primaryKeyList.size(); int count = 0; Date journalTime; Date
	 * journalTimeForRowId; index = tableName.indexOf("_"); index =
	 * tableName.indexOf("_", index + 1); tableName = tableName.substring(index
	 * + 1, tableName.length() - 1); DateFormat formatter = new
	 * SimpleDateFormat("YYYY-MM-DD HH:mm:ss"); List<String> rowIdListFinal =
	 * new ArrayList<String>();
	 * 
	 * String query = "select " + DATA + COMMA + ROW_ID + " from" +
	 * commonDatabase + DOT + sourceName + UNDERSCORE + countryCode + UNDERSCORE
	 * + INVALID_TYPES + " where " + PART_ODS + EQUAL_SIGN + partitionDate + AND
	 * + TABLE_NAME + EQUAL_SIGN + tableName;
	 * 
	 * thresholdARecord = getListFromQuery(hiveContext, query);
	 * System.out.println("thresholdARecord" + thresholdARecord); for (Row row :
	 * thresholdARecord) { String record = row.get(0).toString();
	 * System.out.println("record" + record); String[] recordArray =
	 * record.split("\u0001"); System.out.println("recordArray" + recordArray);
	 * if (recordArray[2].equalsIgnoreCase("A")) { for (int i = 0; i <
	 * primaryKeyList.size(); i++) { if (record.contains((rowIdList.get(2 +
	 * i)).toString())) { count++; } } if (count == countForPrimaryKey) { try {
	 * journalTime = formatter.parse(recordArray[0]);
	 * System.out.println("journalTime" + journalTime); journalTimeForRowId =
	 * formatter.parse(rowIdList.get(1) .toString());
	 * System.out.println("journalTimeForRowId" + journalTimeForRowId); if
	 * (journalTime.after(journalTimeForRowId)) {
	 * rowIdListFinal.add(row.get(1).toString()); } } catch (ParseException e) {
	 * e.printStackTrace(); } } } } System.out.println("rowIdListFinal" +
	 * rowIdListFinal); return rowIdListFinal; }
	 */

}