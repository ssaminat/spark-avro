package org.capgemini.mrapid.processing.api;

import java.util.List;
import java.util.Map;

import org.apache.spark.SparkConf;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.hive.HiveContext;
import org.capgemini.mrapid.processing.exception.ProcessException;
import org.capgemini.mrapid.processing.exception.QueryException;

/**
 * EodReconProcessor interface contains functionalities for EOD Reconciliation.
 * 
 * @author ikumarav
 */
public interface EodReconProcessor {

	/**
	 * To check that the row count of EOD_Recon table matches with the post
	 * process layer table row count.
	 *
	 * @param sourceName
	 * @param countryCode
	 * @param partitionDate
	 * @throws QueryException
	 */
	public boolean reconcile(String sourceName, String countryCode,
			String partitionDate, Map<String, String> recon, String startDate,
			HiveContext hiveContext, SparkConf prop,
			List<String> metaDataForRecon) throws QueryException,
			ProcessException;

	public List<Row> getReconciliation(String sourceName, String countryCode,
			String partitionDate, HiveContext hiveContext, SparkConf prop,
			List<String> metaDataForRecon);

	public List<Row> getReconciliationForReRun(String sourceName,
			String countryCode, String tableName, String partitionDate,
			HiveContext hiveContext, SparkConf prop);

}
