package org.capgemini.mrapid.processing.sourcetype.impl;

import static org.capgemini.mrapid.processing.util.Constants.AVRO;
import static org.capgemini.mrapid.processing.util.Constants.COMMA;
import static org.capgemini.mrapid.processing.util.Constants.C_JOURNALTIME;
import static org.capgemini.mrapid.processing.util.Constants.C_OPERATIONTYPE;
import static org.capgemini.mrapid.processing.util.Constants.DOT;
import static org.capgemini.mrapid.processing.util.Constants.END_DATE;
import static org.capgemini.mrapid.processing.util.Constants.END_DATETIME;
import static org.capgemini.mrapid.processing.util.Constants.EQUAL_SIGN;
import static org.capgemini.mrapid.processing.util.Constants.FAILURE;
import static org.capgemini.mrapid.processing.util.Constants.FORWARD_SLASH;
import static org.capgemini.mrapid.processing.util.Constants.NFD;
import static org.capgemini.mrapid.processing.util.Constants.PART_ODS;
import static org.capgemini.mrapid.processing.util.Constants.PROCESS_BUILD;
import static org.capgemini.mrapid.processing.util.Constants.PROCESS_LAYER;
import static org.capgemini.mrapid.processing.util.Constants.R202;
import static org.capgemini.mrapid.processing.util.Constants.UNDERSCORE;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.spark.sql.functions.*;
import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Column;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.hive.HiveContext;
import org.capgemini.mrapid.processing.api.SourceTypeProcessor;
import org.capgemini.mrapid.processing.exception.ProcessException;
import org.capgemini.mrapid.processing.exception.QueryException;
import org.capgemini.mrapid.processing.metadata.MetaDataProcessor;
import org.capgemini.mrapid.processing.sparksql.QueryExecutor;
import org.capgemini.mrapid.processing.util.CommonUtil;
import org.capgemini.mrapid.processing.util.ProcessPrimaryKeyUtil;

import scala.collection.JavaConversions;
import scala.collection.Seq;
import static org.apache.spark.sql.functions.*;




/**
 * Abstract class for source type functionalities (Incremental,Transaction and
 * Full Base).<br/>
 * 
 * @author ikumarav
 *
 */
@SuppressWarnings("serial")
public abstract class AbstractSourceTypeProcessor implements
		SourceTypeProcessor {
	final Logger logger = Logger.getLogger(this.getClass());

	/**
	 * This method implements both Delta and Transaction functionalities. <br/>
	 * 
	 * Delta: (I,A,B,D) <br/>
	 * 1. Get the records for recent two partitions and merge with previous
	 * output ORC table record. <br/>
	 * 2. Eliminate the duplicate records. <br/>
	 * 3. All the "B" records without "A", will put the entry in
	 * "DOTOPAL_DUPLICATE_PRIMARYKEYS" table. <br/>
	 * 4. Get the max journal time based on primary keys.<br/>
	 * 5. Join the two temporary tables and insert the updated records(I,A) into
	 * ORC table. <br/>
	 * 
	 * Transaction: (I,A,B) <br/>
	 * 1. Get the records for recent two partitions.<br/>
	 * 2. Eliminate the duplicate records. <br/>
	 * 3. If table has no primary key, insert the records into ORC table. 4. If
	 * table has primary key, then find the max journal time and join two
	 * tables. <br/>
	 * 5. Insert the updated records into ORC table. <br/>
	 */

	public boolean sourceTypeProcess(String sourceName, String tableName,
			String countryCode, String partitionDate, String sourceType,
			List<Row> CurrentAndpreviuosDayPartitions, List<Row> eodAndNextEod,
			List<Row> eod_marker, HiveContext hiveContext, SparkConf prop,
			Broadcast<Map<String, Iterable<String>>> columns,Broadcast<Map<String, Iterable<String>>> primaryColumns, List<String> metaDataList) {
		logger.info("Inside the AbstractSourceTypeProcessor class sourceTypeProcess() method");

		SourceTypeProcessor sourceTypeProcessor = null;
		if (this instanceof IncrementalTypeProcessor) {
			sourceTypeProcessor = (IncrementalTypeProcessor) this;
		} else if (this instanceof TransactionTypeProcessor) {
			sourceTypeProcessor = (TransactionTypeProcessor) this;
		}

		CommonUtil commonUtil = new CommonUtil();
		QueryExecutor queryExecutor = new QueryExecutor(sourceName,
				countryCode, partitionDate);
		MetaDataProcessor metaDataProcessor = new MetaDataProcessor();
		ProcessPrimaryKeyUtil primaryKey = new ProcessPrimaryKeyUtil();
		String columnNamesWithCol =null;
		String filePath = prop.get("spark.filePath");
		String columnsForDuplicate = null;
		String primaryKeyWithCommaSeperator = null;
		String primaryKeysJoins = null;
		String columnsWithCommaSeperator = null;
		String columnsWithCommaSeperatorForNoPrimaryKey = "";
		String primaryKeysColumn = null;
		String processWithAllRecords = tableName + "_tmp";
		String processWithPrimaryKey = tableName + "_primarytmp";
		String processRecordsWithoutDup = tableName + "_tmpWithoutDuplicate";
		String query = "";
		String columnJoins = "";
		String stagingDatabase = prop.get("spark.stagingDatabase");
		String processedDatabase = prop.get("spark.processedDatabase");
		String tableNameWithoutCountry = tableName;
		tableName = sourceName + UNDERSCORE + countryCode + UNDERSCORE
				+ tableName;

		DataFrame records = null;

		List<String> primaryKeyList = new ArrayList<String>();
		List<String> columnListWithoutDataType = new ArrayList<String>();

		String startDate = "";
		String Date = "";
		String fromTimezone = prop.get("spark.fromJournalTimeTimeZone");
		String toTimezone = prop.get("spark.toJournalTimeTimeZone");

		boolean status = true;

		try {

			if (eodAndNextEod.size() > 0 && eodAndNextEod.get(0).get(0) != null) {
				if ((Date = eodAndNextEod.get(0).get(0).toString())
						.contains(":")) {
					startDate = Date.split(" ")[0];
				} else {
					startDate = eodAndNextEod.get(0).get(0).toString();
				}
			}

			/**
			 * Getting the column names with comma separator
			 */
			
			Iterable<String> columnList = columns.value().get(tableNameWithoutCountry
					.toUpperCase());
			logger.info("columnList in query"+columnList);
			QueryExecutor processingQuery = new QueryExecutor(sourceName,
					countryCode, partitionDate);
			/*
			 * query = "show columns in " + stagingDatabase + DOT + tableName;
			 * logger.info("Executing query for getting all the columns from" +
			 * tableName + ":->" + query); columnList =
			 * QueryExecutor.getListFromQuery(hiveContext, query);
			 */columnListWithoutDataType = CommonUtil
					.getColumnListWithoutDataType(columnList);
			columnJoins = CommonUtil
					.getColumnListForJoins(columnListWithoutDataType);
			logger.info("columnJoins "+columnJoins);
			columnsWithCommaSeperator = CommonUtil
					.getColumnsWithCommaSeperator(columnListWithoutDataType);
			columnsWithCommaSeperatorForNoPrimaryKey = CommonUtil
					.getColumnsWithCommaSeperatorNoPrimaryKey(columnListWithoutDataType);
			columnsForDuplicate = CommonUtil
					.getColumnListForDuplicate(columnListWithoutDataType);
			Iterable<String> primaryColumnsList=primaryColumns.value().get(tableNameWithoutCountry.toUpperCase());
			primaryKeyList = ProcessPrimaryKeyUtil.convertIterableToList(primaryColumnsList);
			primaryKeysColumn = CommonUtil
					.getColumnsWithCommaSeperatorFornoPK(columnsWithCommaSeperator);
			primaryKeyWithCommaSeperator = primaryKey
					.getPrimaryKeyWithCommaSeperator(primaryKeyList);
			primaryKeysJoins = primaryKey.getPrimaryKeys(primaryKeyList);
			columnNamesWithCol =CommonUtil.getColumnWithCol(columnListWithoutDataType);
			List<Row> latestPartition = processingQuery.getLatestPartitions(countryCode,
					hiveContext, prop, partitionDate);

///dev/scudee/gps/hdata/gps_staging/all/gps_all_tl_mt199
			DataFrame dataframeAvro = hiveContext
					.read()
					.format(AVRO)
					.load(filePath + FORWARD_SLASH + stagingDatabase
							+ FORWARD_SLASH + countryCode + FORWARD_SLASH
							+ tableName + FORWARD_SLASH + PART_ODS + EQUAL_SIGN
							+ latestPartition.get(0).get(0) + "/*");
			logger.info("dataframeAvro");
			dataframeAvro.show();
///dev/scudee/gps/hdata/gps_snapshot/all/gps_all_tl_mt199/edmp_partitiondate=2017-02-21
			DataFrame dataframeOrc = hiveContext
					.read()
					.format("orc")
					.load(filePath + FORWARD_SLASH + processedDatabase
							+ FORWARD_SLASH + countryCode + FORWARD_SLASH
							+ tableName + FORWARD_SLASH + PART_ODS + EQUAL_SIGN
							+ latestPartition.get(1).get(0) + "/*");
			logger.info("dataframeOrc");
			DataFrame dataframeOrctemp=dataframeOrc.drop("_col1").drop("_col2").drop("_col3").drop("_col4");
			dataframeOrc.show();
			dataframeOrctemp.show();
			records = dataframeAvro.unionAll(dataframeOrctemp);
			logger.info("records");
			records.show();
			String rundate="run_date";
			String c_journaltime="c_journaltime";
			DataFrame maxDF;
			DataFrame df3 = null;
			String[] pkColumns = null;
			String c_journaltimePK="b."+c_journaltime;
			Seq<String> seqlist = scala.collection.JavaConversions.asScalaBuffer(primaryKeyList).toList().toSeq();
logger.info("primaryKeyList.size is "+primaryKeyList.size());

			switch (primaryKeyList.size()) {
			case 1:
				//maxDF = records.groupBy(primaryKeyList.get(0)).agg(max("c_journaltime").as("c_journaltime"));

				maxDF = records.groupBy(primaryKeyList.get(0)).agg(max("c_journaltime").as("c_journaltime"));
				df3=records.join(maxDF,( maxDF.col(primaryKeyList.get(0)).equalTo(records.col(primaryKeyList.get(0)))));
				break;
			case 2:
				maxDF = records.groupBy(primaryKeyList.get(0),primaryKeyList.get(1)).agg(max("c_journaltime").as("c_journaltime"));
				df3=records.join(maxDF,( maxDF.col(primaryKeyList.get(0)).equalTo(records.col(primaryKeyList.get(0)))).and(maxDF.col(primaryKeyList.get(1)).equalTo(records.col(primaryKeyList.get(1)))));
				break;
			case 3:
				maxDF = records.groupBy(primaryKeyList.get(0),primaryKeyList.get(1),primaryKeyList.get(2)).agg(max("c_journaltime").as("c_journaltime"));
				df3=records.join(maxDF,( maxDF.col(primaryKeyList.get(0)).equalTo(records.col(primaryKeyList.get(0)))).and(maxDF.col(primaryKeyList.get(1)).equalTo(records.col(primaryKeyList.get(1)))).and(maxDF.col(primaryKeyList.get(2)).equalTo(records.col(primaryKeyList.get(2)))));
				break;
			case 4:
				maxDF = records.groupBy(primaryKeyList.get(0),primaryKeyList.get(1),primaryKeyList.get(2),primaryKeyList.get(3)).agg(max("c_journaltime").as("c_journaltime"));
				df3=records.join(maxDF,( maxDF.col(primaryKeyList.get(0)).equalTo(records.col(primaryKeyList.get(0)))).and(maxDF.col(primaryKeyList.get(1)).equalTo(records.col(primaryKeyList.get(1)))).and(maxDF.col(primaryKeyList.get(2)).equalTo(records.col(primaryKeyList.get(2)))).and(maxDF.col(primaryKeyList.get(3)).equalTo(records.col(primaryKeyList.get(3)))));
				break;
			case 5:
				logger.info("inside case 5");
				maxDF = records.groupBy(primaryKeyList.get(0),primaryKeyList.get(1),primaryKeyList.get(2),primaryKeyList.get(3),primaryKeyList.get(4)).agg(max(c_journaltime).as("c_journaltime"));
				logger.info("maxDF");
				maxDF.show();
				logger.info("maxDF");
				pkColumns =new String[]{primaryKeyList.get(0).toLowerCase(),primaryKeyList.get(1).toLowerCase(),primaryKeyList.get(2).toLowerCase(),primaryKeyList.get(3).toLowerCase(),primaryKeyList.get(4).toLowerCase(),c_journaltime};
				String pkList1="b."+primaryKeyList.get(0).toLowerCase();
				String pkList2="b."+primaryKeyList.get(1).toLowerCase();
				String pkList3="b."+primaryKeyList.get(2).toLowerCase();
				String pkList4="b."+primaryKeyList.get(3).toLowerCase();
				String pkList5="b."+primaryKeyList.get(4).toLowerCase();
				logger.info("pklist :"+pkList1+":"+pkList2+":"+pkList3+":"+pkList4+":"+pkList5);
//				df3=records.join(maxDF,( maxDF.col("c_journaltime").equalTo(records.col("c_journaltime"))).and(maxDF.col(primaryKeyList.get(0)).equalTo(records.col(primaryKeyList.get(0)))).and(maxDF.col(primaryKeyList.get(1)).equalTo(records.col(primaryKeyList.get(1)))).and(maxDF.col(primaryKeyList.get(2)).equalTo(records.col(primaryKeyList.get(2)))).and(maxDF.col(primaryKeyList.get(3)).equalTo(records.col(primaryKeyList.get(3)))).and(maxDF.col(primaryKeyList.get(4)).equalTo(records.col(primaryKeyList.get(4)))));
				//logger.info(".drop(col("b."+primaryKeyList.get(0))).drop(col("b."+primaryKeyList.get(1))).drop(col("b."+primaryKeyList.get(2))).drop(col("b."+primaryKeyList.get(3))).drop(col("b."+primaryKeyList.get(4)))");
/*				df3=records.alias("a").join(maxDF.alias("b"),( maxDF.col("c_journaltime").equalTo(records.col("c_journaltime"))).and(maxDF.col(primaryKeyList.get(0)).equalTo(records.col(primaryKeyList.get(0)))).and(maxDF.col(primaryKeyList.get(1)).equalTo(records.col(primaryKeyList.get(1)))).and(maxDF.col(primaryKeyList.get(2)).equalTo(records.col(primaryKeyList.get(2)))).and(maxDF.col(primaryKeyList.get(3)).equalTo(records.col(primaryKeyList.get(3)))).and(maxDF.col(primaryKeyList.get(4)).equalTo(records.col(primaryKeyList.get(4))))).drop(col("b.c_journaltime")).drop(col("b."+primaryKeyList.get(0))).drop(col("b."+primaryKeyList.get(1))).drop(col("b."+primaryKeyList.get(2))).drop(col("b."+primaryKeyList.get(3))).drop(col("b."+primaryKeyList.get(4)));
*/				logger.info("df3");
logger.info("PK are :"+primaryKeyList.get(0)+" ; "+primaryKeyList.get(1)+" ; "+primaryKeyList.get(2)+" ; "+primaryKeyList.get(3)+" ; "+primaryKeyList.get(4)+" ; ");
df3=records.alias("a").join(maxDF.alias("b"),( maxDF.col(c_journaltime).equalTo(records.col(c_journaltime))).and(maxDF.col(primaryKeyList.get(0)).equalTo(records.col(primaryKeyList.get(0)))).and(maxDF.col(primaryKeyList.get(1)).equalTo(records.col(primaryKeyList.get(1)))).and(maxDF.col(primaryKeyList.get(2)).equalTo(records.col(primaryKeyList.get(2)))).and(maxDF.col(primaryKeyList.get(3)).equalTo(records.col(primaryKeyList.get(3)))).and(maxDF.col(primaryKeyList.get(4)).equalTo(records.col(primaryKeyList.get(4))))).drop(col(pkList1)).drop(col(pkList2)).drop(col(pkList3)).drop(col(pkList4)).drop(col(pkList5)).drop(col(c_journaltimePK));
//.drop(col("b.c_journaltime")).drop(col("b.cust_id")).drop(col("b.batch_ref")).drop(col("b.pymt_ref")).drop(col("b.country_code")).drop(col("b.city_code"));

				df3.show();
				break;

			}
			//DataFrame df4=df3.select(col("t.rowid"),col("t.msgtype"),col("t.rowid"),col("t.msgtype"),col("t.c_journaltime"),col("t.c_transactionid"),col("t.c_operationtype"),col("t.c_userid"),col("t.prdcd"),col("t.starttime"));
			//DataFrame df4=df3.selectExpr(columnNamesWithCol);
			//DataFrame df4=df3.select(columnNamesWithCol);
			DataFrame recordsWithoutX=df3.where("c_operationtype<>'D'");
			logger.info("without X:");
			recordsWithoutX.show();
			logger.info("PK columns for duplicates: "+pkColumns[0]+pkColumns[1]+pkColumns[2]+pkColumns[3]+pkColumns[4]);
			DataFrame recordsWithoutDuplicates=recordsWithoutX.dropDuplicates(pkColumns);
			recordsWithoutDuplicates.show();
			logger.info("chuma");
			recordsWithoutDuplicates.registerTempTable("processedrecords");
			
			query = " select a." + "`" + "rowid" + "`" + ", " + "'" + startDate
					+ "'" + COMMA + "from_utc_timestamp(to_utc_timestamp("
					+ "a." + C_JOURNALTIME + "," + "\"" + fromTimezone + "\""
					+ ")," + "\"" + toTimezone + "\"" + ")" + COMMA + "\""
					+ END_DATE + "\"" + COMMA + "\"" + END_DATETIME + "\""
					+ COMMA + columnJoins + " from " + "processedrecords a" ;
			String ORCPath = filePath + FORWARD_SLASH + processedDatabase
					+ FORWARD_SLASH + countryCode + FORWARD_SLASH + tableName
					+ FORWARD_SLASH + PART_ODS + EQUAL_SIGN + partitionDate;
			CommonUtil.deletePreviousPath(ORCPath);
			
			String finalQuery = "INSERT INTO " + processedDatabase + DOT
					+ tableName + " PARTITION(" + PART_ODS + "='"
					+ (startDate.equals("") ? partitionDate : startDate) + "')"
					+ query;
			QueryExecutor.getDataFrameFromQuery(hiveContext, finalQuery);

		
		} catch (Exception exception) {
			logger.error(exception.getMessage());
			status = false;
			metaDataList.add(metaDataProcessor.processMetaData(sourceName, countryCode,
					partitionDate, tableName, FAILURE, exception.getMessage(),
					PROCESS_LAYER, sourceTypeProcessor.getType(), hiveContext,
					prop));
			String description = "Due to " + exception.getMessage()
					+ sourceTypeProcessor.getType() + "table " + tableName
					+ " is " + FAILURE;
			commonUtil
					.createFileForRemedy(sourceName, countryCode,
							partitionDate, NFD, R202, description,
							PROCESS_BUILD, prop);
			if (exception instanceof RuntimeException) {
				System.exit(0);
			}

		}
		logger.info("end table");
		//hiveContext.dropTempTable(processWithAllRecords);
		//hiveContext.dropTempTable(processWithPrimaryKey);
		//hiveContext.dropTempTable(processRecordsWithoutDup);
		logger.info("end2 table");
		return status;

	}// method
}// class
