package org.capgemini.mrapid.processing.file.impl;

import static org.capgemini.mrapid.processing.util.Constants.CDC;
import static org.capgemini.mrapid.processing.util.Constants.DOT;
import static org.capgemini.mrapid.processing.util.Constants.FAILURE;
import static org.capgemini.mrapid.processing.util.Constants.FD_NFD;
import static org.capgemini.mrapid.processing.util.Constants.MASTER;
import static org.capgemini.mrapid.processing.util.Constants.PROCESS_BUILD;
import static org.capgemini.mrapid.processing.util.Constants.PROCESS_LAYER;
import static org.capgemini.mrapid.processing.util.Constants.R202;
import static org.capgemini.mrapid.processing.util.Constants.SCB_ALL_TAB;
import static org.capgemini.mrapid.processing.util.Constants.SOURCETYPE;
import static org.capgemini.mrapid.processing.util.Constants.SUCESS;
import static org.capgemini.mrapid.processing.util.Constants.TRANSACTION;
import static org.capgemini.mrapid.processing.util.Constants.UNDERSCORE;
import static org.capgemini.mrapid.processing.util.Constants.UNIONALL;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.hive.HiveContext;
import org.capgemini.mrapid.processing.api.FileProcessor;
import org.capgemini.mrapid.processing.api.SourceTypeProcessor;
import org.capgemini.mrapid.processing.exception.ProcessException;
import org.capgemini.mrapid.processing.exception.QueryException;
import org.capgemini.mrapid.processing.factory.SourceTypeProcessorFactory;
import org.capgemini.mrapid.processing.metadata.MetaDataProcessor;
import org.capgemini.mrapid.processing.rowcounts.RowCounts;
import org.capgemini.mrapid.processing.sparksql.QueryExecutor;
import org.capgemini.mrapid.processing.util.CommonUtil;

/**
 * This class decide which process(Delta,Transaction or Full Dump) need to
 * implement for the table based on sourceType. <br/>
 * Based on hdfInput 4th argument (Y or N), decide the table need to implement
 * Full Dumb or not.<br/>
 * If hdfInput 4th argument is 'Y', then 5th hdfInput arguments is table name
 * and process the Full Dump implementations for that table. <br/>
 * If hdfInput 4th argument is 'N', then process the Delta or Transaction
 * implementations. <br/>
 * 
 * @author ikumarav
 *
 */
public class CDCFileProcessorImpl implements FileProcessor {
	final Logger logger = Logger.getLogger(this.getClass());
	public static final String CLASSNAME = "CDCFileProcessorImpl";

	RowCounts rowCount = new RowCounts();

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.capgemini.mrapid.processing.api.FileProcessor#process(java.lang.String
	 * [])
	 */
	public boolean process(String[] hdfInput, HiveContext hiveContext,JavaSparkContext JSC,
			SparkConf prop) throws ProcessException, QueryException {
		SourceTypeProcessorFactory sourceTypeProcessorFactory = new SourceTypeProcessorFactory();
		MetaDataProcessor metaDataProcessor = new MetaDataProcessor();
		Map<String, String> tableNameWithSourceType = new HashMap<String, String>();
		List<String> tableList = new ArrayList<String>();
		boolean isError = false;
		boolean status = false;
		List<Row> latestPartition = null;
		List<Row> journalTime = null;
		List<Row> eodDate = null;
		boolean fullBase = false;
		Broadcast<Map<String, Iterable<String>>> columns =null;
		Broadcast<Map<String, Iterable<String>>> primaryKeyColumnsMap =null;
		List<String> metaDateList = new ArrayList<String>();
		List<String> metaDateCdcList = new ArrayList<String>();
		String commonDatabase = prop.get("spark.commonDatabase");
		String finalQueryForMasterMetadata = "";
		String finalQueryForTransacttionMetadata = "";
		String finalQueryForCdcMetadata = "";
		logger.info(CLASSNAME + "process method has started");

		/**
		 * hdfInput[0] : sourceName. <br/>
		 * Cannot be null <br/>
		 * hdfInput[1] : countryName. <br/>
		 * Cannot be null <br/>
		 * hdfInput[2] : partitionDate.<br/>
		 * Cannot be null <br/>
		 * hdfInput[3] : 'Y' or 'N'.<br/>
		 * hdfInput[4] : tableName.<br/>
		 * Cannot be null <br/>
		 * */

		String sourceName = hdfInput[0];
		String countryCode = hdfInput[1];
		String partitionDate = hdfInput[2];
		// String isFullBase = hdfInput[3];

		QueryExecutor processingQuery = new QueryExecutor(sourceName,
				countryCode, partitionDate);
		CommonUtil commonUtil = new CommonUtil();
		/*
		 * Check the hdfinput 4th argument is 'Y' or 'N'. <br/> If it is
		 * 'Y',create the FullBaseTypeProcessor object and call the
		 * sourceTypeProcess() method.
		 */

		/*
		 * if ("Y".equalsIgnoreCase(isFullBase)) {
		 * 
		 * String tableNameForFullBase = hdfInput[4].toLowerCase(); List<String>
		 * tableListForFullBase = new ArrayList<String>(); fullBase = true;
		 * tableListForFullBase.add(tableNameForFullBase);
		 * 
		 * logger.info("This table " + tableNameForFullBase +
		 * " needs to implement the Fullbase process");
		 * 
		 * FullBaseTypeProcessor fullBaseTypeProcessor = new
		 * FullBaseTypeProcessor(); eodDate =
		 * processingQuery.getEodDate(countryCode, partitionDate); status =
		 * fullBaseTypeProcessor.sourceTypeProcess(sourceName,
		 * tableNameForFullBase, countryCode, partitionDate, latestPartition,
		 * eodDate, journalTime);
		 * 
		 * rowCount.rowCount(sourceName, countryCode, partitionDate,
		 * tableListForFullBase, fullBase);
		 * 
		 * if (status) { metaDataProcessor.processMetaData(sourceName,
		 * countryCode, partitionDate, tableNameForFullBase, SUCESS,
		 * "Fullbase Processing is successfully completed", PROCESS_LAYER,
		 * FULLBASE); } else { metaDataProcessor.processMetaData(sourceName,
		 * countryCode, partitionDate, tableNameForFullBase, FAILURE,
		 * "Fullbase Processing is not successfully completed", PROCESS_LAYER,
		 * FULLBASE); String description = FULLBASE + "table" +
		 * tableNameForFullBase + "is" + FAILURE + "in" + PROCESS_LAYER;
		 * commonUtil.createFileForRemedy(sourceName, countryCode,
		 * partitionDate, "FD", "202", description, "process_build"); } return
		 * false; }
		 */
		// fullBase = false;
		try {

			/*
			 * tableNameWithSourceType is a map, it contains the tableName and
			 * sourceType. tableList is a list, it contains all the tableNames.
			 */

			tableNameWithSourceType = processingQuery.executeQueryForTableList(
					SOURCETYPE, countryCode, hiveContext, prop, partitionDate);
			tableList = new ArrayList<String>(tableNameWithSourceType.keySet());
			eodDate = processingQuery.getEodDate(countryCode, partitionDate,
					hiveContext, prop);
			latestPartition = processingQuery.getLatestPartitions(countryCode,
					hiveContext, prop, partitionDate);

			journalTime = processingQuery.getJournalTime(countryCode,
					latestPartition, hiveContext, prop, partitionDate);
			String filePath = prop.get("spark.filePath");
			columns=CommonUtil.getColumnsList(filePath,commonDatabase,sourceName,countryCode,JSC);
			primaryKeyColumnsMap = CommonUtil.getPrimaryColumnsList(JSC);

			logger.info("columns in cdc"+columns);

		} catch (QueryException queryException) {
			logger.error(queryException.getMessage());
			isError = true;
			metaDateCdcList.add(metaDataProcessor.processMetaData(sourceName, countryCode,
					partitionDate, null, FAILURE, queryException.getMessage(),
					PROCESS_LAYER, CDC, hiveContext, prop));
			String description = "Due to " + queryException.getMessage()
					+ PROCESS_LAYER + "is " + FAILURE;
			commonUtil.createFileForRemedy(sourceName, countryCode,
					partitionDate, FD_NFD, R202, description, PROCESS_BUILD,
					prop);

		} catch (ProcessException processException) {
			logger.error(processException.getMessage());
			isError = true;
			metaDateCdcList.add(metaDataProcessor.processMetaData(sourceName, countryCode,
					partitionDate, null, FAILURE,
					processException.getMessage(), PROCESS_LAYER, CDC,
					hiveContext, prop));
			String description = "Due to " + processException.getMessage()
					+ PROCESS_LAYER + "is " + FAILURE;
			commonUtil.createFileForRemedy(sourceName, countryCode,
					partitionDate, FD_NFD, "231", description, PROCESS_BUILD,
					prop);

		} catch (Exception exception) {
			logger.error(exception);
			isError = true;
			status = false;
			metaDateCdcList.add(metaDataProcessor.processMetaData(sourceName, countryCode,
					partitionDate, null, FAILURE, exception.getMessage(),
					PROCESS_LAYER, CDC, hiveContext, prop));
			String description = "Due to " + exception.getMessage() + CDC
					+ " is " + FAILURE;
			commonUtil.createFileForRemedy(sourceName, countryCode,
					partitionDate, FD_NFD, R202, description, PROCESS_BUILD,
					prop);
			if (exception instanceof RuntimeException) {
				System.exit(0);
			}

		}

		if (latestPartition == null || latestPartition.isEmpty()) {
			commonUtil.createFileForRemedy(sourceName, countryCode,
					partitionDate, FD_NFD, "231", "For this " + countryCode
							+ "EOD_Marker is missing", PROCESS_BUILD, prop);
		}

		if (!isError) {
			logger.info("Logging the success stage in CDC level into process metadata table");
			metaDateCdcList.add(metaDataProcessor.processMetaData(sourceName, countryCode,
					partitionDate, null, SUCESS, "CDC is successfully started",
					"Processing Layer", CDC, hiveContext, prop));
		}
		for (String tableName : tableList) {

			logger.info("Getting records from " + tableName);

			SourceTypeProcessor sourceTypeProcessor = sourceTypeProcessorFactory
					.createProcessor(tableNameWithSourceType.get(tableName));

			if (sourceTypeProcessor != null)
				status = sourceTypeProcessor.sourceTypeProcess(sourceName,
						tableName.toLowerCase(), countryCode, partitionDate,
						tableNameWithSourceType.get(tableName),
						latestPartition, eodDate, journalTime, hiveContext,
						prop, columns,primaryKeyColumnsMap,metaDateList);
			logger.info("outside STP: ");

			if (status) {
				logger.info("inside for if: ");
				metaDateList.add(metaDataProcessor.processMetaData(sourceName, countryCode,
						partitionDate, tableName, SUCESS,
						sourceTypeProcessor.getType()
								+ " is successfully completed", PROCESS_LAYER,
						sourceTypeProcessor.getType(), hiveContext, prop));
logger.info("down");
			}
			logger.info("endd");
			status = false;

		}
		try{
		for (String stringList : metaDateList) {
			logger.info(" inside metadatalist ");
			
			if ((stringList.contains(MASTER))) {

				if (metaDateList.size() == 1) {
					finalQueryForMasterMetadata = finalQueryForMasterMetadata
							+ stringList + " from " + commonDatabase + DOT
							+ sourceName + UNDERSCORE + SCB_ALL_TAB
							+ " limit 1";
				} else {
					finalQueryForMasterMetadata = finalQueryForMasterMetadata
							+ stringList + UNIONALL;
				}
			} else if (metaDateList.size() == 1) {
				finalQueryForTransacttionMetadata = finalQueryForTransacttionMetadata
						+ stringList
						+ " from "
						+ commonDatabase
						+ DOT
						+ sourceName + UNDERSCORE + SCB_ALL_TAB + " limit 1";
			} else {
				finalQueryForTransacttionMetadata = finalQueryForTransacttionMetadata
						+ stringList + UNIONALL;
			}
		}
		for (String metaEntryForCdc : metaDateCdcList) {
			if (metaDateCdcList.size() == 1) {
				finalQueryForCdcMetadata = finalQueryForCdcMetadata
						+ metaEntryForCdc + " from " + commonDatabase + DOT
						+ sourceName + UNDERSCORE + SCB_ALL_TAB + " limit 1";
			} else {
				finalQueryForCdcMetadata = finalQueryForCdcMetadata
						+ metaEntryForCdc + UNIONALL;
			}
		}

		if (!metaDateList.isEmpty()) {
			if (finalQueryForMasterMetadata.trim().endsWith(UNIONALL.trim())) {
				finalQueryForMasterMetadata = finalQueryForMasterMetadata
						.substring(0, finalQueryForMasterMetadata.length() - 10);
			}
			if (finalQueryForTransacttionMetadata.trim().endsWith(
					UNIONALL.trim())) {
				finalQueryForTransacttionMetadata = finalQueryForTransacttionMetadata
						.substring(0,
								finalQueryForTransacttionMetadata.length() - 10);
			}
		}
		if (!metaDateCdcList.isEmpty()) {
			if (finalQueryForCdcMetadata.trim().endsWith(UNIONALL.trim())) {
				finalQueryForCdcMetadata = finalQueryForMasterMetadata
						.substring(0, finalQueryForCdcMetadata.length() - 10);
			}
		}
		if (!finalQueryForCdcMetadata.isEmpty()) {
			metaDataProcessor.insertMetaData(sourceName, countryCode,
					partitionDate, PROCESS_LAYER, CDC, hiveContext, prop,
					finalQueryForCdcMetadata);
		} else {
			logger.info("Process metadata entry missing for CDC");
		}
		if (!finalQueryForMasterMetadata.isEmpty()) {
			metaDataProcessor.insertMetaData(sourceName, countryCode,
					partitionDate, PROCESS_LAYER, MASTER, hiveContext, prop,
					finalQueryForMasterMetadata);
		} else {
			logger.info("Process metadata missing for Master");
		}
		if (!finalQueryForTransacttionMetadata.isEmpty()) {
			metaDataProcessor.insertMetaData(sourceName, countryCode,
					partitionDate, PROCESS_LAYER, TRANSACTION, hiveContext,
					prop, finalQueryForTransacttionMetadata);
		} else {
			logger.info("Process metadata missing Transaction");
		}
		if (!tableList.isEmpty()) {
			rowCount.rowCount(sourceName, countryCode, partitionDate,
					tableList, fullBase, hiveContext, prop);
		}
		}
		catch(Exception e)
		{
			logger.info(" err in Processmetadata: " +e.getMessage());
		}
		primaryKeyColumnsMap.unpersist();
		primaryKeyColumnsMap.destroy();
		columns.unpersist();
		columns.destroy();
		return true;
	}

}
