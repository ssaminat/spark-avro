package org.capgemini.mrapid.processing.file.impl;

import static org.apache.spark.sql.functions.max;
import static org.capgemini.mrapid.processing.util.Constants.FORWARD_SLASH;
import static org.capgemini.mrapid.processing.util.Constants.SCB_ALL_TAB_COLUMNS;
import static org.capgemini.mrapid.processing.util.Constants.STAR;
import static org.capgemini.mrapid.processing.util.Constants.UNDERSCORE;
import scala.collection.immutable.Seq;

import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SQLContext;

import scala.Tuple2;

public class NBPFileProcessorImpl {
	final Logger logger = Logger.getLogger(this.getClass());
	static JavaRDD<String> allTablesRecords;

	public void process() {
		SparkConf prop;
		/*
		 * private static final SparkConf conf = new SparkConf() .setMaster();
		 */SparkConf conf = new SparkConf().setAppName("NBP Application")
				.setMaster("local");
		JavaSparkContext sc = new JavaSparkContext(conf);
		SQLContext hc;

		/*
		 * prop = new SparkConf().setAppName("SPARK"); sc = new
		 * JavaSparkContext(prop);
		 */hc = new SQLContext(sc);
		String path = "";
		String path1 = "";
		String filePath = null;
		String commonDatabase = null;
		String sourceName = null;
		final String countryCode = null;
		JavaSparkContext JSC = null;
		Map<String, String> tablesMap =getTablesList(JSC);
		// (Map<String, Iterable<String>>) getColumnsList(filePath,
		// commonDatabase, sourceName, countryCode, JSC);
		for (String tableName : tablesMap.keySet()) {
			if (tableName.equalsIgnoreCase("TL_EOD_MARKER")) {
				continue;
			}
if("MASTER".equalsIgnoreCase(tablesMap.get(tableName)))
		{
	DataFrame dataframeavro = hc.read().format("com.databricks.spark.avro")
			.load(path);
	DataFrame dataframeavroWithoutX=dataframeavro.where("operation_type<>'X'");
	//path1-prevday ORC files(using filedate-1 or clarify
	DataFrame dataframeprevorc = hc.read().format("com.databricks.spark.avro")
			.load(path1);
	dataframeavroWithoutX.join(dataframeprevorc, (scala.collection.Seq<String>) Seq("pk","pk1"), "left_outer").agg(max("rundate").as("rundate"));
	dataframeavroWithoutX.registerTempTable("temp");
	//have to find alternate solution to write to orc
	//insert into orc
if("TRANSACTION".equalsIgnoreCase(tablesMap.get(tableName)))
{
	DataFrame dataframe = hc.read().format("com.databricks.spark.avro")
			.load(path);
	dataframe.registerTempTable("temp");
	//	DataFrame dataframeavroWithoutX=dataframeavro.where("operation_type<>'X'");

	//have to find alternate solution to write to orc
	//insert into orc
}
		}
		}
		

	}



	private scala.collection.Seq<String> Seq(String string, String string2) {
		// TODO Auto-generated method stub
		return null;
	}



	public static Map<String, String> getTablesList(
			JavaSparkContext JSC) {

		JavaRDD<String> rdd = JSC
				.textFile("hdfs://nnscbhaasdev/dev/scudee/gps/hdata/gps_dev_ops/gps_all_tables/all_all_tables_V1");
		Map<String, String> tablesMap = rdd
				.mapToPair(new PairFunction<String, String, String>() {

					public Tuple2<String, String> call(String v)
							throws Exception {
						return new Tuple2<String, String>(v.split("\u0002")[1],
								v.split("\u0002")[3]);
					}
				}).collectAsMap();
		return tablesMap;
	}

	public static Broadcast<Map<String, Iterable<String>>> getColumnsList(
			String filePath, String commonDatabase, String sourceName,
			final String countryCode, JavaSparkContext JSC) {

		String allTabColumnsPath = filePath + FORWARD_SLASH + commonDatabase
				+ FORWARD_SLASH + sourceName + UNDERSCORE + SCB_ALL_TAB_COLUMNS
				+ FORWARD_SLASH + STAR;
		allTablesRecords = JSC.textFile(allTabColumnsPath)
				.filter(new Function<String, Boolean>() {

					public Boolean call(String v1) throws Exception {

						if (v1.split("\u0002")[2].equalsIgnoreCase(countryCode)) {
							return true;
						}
						return false;
					}
				}).cache();
		JavaPairRDD<String, Iterable<String>> columnsRDD = allTablesRecords
				.mapToPair(new PairFunction<String, String, String>() {

					public Tuple2<String, String> call(String v)
							throws Exception {
						return new Tuple2<String, String>(v.split("\u0002")[0],
								v.split("\u0002")[1]);
					}
				}).groupByKey();
		Broadcast<Map<String, Iterable<String>>> columns = JSC
				.broadcast(columnsRDD.collectAsMap());
		// columns.value().get(0);
		// logger.info("columns in iterable-------->"+columns);
		return columns;

	}

	public static Broadcast<Map<String, Iterable<String>>> getPrimaryColumnsList(
			JavaSparkContext JSC) {
		JavaRDD<String> primaryKeyRecords = allTablesRecords
				.filter(new Function<String, Boolean>() {

					public Boolean call(String v1) throws Exception {
						if (v1.split("\u0002")[7].equalsIgnoreCase("Y")) {
							return true;
						}
						return false;
					}
				});
		JavaPairRDD<String, Iterable<String>> primaryKeyColumnsRDD = primaryKeyRecords
				.mapToPair(new PairFunction<String, String, String>() {

					public Tuple2<String, String> call(String v)
							throws Exception {
						return new Tuple2<String, String>(v.split("\u0002")[0],
								v.split("\u0002")[1]);
					}
				}).groupByKey();
		Broadcast<Map<String, Iterable<String>>> primaryKeyColumns = JSC
				.broadcast(primaryKeyColumnsRDD.collectAsMap());
		// logger.info("columns in iterable-------->"+primaryKeyColumns);
		return primaryKeyColumns;
	}
}
