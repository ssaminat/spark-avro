package org.capgemini.mrapid.processing.factory;

import static org.capgemini.mrapid.processing.util.Constants.MASTER;
import static org.capgemini.mrapid.processing.util.Constants.TRANSACTION;

import org.apache.log4j.Logger;
import org.capgemini.mrapid.processing.api.SourceTypeProcessor;
import org.capgemini.mrapid.processing.sourcetype.impl.IncrementalTypeProcessor;
import org.capgemini.mrapid.processing.sourcetype.impl.TransactionTypeProcessor;

/**
 * This Factory class is used to decide for which sourceType(Delta or
 * Transaction) needs to create a processor.
 * 
 * @author ikumarav
 *
 */

public class SourceTypeProcessorFactory {
	final static Logger logger = Logger
			.getLogger(SourceTypeProcessorFactory.class);

	/**
	 * This method creates a object based on sourceType.
	 * 
	 * @param sourceType
	 *            : Name of the SourceType <br/>
	 *            Cannot be null <br/>
	 * @return Object of SourceTypeProcessor
	 */
	public SourceTypeProcessor createProcessor(String sourceType) {

		if (MASTER.equalsIgnoreCase(sourceType)) {
			logger.info("Starting the Delta processing");
			return new IncrementalTypeProcessor();
		} else if (TRANSACTION.equalsIgnoreCase(sourceType)) {
			logger.info("Starting the Transactional processing");
			return new TransactionTypeProcessor();
		} else {
			return null;
		}

	}

}
