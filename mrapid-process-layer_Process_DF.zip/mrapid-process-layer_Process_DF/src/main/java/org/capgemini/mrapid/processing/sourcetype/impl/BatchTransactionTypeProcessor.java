package org.capgemini.mrapid.processing.sourcetype.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.hive.HiveContext;
import org.capgemini.mrapid.processing.api.BatchSourceTypeProcessor;
import org.capgemini.mrapid.processing.metadata.MetaDataProcessor;
import org.capgemini.mrapid.processing.sparksql.QueryExecutor;
import org.capgemini.mrapid.processing.util.CommonUtil;

import static org.capgemini.mrapid.processing.util.Constants.AVRO;
import static org.capgemini.mrapid.processing.util.Constants.FAILURE;
import static org.capgemini.mrapid.processing.util.Constants.FORWARD_SLASH;
import static org.capgemini.mrapid.processing.util.Constants.NFD;
import static org.capgemini.mrapid.processing.util.Constants.PART_ODS;
import static org.capgemini.mrapid.processing.util.Constants.EQUAL_SIGN;
import static org.capgemini.mrapid.processing.util.Constants.COMMA;
import static org.capgemini.mrapid.processing.util.Constants.C_JOURNALTIME;
import static org.capgemini.mrapid.processing.util.Constants.END_DATE;
import static org.capgemini.mrapid.processing.util.Constants.END_DATETIME;
import static org.capgemini.mrapid.processing.util.Constants.PROCESS_BUILD;
import static org.capgemini.mrapid.processing.util.Constants.PROCESS_LAYER;
import static org.capgemini.mrapid.processing.util.Constants.R202;
import static org.capgemini.mrapid.processing.util.Constants.UNDERSCORE;
import static org.capgemini.mrapid.processing.util.Constants.DOT;
public class BatchTransactionTypeProcessor extends
BatchAbstractSourceTypeProcessor{

	final Logger logger = Logger.getLogger(this.getClass());

	
	public boolean batchSourceTypeProcess(String sourceName, String tableName,
			String countryCode, String partitionDate, String sourceType,
			List<Row> CurrentAndpreviuosDayPartitions, List<Row> eodAndNextEod,
			List<Row> eod_marker, HiveContext hiveContext, SparkConf prop,
			Broadcast<Map<String, Iterable<String>>> columns,Broadcast<Map<String, Iterable<String>>> primaryColumns, List<String> metaDataList) {
		logger.info("Inside the AbstractSourceTypeProcessor class sourceTypeProcess() method");
		BatchSourceTypeProcessor sourceTypeProcessor = null;
		String filePath = prop.get("spark.filePath");
		String stagingDatabase = prop.get("spark.stagingDatabase");
		String processedDatabase = prop.get("spark.processedDatabase");
		CommonUtil commonUtil=new CommonUtil();
		MetaDataProcessor metaDataProcessor = new MetaDataProcessor();
		String startDate = "";
		String Date = "";
		String query = "";
		String columnJoins = "";
		String fromTimezone = prop.get("spark.fromJournalTimeTimeZone");
		String toTimezone = prop.get("spark.toJournalTimeTimeZone");
		String tableNameWithoutCountry = tableName;
		List<String> columnListWithoutDataType = new ArrayList<String>();
		Boolean status=true;
		tableName = sourceName + UNDERSCORE + countryCode + UNDERSCORE
				+ tableName;
		try {
		Iterable<String> columnList = columns.value().get(tableNameWithoutCountry
				.toUpperCase());
		logger.info("columnList in query"+columnList);
		columnListWithoutDataType = commonUtil
				.getColumnListWithoutDataType(columnList);
		columnJoins = commonUtil
				.getColumnListForJoins(columnListWithoutDataType);
		logger.info("columnJoins "+columnJoins);
		DataFrame dataframe = hiveContext
				.read()
				.format(AVRO)
				.load(filePath + FORWARD_SLASH + stagingDatabase
						+ FORWARD_SLASH + countryCode + FORWARD_SLASH
						+ tableName + FORWARD_SLASH + PART_ODS + EQUAL_SIGN
						+ partitionDate + "/*");
		String processWithAllRecords = tableName + "_tmp";
	dataframe.registerTempTable(processWithAllRecords);
		query = " select a." + "`" + "rowid" + "`" + COMMA + "'"
				+ partitionDate + "'" + COMMA
				+ "from_utc_timestamp(to_utc_timestamp(" + "a."
				+ C_JOURNALTIME + "," + "\"" + fromTimezone + "\"" + "),"
				+ "\"" + toTimezone + "\"" + ")" + COMMA + "\"" + END_DATE
				+ "\"" + COMMA + "\"" + END_DATETIME + "\"" + COMMA
				+ columnJoins + " from " + processWithAllRecords + " a";
		logger.info("Executing query for joining two temporary tables for"
				+ tableName + ":->" + query);
		String finalQuery = "INSERT INTO " + processedDatabase + DOT
				+ tableName + " PARTITION(" + PART_ODS + "='"
				+ partitionDate + "')" + query;
		logger.info("Executing query for inserting the records into process layer:->"
				+ finalQuery);
		
			QueryExecutor.getDataFrameFromQuery(hiveContext, finalQuery);
		} catch (Exception exception) {
			status = false;
			metaDataList.add(metaDataProcessor.processMetaData(sourceName, countryCode,
					partitionDate, tableName, FAILURE, exception.getMessage(),
					PROCESS_LAYER, sourceTypeProcessor.getType(), hiveContext,
					prop));
			String description = "Due to " + exception.getMessage()
					+ sourceTypeProcessor.getType() + "table " + tableName
					+ " is " + FAILURE;
			commonUtil
					.createFileForRemedy(sourceName, countryCode,
							partitionDate, NFD, R202, description,
							PROCESS_BUILD, prop);
			if (exception instanceof RuntimeException) {
				System.exit(0);
			}
		}
		
		hiveContext.dropTempTable("processWithAllRecords");
		return status;

	}

	public String getType() {
		return "Transaction";
	}

}
