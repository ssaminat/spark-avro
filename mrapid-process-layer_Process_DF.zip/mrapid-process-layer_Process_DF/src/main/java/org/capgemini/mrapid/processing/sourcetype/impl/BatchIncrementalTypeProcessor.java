package org.capgemini.mrapid.processing.sourcetype.impl;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.hive.HiveContext;
import org.capgemini.mrapid.processing.api.SourceTypeProcessor;

public class BatchIncrementalTypeProcessor extends BatchAbstractSourceTypeProcessor{

	final Logger logger = Logger.getLogger(this.getClass());

	public String getType() {
		return null;
	}

}
