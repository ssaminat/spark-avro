package org.capgemini.mrapid.processing.factory;

import static org.capgemini.mrapid.processing.util.Constants.MASTER;
import static org.capgemini.mrapid.processing.util.Constants.TRANSACTION;

import org.apache.log4j.Logger;
import org.capgemini.mrapid.processing.api.BatchSourceTypeProcessor;
import org.capgemini.mrapid.processing.sourcetype.impl.BatchIncrementalTypeProcessor;
import org.capgemini.mrapid.processing.sourcetype.impl.BatchTransactionTypeProcessor;

public class BatchSourceTypeProcessorFactory {
	final static Logger logger = Logger
			.getLogger(SourceTypeProcessorFactory.class);

	/**
	 * This method creates a object based on sourceType.
	 * 
	 * @param sourceType
	 *            : Name of the SourceType <br/>
	 *            Cannot be null <br/>
	 * @return Object of SourceTypeProcessor
	 */
	public BatchSourceTypeProcessor createProcessor(String sourceType) {

		if (MASTER.equalsIgnoreCase(sourceType)) {
			logger.info("Starting the Delta processing");
			return new BatchIncrementalTypeProcessor();
		} else if (TRANSACTION.equalsIgnoreCase(sourceType)) {
			logger.info("Starting the Transactional processing");
			return new BatchTransactionTypeProcessor();
		} else {
			return null;
		}

	}

}
