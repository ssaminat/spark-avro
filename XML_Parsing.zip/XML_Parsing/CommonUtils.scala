package test
import java.io.FileInputStream
import java.io._
import org.slf4j.LoggerFactory
import java.sql.Connection
import java.sql.DriverManager

class CommonUtils() {


  /**
   * Removes all non printable characters, new line, tab characters in a string
   * @param data
   * @return
   */
  def stringCleanser(data: String): String =
    {

      val cleanString = data.replaceAll("[\\t\\n\\r\\p{Cntrl}\\p{Z}\"\\P{InBasic_Latin}]", "").trim()
      cleanString

    }

}




