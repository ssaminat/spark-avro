package test

import java.io._
import scala.io._
import java.text.SimpleDateFormat
import java.util.Date
import scala.xml._

object MetaAppSample {
  def main(args: Array[String]) {
    println("sample")
    val path = new File("jeffrey_xml")
    //path.listFiles().foreach(println)
    getAttributeFromXml(path.listFiles())
  }

  def getAttributeFromXml(xmlfiles: Array[File]): Unit =
    {
      val commonUtil = new CommonUtils()
      val printWtiter1 = new PrintWriter(new FileOutputStream("Report.txt"), false)
      val tableMappingTag = "TableMapping"
      val sourceTableTag = "sourceTableName"
      val sourceColumnTag = "SourceColumn"
      val columnNameTag = "columnName"
      val dataTypeTag = "dataType"
      val pkTag = "key"
      val AT_THE_RATEOF = "@"
      val TAB_DELIMITER = "\t"

      var xmlMap = Map.empty[String, Set[String]]
      var tempcolumns = scala.collection.mutable.Set.empty[String]

      try {

        var tableMapping = NodeSeq.Empty

        xmlfiles.foreach {
          file =>
            {
              val schemaXml = XML.loadFile(file)
              val tableMapping = (schemaXml \\ "TableMapping")
              var finalColumns = Set.empty[String]
              //println(file.getName)
              
              
              tableMapping.map(tableTag => {
                tempcolumns.clear()

                ((tableTag \\ "SourceColumn").map(f => Seq(f \@ "columnName", f \@ "key")).filter(p => p(1).equalsIgnoreCase("true"))).foreach(f => {
                  //println(f(0)+":"+f(1))
                  tempcolumns += commonUtil.stringCleanser(f(0).toString()).toUpperCase()
                  finalColumns = scala.collection.immutable.Set(tempcolumns.toList: _*)
                  xmlMap += commonUtil.stringCleanser(((tableTag \@ "sourceTableName").toString())).toUpperCase() -> finalColumns

                })

              })

            }
        }
        xmlMap.foreach(p => println((p._1 + "->" + p._2.mkString(","))))

      } catch {
        case e: Throwable =>
          e.printStackTrace()
          sys.exit()
      }

    }
}